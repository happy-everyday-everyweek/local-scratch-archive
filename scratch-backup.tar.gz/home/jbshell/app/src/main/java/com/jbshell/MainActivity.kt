package com.jbshell

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var statusView: TextView
    private lateinit var input: EditText
    private lateinit var output: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var process: Process? = null
    private var kernelPath: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val pad = (16 * resources.displayMetrics.density).toInt()
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "JBShell · just-bash 内核测试"
        title.textSize = 18f
        root.addView(title)

        statusView = TextView(this)
        statusView.textSize = 12f
        root.addView(statusView)

        val grantBtn = Button(this)
        grantBtn.text = "授予『所有文件访问』权限"
        grantBtn.setOnClickListener { requestAllFilesAccess() }
        root.addView(grantBtn)

        input = EditText(this)
        input.hint = "输入命令，例如: echo hello | wc -c"
        input.setSingleLine(false)
        root.addView(
            input,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val runBtn = Button(this)
        runBtn.text = "运行"
        runBtn.setOnClickListener { runCommand() }
        row.addView(runBtn)
        val clearBtn = Button(this)
        clearBtn.text = "清屏"
        clearBtn.setOnClickListener { output.text = "" }
        row.addView(clearBtn)
        root.addView(row)

        val scroll = ScrollView(this)
        output = TextView(this)
        output.textSize = 12f
        output.gravity = Gravity.START
        scroll.addView(output)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun hasAllFilesAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
    }

    private fun refreshStatus() {
        statusView.text = if (hasAllFilesAccess()) {
            "权限：所有文件访问 ✓"
        } else {
            "权限：未授予（点上方按钮授权）"
        }
    }

    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ),
                1001
            )
        }
    }

    private fun ensureKernel(): File? {
        kernelPath?.let { if (it.exists()) return it }
        val out = File(filesDir, "jbshell")
        if (!out.exists() || out.length() == 0L) {
            try {
                assets.open("jbshell").use { ins ->
                    FileOutputStream(out).use { os -> ins.copyTo(os) }
                }
            } catch (e: Exception) {
                append("└ 内核尚未打包：等待编译清零后置入 assets/jbshell 再重装\n")
                return null
            }
        }
        out.setExecutable(true, false)
        kernelPath = out
        return out
    }

    private fun startKernel(bin: File) {
        val pb = ProcessBuilder(bin.absolutePath)
        pb.redirectErrorStream(true)
        pb.directory(filesDir)
        val p = pb.start()
        process = p
        Thread {
            try {
                val buf = ByteArray(4096)
                while (true) {
                    val n = p.inputStream.read(buf)
                    if (n <= 0) break
                    val s = String(buf, 0, n)
                    handler.post { append(s) }
                }
            } catch (_: Exception) {
            }
            handler.post { append("└ 内核进程已退出\n") }
        }.start()
    }

    private fun runCommand() {
        val line = input.text.toString()
        if (line.isBlank()) return
        append("> " + line + "\n")
        val bin = ensureKernel() ?: return
        var p = process
        if (p == null || !p.isAlive) {
            startKernel(bin)
            p = process
        }
        try {
            p!!.outputStream.write((line + "\n").toByteArray())
            p!!.outputStream.flush()
        } catch (e: Exception) {
            append("└ 写入内核失败: " + e.message + "\n")
        }
        input.setText("")
    }

    private fun append(s: String) {
        output.append(s)
    }

    override fun onDestroy() {
        super.onDestroy()
        process?.destroy()
    }
}
