package com.splitstep.app;

import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import moe.shizuku.server.IRemoteProcess;
import moe.shizuku.server.IShizukuService;
import rikka.shizuku.Shizuku;

/**
 * 通过 Shizuku 以 shell 权限执行命令。
 * 走 IShizukuService.newProcess 拿 IRemoteProcess，再经 ParcelFileDescriptor 读写子进程。
 */
public class ShizukuShell {
    private static final String TAG = "SplitStep.Shell";

    private ShizukuShell() {
    }

    public interface ResultCallback {
        void onResult(int exitCode, String stdout, String stderr);
    }

    public static void exec(String command, ResultCallback callback) {
        if (!Shizuku.pingBinder()) {
            if (callback != null) callback.onResult(-1, "", "shizuku not running");
            return;
        }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            if (callback != null) callback.onResult(-1, "", "shizuku permission not granted");
            return;
        }
        try {
            IShizukuService service = IShizukuService.Stub.asInterface(Shizuku.getBinder());
            IRemoteProcess process = service.newProcess(
                    new String[]{"sh", "-c", command}, null, null);
            int exit = process.waitFor();
            String stdout = readFd(process.getInputStream());
            String stderr = readFd(process.getErrorStream());
            if (callback != null) callback.onResult(exit, stdout, stderr);
        } catch (Throwable t) {
            Log.e(TAG, "exec error: " + command, t);
            if (callback != null) callback.onResult(-1, "", String.valueOf(t));
        }
    }

    private static String readFd(ParcelFileDescriptor pfd) {
        if (pfd == null) return "";
        StringBuilder sb = new StringBuilder();
        try (InputStream is = new FileInputStream(pfd.getFileDescriptor());
             BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            char[] buf = new char[4096];
            int n;
            while ((n = reader.read(buf)) != -1) {
                sb.append(buf, 0, n);
            }
        } catch (IOException e) {
            Log.e(TAG, "readFd error", e);
        } finally {
            try {
                pfd.close();
            } catch (IOException ignored) {
            }
        }
        return sb.toString();
    }
}