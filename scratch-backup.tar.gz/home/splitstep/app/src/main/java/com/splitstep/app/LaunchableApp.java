package com.splitstep.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** 已安装的可启动应用（含启动 Activity 组件名）。 */
public class LaunchableApp {
    public final String packageName;
    public final String activityName;
    public final String label;
    public final Drawable icon;
    public final boolean isSystem;

    public LaunchableApp(String packageName, String activityName, String label,
                         Drawable icon, boolean isSystem) {
        this.packageName = packageName;
        this.activityName = activityName;
        this.label = label;
        this.icon = icon;
        this.isSystem = isSystem;
    }

    public String getComponent() {
        return packageName + "/" + activityName;
    }

    /** 查询所有可启动应用，系统应用排后。 */
    public static List<LaunchableApp> query(Context context) {
        PackageManager pm = context.getPackageManager();
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> list = pm.queryIntentActivities(mainIntent, 0);
        List<LaunchableApp> apps = new ArrayList<>();
        for (ResolveInfo ri : list) {
            try {
                if (ri.activityInfo == null || ri.activityInfo.packageName == null) continue;
                String pkg = ri.activityInfo.packageName;
                String act = ri.activityInfo.name;
                String label = ri.loadLabel(pm) != null ? ri.loadLabel(pm).toString() : pkg;
                Drawable icon = ri.loadIcon(pm);
                boolean isSystem = (ri.activityInfo.applicationInfo.flags
                        & ApplicationInfo.FLAG_SYSTEM) != 0;
                apps.add(new LaunchableApp(pkg, act, label, icon, isSystem));
            } catch (Throwable ignored) {
            }
        }
        // 按 用户应用优先、再按 label 排序
        Collections.sort(apps, (a, b) -> {
            if (a.isSystem != b.isSystem) return a.isSystem ? 1 : -1;
            return a.label.compareToIgnoreCase(b.label);
        });
        return apps;
    }
}