package com.splitstep.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.view.View;

/**
 * 窗口框，对照 OneStep4 的 OneStepWindowView（精简版）。
 * 结构：TextureView（虚拟屏画面，黑底）+ placeholder（边框+空窗标记）。
 * 有应用时 placeholder 隐藏，空窗时显示 add 标记 58dp 居中。
 * 侧窗手势：拖拽超阈值 dismiss，未动则点击 promote，不到阈值 settle 归位。
 */
public final class SplitWindowView extends FrameLayout {
    public interface Callbacks {
        boolean isVerticalWindowLayout();
        int getSideDismissDirection();
        int getSideDismissDistancePx();
        boolean canDismissSlot(int slot);
        boolean movedPastSideDismissThreshold(float dx, float dy);
        void dismissSideWindow(int slot);
        void settleSideWindowBack(SplitWindowView windowView);
        void handleSideSlotClick(int slot);
    }

    private final Callbacks callbacks;
    private boolean mainWindow;
    private int slot = -1;
    private float sideTouchDownX;
    private float sideTouchDownY;
    private boolean sideTouchMoved;

    private final FrameLayout embeddedContainer;
    private final android.view.TextureView textureView;
    private final FrameLayout placeholder;
    private final ImageView emptyMark;
    private final VirtualDisplayController controller;
    private LaunchableApp boundApp;

    // 主窗触摸转发
    private float lastTouchX;
    private float lastTouchY;
    private boolean touchDown;

    public SplitWindowView(Context context, int slot, boolean mainWindow,
                           Drawable placeholderBorder, Callbacks callbacks,
                           VirtualDisplayController controller) {
        super(context);
        this.slot = slot;
        this.mainWindow = mainWindow;
        this.callbacks = callbacks;
        this.controller = controller;
        setClipToOutline(false);
        setClipChildren(true);
        setClipToPadding(true);
        setBackgroundColor(Color.TRANSPARENT);

        embeddedContainer = new FrameLayout(context);
        embeddedContainer.setBackgroundColor(Color.BLACK);
        embeddedContainer.setClipChildren(true);
        embeddedContainer.setClipToPadding(true);
        addView(embeddedContainer, matchFrame());

        textureView = new android.view.TextureView(context);
        textureView.setOpaque(false);
        embeddedContainer.addView(textureView, matchFrame());
        textureView.setSurfaceTextureListener(new android.view.TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                controller.createOrUpdate(new Surface(st), w, h);
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
                if (w > 0 && h > 0) {
                    controller.createOrUpdate(new Surface(st), w, h);
                }
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                controller.release();
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture st) {
            }
        });
        textureView.setOnTouchListener((v, event) -> {
            if (!mainWindow || boundApp == null || !controller.isCreated()) {
                return false;
            }
            float x = event.getX();
            float y = event.getY();
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastTouchX = x;
                    lastTouchY = y;
                    touchDown = true;
                    break;
                case MotionEvent.ACTION_UP:
                    if (!touchDown) return true;
                    touchDown = false;
                    float dx = x - lastTouchX;
                    float dy = y - lastTouchY;
                    long dt = event.getEventTime() - event.getDownTime();
                    if (dx * dx + dy * dy < 64 && dt < 500) {
                        controller.tap(x, y);
                    } else {
                        controller.swipe(lastTouchX, lastTouchY, x, y,
                                Math.max(80, Math.min(dt, 600)));
                    }
                    break;
                case MotionEvent.ACTION_CANCEL:
                    touchDown = false;
                    break;
                default:
                    break;
            }
            return true;
        });

        placeholder = new FrameLayout(context);
        placeholder.setBackground(placeholderBorder);
        placeholder.setPadding(dp(1), dp(1), dp(1), dp(1));
        placeholder.setClipChildren(true);
        placeholder.setClipToPadding(true);
        addView(placeholder, matchFrame());

        emptyMark = new ImageView(context);
        emptyMark.setImageResource(R.drawable.add);
        emptyMark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        emptyMark.setContentDescription("空窗口");
        placeholder.addView(emptyMark,
                new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER));

        applyBoundContent();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (!mainWindow && slot >= 0) {
            return handleSideWindowTouch(event);
        }
        return super.dispatchTouchEvent(event);
    }

    public int getSlot() {
        return slot;
    }

    public void setSlot(int slot) {
        this.slot = slot;
    }

    public VirtualDisplayController getController() {
        return controller;
    }

    public LaunchableApp getBoundApp() {
        return boundApp;
    }

    public void setMainWindowMode(boolean mainWindow) {
        this.mainWindow = mainWindow;
    }

    public boolean isMainWindow() {
        return mainWindow;
    }

    public void bind(LaunchableApp app, int slot) {
        this.slot = slot;
        this.boundApp = app;
        applyBoundContent();
    }

    private void applyBoundContent() {
        if (boundApp == null) {
            emptyMark.setVisibility(View.VISIBLE);
            embeddedContainer.setVisibility(View.INVISIBLE);
            placeholder.setVisibility(View.VISIBLE);
            setAlpha(1f);
            return;
        }
        emptyMark.setVisibility(View.GONE);
        placeholder.setVisibility(View.GONE);
        embeddedContainer.setVisibility(View.VISIBLE);
        setAlpha(1f);
    }

    private boolean handleSideWindowTouch(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                sideTouchDownX = event.getRawX();
                sideTouchDownY = event.getRawY();
                sideTouchMoved = false;
                animate().cancel();
                ViewParent parent = getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                updateSideWindowDrag(event);
                return true;
            case MotionEvent.ACTION_UP:
                finishSideWindowTouch(event);
                return true;
            case MotionEvent.ACTION_CANCEL:
                callbacks.settleSideWindowBack(this);
                return true;
            default:
                return true;
        }
    }

    private void updateSideWindowDrag(MotionEvent event) {
        float dx = event.getRawX() - sideTouchDownX;
        float dy = event.getRawY() - sideTouchDownY;
        float touchSlop = dp(5);
        if (dx * dx + dy * dy > touchSlop * touchSlop) {
            sideTouchMoved = true;
        }
        if (!sideTouchMoved) {
            return;
        }
        float visualOffset;
        if (callbacks.isVerticalWindowLayout()) {
            visualOffset = Math.max(0f, dy);
            setTranslationX(0f);
            setTranslationY(visualOffset);
        } else {
            int direction = callbacks.getSideDismissDirection();
            visualOffset = dx * direction > 0 ? dx : 0f;
            setTranslationX(visualOffset);
            setTranslationY(0f);
        }
        float progress = Math.min(1f,
                Math.abs(visualOffset) / Math.max(1f, callbacks.getSideDismissDistancePx()));
        setAlpha(1f - progress * 0.46f);
    }

    private void finishSideWindowTouch(MotionEvent event) {
        float dx = event.getRawX() - sideTouchDownX;
        float dy = event.getRawY() - sideTouchDownY;
        if (sideTouchMoved && callbacks.canDismissSlot(slot)
                && callbacks.movedPastSideDismissThreshold(dx, dy)) {
            callbacks.dismissSideWindow(slot);
        } else if (!sideTouchMoved) {
            performClick();
            callbacks.handleSideSlotClick(slot);
        } else {
            callbacks.settleSideWindowBack(this);
        }
    }

    public static GradientDrawable makePlaceholderBorder(Context context) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.TRANSPARENT);
        drawable.setCornerRadius(0f);
        float density = context.getResources().getDisplayMetrics().density;
        drawable.setStroke(Math.max(1, Math.round(0.5f * density)), 0x40ffffff);
        return drawable;
    }

    private FrameLayout.LayoutParams matchFrame() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}