package com.splitstep.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * SplitStep 设置（对照 OneStep4 的 OneStepSettings 默认值）。
 * 只保留与分屏相关的项：竖排/横排、侧窗数、顶栏图标缩放、侧条间距缩放、顶条留白缩放。
 */
public final class SplitSettings {
    private static final String PREFS = "splitstep";
    private static final String K_VERTICAL = "vertical_window_layout";
    private static final String K_SIDE_COUNT = "side_window_count";
    private static final String K_ICON_SCALE = "top_app_icon_scale";
    private static final String K_STRIP_SPACING_SCALE = "top_app_strip_spacing_scale";
    private static final String K_STRIP_VPADDING_SCALE = "top_app_strip_vpadding_scale";

    // 对照原版
    public static final int MIN_SIDE_WINDOWS = 3;
    public static final int DEFAULT_SIDE_WINDOWS = 3;
    public static final int MAX_SIDE_WINDOWS = 6;
    public static final int TOP_APP_ICON_SIZE_DEFAULT_DP = 46;
    public static final int TOP_APP_ICON_SCALE_DEFAULT = 100;
    public static final int TOP_APP_ICON_SCALE_MIN = 60;
    public static final int TOP_APP_ICON_SCALE_MAX = 120;
    public static final int TOP_APP_STRIP_SPACING_SCALE_DEFAULT = 100;
    public static final int TOP_APP_STRIP_SPACING_SCALE_MIN = 50;
    public static final int TOP_APP_STRIP_SPACING_SCALE_MAX = 120;
    public static final int TOP_APP_STRIP_VERTICAL_PADDING_SCALE_DEFAULT = 100;
    public static final int TOP_APP_STRIP_VERTICAL_PADDING_SCALE_MIN = 40;
    public static final int TOP_APP_STRIP_VERTICAL_PADDING_SCALE_MAX = 120;

    public final boolean verticalWindowLayout;
    public final int sideWindowCount;
    public final int topAppIconScalePct;
    public final int topAppStripSpacingScalePct;
    public final int topAppStripVerticalPaddingScalePct;

    public SplitSettings(boolean verticalWindowLayout, int sideWindowCount,
                         int topAppIconScalePct, int topAppStripSpacingScalePct,
                         int topAppStripVerticalPaddingScalePct) {
        this.verticalWindowLayout = verticalWindowLayout;
        this.sideWindowCount = clamp(sideWindowCount, MIN_SIDE_WINDOWS, MAX_SIDE_WINDOWS);
        this.topAppIconScalePct = clamp(topAppIconScalePct,
                TOP_APP_ICON_SCALE_MIN, TOP_APP_ICON_SCALE_MAX);
        this.topAppStripSpacingScalePct = clamp(topAppStripSpacingScalePct,
                TOP_APP_STRIP_SPACING_SCALE_MIN, TOP_APP_STRIP_SPACING_SCALE_MAX);
        this.topAppStripVerticalPaddingScalePct = clamp(topAppStripVerticalPaddingScalePct,
                TOP_APP_STRIP_VERTICAL_PADDING_SCALE_MIN,
                TOP_APP_STRIP_VERTICAL_PADDING_SCALE_MAX);
    }

    public static SplitSettings load(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return new SplitSettings(
                p.getBoolean(K_VERTICAL, false),
                p.getInt(K_SIDE_COUNT, DEFAULT_SIDE_WINDOWS),
                p.getInt(K_ICON_SCALE, TOP_APP_ICON_SCALE_DEFAULT),
                p.getInt(K_STRIP_SPACING_SCALE, TOP_APP_STRIP_SPACING_SCALE_DEFAULT),
                p.getInt(K_STRIP_VPADDING_SCALE, TOP_APP_STRIP_VERTICAL_PADDING_SCALE_DEFAULT));
    }

    public void save(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(K_VERTICAL, verticalWindowLayout)
                .putInt(K_SIDE_COUNT, sideWindowCount)
                .putInt(K_ICON_SCALE, topAppIconScalePct)
                .putInt(K_STRIP_SPACING_SCALE, topAppStripSpacingScalePct)
                .putInt(K_STRIP_VPADDING_SCALE, topAppStripVerticalPaddingScalePct)
                .apply();
    }

    public int getTopAppIconSizeDp() {
        return Math.max(1, Math.round(TOP_APP_ICON_SIZE_DEFAULT_DP * topAppIconScalePct / 100f));
    }

    public int getTopAppStripSidePaddingDp() {
        return Math.max(8, Math.round(16 * topAppStripSpacingScalePct / 100f));
    }

    public int getTopAppStripVerticalPaddingDp() {
        return Math.max(0, Math.round(4 * topAppStripVerticalPaddingScalePct / 100f));
    }

    /** 每个图标单元格宽度（dp），对照原版公式：iconSize+28，再按间距缩放，保底 iconSize+12 */
    public int getTopAppStripCellWidthDp(int iconSizeDp) {
        int baseWidthDp = iconSizeDp + 28;
        return Math.max(iconSizeDp + 12,
                Math.round(baseWidthDp * topAppStripSpacingScalePct / 100f));
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}