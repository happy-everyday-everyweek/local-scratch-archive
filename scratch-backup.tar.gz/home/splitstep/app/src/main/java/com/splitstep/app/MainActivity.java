package com.splitstep.app;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import rikka.shizuku.Shizuku;

/**
 * SplitStep 主界面（对照 OneStep4 的桌面结构精简版，只保留分屏）：
 *
 * - 根：FrameLayout（壁纸渐变兜底 fallback）
 * - workspace：FrameLayout，承载黑色 screenContainerBackground + 主窗/侧窗
 * - topChrome：顶部栏（导航条 + 应用条），分屏时显示，单窗时滑出隐藏
 * - 主窗 + 侧窗：WindowLayout 算矩形，200ms AccelerateDecelerate 切换动画
 * - 应用出现：0.82 缩放 240ms 放大；主窗替换：160ms 淡出；侧窗 dismiss：180ms 滑出
 * - 点应用条图标：主窗空则直接进主窗，否则进空侧窗并 promote 到主窗，全满则替换主窗
 * - 侧窗点击：与主窗交换（promote）；侧窗拖拽超 48dp dismiss
 */
public class MainActivity extends Activity {
    private static final String TAG = "SplitStep.Main";
    private static final int REQ_SHIZUKU = 1001;

    // ---- 对照 OneStep4 的动效/尺寸常量 ----
    private static final int MAX_WINDOWS = SplitSettings.MAX_SIDE_WINDOWS + 2;
    private static final int WINDOW_FRAME_SWITCH_ANIMATION_MS = 200;
    private static final int TOP_APP_REORDER_ANIMATION_MS = 220;
    private static final int SIDE_DISMISS_DISTANCE_DP = 48;
    private static final int SIDE_DISMISS_SETTLE_MS = 180;
    private static final int SIDE_SETTLE_BACK_MS = 160;
    private static final int WINDOW_SCALE_APPEAR_MS = 240;
    private static final float WINDOW_SCALE_APPEAR_START = 0.82f;
    private static final int MAIN_APP_REPLACE_FADE_OUT_MS = 160;

    private static final int TOP_NAV_VERTICAL_SPACING_DEFAULT_DP = 20;
    private static final int TOP_BAR_HEIGHT_DEFAULT_DP = 74;
    private static final int TOP_NAV_CONTENT_HEIGHT_DP = 42;
    private static final int TOP_NAV_BUTTON_SIZE_DP = 26;
    private static final int TOP_NAV_BUTTON_SPACING_DP = 8;
    private static final int TOP_NAV_ICON_SIZE_DP = 20;

    private FrameLayout rootContainer;
    private FrameLayout workspace;
    private View screenContainerBackground;

    private FrameLayout topChromeContainer;
    private LinearLayout topChromeContent;
    private HorizontalScrollView topAppStripScrollView;
    private LinearLayout topAppStripRow;
    private View topAppStripRoot;
    private final List<AppShortcutView> shortcutViews = new ArrayList<>();
    private int topAppStripOrderAnimationGeneration;

    private LinearLayout topNavLeftControls;
    private LinearLayout topNavRightControls;
    private ImageView topNavPageLeftControl;
    private ImageView topNavPageRightControl;
    private ImageView topNavExpandRightControl;

    private final LaunchableApp[] windowApps = new LaunchableApp[MAX_WINDOWS];
    private final SplitWindowView[] windowViews = new SplitWindowView[MAX_WINDOWS];
    private final VirtualDisplayController[] controllers =
            new VirtualDisplayController[MAX_WINDOWS];
    private final List<Integer> sideSlotOrder = new ArrayList<>();
    private int activeMainSlot = 0;
    private boolean mainOnLeft = true;
    private boolean multiWindowMode = false;
    private boolean verticalWindowLayout = false;
    private int sideWindowCount = SplitSettings.DEFAULT_SIDE_WINDOWS;
    private int topAppIconScalePct = SplitSettings.TOP_APP_ICON_SCALE_DEFAULT;
    private int topAppStripSpacingScalePct =
            SplitSettings.TOP_APP_STRIP_SPACING_SCALE_DEFAULT;
    private int topAppStripVerticalPaddingScalePct =
            SplitSettings.TOP_APP_STRIP_VERTICAL_PADDING_SCALE_DEFAULT;
    private int topNavVerticalMarginScalePct = 100;

    private List<LaunchableApp> apps = new ArrayList<>();
    private TextView statusText;
    private final AtomicBoolean animating = new AtomicBoolean(false);
    private int windowAnimationGeneration;

    private final SplitWindowView.Callbacks windowViewCallbacks =
            new SplitWindowView.Callbacks() {
                @Override public boolean isVerticalWindowLayout() {
                    return verticalWindowLayout;
                }

                @Override public int getSideDismissDirection() {
                    return MainActivity.this.getSideDismissDirection();
                }

                @Override public int getSideDismissDistancePx() {
                    return dp(SIDE_DISMISS_DISTANCE_DP);
                }

                @Override public boolean canDismissSlot(int slot) {
                    return slot >= 0 && slot < MAX_WINDOWS
                            && !isMainPaneSlot(slot) && windowApps[slot] != null;
                }

                @Override public boolean movedPastSideDismissThreshold(float dx, float dy) {
                    return MainActivity.this.movedPastSideDismissThreshold(dx, dy);
                }

                @Override public void dismissSideWindow(int slot) {
                    MainActivity.this.dismissSideWindow(slot);
                }

                @Override public void settleSideWindowBack(SplitWindowView windowView) {
                    MainActivity.this.settleSideWindowBack(windowView);
                }

                @Override public void handleSideSlotClick(int slot) {
                    MainActivity.this.handleSideSlotClick(slot);
                }
            };

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
            (requestCode, grantResult) -> {
                if (requestCode == REQ_SHIZUKU) {
                    boolean ok = grantResult == PackageManager.PERMISSION_GRANTED;
                    Log.i(TAG, "shizuku permission result: " + ok);
                    App.handler().post(() -> {
                        refreshApps();
                        updateStatusText();
                    });
                }
            };
    private final Shizuku.OnBinderReceivedListener binderListener = () ->
            App.handler().post(this::updateStatusText);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setFormat(PixelFormat.TRANSLUCENT);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Shizuku.addRequestPermissionResultListener(permissionListener);
        Shizuku.addBinderReceivedListenerSticky(binderListener);

        SplitSettings s = SplitSettings.load(this);
        verticalWindowLayout = s.verticalWindowLayout;
        sideWindowCount = s.sideWindowCount;
        topAppIconScalePct = s.topAppIconScalePct;
        topAppStripSpacingScalePct = s.topAppStripSpacingScalePct;
        topAppStripVerticalPaddingScalePct = s.topAppStripVerticalPaddingScalePct;

        for (int i = 0; i < MAX_WINDOWS; i++) {
            controllers[i] = new VirtualDisplayController(this, i);
        }

        setContentView(createDesktop());
        refreshApps();
        ensureShizukuPermission();
    }

    private void ensureShizukuPermission() {
        if (Shizuku.isPreV11()) {
            status("Shizuku 版本过旧");
            return;
        }
        if (Shizuku.pingBinder()) {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                refreshApps();
            } else {
                Shizuku.requestPermission(REQ_SHIZUKU);
            }
        } else {
            status("Shizuku 未运行：请先启动 Shizuku");
            Toast.makeText(this, "请先启动 Shizuku（ADB/root 方式）", Toast.LENGTH_LONG).show();
        }
        updateStatusText();
    }

    private void refreshApps() {
        apps = LaunchableApp.query(this);
        rebuildTopAppStrip();
        updateStatusText();
    }

    // ---------------- 桌面结构（对照 createDesktop） ----------------

    private View createDesktop() {
        FrameLayout root = new FrameLayout(this);
        rootContainer = root;
        root.setBackground(makeWallpaperFallback());

        workspace = new FrameLayout(this);
        workspace.setBackgroundColor(Color.TRANSPARENT);
        workspace.setClipChildren(true);
        workspace.setClipToPadding(true);
        workspace.addOnLayoutChangeListener((view, left, top, right, bottom,
                                             oldLeft, oldTop, oldRight, oldBottom) -> {
            int width = right - left;
            int height = bottom - top;
            int oldWidth = oldRight - oldLeft;
            int oldHeight = oldBottom - oldTop;
            if (oldWidth <= 0 || oldHeight <= 0
                    || width <= 0 || height <= 0
                    || (width == oldWidth && height == oldHeight)) {
                return;
            }
            view.post(() -> applyWindowLayout(false));
        });
        root.addView(workspace, matchFrame());

        screenContainerBackground = new View(this);
        screenContainerBackground.setBackgroundColor(Color.BLACK);
        workspace.addView(screenContainerBackground, matchFrame());

        topChromeContainer = new FrameLayout(this);
        topChromeContent = new LinearLayout(this);
        topChromeContent.setOrientation(LinearLayout.VERTICAL);
        topChromeContent.setPadding(0, 0, 0, 0);
        topChromeContainer.addView(topChromeContent, matchFrame());
        topChromeContent.addView(createTopNavigationBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, getTopNavHeight()));
        topChromeContent.addView(createTopAppStrip(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, getTopAppStripHeight()));
        FrameLayout.LayoutParams topChromeLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, getTopChromeHeight(), Gravity.TOP);
        root.addView(topChromeContainer, topChromeLp);

        activeMainSlot = 0;
        multiWindowMode = false;
        initializeSideSlotOrder();
        Drawable border = SplitWindowView.makePlaceholderBorder(this);
        for (int i = 0; i < MAX_WINDOWS; i++) {
            final int slot = i;
            windowViews[i] = new SplitWindowView(
                    this, i, i == activeMainSlot, border, windowViewCallbacks,
                    controllers[i]);
            windowViews[i].setOnClickListener(v -> {
                if (isMainPaneSlot(slot)) {
                    return;
                }
                handleSideSlotClick(slot);
            });
            windowViews[i].bind(null, i);
        }
        applyWindowLayout(false);
        setTopChromeVisible(false, false);

        statusText = new TextView(this);
        statusText.setTextColor(Color.WHITE);
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        statusText.setPadding(dp(12), dp(10), dp(12), dp(6));
        root.addView(statusText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START));

        return root;
    }

    private android.graphics.drawable.GradientDrawable makeWallpaperFallback() {
        return new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR, new int[]{
                        0xff9bb68a,
                        0xff78b089,
                        0xff49a6a1
                });
    }

    private void initializeSideSlotOrder() {
        sideSlotOrder.clear();
        for (int slot = 0; slot < MAX_WINDOWS; slot++) {
            if (!isMainPaneSlot(slot)) {
                sideSlotOrder.add(slot);
            }
        }
    }

    // ---------------- 顶栏（导航 + 应用条） ----------------

    private View createTopNavigationBar() {
        FrameLayout navRoot = new FrameLayout(this);
        navRoot.setBackgroundColor(Color.TRANSPARENT);
        topNavLeftControls = new LinearLayout(this);
        topNavLeftControls.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        topNavLeftControls.setPadding(dp(16), 0, 0, 0);
        FrameLayout.LayoutParams leftLp = new FrameLayout.LayoutParams(
                dp(122), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.START | Gravity.CENTER_VERTICAL);
        navRoot.addView(topNavLeftControls, leftLp);

        topNavPageLeftControl = createTopNavImageControl("top_nav_page_left", "应用列表向左");
        topNavPageLeftControl.setOnClickListener(v -> scrollTopAppStripPage(1));
        topNavPageRightControl = createTopNavImageControl("top_nav_page_right", "应用列表向右");
        topNavPageRightControl.setOnClickListener(v -> scrollTopAppStripPage(-1));
        topNavExpandRightControl = createTopNavImageControl("top_nav_expand_right", "展开");
        topNavExpandRightControl.setOnClickListener(v -> exitOneStepMode());

        TextView title = new TextView(this);
        title.setText("SplitStep");
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setTextColor(0x86ffffff);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setShadowLayer(dp(1), 0, dp(1), 0x26000000);
        setDpTextSize(title, 20);
        FrameLayout.LayoutParams titleLp = new FrameLayout.LayoutParams(
                dp(172), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        navRoot.addView(title, titleLp);

        topNavRightControls = new LinearLayout(this);
        topNavRightControls.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        topNavRightControls.setPadding(0, 0, dp(16), 0);
        FrameLayout.LayoutParams rightLp = new FrameLayout.LayoutParams(
                dp(122), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END | Gravity.CENTER_VERTICAL);
        navRoot.addView(topNavRightControls, rightLp);
        updateTopNavigationControls();

        View topLine = new View(this);
        topLine.setBackgroundColor(0x18715f53);
        navRoot.addView(topLine, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1), Gravity.TOP));
        View bottomLine = new View(this);
        bottomLine.setBackgroundColor(0x18715f53);
        navRoot.addView(bottomLine, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1), Gravity.BOTTOM));
        return navRoot;
    }

    private ImageView createTopNavImageControl(String drawableName, String description) {
        ImageView control = new ImageView(this);
        int resId = getResources().getIdentifier(
                drawableName, "drawable", getPackageName());
        Drawable src = resId != 0 ? getDrawable(resId) : null;
        if (src != null) {
            LayerDrawable icon = new LayerDrawable(new Drawable[]{src});
            icon.setLayerSize(0, dp(TOP_NAV_ICON_SIZE_DP), dp(TOP_NAV_ICON_SIZE_DP));
            icon.setLayerGravity(0, Gravity.CENTER);
            control.setImageDrawable(icon);
        } else {
            control.setImageDrawable(null);
        }
        control.setScaleType(ImageView.ScaleType.CENTER);
        control.setPadding(0, 0, 0, 0);
        control.setImageAlpha(217);
        control.setContentDescription(description);
        control.setClickable(true);
        control.setFocusable(true);
        return control;
    }

    private void updateTopNavigationControls() {
        if (topNavLeftControls == null || topNavRightControls == null
                || topNavPageLeftControl == null || topNavPageRightControl == null
                || topNavExpandRightControl == null) {
            return;
        }
        topNavLeftControls.removeAllViews();
        topNavRightControls.removeAllViews();
        addTopNavControl(topNavLeftControls, topNavPageLeftControl);
        addTopNavControl(topNavLeftControls, topNavPageRightControl);
        addTopNavControl(topNavRightControls, topNavExpandRightControl);
    }

    private void addTopNavControl(LinearLayout container, View control) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                dp(TOP_NAV_BUTTON_SIZE_DP), dp(TOP_NAV_BUTTON_SIZE_DP));
        if (container.getChildCount() > 0) {
            layoutParams.leftMargin = dp(TOP_NAV_BUTTON_SPACING_DP);
        }
        container.addView(control, layoutParams);
    }

    private void scrollTopAppStripPage(int visualDirection) {
        HorizontalScrollView scrollView = topAppStripScrollView;
        if (scrollView == null || scrollView.getChildCount() == 0
                || scrollView.getWidth() <= 0) {
            return;
        }
        int pageWidth = Math.max(1, scrollView.getWidth());
        int childWidth = scrollView.getChildAt(0).getWidth();
        int maxScrollX = Math.max(0, childWidth - scrollView.getWidth());
        int targetScrollX = scrollView.getScrollX() + visualDirection * pageWidth;
        targetScrollX = Math.max(0, Math.min(maxScrollX, targetScrollX));
        scrollView.smoothScrollTo(targetScrollX, 0);
    }

    private View createTopAppStrip() {
        FrameLayout stripRoot = new FrameLayout(this);
        topAppStripRoot = stripRoot;
        stripRoot.setBackgroundColor(Color.TRANSPARENT);
        stripRoot.setClipChildren(true);
        stripRoot.setClipToPadding(true);
        HorizontalScrollView scrollView = new HorizontalScrollView(this);
        topAppStripScrollView = scrollView;
        scrollView.setHorizontalScrollBarEnabled(false);
        scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        stripRoot.addView(scrollView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, getTopAppStripHeight(), Gravity.TOP));
        LinearLayout row = new LinearLayout(this);
        topAppStripRow = row;
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(getTopAppStripSidePaddingDp()),
                dp(getTopAppStripVerticalPaddingDp()),
                dp(getTopAppStripSidePaddingDp()),
                dp(getTopAppStripVerticalPaddingDp()));
        scrollView.addView(row, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        View bottomLine = new View(this);
        bottomLine.setBackgroundColor(Color.BLACK);
        stripRoot.addView(bottomLine, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(2), Gravity.BOTTOM));
        return stripRoot;
    }

    private void rebuildTopAppStrip() {
        if (topAppStripRow == null) return;
        topAppStripRow.removeAllViews();
        shortcutViews.clear();
        int iconSizeDp = getTopAppIconSizeDp();
        for (final LaunchableApp app : getPrioritizedApps()) {
            AppShortcutView shortcut = new AppShortcutView(this, false, iconSizeDp, 0);
            shortcut.setStatusIndicatorEnabled(true);
            shortcut.bind(app);
            shortcut.setOnClickListener(v -> addOrFocusApp(app));
            int cellWidthDp = getTopAppStripCellWidthDp(iconSizeDp);
            LinearLayout.LayoutParams shortcutLp = new LinearLayout.LayoutParams(
                    dp(cellWidthDp), ViewGroup.LayoutParams.MATCH_PARENT);
            topAppStripRow.addView(shortcut, shortcutLp);
            shortcutViews.add(shortcut);
        }
        updateShortcutAppStatuses();
    }

    private List<LaunchableApp> getPrioritizedApps() {
        Set<String> visibleKeys = getVisibleWindowAppKeys();
        List<LaunchableApp> visible = new ArrayList<>();
        List<LaunchableApp> rest = new ArrayList<>();
        for (LaunchableApp app : apps) {
            if (visibleKeys.contains(app.packageName)) {
                visible.add(app);
            } else {
                rest.add(app);
            }
        }
        List<LaunchableApp> result = new ArrayList<>(apps.size());
        result.addAll(visible);
        result.addAll(rest);
        return result;
    }

    private Set<String> getVisibleWindowAppKeys() {
        Set<String> keys = new LinkedHashSet<>();
        for (LaunchableApp app : windowApps) {
            if (app != null) keys.add(app.packageName);
        }
        return keys;
    }

    private void updateTopAppStripOrder() {
        LinearLayout row = topAppStripRow;
        if (row == null) return;
        Set<String> visibleKeys = getVisibleWindowAppKeys();
        List<String> configuredOrder = new ArrayList<>();
        for (LaunchableApp app : apps) {
            configuredOrder.add(app.packageName);
        }
        List<String> desiredOrder = prioritizeVisible(configuredOrder, visibleKeys);
        java.util.Map<String, View> viewsByKey = new java.util.HashMap<>();
        List<String> currentOrder = new ArrayList<>();
        for (int index = 0; index < row.getChildCount(); index++) {
            View child = row.getChildAt(index);
            if (!(child instanceof AppShortcutView)) continue;
            String key = ((AppShortcutView) child).getInstanceKeyValue();
            currentOrder.add(key);
            viewsByKey.put(key, child);
        }
        if (currentOrder.equals(desiredOrder)) {
            updateShortcutAppStatuses();
            return;
        }
        java.util.Map<String, Float> visualLeftByKey = new java.util.HashMap<>();
        for (java.util.Map.Entry<String, View> entry : viewsByKey.entrySet()) {
            View child = entry.getValue();
            child.animate().cancel();
            visualLeftByKey.put(entry.getKey(), child.getLeft() + child.getTranslationX());
            child.setTranslationX(0f);
        }
        HorizontalScrollView scrollView = topAppStripScrollView;
        int preservedScrollX = scrollView == null ? 0 : scrollView.getScrollX();
        int preservedScrollY = scrollView == null ? 0 : scrollView.getScrollY();
        boolean animate = row.isLaidOut() && row.getWidth() > 0 && row.isShown();
        row.removeAllViews();
        for (String key : desiredOrder) {
            View child = viewsByKey.get(key);
            if (child != null) row.addView(child);
        }
        int animationGeneration = ++topAppStripOrderAnimationGeneration;
        if (!animate) {
            if (scrollView != null) scrollView.scrollTo(preservedScrollX, preservedScrollY);
            updateShortcutAppStatuses();
            return;
        }
        row.getViewTreeObserver().addOnPreDrawListener(
                new android.view.ViewTreeObserver.OnPreDrawListener() {
                    @Override public boolean onPreDraw() {
                        android.view.ViewTreeObserver observer = row.getViewTreeObserver();
                        if (observer.isAlive()) observer.removeOnPreDrawListener(this);
                        if (animationGeneration != topAppStripOrderAnimationGeneration
                                || row != topAppStripRow) {
                            return true;
                        }
                        if (scrollView != null) {
                            scrollView.scrollTo(preservedScrollX, preservedScrollY);
                        }
                        for (int index = 0; index < row.getChildCount(); index++) {
                            View child = row.getChildAt(index);
                            if (!(child instanceof AppShortcutView)) continue;
                            String key = ((AppShortcutView) child).getInstanceKeyValue();
                            Float previousVisualLeft = visualLeftByKey.get(key);
                            if (previousVisualLeft == null) continue;
                            float startTranslation = previousVisualLeft - child.getLeft();
                            if (Math.abs(startTranslation) < 0.5f) {
                                child.setTranslationX(0f);
                                continue;
                            }
                            child.setTranslationX(startTranslation);
                            child.animate()
                                    .translationX(0f)
                                    .setDuration(TOP_APP_REORDER_ANIMATION_MS)
                                    .setInterpolator(
                                            new AccelerateDecelerateInterpolator())
                                    .start();
                        }
                        return true;
                    }
                });
        row.requestLayout();
        updateShortcutAppStatuses();
    }

    private static List<String> prioritizeVisible(List<String> orderedKeys,
                                                  Set<String> visibleKeys) {
        if (orderedKeys == null || orderedKeys.isEmpty()
                || visibleKeys == null || visibleKeys.isEmpty()) {
            return orderedKeys == null
                    ? new ArrayList<String>() : new ArrayList<>(orderedKeys);
        }
        List<String> prioritized = new ArrayList<>(orderedKeys.size());
        for (String key : orderedKeys) {
            if (visibleKeys.contains(key)) prioritized.add(key);
        }
        for (String key : orderedKeys) {
            if (!visibleKeys.contains(key)) prioritized.add(key);
        }
        return prioritized;
    }

    private void updateShortcutAppStatuses() {
        for (AppShortcutView shortcutView : shortcutViews) {
            String key = shortcutView.getInstanceKeyValue();
            boolean foreground = findSlot(key) >= 0;
            shortcutView.setActive(foreground);
            shortcutView.setAppStatus(foreground
                    ? AppShortcutView.AppStatus.FOREGROUND
                    : AppShortcutView.AppStatus.NONE);
        }
    }

    // ---------------- 窗口布局（对照 WindowLayoutCalculator 单主窗） ----------------

    private void applyWindowLayout(boolean animate) {
        applyWindowLayout(animate, null);
    }

    private void applyWindowLayout(boolean animate, Runnable onAnimationFinished) {
        if (workspace == null) return;
        if (workspace.getWidth() == 0 || workspace.getHeight() == 0) {
            workspace.post(() -> applyWindowLayout(false, onAnimationFinished));
            return;
        }
        Rect[] targetRects = calculateWindowRects();
        updateScreenContainerBackground();
        ensureWindowChildren();

        for (int slot = 0; slot < MAX_WINDOWS; slot++) {
            boolean visible = isWindowSlotEnabled(slot);
            windowViews[slot].setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
            windowViews[slot].setMainWindowMode(isMainPaneSlot(slot));
            windowViews[slot].setSlot(slot);
        }
        Runnable layoutFinished = () -> {
            applyWindowZOrder();
            updateShortcutAppStatuses();
            if (onAnimationFinished != null) onAnimationFinished.run();
        };
        if (!animate || !hasLaidOutWindowFrames()) {
            cancelWindowAnimation();
            for (int slot = 0; slot < MAX_WINDOWS; slot++) {
                setWindowFrame(windowViews[slot], targetRects[slot]);
                resetWindowTransform(windowViews[slot]);
            }
            applyWindowZOrder();
            layoutFinished.run();
            return;
        }
        animateWindowFrames(targetRects, layoutFinished);
    }

    private void ensureWindowChildren() {
        for (int slot = 0; slot < MAX_WINDOWS; slot++) {
            SplitWindowView windowView = windowViews[slot];
            if (windowView.getParent() != workspace) {
                ViewGroup parent = (ViewGroup) windowView.getParent();
                if (parent != null) parent.removeView(windowView);
                workspace.addView(windowView);
            }
        }
    }

    private void updateScreenContainerBackground() {
        if (screenContainerBackground == null) return;
        int topMargin = multiWindowMode ? getTopChromeHeight() : 0;
        FrameLayout.LayoutParams layoutParams =
                (FrameLayout.LayoutParams) screenContainerBackground.getLayoutParams();
        if (layoutParams.topMargin == topMargin) return;
        layoutParams.topMargin = topMargin;
        screenContainerBackground.setLayoutParams(layoutParams);
    }

    private Rect[] calculateWindowRects() {
        return WindowLayout.calculate(MAX_WINDOWS,
                workspace.getWidth(),
                workspace.getHeight(),
                dp(2),
                getTopChromeHeight(),
                multiWindowMode,
                verticalWindowLayout,
                activeMainSlot,
                new ArrayList<>(sideSlotOrder),
                getVisibleSideWindowCount(),
                mainOnLeft,
                dp(3));
    }

    private boolean hasLaidOutWindowFrames() {
        for (int slot = 0; slot < MAX_WINDOWS; slot++) {
            if (!isWindowSlotEnabled(slot)) continue;
            SplitWindowView windowView = windowViews[slot];
            if (windowView.getWidth() <= 0 || windowView.getHeight() <= 0) return false;
        }
        return true;
    }

    private void animateWindowFrames(Rect[] targetRects, Runnable onAnimationFinished) {
        int animationGeneration = ++windowAnimationGeneration;
        int changingWindowCount = 0;
        for (int slot = 0; slot < MAX_WINDOWS; slot++) {
            SplitWindowView windowView = windowViews[slot];
            if (windowView.getVisibility() == View.VISIBLE
                    && !getWindowFrame(windowView).equals(targetRects[slot])) {
                changingWindowCount++;
            }
        }
        if (changingWindowCount == 0) {
            for (int slot = 0; slot < MAX_WINDOWS; slot++) {
                setWindowFrame(windowViews[slot], targetRects[slot]);
                resetWindowTransform(windowViews[slot]);
            }
            applyWindowZOrder();
            if (onAnimationFinished != null) onAnimationFinished.run();
            return;
        }
        animating.set(true);
        applyWindowZOrder();
        final int[] remainingAnimations = {changingWindowCount};
        for (int slot = 0; slot < MAX_WINDOWS; slot++) {
            SplitWindowView windowView = windowViews[slot];
            windowView.animate().cancel();
            if (windowView.getVisibility() != View.VISIBLE) {
                setWindowFrame(windowView, targetRects[slot]);
                resetWindowTransform(windowView);
                continue;
            }
            Rect currentRect = getWindowFrame(windowView);
            Rect targetRect = targetRects[slot];
            if (currentRect.equals(targetRect)) {
                resetWindowTransform(windowView);
                continue;
            }
            float targetScaleX = targetRect.width() / Math.max(1f, currentRect.width());
            float targetScaleY = targetRect.height() / Math.max(1f, currentRect.height());
            configureWindowPivot(windowView, currentRect, targetRect);
            float targetTranslationX = targetRect.left - currentRect.left
                    - windowView.getPivotX() * (1f - targetScaleX);
            float targetTranslationY = targetRect.top - currentRect.top
                    - windowView.getPivotY() * (1f - targetScaleY);
            windowView.animate()
                    .translationX(targetTranslationX)
                    .translationY(targetTranslationY)
                    .scaleX(targetScaleX)
                    .scaleY(targetScaleY)
                    .setDuration(WINDOW_FRAME_SWITCH_ANIMATION_MS)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .withEndAction(() -> {
                        if (animationGeneration != windowAnimationGeneration) return;
                        remainingAnimations[0]--;
                        if (remainingAnimations[0] == 0) {
                            animating.set(false);
                            for (int s = 0; s < MAX_WINDOWS; s++) {
                                setWindowFrame(windowViews[s], targetRects[s]);
                                resetWindowTransform(windowViews[s]);
                            }
                            applyWindowZOrder();
                            if (onAnimationFinished != null) {
                                workspace.postDelayed(onAnimationFinished, 48);
                            }
                        }
                    })
                    .start();
        }
    }

    private void cancelWindowAnimation() {
        windowAnimationGeneration++;
        animating.set(false);
    }

    private boolean isWindowAnimationRunning() {
        return animating.get();
    }

    private void applyWindowZOrder() {
        for (int slot : sideSlotOrder) {
            if (!isWindowSlotEnabled(slot)) continue;
            SplitWindowView sideView = windowViews[slot];
            sideView.setElevation(0f);
            sideView.setTranslationZ(0f);
            sideView.setZ(0f);
            sideView.bringToFront();
        }
        SplitWindowView activeMainView = windowViews[activeMainSlot];
        activeMainView.setElevation(dp(8));
        activeMainView.setTranslationZ(dp(8));
        activeMainView.setZ(dp(16));
        activeMainView.bringToFront();
        if (statusText != null) statusText.bringToFront();
        workspace.invalidate();
    }

    private void configureWindowPivot(View view, Rect currentRect, Rect targetRect) {
        if (targetRect.left == 0 && currentRect.left == 0) {
            view.setPivotX(0);
        } else if (workspace != null && targetRect.right == workspace.getWidth()
                && currentRect.right == workspace.getWidth()) {
            view.setPivotX(currentRect.width());
        } else {
            view.setPivotX(currentRect.width() / 2f);
        }
        if (targetRect.top == 0 && currentRect.top == 0) {
            view.setPivotY(0);
        } else if (workspace != null && targetRect.bottom == workspace.getHeight()
                && currentRect.bottom == workspace.getHeight()) {
            view.setPivotY(currentRect.height());
        } else {
            view.setPivotY(currentRect.height() / 2f);
        }
    }

    private Rect getWindowFrame(View view) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) view.getLayoutParams();
        return new Rect(lp.leftMargin, lp.topMargin,
                lp.leftMargin + Math.max(1, lp.width),
                lp.topMargin + Math.max(1, lp.height));
    }

    private void setWindowFrame(View view, Rect rect) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) view.getLayoutParams();
        if (lp == null) {
            lp = new FrameLayout.LayoutParams(rect.width(), rect.height());
        }
        if (lp.width == rect.width() && lp.height == rect.height()
                && lp.leftMargin == rect.left && lp.topMargin == rect.top) {
            return;
        }
        lp.width = rect.width();
        lp.height = rect.height();
        lp.leftMargin = rect.left;
        lp.topMargin = rect.top;
        lp.gravity = Gravity.TOP | Gravity.START;
        view.setLayoutParams(lp);
    }

    private void resetWindowTransform(View view) {
        view.animate().cancel();
        view.setTranslationX(0);
        view.setTranslationY(0);
        view.setScaleX(1f);
        view.setScaleY(1f);
    }

    private void setTopChromeVisible(boolean visible, boolean animate) {
        if (topChromeContainer == null) return;
        int chromeHeight = Math.max(1, getTopChromeHeight());
        android.view.ViewGroup.LayoutParams layoutParams =
                topChromeContainer.getLayoutParams();
        if (layoutParams != null && layoutParams.height != chromeHeight) {
            layoutParams.height = chromeHeight;
            topChromeContainer.setLayoutParams(layoutParams);
        }
        topChromeContainer.animate().cancel();
        if (visible) {
            topChromeContainer.setVisibility(View.VISIBLE);
            if (!animate) {
                topChromeContainer.setTranslationY(0f);
                return;
            }
            topChromeContainer.setTranslationY(-chromeHeight);
            topChromeContainer.animate()
                    .translationY(0f)
                    .setDuration(WINDOW_FRAME_SWITCH_ANIMATION_MS)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .start();
            return;
        }
        if (!animate) {
            topChromeContainer.setTranslationY(-chromeHeight);
            topChromeContainer.setVisibility(View.GONE);
            return;
        }
        topChromeContainer.animate()
                .translationY(-chromeHeight)
                .setDuration(WINDOW_FRAME_SWITCH_ANIMATION_MS)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .withEndAction(() -> topChromeContainer.setVisibility(View.GONE))
                .start();
    }

    private void enterOneStepMode(boolean sideFromLeft) {
        mainOnLeft = !sideFromLeft;
        updateTopNavigationControls();
        multiWindowMode = false;
        applyWindowLayout(false);
        multiWindowMode = true;
        setTopChromeVisible(true, true);
        applyWindowLayout(true);
    }

    private void exitOneStepMode() {
        if (!multiWindowMode) return;
        multiWindowMode = false;
        setTopChromeVisible(false, true);
        applyWindowLayout(true);
    }

    // ---------------- 应用放置（对照 addOrFocusApp 精简） ----------------

    private void addOrFocusApp(LaunchableApp app) {
        if (app == null) return;
        if (!hasShizukuPermission()) {
            Toast.makeText(this, "Shizuku 未授权", Toast.LENGTH_SHORT).show();
            ensureShizukuPermission();
            return;
        }
        if (isWindowAnimationRunning()) return;
        int existingSlot = findSlot(app.packageName);
        if (existingSlot >= 0) {
            if (existingSlot != activeMainSlot) {
                switchMainSlot(existingSlot, true);
            }
            return;
        }
        if (windowApps[activeMainSlot] == null) {
            startAppInSlot(activeMainSlot, app, true, false);
            return;
        }
        int emptySideSlot = findEmptySideSlot();
        if (emptySideSlot >= 0) {
            // 先在空侧窗启动，再 promote 到主窗（对照 stageAppForMainPromotion）
            windowApps[emptySideSlot] = app;
            windowViews[emptySideSlot].bind(app, emptySideSlot);
            launchInSlot(emptySideSlot, app);
            switchMainSlot(emptySideSlot, true);
            startAppAppearAfterPromotion(emptySideSlot, app);
            return;
        }
        replaceMainApp(activeMainSlot, app);
    }

    private void startAppAppearAfterPromotion(int slot, LaunchableApp app) {
        // promote 完成后补一次出现动画（窗口切换动画已在 switchMainSlot 中执行）
        workspace.postDelayed(() -> animateWindowAppAppear(slot, app, false), 60);
    }

    private void startAppInSlot(int slot, LaunchableApp app, boolean animateAppearance,
                                boolean fadeIn) {
        if (slot < 0 || slot >= MAX_WINDOWS || app == null) return;
        windowApps[slot] = app;
        windowViews[slot].bind(app, slot);
        renderWindows();
        launchInSlot(slot, app);
        if (animateAppearance) animateWindowAppAppear(slot, app, fadeIn);
        if (!multiWindowMode) enterOneStepMode(!mainOnLeft);
        else applyWindowLayout(true);
    }

    private void replaceMainApp(int slot, LaunchableApp app) {
        if (slot < 0 || slot >= MAX_WINDOWS || app == null) return;
        final SplitWindowView windowView = windowViews[slot];
        windowView.animate().cancel();
        windowView.setScaleX(1f);
        windowView.setScaleY(1f);
        windowView.setTranslationX(0f);
        windowView.setTranslationY(0f);
        // 对照原版：160ms 淡出旧内容，再启动新应用并 240ms 放大出现
        windowView.animate()
                .alpha(0f)
                .setDuration(MAIN_APP_REPLACE_FADE_OUT_MS)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .withEndAction(() -> {
                    windowApps[slot] = app;
                    windowViews[slot].bind(app, slot);
                    renderWindows();
                    launchInSlot(slot, app);
                    windowView.setAlpha(1f);
                    animateWindowAppAppear(slot, app, true);
                })
                .start();
    }

    private void animateWindowAppAppear(int slot, LaunchableApp expectedApp, boolean fadeIn) {
        if (slot < 0 || slot >= MAX_WINDOWS || !isWindowSlotEnabled(slot)) return;
        if (windowApps[slot] == null
                || !windowApps[slot].packageName.equals(expectedApp.packageName)) {
            return;
        }
        final SplitWindowView windowView = windowViews[slot];
        windowView.animate().cancel();
        windowView.setPivotX(windowView.getWidth() / 2f);
        windowView.setPivotY(windowView.getHeight() / 2f);
        windowView.setTranslationX(0f);
        windowView.setTranslationY(0f);
        windowView.setScaleX(WINDOW_SCALE_APPEAR_START);
        windowView.setScaleY(WINDOW_SCALE_APPEAR_START);
        windowView.setAlpha(fadeIn ? 0f : 1f);
        windowView.post(() -> {
            if (isWindowAnimationRunning()) return;
            if (windowApps[slot] == null
                    || !windowApps[slot].packageName.equals(expectedApp.packageName)) {
                return;
            }
            windowView.animate().cancel();
            windowView.setPivotX(windowView.getWidth() / 2f);
            windowView.setPivotY(windowView.getHeight() / 2f);
            windowView.setTranslationX(0f);
            windowView.setTranslationY(0f);
            windowView.animate()
                    .alpha(1f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(WINDOW_SCALE_APPEAR_MS)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .start();
        });
    }

    private void switchMainSlot(int newMainSlot, boolean animate) {
        if (newMainSlot < 0 || newMainSlot >= MAX_WINDOWS
                || newMainSlot == activeMainSlot
                || windowApps[newMainSlot] == null) {
            return;
        }
        int sideIndex = sideSlotOrder.indexOf(newMainSlot);
        if (sideIndex < 0) return;
        int oldMainSlot = activeMainSlot;
        sideSlotOrder.set(sideIndex, oldMainSlot);
        activeMainSlot = newMainSlot;
        if (!verticalWindowLayout) mainOnLeft = !mainOnLeft;
        updateTopNavigationControls();
        applyWindowLayout(animate);
    }

    private void handleSideSlotClick(int slot) {
        if (slot < 0 || slot >= MAX_WINDOWS || isMainPaneSlot(slot)) return;
        if (isWindowAnimationRunning()) return;
        if (windowApps[slot] == null) return;
        switchMainSlot(slot, true);
    }

    private void dismissSideWindow(int slot) {
        if (slot < 0 || slot >= MAX_WINDOWS || isMainPaneSlot(slot)) return;
        LaunchableApp dismissedApp = windowApps[slot];
        if (dismissedApp == null) {
            settleSideWindowBack(windowViews[slot]);
            return;
        }
        SplitWindowView windowView = windowViews[slot];
        int direction = getSideDismissDirection();
        windowView.animate().cancel();
        windowView.setElevation(0f);
        windowView.setTranslationZ(0f);
        windowView.setZ(0f);
        windowViews[activeMainSlot].bringToFront();
        ViewPropertyAnimator animator = windowView.animate()
                .alpha(0.18f)
                .setDuration(SIDE_DISMISS_SETTLE_MS)
                .setInterpolator(new AccelerateDecelerateInterpolator());
        if (verticalWindowLayout) {
            animator.translationY(windowView.getHeight() + dp(24));
        } else {
            animator.translationX(direction * (windowView.getWidth() + dp(24)));
        }
        animator.start();
        final String pkg = dismissedApp.packageName;
        windowView.postDelayed(() -> {
            windowApps[slot] = null;
            windowViews[slot].bind(null, slot);
            windowView.setTranslationX(0f);
            windowView.setTranslationY(0f);
            windowView.setScaleX(1f);
            windowView.setScaleY(1f);
            windowView.setAlpha(1f);
            controllers[slot].killApp(pkg, null);
            renderWindows();
            applyWindowLayout(false);
        }, SIDE_DISMISS_SETTLE_MS + 16L);
    }

    private void settleSideWindowBack(SplitWindowView windowView) {
        windowView.animate().cancel();
        windowView.animate()
                .translationX(0f)
                .translationY(0f)
                .alpha(1f)
                .setDuration(SIDE_SETTLE_BACK_MS)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .start();
    }

    private boolean isSideRailOnLeft() {
        return !mainOnLeft;
    }

    private int getSideDismissDirection() {
        return isSideRailOnLeft() ? -1 : 1;
    }

    private boolean movedPastSideDismissThreshold(float dx, float dy) {
        if (verticalWindowLayout) {
            return dy > 0
                    && Math.abs(dy) >= dp(SIDE_DISMISS_DISTANCE_DP)
                    && Math.abs(dy) > Math.abs(dx) * 0.85f;
        }
        int direction = getSideDismissDirection();
        return dx * direction > 0
                && Math.abs(dx) >= dp(SIDE_DISMISS_DISTANCE_DP)
                && Math.abs(dx) > Math.abs(dy) * 0.85f;
    }

    // ---------------- 槽位查询 ----------------

    private boolean isMainPaneSlot(int slot) {
        return slot == activeMainSlot;
    }

    private boolean isWindowSlotEnabled(int slot) {
        if (isMainPaneSlot(slot)) return true;
        int sideIndex = sideSlotOrder.indexOf(slot);
        return sideIndex >= 0 && sideIndex < getVisibleSideWindowCount();
    }

    private int getVisibleSideWindowCount() {
        return Math.min(sideWindowCount, sideSlotOrder.size());
    }

    private int findSlot(String packageName) {
        for (int i = 0; i < MAX_WINDOWS; i++) {
            LaunchableApp app = windowApps[i];
            if (app != null && TextUtils.equals(app.packageName, packageName)) return i;
        }
        return -1;
    }

    private int findEmptySideSlot() {
        for (int slot : sideSlotOrder) {
            if (isWindowSlotEnabled(slot) && windowApps[slot] == null) return slot;
        }
        return -1;
    }

    private void renderWindows() {
        for (int i = 0; i < MAX_WINDOWS; i++) {
            windowViews[i].bind(windowApps[i], i);
        }
        updateShortcutAppStatuses();
        updateTopAppStripOrder();
    }

    // ---------------- 虚拟屏启动 ----------------

    private void launchInSlot(final int slot, final LaunchableApp app) {
        VirtualDisplayController controller = controllers[slot];
        if (!controller.isCreated()) {
            status("虚拟屏未就绪（槽 " + slot + "），稍后重试");
            return;
        }
        status("正在打开 " + app.label + " …");
        controller.launchApp(app.packageName, app.getComponent(), () ->
                status(app.label + " 已打开（槽 " + slot
                        + " / 虚拟屏 " + controller.getDisplayId() + "）"));
    }

    private boolean hasShizukuPermission() {
        return Shizuku.pingBinder()
                && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
    }

    // ---------------- 尺寸（对照原版公式） ----------------

    private int getTopChromeHeight() {
        return getTopNavHeight() + getTopAppStripHeight();
    }

    private int getTopNavHeight() {
        return dp(getTopNavHeightDp());
    }

    private int getTopNavHeightDp() {
        int verticalSpacingDp = Math.round(TOP_NAV_VERTICAL_SPACING_DEFAULT_DP
                * topNavVerticalMarginScalePct / 100f);
        return TOP_NAV_BUTTON_SIZE_DP + verticalSpacingDp;
    }

    private int getTopAppStripHeight() {
        return dp(getTopAppStripHeightDp());
    }

    private int getTopAppStripHeightDp() {
        return getTopBarHeightDp(topAppStripVerticalPaddingScalePct);
    }

    private int getTopBarHeightDp(int scalePct) {
        int scaledHeightDp = Math.round(TOP_BAR_HEIGHT_DEFAULT_DP * scalePct / 100f);
        int contentBlockDp = Math.max(TOP_NAV_CONTENT_HEIGHT_DP, getTopAppIconSizeDp() + 6);
        int minHeightDp = contentBlockDp + getTopBarVerticalPaddingDp(scalePct) * 2;
        return Math.max(minHeightDp, scaledHeightDp);
    }

    private int getTopAppIconSizeDp() {
        return Math.max(1, Math.round(SplitSettings.TOP_APP_ICON_SIZE_DEFAULT_DP
                * topAppIconScalePct / 100f));
    }

    private int getTopAppStripSidePaddingDp() {
        return Math.max(8, Math.round(16 * topAppStripSpacingScalePct / 100f));
    }

    private int getTopAppStripVerticalPaddingDp() {
        return getTopBarVerticalPaddingDp(topAppStripVerticalPaddingScalePct);
    }

    private int getTopBarVerticalPaddingDp(int scalePct) {
        return Math.max(0, Math.round(4 * scalePct / 100f));
    }

    private int getTopAppStripCellWidthDp(int iconSizeDp) {
        int baseWidthDp = iconSizeDp + 28;
        return Math.max(iconSizeDp + 12,
                Math.round(baseWidthDp * topAppStripSpacingScalePct / 100f));
    }

    // ---------------- 杂项 ----------------

    private void status(String s) {
        Log.i(TAG, "status: " + s);
        if (statusText != null) statusText.setText(s);
    }

    private void updateStatusText() {
        boolean binder = false;
        boolean granted = false;
        try {
            binder = Shizuku.pingBinder();
            granted = binder && Shizuku.checkSelfPermission()
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) {
        }
        if (!binder) {
            status("Shizuku 未运行（请先启动 Shizuku 服务）");
        } else if (!granted) {
            status("Shizuku 未授权（点击授予）");
        } else {
            status("Shizuku 就绪 · 点顶部应用在分屏中打开");
        }
    }

    private FrameLayout.LayoutParams matchFrame() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private void setDpTextSize(TextView view, float dp) {
        view.setTextSize(TypedValue.COMPLEX_UNIT_DIP, dp);
    }

    private int dp(float value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()));
    }

    private int dp(int value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()));
    }

    @Override
    public void onBackPressed() {
        if (multiWindowMode) {
            LaunchableApp mainApp = windowApps[activeMainSlot];
            if (mainApp != null && controllers[activeMainSlot].isCreated()) {
                controllers[activeMainSlot].sendBackKey(() -> {
                });
                return;
            }
            exitOneStepMode();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        Shizuku.removeBinderReceivedListener(binderListener);
        for (VirtualDisplayController c : controllers) {
            if (c != null) c.release();
        }
    }
}