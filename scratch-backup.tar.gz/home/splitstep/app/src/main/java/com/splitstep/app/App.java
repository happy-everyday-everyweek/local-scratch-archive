package com.splitstep.app;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;

public class App extends Application {
    private static App instance;
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    public static App get() {
        return instance;
    }

    public static Handler handler() {
        return MAIN_HANDLER;
    }
}
