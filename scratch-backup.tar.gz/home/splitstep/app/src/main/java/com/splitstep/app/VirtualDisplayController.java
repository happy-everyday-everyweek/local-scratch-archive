package com.splitstep.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;

/**
 * 逐槽虚拟屏控制器：每个窗口槽位拥有独立的 VirtualDisplay。
 * Surface 由各 SplitWindowView 的 TextureView 提供，随布局尺寸创建/更新。
 * 应用启动与输入全部走 ShizukuShell（shell 权限）。
 */
public class VirtualDisplayController {
    private static final String TAG = "SplitStep.VD";

    private final Context context;
    private VirtualDisplay virtualDisplay;
    private Surface surface;
    private int width;
    private int height;
    private int displayId = -1;
    private final int slot;

    public VirtualDisplayController(Context context, int slot) {
        this.context = context.getApplicationContext();
        this.slot = slot;
    }

    /** 兼容旧构造：默认槽 0。 */
    public VirtualDisplayController(Context context) {
        this(context, 0);
    }

    public int getSlot() {
        return slot;
    }

    public boolean isCreated() {
        return virtualDisplay != null && virtualDisplay.getDisplay() != null
                && virtualDisplay.getDisplay().isValid();
    }

    public int getDisplayId() {
        return displayId;
    }

    /**
     * 创建/更新虚拟屏。
     *
     * @param surface 用于承载虚拟屏画面的 Surface（来自本槽 TextureView）
     */
    @SuppressLint("WrongConstant")
    public void createOrUpdate(Surface surface, int w, int h) {
        if (surface == null || w <= 0 || h <= 0) return;
        boolean sameSurface = surface == this.surface && w == this.width && h == this.height;
        if (sameSurface && isCreated()) return;

        this.surface = surface;
        this.width = w;
        this.height = h;

        DisplayManager dm = (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
        if (dm == null) return;

        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        int density = metrics.densityDpi;

        if (virtualDisplay != null) {
            try {
                virtualDisplay.release();
            } catch (Throwable ignored) {
            }
            virtualDisplay = null;
        }

        try {
            virtualDisplay = dm.createVirtualDisplay(
                    "SplitStepVD-" + slot,
                    w,
                    h,
                    density,
                    surface,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY);
            if (virtualDisplay != null && virtualDisplay.getDisplay() != null) {
                displayId = virtualDisplay.getDisplay().getDisplayId();
                Log.i(TAG, "slot=" + slot + " vd created id=" + displayId
                        + " size=" + w + "x" + h);
            }
        } catch (Throwable t) {
            Log.e(TAG, "createVirtualDisplay failed slot=" + slot, t);
            displayId = -1;
        }
    }

    public void release() {
        if (virtualDisplay != null) {
            try {
                virtualDisplay.release();
            } catch (Throwable ignored) {
            }
            virtualDisplay = null;
        }
        displayId = -1;
        surface = null;
    }

    /**
     * 在本槽虚拟屏上启动应用。经 Shizuku shell 执行 am start --display <id>。
     */
    public void launchApp(final String packageName, final String component, Runnable onDone) {
        if (displayId < 0) {
            Log.w(TAG, "launchApp: no virtual display slot=" + slot);
            return;
        }
        final String cmd;
        if (component != null && component.contains("/")) {
            cmd = "am start --display " + displayId + " -n " + component
                    + " -f 0x10008000";
        } else {
            cmd = "am start --display " + displayId + " -a android.intent.action.MAIN "
                    + "-c android.intent.category.LAUNCHER -p " + packageName
                    + " -f 0x10008000";
        }
        Log.i(TAG, "launch: " + cmd);
        ShizukuShell.exec(cmd, (code, stdout, stderr) -> {
            Log.i(TAG, "launch result code=" + code + " out=" + stdout + " err=" + stderr);
            if (onDone != null) App.handler().post(onDone);
        });
    }

    /**
     * force-stop 本槽里的应用。
     */
    public void killApp(final String packageName, Runnable onDone) {
        ShizukuShell.exec("am force-stop " + packageName, (code, stdout, stderr) -> {
            Log.i(TAG, "kill result code=" + code);
            if (onDone != null) App.handler().post(onDone);
        });
    }

    /**
     * 向本槽虚拟屏注入返回键（经 shell input keyevent --display）。
     */
    public void sendBackKey(Runnable onDone) {
        if (displayId < 0) return;
        ShizukuShell.exec("input keyevent --display " + displayId + " KEYCODE_BACK",
                (code, stdout, stderr) -> {
                    if (onDone != null) App.handler().post(onDone);
                });
    }

    /**
     * 向本槽虚拟屏注入点击（坐标为虚拟屏内坐标，与 TextureView 1:1）。
     */
    public void tap(float x, float y) {
        if (displayId < 0) return;
        ShizukuShell.exec("input tap --display " + displayId + " "
                + Math.round(x) + " " + Math.round(y), null);
    }

    /**
     * 向本槽虚拟屏注入滑动。
     */
    public void swipe(float x1, float y1, float x2, float y2, long durationMs) {
        if (displayId < 0) return;
        ShizukuShell.exec("input swipe --display " + displayId + " "
                + Math.round(x1) + " " + Math.round(y1) + " "
                + Math.round(x2) + " " + Math.round(y2) + " " + durationMs, null);
    }
}