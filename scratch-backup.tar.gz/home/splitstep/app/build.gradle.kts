plugins {
    id("com.android.application")
}
android {
    namespace = "com.splitstep.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.splitstep.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    // Shizuku shell 通道（虚拟屏/启动应用走 shell 权限）
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    // View UI
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("androidx.recyclerview:recyclerview:1.3.0")
    implementation("androidx.core:core:1.16.0")
}