package com.zcode.port

import android.app.Activity
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.textSize = 13f
        val pad = (16 * resources.displayMetrics.density).toInt()
        tv.setPadding(pad, pad, pad, pad)
        val sv = ScrollView(this)
        sv.addView(tv)
        setContentView(sv)

        // 原生入口约定：单实例、单线程；先 init 再调用其它入口。
        val ex = Executors.newSingleThreadExecutor()
        ex.execute {
            val sb = StringBuilder()
            sb.appendLine("== 1. 静态层切片 libzcodecore.so (JNI) ==")
            try {
                NativeCore.init()
                sb.appendLine("init: ok")
                sb.appendLine("sessionId: " + NativeCore.sessionId())
                sb.appendLine("turnId:    " + NativeCore.turnId())
                sb.appendLine("eventId:   " + NativeCore.eventId())
                sb.appendLine("traceId:   " + NativeCore.traceId())
                sb.appendLine("uuid7:     " + NativeCore.uuid7())
                sb.appendLine("uuid:      " + NativeCore.uuid())
                sb.appendLine("egress(10.0.0.5): " + NativeCore.egressCheck("10.0.0.5"))
                sb.appendLine("egress(8.8.8.8):  " + NativeCore.egressCheck("8.8.8.8"))
                sb.appendLine("egress(::1):      " + NativeCore.egressCheck("::1"))
                NativeCore.collect()
                sb.appendLine("collect: ok")
            } catch (t: Throwable) {
                sb.appendLine("FAIL: " + t)
            }
            sb.appendLine()
            sb.appendLine("== 2. 动态层核心 libzcodecore_cli.so (原生可执行) ==")
            sb.append(runNativeCore())
            runOnUiThread { tv.text = sb.toString() }
        }
    }

    /** 动态岛引擎无法嵌入 library 模式，所以真实 zod schema 代码走这条原生可执行车道。 */
    private fun runNativeCore(): String {
        val bin = File(applicationInfo.nativeLibraryDir, "libzcodecore_cli.so")
        if (!bin.exists()) {
            return "missing: " + bin.absolutePath
        }
        return try {
            val p = ProcessBuilder(bin.absolutePath).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            out + "exit=" + code
        } catch (t: Throwable) {
            "FAIL: " + t
        }
    }
}
