package com.zcode.port

/** JNI bridge to libzcodecore.so (scriptc-built ZCode core slice). */
object NativeCore {
    init {
        System.loadLibrary("zcodecore")
    }

    external fun init()
    external fun collect()
    external fun sessionId(): String
    external fun turnId(): String
    external fun eventId(): String
    external fun traceId(): String
    external fun uuid7(): String
    external fun uuid(): String
    external fun egressCheck(ip: String): String
}