#!/bin/sh
# 把 scriptc 产出的静态归档（library mode）链接成 Android aarch64 动态库 libzcodecore.so。
# 配方来自 HANDOFF §3：ld.lld -r 合并成员 -> llvm-objcopy 只保留 zc_* 全局符号 ->
# clang -target aarch64-linux-android26 + NDK sysroot + -Bsymbolic 与其 JNI shim 一起链接。
set -u
WS="${WS:-/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa}"
PORT="$WS/zcode-port"
NDK="${ANDROID_NDK_ROOT:-/root/ndk/android-ndk-r27c}"
SYSROOT="$NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot"
OUT="${1:-$PORT/libzcodecore.so}"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

ARCHIVE="$(ls -1 "$PORT"/.scriptc/*.lib.a 2>/dev/null | head -1)"
if [ -z "$ARCHIVE" ]; then
  echo "no static archive found under $PORT/.scriptc" >&2
  exit 1
fi
echo "archive: $ARCHIVE"

cd "$WORK" || exit 1
ar x "$ARCHIVE"
ld.lld -r ./*.o -o merged.o || exit 1

# 只保留 zc_* 与 JNI shim 需要的契约符号为全局
: > keep.txt
nm --defined-only merged.o | awk '$2=="T" || $2=="W" {print $3}' | grep -E '^zc_' >> keep.txt
llvm-objcopy --keep-global-symbols=keep.txt merged.o stripped.o || exit 1
echo "kept symbols: $(wc -l < keep.txt)"

clang \
  --target=aarch64-linux-android26 \
  --sysroot="$SYSROOT" \
  -fuse-ld=lld \
  -shared \
  -rtlib=compiler-rt \
  --unwindlib=none \
  -Wl,-Bsymbolic \
  -O2 \
  stripped.o "$PORT/jni/zcode_jni.c" "$PORT/jni/zc_compat.c" \
  -llog -lc -lm \
  -o "$OUT" || exit 1

echo "wrote: $OUT"
ls -la "$OUT"
nm -D --defined-only "$OUT" | grep -cE 'Java_com_zcode_port|zc_' || true