#!/bin/sh
# Audit libzcodecore.so undefined symbols against the bionic (API 33) stubs.
# Every UND symbol that is not provided by bionic/libm/liblog/libdl would
# fail the device's eager (BIND_NOW) resolution at dlopen time.
# Usage: sh tools/check_bionic_symbols.sh
cd "$(dirname "$0")/.." || exit 1
S=${NDK_SYSROOT:-/root/ndk/android-ndk-r27c/toolchains/llvm/prebuilt/linux-x86_64/sysroot}
L=$S/usr/lib/aarch64-linux-android/33

llvm-readelf --dyn-syms -W libzcodecore.so | grep ' UND ' | sed -E 's/.*UND //; s/@.*//' | sort -u > /tmp/zc_und.txt
for lib in libc.so libm.so liblog.so libdl.so; do
  llvm-nm -D $L/$lib 2>/dev/null | awk '{print $NF}' | sed 's/@.*//'
done | sort -u > /tmp/zc_bionic.txt

miss=0
while read s; do
  [ -z "$s" ] && continue
  grep -qx "$s" /tmp/zc_bionic.txt || { echo "MISSING: $s"; miss=1; }
done < /tmp/zc_und.txt

if [ $miss -eq 0 ]; then
  echo "OK: all undefined symbols are bionic-provided"
else
  exit 1
fi