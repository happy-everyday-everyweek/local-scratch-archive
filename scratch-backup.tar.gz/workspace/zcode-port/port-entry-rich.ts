import { createSessionId, createTurnId, createEventId, createTraceId } from "@zcode/contracts/interfaces/shared.js";
import { uuidv7, createUuid } from "@zcode/shared/uuid.js";
import { getPublicEgressIpBlockReason } from "@zcode/contracts/network/public-egress-ip.js";
import { workflowRunSchema } from "@zcode/shared/zcode-protocol-v4/workflow-runs.js";
import {
  canonicalWorkflowRun,
  workflowRunEntryKey,
} from "@zcode/shared/zcode-protocol-v4/workflow-runs-delta.js";
import { workflowRunEntryRefSchema } from "@zcode/shared/zcode-protocol-v4/delta.js";

export function portSessionId(): string {
  return createSessionId();
}

export function portTurnId(): string {
  return createTurnId();
}

export function portEventId(): string {
  return createEventId();
}

export function portTraceId(): string {
  return createTraceId();
}

export function portUuid7(): string {
  return uuidv7();
}

export function portUuid(): string {
  return createUuid();
}

export function portEgressCheck(ip: string): string {
  const result = getPublicEgressIpBlockReason(ip);
  return result === undefined ? "allowed" : result.reason;
}

/** 用真实 workflowRun schema 解析一段 JSON：验证 zod-lite 的原生校验行为。 */
export function portValidateWorkflowRun(json: string): string {
  const parsed = JSON.parse(json);
  const r = workflowRunSchema.safeParse(parsed);
  return r.success ? "ok" : "invalid";
}

/** 真实的 (siteId, ordinal) 去重键。 */
export function portWorkflowRunEntryKey(siteId: string, ordinal: number): string {
  return workflowRunEntryKey({ siteId: siteId, ordinal: ordinal });
}

/** 真实规范键序重建（record/可选键路径）。 */
export function portCanonicalWorkflowRunJson(json: string): string {
  return JSON.stringify(canonicalWorkflowRun(JSON.parse(json)));
}

/** 校验一条 run 条目引用（pick 出来的 record）。 */
export function portValidateEntryRef(json: string): string {
  const r = workflowRunEntryRefSchema.safeParse(JSON.parse(json));
  return r.success ? "ok" : "invalid";
}
