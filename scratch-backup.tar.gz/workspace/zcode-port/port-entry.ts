// zcode-port/port-entry.ts
// library 模式（静态层）切片入口：只依赖不需要动态岛引擎的模块，
// 因此可以走 scriptc build --lib 产出静态归档，再由 tools/link_so.sh
// 链成 libzcodecore.so，经 JNI 暴露给 Android。
//
// 需要动态层的真实 ZCode 能力（zod-lite schema 校验、workflow delta 纯函数）
// 放在 port-cli.ts，走 --dynamic 可执行车道。
import { createSessionId, createTurnId, createEventId, createTraceId } from "@zcode/contracts/interfaces/shared.js";
import { uuidv7, createUuid } from "@zcode/shared/uuid.js";
import { getPublicEgressIpBlockReason } from "@zcode/contracts/network/public-egress-ip.js";

export function portSessionId(): string {
  return createSessionId();
}

export function portTurnId(): string {
  return createTurnId();
}

export function portEventId(): string {
  return createEventId();
}

export function portTraceId(): string {
  return createTraceId();
}

export function portUuid7(): string {
  return uuidv7();
}

export function portUuid(): string {
  return createUuid();
}

export function portEgressCheck(ip: string): string {
  const result = getPublicEgressIpBlockReason(ip);
  return result === undefined ? "allowed" : result.reason;
}