#!/bin/sh
# ZCode Android port: compile the profile entry into an aarch64-linux-android
# static archive (scriptc library mode, API 26+).
cd "$(dirname "$0")" || exit 1
export SCRIPTC_CC=zigcc
export SCRIPTC_TARGET=aarch64-linux-android
export ANDROID_NDK_ROOT=/root/ndk/android-ndk-r27c
exec node ../scriptc-try/node_modules/.bin/scriptc build --lib --profile profile.json
