package com.zcode.core;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.system.Os;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * ZCode Core 自检壳 v4（正式版）：
 * 1) 解包载荷（原生单文件[含安卓修复] / 标准 Node）；
 * 2) 一键自检：原生 --version、--help、doctor、兼容模式 --version，附 logcat 抓取；
 * 3) 全程日志展示并落盘到外置媒体目录。
 */
public class MainActivity extends Activity {

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final StringBuilder logBuf = new StringBuilder();
    private final AtomicBoolean busy = new AtomicBoolean(false);

    private TextView statusView;
    private TextView logView;
    private EditText argsInput;
    private RadioButton seaModeBtn;
    private RadioButton plainModeBtn;

    private File coreDir, workDir, storageDir, homeDir, tmpDir, localLogDir, extLogDir;
    private String logFilePath = "(尚未写入)";

    private static final String FUSE_PATTERN = "NODE_SEA_FUSE_fce680ab2cc467b6e072b8b5df1996b2:1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        new Thread(this::prepareThenSelfTest, "zcode-prep").start();
    }

    // ---------------------------------------------------------------- UI

    private void buildUi() {
        int pad = dp(10);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("ZCode Core 自检 v4");
        title.setTextSize(18);
        root.addView(title);

        statusView = new TextView(this);
        statusView.setText("正在初始化...");
        statusView.setTextSize(13);
        statusView.setPadding(0, dp(6), 0, dp(6));
        root.addView(statusView);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button selfTestBtn = new Button(this);
        selfTestBtn.setText("一键自检");
        selfTestBtn.setOnClickListener(v -> startThread("selftest", () -> {
            runSelfTest();
            saveLog();
        }));
        Button reextractBtn = new Button(this);
        reextractBtn.setText("重新解包");
        reextractBtn.setOnClickListener(v -> startThread("reextract", () -> {
            log("== 手动重新解包 ==");
            deleteRecursive(coreDir);
            deleteRecursive(storageDir);
            try {
                initDirs();
                ensureExtracted();
                log("重新解包完成");
            } catch (Throwable t) {
                log("重新解包失败: " + t);
                logStack(t);
            }
            saveLog();
        }));
        Button logcatBtn = new Button(this);
        logcatBtn.setText("抓logcat");
        logcatBtn.setOnClickListener(v -> startThread("logcat", () -> {
            captureLogcat();
            saveLog();
        }));
        row1.addView(selfTestBtn);
        row1.addView(reextractBtn);
        row1.addView(logcatBtn);
        root.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        seaModeBtn = new RadioButton(this);
        seaModeBtn.setText("原生模式");
        seaModeBtn.setChecked(true);
        plainModeBtn = new RadioButton(this);
        plainModeBtn.setText("兼容模式");
        RadioGroup group = new RadioGroup(this);
        group.setOrientation(RadioGroup.HORIZONTAL);
        group.addView(seaModeBtn);
        group.addView(plainModeBtn);
        row2.addView(group);
        root.addView(row2);

        argsInput = new EditText(this);
        argsInput.setText("--version");
        argsInput.setSingleLine(true);
        root.addView(argsInput);

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        Button runBtn = new Button(this);
        runBtn.setText("运行");
        runBtn.setOnClickListener(v -> startThread("run", this::runCustom));
        Button clearBtn = new Button(this);
        clearBtn.setText("清空日志");
        clearBtn.setOnClickListener(v -> {
            synchronized (logBuf) {
                logBuf.setLength(0);
            }
            logView.setText("");
        });
        row3.addView(runBtn);
        row3.addView(clearBtn);
        root.addView(row3);

        ScrollView scroll = new ScrollView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scroll.setLayoutParams(lp);
        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(10);
        logView.setTextIsSelectable(true);
        scroll.addView(logView, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll);

        TextView hint = new TextView(this);
        hint.setTextSize(10);
        hint.setText("日志会同步写入 /sdcard/Android/media/com.zcode.core/logs/");
        root.addView(hint);

        setContentView(root);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------------------------------------------------------------- 准备

    private void prepareThenSelfTest() {
        try {
            log("== ZCode Core 自检启动 (v4) ==");
            log("设备: " + Build.MANUFACTURER + " " + Build.MODEL
                    + " | Android " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")");
            log("ABI: " + String.join(",", Build.SUPPORTED_ABIS));
            log("应用 targetSdk=" + getApplicationInfo().targetSdkVersion);
            initDirs();
            ensureExtracted();
            log("核心目录: " + coreDir.getAbsolutePath()
                    + "  总大小: " + (dirSize(coreDir) / 1048576) + " MB");
            listCoreFiles();
            runSelfTest();
        } catch (Throwable t) {
            log("!! 初始化阶段异常: " + t);
            logStack(t);
            setStatus("初始化失败: " + t.getMessage());
        } finally {
            saveLog();
        }
    }

    private void initDirs() {
        File files = getFilesDir();
        coreDir = new File(files, "core");
        workDir = new File(files, "work");
        storageDir = new File(files, "zcode-storage");
        homeDir = new File(files, "home");
        tmpDir = new File(files, "tmp");
        localLogDir = new File(files, "run-logs");
        coreDir.mkdirs();
        workDir.mkdirs();
        storageDir.mkdirs();
        homeDir.mkdirs();
        tmpDir.mkdirs();
        localLogDir.mkdirs();
        try {
            File[] ext = getExternalMediaDirs();
            if (ext != null && ext.length > 0 && ext[0] != null) {
                extLogDir = new File(ext[0], "logs");
                extLogDir.mkdirs();
            }
        } catch (Throwable ignored) {
        }
    }

    private String readSmall(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[16];
            int n = in.read(b);
            return new String(b, 0, Math.max(n, 0), "US-ASCII");
        } catch (Throwable t) {
            return "";
        }
    }

    private void ensureExtracted() throws IOException {
        File marker = new File(coreDir, ".ready");
        File seaBin = new File(coreDir, "zcode");
        File nodeBin = new File(coreDir, "node");
        if (marker.exists() && "v4".equals(readSmall(marker).trim())
                && seaBin.exists() && nodeBin.exists()
                && seaBin.length() > 10_000_000) {
            log("核心已解包（v4），跳过解包步骤");
            return;
        }
        log("开始解包内置载荷 v4（首次约需 2 分钟）...");
        deleteRecursive(coreDir);
        coreDir.mkdirs();
        copyAssetDir("core", coreDir);
        chmodTree(coreDir);
        try (FileWriter w = new FileWriter(marker)) {
            w.write("v4");
        }
        log("解包完成");
    }

    private void copyAssetDir(String assetPath, File dest) throws IOException {
        AssetManager am = getAssets();
        String[] children = am.list(assetPath);
        if (children == null || children.length == 0) {
            copyAssetFile(assetPath, dest);
            return;
        }
        if (!dest.exists() && !dest.mkdirs()) {
            throw new IOException("创建目录失败: " + dest);
        }
        Arrays.sort(children);
        for (String child : children) {
            copyAssetDir(assetPath + "/" + child, new File(dest, child));
        }
    }

    private void copyAssetFile(String assetPath, File dest) throws IOException {
        long t0 = System.currentTimeMillis();
        try (InputStream in = getAssets().open(assetPath);
             FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[512 * 1024];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                total += n;
            }
            log("解包: " + assetPath + "  " + (total / 1048576) + " MB  ("
                    + (System.currentTimeMillis() - t0) + " ms)");
        }
    }

    private void chmodTree(File f) {
        if (f.isDirectory()) {
            File[] cs = f.listFiles();
            if (cs != null) {
                for (File c : cs) {
                    chmodTree(c);
                }
            }
        } else {
            try {
                Os.chmod(f.getAbsolutePath(), 0755);
            } catch (Throwable ignored) {
            }
        }
    }

    private void listCoreFiles() {
        File[] cs = coreDir.listFiles();
        if (cs == null) {
            return;
        }
        Arrays.sort(cs);
        for (File c : cs) {
            log("  core/" + c.getName() + "  " + (c.length() / 1024) + " KB");
        }
    }

    // ---------------------------------------------------------------- 自检

    private void runSelfTest() {
        setStatus("自检中...");

        RunResult seaVer = runSea("--version");
        boolean seaOk = isVersionOk(seaVer);

        RunResult seaHelp = runSea("--help");
        boolean helpOk = seaHelp.exit == 0 && seaHelp.output.contains("Usage");

        RunResult seaDoctor = runSea("doctor");
        boolean doctorOk = seaDoctor.exit == 0 && seaDoctor.output.contains("version");

        captureLogcatInternal();

        RunResult plainVer = runPlain("--version");
        boolean plainOk = isVersionOk(plainVer);

        String summary = "自检结论 — 原生: " + tag(seaOk)
                + " | 帮助: " + tag(helpOk)
                + " | doctor: " + tag(doctorOk)
                + " | 兼容: " + tag(plainOk);
        log("");
        log("========================================");
        log(summary);
        log("========================================");
        setStatus(summary);
    }

    /** 单独跑一次带 SEA 原生调试的探针（输出进日志）。 */
    private RunResult runTraceProbe() {
        List<String> cmd = Collections.singletonList(new File(coreDir, "zcode").getAbsolutePath());
        return runProc("原生(SEA追踪) --version", cmd, false,
                Collections.singletonMap("NODE_DEBUG_NATIVE", "SEA"), 60_000);
    }

    private boolean isVersionOk(RunResult r) {
        return r.exit == 0 && r.output.matches("(?s).*\\d+\\.\\d+\\.\\d+.*");
    }

    private String tag(boolean b) {
        return b ? "OK" : "失败";
    }

    private void runCustom() {
        String raw = argsInput.getText().toString().trim();
        List<String> args = raw.isEmpty()
                ? Collections.<String>emptyList()
                : Arrays.asList(raw.split("\\s+"));
        boolean usePlain = plainModeBtn.isChecked();
        if (usePlain) {
            runPlain(args.toArray(new String[0]));
        } else {
            runSea(args.toArray(new String[0]));
        }
        saveLog();
    }

    private RunResult runSea(String... args) {
        List<String> cmd = new ArrayList<>();
        cmd.add(new File(coreDir, "zcode").getAbsolutePath());
        cmd.addAll(Arrays.asList(args));
        return runProc("原生模式 " + String.join(" ", args), cmd, false, null, 120_000);
    }

    private RunResult runPlain(String... args) {
        List<String> cmd = new ArrayList<>();
        cmd.add(new File(coreDir, "node").getAbsolutePath());
        cmd.add(new File(coreDir, "zcode.cjs").getAbsolutePath());
        cmd.addAll(Arrays.asList(args));
        return runProc("兼容模式 " + String.join(" ", args), cmd, true, null, 120_000);
    }

    private RunResult runProc(String label, List<String> cmd, boolean plainEnv,
                              Map<String, String> extras, int timeoutMs) {
        if (!busy.compareAndSet(false, true)) {
            log("(已有任务在执行，忽略本次请求)");
            return new RunResult(-1, "");
        }
        RunResult r = new RunResult();
        try {
            setStatus("运行中: " + label);
            log("");
            log("$ " + String.join(" ", cmd));
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.directory(workDir);
            pb.redirectErrorStream(true);
            Map<String, String> env = pb.environment();
            env.putAll(baseEnv(plainEnv));
            if (extras != null) {
                env.putAll(extras);
            }

            long t0 = System.currentTimeMillis();
            Process p = pb.start();
            final StringBuilder out = new StringBuilder();
            Thread pump = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        out.append(line).append('\n');
                        log(line);
                    }
                } catch (Throwable ignored) {
                }
            }, "pump");
            pump.start();

            boolean finished = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS);
            if (!finished) {
                p.destroyForcibly();
                log("!! 超时(" + timeoutMs + "ms)，已终止进程");
                r.exit = -999;
            } else {
                r.exit = p.exitValue();
            }
            try {
                pump.join(3000);
            } catch (InterruptedException ignored) {
            }
            r.output = out.toString();
            r.ms = System.currentTimeMillis() - t0;
            log("退出码: " + r.exit + " | 耗时: " + r.ms + " ms");
        } catch (Throwable t) {
            log("!! 运行异常: " + t);
            logStack(t);
            r.exit = -1000;
        } finally {
            busy.set(false);
        }
        return r;
    }

    private void captureLogcat() {
        captureLogcatInternal();
    }

    private void captureLogcatInternal() {
        runProc("logcat 快照", Arrays.asList("/system/bin/logcat", "-d", "-t", "400"),
                false, null, 30_000);
    }

    // ---------------------------------------------------------------- 探针

    /**
     * 生成"掉熔丝"副本：把 NODE_SEA_FUSE_...:1 的最后一字节改成 :0，
     * 让注入过的二进制以普通 Node 方式运行，用来判断基座是否健康。
     */
    private boolean ensureFuse0Copy() {
        File src = new File(coreDir, "zcode");
        File dst = new File(coreDir, "zcode-fuse0");
        try {
            if (dst.exists() && dst.length() == src.length()) {
                return true;
            }
            byte[] pat = FUSE_PATTERN.getBytes("US-ASCII");
            int m = pat.length;
            long matchPos = -1;

            try (RandomAccessFile raf = new RandomAccessFile(src, "r")) {
                long len = raf.length();
                byte[] buf = new byte[1 << 20];
                byte[] tail = new byte[m - 1];
                int tailLen = 0;
                long pos = 0;
                outer:
                while (pos < len) {
                    raf.seek(pos);
                    int n = raf.read(buf);
                    if (n <= 0) {
                        break;
                    }
                    int workLen = tailLen + n;
                    byte[] work = new byte[workLen];
                    System.arraycopy(tail, 0, work, 0, tailLen);
                    System.arraycopy(buf, 0, work, tailLen, n);
                    for (int i = 0; i + m <= workLen; i++) {
                        boolean ok = true;
                        for (int j = 0; j < m; j++) {
                            if (work[i + j] != pat[j]) {
                                ok = false;
                                break;
                            }
                        }
                        if (ok) {
                            matchPos = pos - tailLen + i;
                            break outer;
                        }
                    }
                    int keep = Math.min(m - 1, workLen);
                    System.arraycopy(work, workLen - keep, tail, 0, keep);
                    tailLen = keep;
                    pos += n;
                }
            }
            if (matchPos < 0) {
                log("(未找到熔丝标记，无法生成掉熔丝副本)");
                return false;
            }

            try (RandomAccessFile in = new RandomAccessFile(src, "r");
                 RandomAccessFile out = new RandomAccessFile(dst, "rw")) {
                byte[] buf = new byte[1 << 20];
                long total = in.length();
                long written = 0;
                while (written < total) {
                    int n = in.read(buf);
                    if (n <= 0) {
                        break;
                    }
                    out.write(buf, 0, n);
                    written += n;
                }
            }
            try (RandomAccessFile out = new RandomAccessFile(dst, "rw")) {
                long flipAt = matchPos + m - 1;
                out.seek(flipAt);
                int b = out.read();
                if (b == '1') {
                    out.seek(flipAt);
                    out.write('0');
                    log("已生成掉熔丝副本（熔丝 :1 -> :0，位置 " + flipAt + "）");
                } else {
                    log("(熔丝字节异常: " + b + "，副本未翻转)");
                }
            }
            try {
                Os.chmod(dst.getAbsolutePath(), 0755);
            } catch (Throwable ignored) {
            }
            return true;
        } catch (Throwable t) {
            log("(生成掉熔丝副本失败: " + t + ")");
            return false;
        }
    }

    private Map<String, String> baseEnv(boolean plainMode) {
        Map<String, String> m = new HashMap<>();
        m.put("LD_LIBRARY_PATH", new File(coreDir, "lib").getAbsolutePath());
        m.put("ZCODE_STORAGE_DIR", storageDir.getAbsolutePath());
        m.put("HOME", homeDir.getAbsolutePath());
        m.put("TMPDIR", tmpDir.getAbsolutePath());
        m.put("PATH", "/system/bin:/system/xbin:/vendor/bin:/product/bin");
        m.put("TERM", "xterm-256color");
        m.put("LANG", "C.UTF-8");
        if (plainMode) {
            m.put("ZCODE_RG_BINARY", new File(coreDir, "rg").getAbsolutePath());
        }
        return m;
    }

    private static class RunResult {
        int exit;
        String output = "";
        long ms;

        RunResult() {
        }

        RunResult(int exit, String output) {
            this.exit = exit;
            this.output = output;
        }
    }

    // ---------------------------------------------------------------- 工具

    private void startThread(String name, Runnable r) {
        new Thread(r, "zcode-" + name).start();
    }

    private void log(String line) {
        synchronized (logBuf) {
            logBuf.append(line).append('\n');
            if (logBuf.length() > 300_000) {
                logBuf.delete(0, 100_000);
            }
        }
        final String l = line;
        ui.post(() -> logView.append(l + "\n"));
    }

    private void logStack(Throwable t) {
        for (StackTraceElement e : t.getStackTrace()) {
            log("    at " + e);
        }
    }

    private void setStatus(String s) {
        ui.post(() -> statusView.setText(s));
    }

    private void saveLog() {
        String text;
        synchronized (logBuf) {
            text = logBuf.toString();
        }
        String name = "run-"
                + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date())
                + ".txt";
        try {
            File f = new File(localLogDir, "latest.txt");
            try (FileWriter w = new FileWriter(f)) {
                w.write(text);
            }
        } catch (Throwable ignored) {
        }
        if (extLogDir != null) {
            try {
                File f = new File(extLogDir, name);
                try (FileWriter w = new FileWriter(f)) {
                    w.write(text);
                }
                logFilePath = f.getAbsolutePath();
            } catch (Throwable ignored) {
            }
        }
        log("(日志已保存: " + logFilePath + " )");
    }

    private long dirSize(File f) {
        if (f == null) {
            return 0;
        }
        if (f.isFile()) {
            return f.length();
        }
        long s = 0;
        File[] cs = f.listFiles();
        if (cs != null) {
            for (File c : cs) {
                s += dirSize(c);
            }
        }
        return s;
    }

    private void deleteRecursive(File f) {
        if (f == null || !f.exists()) {
            return;
        }
        if (f.isDirectory()) {
            File[] cs = f.listFiles();
            if (cs != null) {
                for (File c : cs) {
                    deleteRecursive(c);
                }
            }
        }
        f.delete();
    }
}