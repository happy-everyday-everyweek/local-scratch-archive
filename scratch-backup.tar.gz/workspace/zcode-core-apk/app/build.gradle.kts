plugins {
    id("com.android.application")
}

android {
    namespace = "com.zcode.core"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.zcode.core"
        minSdk = 26
        targetSdk = 28
        versionCode = 4
        versionName = "0.4.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
    }
}

dependencies {
}
