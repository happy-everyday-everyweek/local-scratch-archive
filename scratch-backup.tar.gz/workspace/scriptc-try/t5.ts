interface ArgDef {
  short?: string;
  long?: string;
  type: "boolean" | "string" | "number";
  default?: boolean | string | number;
}

interface ParsedArgs {
  flags: Record<string, boolean | string | number | undefined>;
  positional: string[];
}

type ParseResult =
  | { ok: true; result: ParsedArgs }
  | { ok: false; error: string };

function core(
  cmdName: string,
  args: string[],
  defs: Record<string, ArgDef>,
): ParseResult {
  const flags: Record<string, boolean | string | number | undefined> = {};
  void cmdName;
  void defs;
  flags.decode = true;
  return { ok: true, result: { flags, positional: args } };
}

export function parseArgs<T extends Record<string, ArgDef>>(
  cmdName: string,
  args: string[],
  defs: T,
): ParseResult {
  void defs;
  return core(cmdName, args, defs);
}

export function use(): void {
  const parsed = parseArgs("base64", ["-d", "file"], {
    decode: { short: "d", long: "decode", type: "boolean" as const },
    wrap: { short: "w", long: "wrap", type: "number" as const, default: 76 },
  });
  if (!parsed.ok) return;
  const decode = parsed.result.flags.decode;
  const wrap = parsed.result.flags.wrap;
  const files = parsed.result.positional;
  console.log(String(decode));
  console.log(String(wrap));
  console.log(String(files.length));
  if (typeof wrap === "number" && wrap < 0) {
    console.log("negative");
  }
}

void use();