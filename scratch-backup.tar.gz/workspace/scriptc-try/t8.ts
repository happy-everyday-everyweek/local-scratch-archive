/** Probe: which String.replace callback shapes compile, and what breaks `+=`. */

function enc(v: string): string {
  return v + "!";
}

export function r1(): void {
  const a = "xy".replace(/[ab]/g, (c) => `%${c.length}`);
  console.log(a);
}

export function r2(): void {
  const b = "xy".replace(/[ab]/g, (c) => c.toUpperCase());
  console.log(b);
}

export function r3(): void {
  const c = "xy".replace(/[ab]/g, (c) => {
    return c.toUpperCase();
  });
  console.log(c);
}

export function r4(): void {
  const d = "xy".replace(/[ab]/g, (c) => `%${enc(c)}`);
  console.log(d);
}

export function r5(): void {
  const e = "xy".replace(/[ab]/g, () => "");
  console.log(e);
}

export function accum(): void {
  let stringKey = "";
  const input = "abcdef";
  for (let i = 0; i < input.length; i++) {
    stringKey += input.charAt(i);
  }
  console.log(stringKey);
}

export function pairLoop(start: number): void {
  const out: string[] = [];
  let i = start;
  let count = 0;
  for (; i < start + 5 && count < 3; i++, count++) {
    out.push(String(i));
  }
  console.log(out.join(","));
}

void r1();
void r2();
void r3();
void r4();
void r5();
void accum();
void pairLoop(1);