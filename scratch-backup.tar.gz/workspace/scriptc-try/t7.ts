interface ArgDef {
  type: "boolean" | "string" | "number";
  default?: boolean | string | number;
}

type FlagValueOf<D> = D extends { type: "boolean" }
  ? boolean
  : D extends { type: "number" }
    ? D extends { default: number }
      ? number
      : number | undefined
    : D extends { default: string }
      ? string
      : string | undefined;

export type FlagsOf<T extends Record<string, ArgDef>> = {
  [K in keyof T]: FlagValueOf<T[K]>;
};

type ResultOf<F> =
  | { ok: true; result: { flags: F; positional: string[] } }
  | { ok: false; error: string };

function raw(args: string[]): unknown {
  return { ok: true, result: { flags: undefined, positional: args } };
}

export function parseArgs<F>(
  cmdName: string,
  args: string[],
  defs: Record<string, ArgDef>,
): ResultOf<F> {
  void cmdName;
  void defs;
  const r = raw(args) as unknown;
  return r as ResultOf<F>;
}

const argDefs = {
  decode: { short: "d", long: "decode", type: "boolean" as const },
  wrap: { short: "w", long: "wrap", type: "number" as const, default: 76 },
  label: { short: "l", long: "label", type: "string" as const },
};

function use(): void {
  const parsed = parseArgs<FlagsOf<typeof argDefs>>("base64", ["-d"], argDefs);
  if (!parsed.ok) return;
  const decode = parsed.result.flags.decode;
  const wrap = parsed.result.flags.wrap;
  const label = parsed.result.flags.label;
  console.log(String(decode));
  console.log(String(wrap < 0));
  console.log(String(Math.ceil(10 / wrap)));
  console.log(String(label));
}

void use();