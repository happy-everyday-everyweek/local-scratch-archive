// Probe: which option-record member blocks a function-typed slot.
interface OptsA {
  cwd: string;
  signal?: AbortSignal;
}
interface CtxA {
  exec?: (command: string, options: OptsA) => Promise<string>;
}

interface OptsB {
  cwd: string;
  signal?: unknown;
}
interface CtxB {
  exec?: (command: string, options: OptsB) => Promise<string>;
}

interface OptsC {
  cwd: string;
}
interface CtxC {
  exec?: (command: string, options: OptsC) => Promise<string>;
}

interface OptsD {
  cwd: string;
  signal?: AbortHandle;
}
interface AbortHandle {
  readonly aborted: boolean;
  addEventListener(type: string, listener: () => void): void;
  removeEventListener(type: string, listener: () => void): void;
}
interface CtxD {
  exec?: (command: string, options: OptsD) => Promise<string>;
}

export function probeA(ctx: CtxA): void {
  if (ctx.exec) {
    ctx.exec("x", { cwd: "/" });
  }
}

export function probeB(ctx: CtxB): void {
  if (ctx.exec) {
    ctx.exec("x", { cwd: "/" });
  }
}

export function probeC(ctx: CtxC): void {
  if (ctx.exec) {
    ctx.exec("x", { cwd: "/" });
  }
}

export function probeD(ctx: CtxD, h: AbortHandle): void {
  if (ctx.exec) {
    ctx.exec("x", { cwd: "/", signal: h });
  }
}

export function main(): void {
  const a: CtxA = {};
  probeA(a);
  const b: CtxB = {};
  probeB(b);
  const c: CtxC = {};
  probeC(c);
  const d: CtxD = {};
  probeD(d, { aborted: false, addEventListener: () => {}, removeEventListener: () => {} });
}

void main();
