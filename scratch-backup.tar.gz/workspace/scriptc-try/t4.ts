type Mapped<T> = { [K in keyof T]: string };

type ParseResult<T> =
  | { ok: true; values: Mapped<T>; positionals: string[] }
  | { ok: false; error: string };

function rawParse(defs: unknown, argv: string[]): unknown {
  void defs;
  return { ok: false, error: "not implemented " + String(argv.length) };
}

export function parseArgs<T>(defs: T, argv: string[]): ParseResult<T> {
  const raw = rawParse(defs, argv) as unknown;
  return raw as ParseResult<T>;
}

export function use(): void {
  const r = parseArgs({ alpha: "string" }, ["--alpha", "beta"]);
  if (r.ok) {
    console.log(r.values.alpha);
  } else {
    console.log(r.error);
  }
}

void use();