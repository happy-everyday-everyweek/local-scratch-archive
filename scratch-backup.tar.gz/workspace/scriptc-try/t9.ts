/** Probe: are records/arrays that hold function members compilable at all? */

interface Entry {
  name: string;
  fn: (a: string) => string;
}

const table: Entry[] = [
  { name: "a", fn: (a) => a + "!" },
  { name: "b", fn: (a) => a },
];

export function pick(name: string): string {
  for (const e of table) {
    if (e.name === name) return e.fn("x");
  }
  return "";
}

// Variant: record with a function member read through a local copy
interface Ctx {
  handler: (a: string) => string;
}

export function callIt(c: Ctx): string {
  const h = c.handler;
  return h("y");
}

void pick("a");
void callIt({ handler: (a) => a });