/** Probe: which arm of an index-signature value union breaks lowering? */

type FileContent = string | Uint8Array;

interface FileInit {
  content: FileContent;
  mode?: number;
  mtime?: Date;
}

// 1: plain string values
type R1 = Record<string, string>;
class C1 {
  constructor(private o: { files?: R1 }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

// 2: string | Uint8Array
type R2 = Record<string, string | Uint8Array>;
class C2 {
  constructor(private o: { files?: R2 }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

// 3: string | record
type R3 = Record<string, string | { content: string }>;
class C3 {
  constructor(private o: { files?: R3 }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

// 4: string | FileInit (record with optional members)
type R4 = Record<string, string | FileInit>;
class C4 {
  constructor(private o: { files?: R4 }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

// 5: the real InitialFiles shape
type R5 = Record<string, FileContent | FileInit>;
class C5 {
  constructor(private o: { files?: R5 }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

export function main(): void {
  console.log(String(new C1({}).n()));
  console.log(String(new C2({}).n()));
  console.log(String(new C3({}).n()));
  console.log(String(new C4({}).n()));
  console.log(String(new C5({}).n()));
}

void main();