/** Probe: cheapest replacement for `x?.member` on a union-typed receiver. */

interface OpA {
  type: "PatternReplacement";
  value: string;
}
interface OpB {
  type: "Substring";
  offset: number;
}

interface PartA {
  type: "ParameterExpansion";
  operation?: OpA | OpB;
  parameter: string;
}
interface PartB {
  type: "Literal";
  text: string;
}

type Part = PartA | PartB;

// shape 1: the original `?.` form
export function f1(p: Part): boolean {
  return p.type === "ParameterExpansion" && p.operation?.type === "Substring";
}

// shape 2: explicit !== undefined guard on a fresh read
export function f2(p: Part): boolean {
  return (
    p.type === "ParameterExpansion" &&
    p.operation !== undefined &&
    p.operation.type === "Substring"
  );
}

// shape 3: non-null assertion
export function f3(p: Part): boolean {
  return p.type === "ParameterExpansion" && p.operation!.type === "Substring";
}

// shape 4: local binding inside the block
export function f4(p: Part): boolean {
  if (p.type !== "ParameterExpansion") return false;
  const op = p.operation;
  if (op === undefined) return false;
  return op.type === "Substring";
}

// shape 5: `?.` on a local (non-property) union value
export function f5(op: OpA | OpB | undefined): boolean {
  return op?.type === "Substring";
}

export function main(): void {
  console.log(String(f1({ type: "Literal", text: "x" })));
  console.log(String(f2({ type: "Literal", text: "x" })));
  console.log(String(f3({ type: "Literal", text: "x" })));
  console.log(String(f4({ type: "Literal", text: "x" })));
  console.log(String(f5(undefined)));
}

void main();