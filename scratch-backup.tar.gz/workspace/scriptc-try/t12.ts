/** Probe: do optional function members block an options record's lowering? */

type FnAlias = (a: string) => string;

interface OptsA {
  handler?: FnAlias;
}
class CA {
  constructor(private o: OptsA) {}
  n(): number {
    return this.o.handler !== undefined ? 1 : 0;
  }
}

interface OptsB {
  handler?: () => void;
}
class CB {
  constructor(private o: OptsB) {}
  n(): number {
    return this.o.handler !== undefined ? 1 : 0;
  }
}

interface OptsC {
  label?: string;
  count?: number;
}
class CC {
  constructor(private o: OptsC) {}
  n(): number {
    return this.o.count !== undefined ? this.o.count : 0;
  }
}

interface OptsD {
  handler: FnAlias;
}
class CD {
  constructor(private o: OptsD) {}
  n(): number {
    return this.o.handler("x").length;
  }
}

export function main(): void {
  console.log(String(new CA({}).n()));
  console.log(String(new CB({}).n()));
  console.log(String(new CC({}).n()));
  console.log(String(new CD({ handler: (a) => a }).n()));
}

void main();