	.file	"hello.ts"
	.text
	.p2align	2
	.type	sc_bad_tag,@function
sc_bad_tag:
	.cfi_startproc
	str	x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -16
	adrp	x0, sc_bad_tag_msg
	add	x0, x0, :lo12:sc_bad_tag_msg
	bl	scr_trap
.Lfunc_end0:
	.size	sc_bad_tag, .Lfunc_end0-sc_bad_tag
	.cfi_endproc

	.globl	main
	.p2align	2
	.type	main,@function
main:
	.cfi_startproc
	sub	sp, sp, #64
	stp	x30, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	.cfi_def_cfa_offset 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w30, -48
	mov	x19, x1
	mov	w20, w0
	bl	scr_init
	adrp	x8, :got:scr_error_vts
	mov	w10, #2
	mov	w9, #4
	ldr	x8, [x8, :got_lo12:scr_error_vts]
	mov	w21, #1
	mov	w0, w20
	mov	x1, x19
	stp	x10, x10, [x8, #48]
	mov	w10, #3
	stp	xzr, x9, [x8]
	stp	x21, x21, [x8, #24]
	stp	x10, x10, [x8, #72]
	stp	x9, x9, [x8, #96]
	bl	scr_lib_init
	adrp	x8, sc_g_e__x25_loaded
	ldrb	w9, [x8, :lo12:sc_g_e__x25_loaded]
	tbnz	w9, #0, .LBB1_16
	strb	w21, [x8, :lo12:sc_g_e__x25_loaded]
	bl	scr_process_argv
	mov	x19, x0
	bl	scr_arr_len
	fmov	d1, #2.00000000
	fcmp	d0, d1
	b.le	.LBB1_4
	bl	scr_process_argv
	mov	x21, x0
	bl	scr_arr_retain_v
	fmov	d0, #2.00000000
	mov	x22, x0
	bl	scr_arr_state
	fmov	d1, #1.00000000
	fcmp	d0, d1
	b.ne	.LBB1_5
	mov	x0, x21
	bl	scr_arr_retain_v
	fmov	d0, #2.00000000
	mov	x23, x0
	bl	scr_arr_get_ref
	adrp	x2, :got:scr_str_retain_v
	adrp	x3, :got:scr_str_release_v
	mov	x1, x0
	ldr	x2, [x2, :got_lo12:scr_str_retain_v]
	ldr	x3, [x3, :got_lo12:scr_str_release_v]
	mov	w0, wzr
	mov	x4, xzr
	bl	scr_union_new_ref
	mov	x20, x0
	mov	x0, x23
	bl	scr_arr_release
	b	.LBB1_6
.LBB1_4:
	adrp	x0, sc_lit_0
	add	x0, x0, :lo12:sc_lit_0
	bl	scr_str_retain_v
	mov	x21, x0
	b	.LBB1_11
.LBB1_5:
	adrp	x20, sc_unit_0
	add	x20, x20, :lo12:sc_unit_0
.LBB1_6:
	mov	x0, x22
	bl	scr_arr_release
	mov	x0, x21
	bl	scr_arr_release
	mov	x0, x20
	bl	scr_union_retain_v
	ldr	w21, [x0, #8]
	bl	scr_union_release
	cmp	w21, #1
	b.ne	.LBB1_8
	adrp	x0, sc_lit_3
	add	x0, x0, :lo12:sc_lit_3
	bl	scr_str_retain_v
	mov	x21, x0
	mov	w0, #1
	mov	x1, x21
	bl	scr_error_new
	adrp	x1, :got:scr_error_retain_v
	adrp	x2, :got:scr_error_release_v
	mov	x3, xzr
	ldr	x1, [x1, :got_lo12:scr_error_retain_v]
	ldr	x2, [x2, :got_lo12:scr_error_release_v]
	bl	scr_throw_obj
	mov	x0, x21
	bl	scr_str_release
	mov	x21, xzr
	b	.LBB1_9
.LBB1_8:
	mov	x0, x20
	bl	scr_union_retain_v
	mov	x22, x0
	ldr	x0, [x0, #40]
	bl	scr_str_retain_v
	mov	x21, x0
	mov	x0, x22
	bl	scr_union_release
.LBB1_9:
	mov	x0, x20
	bl	scr_union_release
	bl	scr_exc_pending
	cbz	w0, .LBB1_11
	mov	x0, x21
	bl	scr_str_release
	mov	x0, x19
	bl	scr_arr_release
	b	.LBB1_16
.LBB1_11:
	adrp	x2, :got:scr_str_retain_v
	adrp	x3, :got:scr_str_release_v
	mov	w0, wzr
	ldr	x2, [x2, :got_lo12:scr_str_retain_v]
	ldr	x3, [x3, :got_lo12:scr_str_release_v]
	mov	x1, x21
	mov	x4, xzr
	bl	scr_union_new_ref
	adrp	x21, sc_g_e_who
	mov	x20, x0
	ldr	x8, [x21, :lo12:sc_g_e_who]
	mov	x0, x8
	bl	scr_union_release
	mov	x0, x19
	str	x20, [x21, :lo12:sc_g_e_who]
	bl	scr_arr_release
	adrp	x0, sc_lit_1
	add	x0, x0, :lo12:sc_lit_1
	bl	scr_str_retain_v
	ldr	x8, [x21, :lo12:sc_g_e_who]
	mov	x19, x0
	mov	x0, x8
	bl	scr_union_retain_v
	ldr	w8, [x0, #8]
	mov	x20, x0
	cmp	w8, #1
	b.eq	.LBB1_14
	cbnz	w8, .LBB1_20
	ldr	x0, [x20, #40]
	b	.LBB1_15
.LBB1_14:
	adrp	x0, sc_lit_2
	add	x0, x0, :lo12:sc_lit_2
.LBB1_15:
	bl	scr_str_retain_v
	mov	x21, x0
	mov	x0, x19
	mov	x1, x21
	bl	scr_str_concat
	mov	x22, x0
	mov	w8, #1
	str	x0, [sp, #8]
	mov	x1, sp
	mov	w0, #1
	str	w8, [sp]
	bl	scr_console_log
	mov	x0, x19
	bl	scr_str_release
	mov	x0, x20
	bl	scr_union_release
	mov	x0, x21
	bl	scr_str_release
	mov	x0, x22
	bl	scr_str_release
.LBB1_16:
	bl	scr_exc_pending
	bl	scr_exc_pending
	tbz	w0, #0, .LBB1_18
	bl	scr_exc_print_uncaught
	adrp	x8, sc_g_e_who
	ldr	x0, [x8, :lo12:sc_g_e_who]
	bl	scr_union_release
	mov	w0, #1
	b	.LBB1_19
.LBB1_18:
	adrp	x8, sc_g_e_who
	ldr	x0, [x8, :lo12:sc_g_e_who]
	bl	scr_union_release
	bl	scr_exit_code_hint_get
.LBB1_19:
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x30, x23, [sp, #16]
	add	sp, sp, #64
	ret
.LBB1_20:
	bl	sc_bad_tag
.Lfunc_end1:
	.size	main, .Lfunc_end1-main
	.cfi_endproc

	.type	sc_lit_0,@object
	.data
	.p2align	4, 0x0
sc_lit_0:
	.xword	-1
	.xword	5
	.xword	5
	.asciz	"world"
	.zero	2
	.size	sc_lit_0, 32

	.type	sc_lit_1,@object
	.p2align	4, 0x0
sc_lit_1:
	.xword	-1
	.xword	7
	.xword	7
	.asciz	"hello, "
	.size	sc_lit_1, 32

	.type	sc_lit_2,@object
	.p2align	4, 0x0
sc_lit_2:
	.xword	-1
	.xword	9
	.xword	9
	.asciz	"undefined"
	.zero	6
	.size	sc_lit_2, 40

	.type	sc_lit_3,@object
	.p2align	4, 0x0
sc_lit_3:
	.xword	-1
	.xword	103
	.xword	103
	.asciz	"undefined is not representable in the target union (a value narrowed or asserted past it still held it)"
	.size	sc_lit_3, 128

	.type	sc_unit_0,@object
	.p2align	4, 0x0
sc_unit_0:
	.xword	-1
	.word	1
	.zero	4
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.size	sc_unit_0, 48

	.type	sc_g_e_who,@object
	.local	sc_g_e_who
	.comm	sc_g_e_who,8,8
	.type	sc_g_e__x25_loaded,@object
	.local	sc_g_e__x25_loaded
	.comm	sc_g_e__x25_loaded,1,4
	.type	sc_bad_tag_msg,@object
	.section	.rodata,"a",@progbits
	.p2align	4, 0x0
sc_bad_tag_msg:
	.asciz	"scriptc: internal error: invalid union tag\n"
	.size	sc_bad_tag_msg, 44

	.section	".note.GNU-stack","",@progbits
