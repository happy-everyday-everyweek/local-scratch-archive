type FileContent = string | Uint8Array;
interface FileEntry { type: "file"; content: FileContent; mode: number; mtime: Date }
interface DirectoryEntry { type: "directory"; mode: number; mtime: Date }
interface SymlinkEntry { type: "symlink"; target: string; mode: number; mtime: Date }
interface LazyFileEntry { type: "file"; lazy: () => string | Uint8Array | Promise<string | Uint8Array>; mode: number; mtime: Date }
type FsEntry = FileEntry | LazyFileEntry | DirectoryEntry | SymlinkEntry;
class C1 { private data: Map<string, FsEntry> = new Map(); n(): number { return this.data.size; } }
class C2 { private data: Map<string, Uint8Array> = new Map(); private ids = new WeakMap<Uint8Array, number>(); n(): number { return this.data.size; } }
class C3 { private data: Map<string, FsEntry> = new Map(); private ids = new WeakMap<FsEntry, string>(); n(): number { return this.data.size; } }
void main();
function main(): void {
  console.log(String(new C1().n()));
  console.log(String(new C2().n()));
  console.log(String(new C3().n()));
}
