const code = "1 + 1";
console.log(eval(code));
