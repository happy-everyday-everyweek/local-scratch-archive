type FileContent = string | Uint8Array;
interface F1 { type: "file"; content: FileContent; mode: number; mtime: Date }
interface D1 { type: "directory"; mode: number; mtime: Date }
interface L1 { type: "file"; lazy: () => string; mode: number; mtime: Date }
interface L2 { type: "file"; lazy: () => string | Uint8Array | Promise<string | Uint8Array>; mode: number; mtime: Date }
type EA = F1 | D1;
type EB = F1 | D1 | L1;
type EC = F1 | D1 | L2;
interface IA { [p: string]: EA }
interface IB { [p: string]: EB }
interface IC { [p: string]: EC }
class CA { private d: Map<string, EA> = new Map(); constructor(i?: IA) { if (i) { for (const k of Object.keys(i)) { const v = i[k]; if (v !== undefined) this.d.set(k, v); } } } n(): number { return this.d.size; } }
class CB { private d: Map<string, EB> = new Map(); constructor(i?: IB) { if (i) { for (const k of Object.keys(i)) { const v = i[k]; if (v !== undefined) this.d.set(k, v); } } } n(): number { return this.d.size; } }
class CC { private d: Map<string, EC> = new Map(); constructor(i?: IC) { if (i) { for (const k of Object.keys(i)) { const v = i[k]; if (v !== undefined) this.d.set(k, v); } } } n(): number { return this.d.size; } }
void main();
function main(): void {
  const a = new CA();
  const b = new CB();
  const c = new CC();
  console.log(String(a.n()) + String(b.n()) + String(c.n()));
}
