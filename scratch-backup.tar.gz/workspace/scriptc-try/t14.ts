interface A1 { type: "file"; content: string | Uint8Array; mode: number; mtime: number }
interface D1 { type: "directory"; mode: number; mtime: number }
interface S1 { type: "symlink"; target: string; mode: number; mtime: number }
interface L1 { type: "file"; lazy: () => string | Uint8Array; mode: number; mtime: number }
interface AD { type: "file"; content: string | Uint8Array; mode: number; mtime: Date }
type E1 = A1 | D1 | S1;
type E2 = A1 | D1 | S1 | L1;
type E3 = AD | D1 | S1;
class C1 { private data: Map<string, E1> = new Map(); n(): number { return this.data.size; } }
class C2 { private data: Map<string, E2> = new Map(); n(): number { return this.data.size; } }
class C3 { private data: Map<string, E3> = new Map(); n(): number { return this.data.size; } }
void main();
function main(): void {
  console.log(String(new C1({}).n()));
  console.log(String(new C2({}).n()));
  console.log(String(new C3({}).n()));
}
