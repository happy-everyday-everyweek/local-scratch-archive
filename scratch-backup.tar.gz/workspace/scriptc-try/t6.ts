type M<T> = { [K in keyof T]: string };

interface Defs {
  alpha: string;
  beta: string;
}

// Test 1: is a CONCRETE mapped type usable at all?
function useMap(): void {
  const v: M<Defs> = { alpha: "a", beta: "b" };
  console.log(v.alpha);
}

// Test 2: generic record parameter, explicit type argument at the call site.
type ResultOf<F> =
  | { ok: true; result: { flags: F; positional: string[] } }
  | { ok: false; error: string };

function raw(args: string[]): unknown {
  return { ok: true, result: { flags: undefined, positional: args } };
}

export function parseArgs<F>(
  cmdName: string,
  args: string[],
  defs: Record<string, string>,
): ResultOf<F> {
  void cmdName;
  void defs;
  const r = raw(args) as unknown;
  return r as ResultOf<F>;
}

function useGeneric(): void {
  const p = parseArgs<{ decode: boolean; wrap: number }>("x", [], {});
  if (!p.ok) return;
  console.log(String(p.result.flags.decode));
  console.log(String(p.result.flags.wrap < 3));
}

void useMap();
void useGeneric();