/** Probe: which member of the union arm blocks an index-signature value? */

// A: optional number member
type RA = Record<string, string | { content: string; mode?: number }>;
class CA {
  constructor(private o: { files?: RA }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

// B: optional Date member
type RB = Record<string, string | { content: string; mtime?: Date }>;
class CB {
  constructor(private o: { files?: RB }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

// C: required Date member
type RC = Record<string, string | { content: string; mtime: Date }>;
class CC {
  constructor(private o: { files?: RC }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

// D: record arm only (no union)
type RD = Record<string, { content: string; mode?: number }>;
class CD {
  constructor(private o: { files?: RD }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

// E: union arm with Uint8Array member inside the record
type RE = Record<string, string | { content: string | Uint8Array }>;
class CE {
  constructor(private o: { files?: RE }) {}
  n(): number {
    return this.o.files !== undefined ? 1 : 0;
  }
}

export function main(): void {
  console.log(String(new CA({}).n()));
  console.log(String(new CB({}).n()));
  console.log(String(new CC({}).n()));
  console.log(String(new CD({}).n()));
  console.log(String(new CE({}).n()));
}

void main();