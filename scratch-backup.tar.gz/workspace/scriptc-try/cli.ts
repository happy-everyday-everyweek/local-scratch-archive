import pc from "picocolors";
console.log(pc.green("hello from dynamic mode"));
