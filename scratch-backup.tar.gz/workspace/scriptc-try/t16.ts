type FileContent = string | Uint8Array;
interface FileEntry { type: "file"; content: FileContent; mode: number; mtime: Date }
interface LazyFileEntry { type: "file"; lazy: () => string | Uint8Array | Promise<string | Uint8Array>; mode: number; mtime: Date }
interface DirectoryEntry { type: "directory"; mode: number; mtime: Date }
type FsEntry = FileEntry | LazyFileEntry | DirectoryEntry;
interface LazyFiles { [path: string]: FsEntry; }
class C1 {
  private data: Map<string, FsEntry> = new Map();
  constructor(initial?: LazyFiles) {
    if (initial) {
      for (const key of Object.keys(initial)) {
        const v = initial[key];
        if (v !== undefined) this.data.set(key, v);
      }
    }
  }
  n(): number { return this.data.size; }
}
void main();
function main(): void {
  const c = new C1();
  console.log(String(c.n()));
}
