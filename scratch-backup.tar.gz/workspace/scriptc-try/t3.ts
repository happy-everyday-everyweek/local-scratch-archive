interface C {
  exec?: (a: string) => string;
}

interface Def {
  parse?: (v: string) => number;
}

// V1: cast at read site
export function v1(c: C): void {
  if (c.exec) {
    const f = c.exec as (a: string) => string;
    console.log(f("x"));
  }
}

// V2: helper returning the required type
function requireF(c: C): (a: string) => string {
  if (c.exec === undefined) throw new Error("missing");
  return c.exec;
}
export function v2(c: C): void {
  const f = requireF(c);
  console.log(f("x"));
}

// V3: two-step cast
export function v3(c: C): void {
  const t = c.exec as unknown as (a: string) => string;
  console.log(t("x"));
}

// V5: local variable then if
export function v5(c: C): void {
  const f = c.exec;
  if (f) {
    console.log(f("x"));
  }
}

// V6: default fill with a same-shaped arrow
export function v6(c: C): void {
  const f = c.exec ?? ((a: string) => a);
  console.log(f("x"));
}

// V7: record field variant (like ValueOptDef.parse)
export function v7(d: Def): void {
  if (d.parse) {
    const p = d.parse as (v: string) => number;
    console.log(String(p("1")));
  }
}

// V8: helper for a record field
function requireParse(d: Def): (v: string) => number {
  if (d.parse === undefined) throw new Error("missing");
  return d.parse;
}
export function v8(d: Def): void {
  const p = requireParse(d);
  console.log(String(p("1")));
}

export function main(): void {
  v1({ exec: (a) => a });
  v2({ exec: (a) => a });
  v3({ exec: (a) => a });
  v5({ exec: (a) => a });
  v6({});
  v7({ parse: (v) => Number(v) });
  v8({ parse: (v) => Number(v) });
}

void main();