interface Opts {
  cwd: string;
}

interface C1 {
  exec: (command: string, options: Opts) => Promise<string>;
}
interface C2 {
  exec?: (command: string, options: Opts) => Promise<string>;
}
interface C3 {
  exec: (command: string) => Promise<string>;
}
interface C4 {
  exec?: (command: string) => Promise<string>;
}
interface C5 {
  cb: () => void;
}
interface C6 {
  cb?: () => void;
}

export function call1(c: C1): void {
  void c.exec("x", { cwd: "/" });
}

export function call2(c: C2): void {
  if (c.exec) {
    void c.exec("x", { cwd: "/" });
  }
}

export function call3(c: C3): void {
  void c.exec("x");
}

export function call4(c: C4): void {
  if (c.exec) {
    void c.exec("x");
  }
}

export function call5(c: C5): void {
  c.cb();
}

export function call6(c: C6): void {
  if (c.cb) {
    c.cb();
  }
}

function makePlain(): (a: string) => string {
  return (a) => a;
}

export function localVar(): void {
  const g: (a: string) => string = (a) => a;
  console.log(g("x"));
  const h = makePlain();
  console.log(h("y"));
}

export function localFn(): void {
  function inner(a: string): string {
    return a;
  }
  console.log(inner("z"));
}

export function main(): void {
  call1({ exec: async () => "" });
  call2({});
  call3({ exec: async () => "" });
  call4({});
  call5({ cb: () => {} });
  call6({});
  localVar();
  localFn();
}

void main();