#!/bin/sh
# rerun3: re-scan core/contracts/rpc after removing the global zod paths mapping
cd /data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zfull || exit 1
for n in core contracts rpc; do
  echo "START $n $(date +%H:%M:%S)"
  timeout 2400 node ../scriptc-try/node_modules/.bin/scriptc coverage entries/$n.ts > reports2/$n.cov.log 2>&1
  echo "DONE $n rc=$? $(date +%H:%M:%S)"
done
echo ALL DONE