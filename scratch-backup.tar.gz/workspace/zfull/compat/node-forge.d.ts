/* Types for node-forge 1.4.0 (the package ships no types). This file is
 * mapped by tsconfig "paths" ("node-forge" -> ./compat/node-forge.d.ts) so
 * scriptc resolves `import forge from "node-forge"` in
 * services/runtime-tools/appCaCert.ts to these declarations. No
 * `declare module` wrapper: a paths-mapped file IS the module. */
interface ForgeKey {
  n?: unknown;
}
interface ForgeKeyPair {
  publicKey: ForgeKey;
  privateKey: ForgeKey;
}
interface ForgeCertAttr {
  name?: string;
  shortName?: string;
  type?: string;
  value?: string;
}
interface ForgeCertExtension {
  name: string;
  cA?: boolean;
  critical?: boolean;
  keyCertSign?: boolean;
  cRLSign?: boolean;
  digitalSignature?: boolean;
  keyEncipherment?: boolean;
  serverAuth?: boolean;
  clientAuth?: boolean;
}
interface ForgeMessageDigest {
  update(msg: string): ForgeMessageDigest;
}
interface ForgeCertificate {
  publicKey: ForgeKey;
  serialNumber: string;
  validity: { notBefore: Date; notAfter: Date };
  setSubject(attrs: ForgeCertAttr[]): void;
  setIssuer(attrs: ForgeCertAttr[]): void;
  setExtensions(exts: ForgeCertExtension[]): void;
  sign(key: ForgeKey, md?: ForgeMessageDigest): void;
}
interface ForgeStatic {
  pki: {
    rsa: { generateKeyPair(bits: number): ForgeKeyPair };
    createCertificate(): ForgeCertificate;
    certificateToPem(cert: ForgeCertificate): string;
    privateKeyToPem(key: ForgeKey): string;
  };
  md: { sha256: { create(): ForgeMessageDigest } };
}
declare const forge: ForgeStatic;
export = forge;