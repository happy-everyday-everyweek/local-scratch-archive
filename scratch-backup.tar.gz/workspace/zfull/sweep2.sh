#!/bin/sh
# zfull coverage sweep 2 - all package entries in the zfull compile domain
WS=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa
SC="$WS/scriptc-try/node_modules/.bin/scriptc"
ZF="$WS/zfull"
mkdir -p "$ZF/reports2"
cd "$ZF" || exit 1
run() {
  name=$1
  echo "[$(date +%H:%M:%S)] START $name"
  timeout 2400 node "$SC" coverage "$ZF/entries/$name.ts" > "$ZF/reports2/$name.cov.log" 2>&1
  rc=$?
  echo "[$(date +%H:%M:%S)] DONE $name rc=$rc bytes=$(wc -c < "$ZF/reports2/$name.cov.log")"
}
for name in core contracts shared shared-types dynamic-workflow dynamic-workflow-runtime adapters bootstrap telemetry i18n cli tui services provider provider-node rpc client server zcode-server-cli model-option-map formal-proof node-repl-host; do
  run "$name"
done
echo "[$(date +%H:%M:%S)] SWEEP2 DONE"
