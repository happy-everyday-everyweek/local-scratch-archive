// foundation-mod.ts
function toDisposable(fn) {
  return { dispose: once(fn) };
}
function once(fn) {
  let called = false;
  return () => {
    if (!called) {
      called = true;
      fn();
    }
  };
}
var DisposableStore = class {
  items = [];
  isDisposed = false;
  add(item) {
    if (this.isDisposed) {
      console.warn("Adding to a disposed DisposableStore");
      item.dispose();
      return item;
    }
    if (!this.items.includes(item)) {
      this.items.push(item);
    }
    return item;
  }
  dispose() {
    if (this.isDisposed) {
      return;
    }
    this.isDisposed = true;
    for (const item of this.items) {
      item.dispose();
    }
    this.items.length = 0;
  }
};
var Event;
((Event2) => {
  Event2.None = () => ({ dispose() {
  } });
  function once2(event) {
    return (listener) => {
      let fired = false;
      const disposable = event((e) => {
        if (!fired) {
          fired = true;
          disposable.dispose();
          listener(e);
        }
      });
      return disposable;
    };
  }
  Event2.once = once2;
  function toPromise(event) {
    return new Promise((resolve) => once2(event)(resolve));
  }
  Event2.toPromise = toPromise;
  function filter(event, fn) {
    return (listener) => event((e) => {
      if (fn(e)) {
        listener(e);
      }
    });
  }
  Event2.filter = filter;
  function map(event, fn) {
    return (listener) => event((e) => listener(fn(e)));
  }
  Event2.map = map;
})(Event || (Event = {}));
var Emitter = class {
  listeners = [];
  disposed = false;
  options;
  constructor(options) {
    this.options = options;
  }
  get event() {
    return (listener) => {
      if (this.disposed) {
        return { dispose() {
        } };
      }
      const isFirst = this.listeners.length === 0;
      if (!this.listeners.includes(listener)) {
        this.listeners.push(listener);
      }
      if (isFirst) {
        this.options?.onWillAddFirstListener?.();
      }
      return toDisposable(() => {
        const index = this.listeners.indexOf(listener);
        if (index !== -1) {
          this.listeners.splice(index, 1);
        }
        if (this.listeners.length === 0) {
          this.options?.onDidRemoveLastListener?.();
        }
      });
    };
  }
  fire(event) {
    if (this.disposed) {
      return;
    }
    for (const listener of [...this.listeners]) {
      listener(event);
    }
  }
  dispose() {
    this.disposed = true;
    this.listeners.length = 0;
  }
};
var CancellationToken;
((CancellationToken2) => {
  CancellationToken2.None = {
    isCancellationRequested: false,
    onCancellationRequested: Event.None
  };
})(CancellationToken || (CancellationToken = {}));
var CancellationTokenSource = class {
  _token;
  emitter = new Emitter();
  _isCancelled = false;
  get token() {
    if (!this._token) {
      this._token = {
        isCancellationRequested: false,
        onCancellationRequested: this.emitter.event
      };
    }
    return this._token;
  }
  cancel() {
    if (!this._isCancelled) {
      this._isCancelled = true;
      this.emitter.fire();
    }
  }
  dispose() {
    this.emitter.dispose();
  }
};

// driver-mod.mts
var out = [];
function log(s) {
  out.push(s);
}
{
  const e = new Emitter();
  const a = (n) => log("A" + n);
  const b = (n) => log("B" + n);
  const da = e.event(a);
  const db = e.event(b);
  e.fire(1);
  da.dispose();
  e.fire(2);
  db.dispose();
  e.fire(3);
}
{
  const e = new Emitter();
  const f = (s) => log("D" + s);
  const d1 = e.event(f);
  const d2 = e.event(f);
  e.fire("x");
  d1.dispose();
  e.fire("y");
  d2.dispose();
}
{
  let firsts = 0;
  let lasts = 0;
  const e = new Emitter({
    onWillAddFirstListener: () => {
      firsts++;
      log("first" + firsts);
    },
    onDidRemoveLastListener: () => {
      lasts++;
      log("last" + lasts);
    }
  });
  const d1 = e.event((n) => log("L" + n));
  const d2 = e.event((n) => log("M" + n));
  e.fire(7);
  d1.dispose();
  d2.dispose();
  d2.dispose();
  log("counts " + firsts + ":" + lasts);
}
{
  const e = new Emitter();
  const d = e.event((n) => log("X" + n));
  e.dispose();
  e.fire(9);
  d.dispose();
}
{
  const warnLog = [];
  const origWarn = console.warn;
  console.warn = (...args) => {
    warnLog.push(args.join(" "));
  };
  const order = [];
  const mk = (name) => toDisposable(() => {
    order.push(name);
  });
  const store = new DisposableStore();
  const it1 = mk("i1");
  const it2 = mk("i2");
  store.add(it1);
  store.add(it1);
  store.add(it2);
  store.dispose();
  log("storeOrder " + order.join(","));
  log("storeWarnCount " + warnLog.length);
  const it3 = mk("i3");
  store.add(it3);
  log("afterDisposedAdd " + order.join(","));
  console.warn = origWarn;
}
{
  const e = new Emitter();
  const rec = [];
  Event.once(e.event)((n) => {
    rec.push("once" + n);
  });
  Event.filter(e.event, (n) => n % 2 === 0)((n) => {
    rec.push("f" + n);
  });
  e.fire(1);
  e.fire(2);
  e.fire(4);
  const d = Event.None(() => {
    rec.push("never");
  });
  d.dispose();
  log("events " + rec.join(","));
}
{
  const e = new Emitter();
  const p = Event.toPromise(e.event);
  e.fire("pt");
  log("promise " + await p);
}
{
  const cts = new CancellationTokenSource();
  const rec = [];
  cts.token.onCancellationRequested(() => rec.push("c1"));
  cts.token.onCancellationRequested(() => rec.push("c2"));
  cts.cancel();
  cts.cancel();
  cts.dispose();
  log("cts " + rec.join(","));
}
console.log("RPC_FOUNDATION_TRACE_BEGIN");
console.log(out.join("\n"));
console.log("RPC_FOUNDATION_TRACE_END");
