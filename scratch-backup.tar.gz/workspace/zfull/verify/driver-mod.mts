import {
  CancellationTokenSource,
  DisposableStore,
  Emitter,
  Event,
  toDisposable,
} from "./foundation-mod.ts";

const out: string[] = [];
function log(s: string): void {
  out.push(s);
}

// 1. basic emit + unsubscribe
{
  const e = new Emitter<number>();
  const a = (n: number) => log("A" + n);
  const b = (n: number) => log("B" + n);
  const da = e.event(a);
  const db = e.event(b);
  e.fire(1);
  da.dispose();
  e.fire(2);
  db.dispose();
  e.fire(3);
}

// 2. duplicate listener dedup
{
  const e = new Emitter<string>();
  const f = (s: string) => log("D" + s);
  const d1 = e.event(f);
  const d2 = e.event(f);
  e.fire("x");
  d1.dispose();
  e.fire("y");
  d2.dispose();
}

// 3. first/last listener callbacks + double dispose
{
  let firsts = 0;
  let lasts = 0;
  const e = new Emitter<number>({
    onWillAddFirstListener: () => {
      firsts++;
      log("first" + firsts);
    },
    onDidRemoveLastListener: () => {
      lasts++;
      log("last" + lasts);
    },
  });
  const d1 = e.event((n) => log("L" + n));
  const d2 = e.event((n) => log("M" + n));
  e.fire(7);
  d1.dispose();
  d2.dispose();
  d2.dispose();
  log("counts " + firsts + ":" + lasts);
}

// 4. disposed emitter
{
  const e = new Emitter<number>();
  const d = e.event((n) => log("X" + n));
  e.dispose();
  e.fire(9);
  d.dispose();
}

// 5. DisposableStore semantics
{
  const warnLog: string[] = [];
  const origWarn = console.warn;
  console.warn = (...args: unknown[]) => {
    warnLog.push(args.join(" "));
  };
  const order: string[] = [];
  const mk = (name: string) => toDisposable(() => { order.push(name); });
  const store = new DisposableStore();
  const it1 = mk("i1");
  const it2 = mk("i2");
  store.add(it1);
  store.add(it1);
  store.add(it2);
  store.dispose();
  log("storeOrder " + order.join(","));
  log("storeWarnCount " + warnLog.length);
  const it3 = mk("i3");
  store.add(it3);
  log("afterDisposedAdd " + order.join(","));
  console.warn = origWarn;
}

// 6. once/filter/None
{
  const e = new Emitter<number>();
  const rec: string[] = [];
  Event.once(e.event)((n) => { rec.push("once" + n); });
  Event.filter(e.event, (n) => n % 2 === 0)((n) => { rec.push("f" + n); });
  e.fire(1);
  e.fire(2);
  e.fire(4);
  const d = Event.None(() => { rec.push("never"); });
  d.dispose();
  log("events " + rec.join(","));
}

// 7. toPromise
{
  const e = new Emitter<string>();
  const p = Event.toPromise(e.event);
  e.fire("pt");
  log("promise " + (await p));
}

// 8. CancellationTokenSource
{
  const cts = new CancellationTokenSource();
  const rec: string[] = [];
  cts.token.onCancellationRequested(() => rec.push("c1"));
  cts.token.onCancellationRequested(() => rec.push("c2"));
  cts.cancel();
  cts.cancel();
  cts.dispose();
  log("cts " + rec.join(","));
}

console.log("RPC_FOUNDATION_TRACE_BEGIN");
console.log(out.join("\n"));
console.log("RPC_FOUNDATION_TRACE_END");