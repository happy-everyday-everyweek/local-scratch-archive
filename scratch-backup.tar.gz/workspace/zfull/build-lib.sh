#!/bin/sh
# zfull build-lib.sh <profile.json> [extra args]
# Builds the profile's entry module to an aarch64-linux-android static archive.
cd "$(dirname "$0")" || exit 1
export SCRIPTC_CC=zigcc
export SCRIPTC_TARGET=aarch64-linux-android
export ANDROID_NDK_ROOT=/root/ndk/android-ndk-r27c
exec node ../scriptc-try/node_modules/.bin/scriptc build --lib --profile "$@"