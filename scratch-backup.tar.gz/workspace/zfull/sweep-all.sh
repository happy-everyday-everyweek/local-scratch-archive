#!/bin/sh
# zfull coverage sweep - full ZCode (non-UI) package coverage survey batch 1
WS=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa
SC="$WS/scriptc-try/node_modules/.bin/scriptc"
Z="$WS/ZCode"
OUT="$WS/zfull/reports"
cd "$WS/zcode-port" || exit 1
run() {
  name=$1; file=$2
  echo "[$(date +%H:%M:%S)] START $name"
  timeout 2400 node "$SC" coverage "$file" > "$OUT/$name.cov.log" 2>&1
  rc=$?
  echo "[$(date +%H:%M:%S)] DONE $name rc=$rc bytes=$(wc -c < "$OUT/$name.cov.log")"
}
run 01-core "$Z/apps/zcode-cli/packages/core/src/index.ts"
run 02-contracts "$Z/apps/zcode-cli/packages/contracts/src/index.ts"
run 03-shared "$Z/packages/shared/src/index.ts"
run 04-shared-types "$Z/apps/zcode-cli/packages/shared-types/src/index.ts"
run 05-dynamic-workflow "$Z/apps/zcode-cli/packages/dynamic-workflow/src/index.ts"
run 06-dynamic-workflow-runtime "$Z/apps/zcode-cli/packages/dynamic-workflow-runtime/src/index.ts"
run 07-adapters "$Z/apps/zcode-cli/packages/adapters/src/index.ts"
run 08-bootstrap "$Z/apps/zcode-cli/packages/bootstrap/src/index.ts"
run 09-telemetry "$Z/apps/zcode-cli/packages/telemetry/src/index.ts"
run 10-i18n "$Z/apps/zcode-cli/packages/i18n/src/index.ts"
run 11-cli "$Z/apps/zcode-cli/packages/cli/src/index.ts"
run 12-tui "$Z/apps/zcode-cli/packages/tui/src/index.ts"
run 13-services "$Z/packages/services/src/index.ts"
run 14-provider "$Z/packages/provider/src/index.ts"
run 15-provider-node "$Z/packages/provider-node/src/index.ts"
run 16-rpc "$Z/packages/rpc/src/index.ts"
run 17-client "$Z/packages/client/src/index.ts"
run 18-server "$Z/packages/server/src/index.ts"
run 19-zcode-server-cli "$Z/packages/zcode-server-cli/src/index.ts"
run 20-model-option-map "$Z/packages/model-option-map/src/index.ts"
echo "[$(date +%H:%M:%S)] SWEEP DONE"
