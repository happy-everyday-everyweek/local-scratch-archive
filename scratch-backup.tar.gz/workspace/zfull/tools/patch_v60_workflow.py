# v5.18: add the apk-aarch64 job (hand-rolled APK: javac + d8 + aapt2 +
# zipalign + apksigner; bundles the freshly linked libzcodecore.so with the
# JNI shim). Inserted right before "coverage-sweep:".
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

JOB = '''  apk-aarch64:
    runs-on: ubuntu-latest
    timeout-minutes: 90
    steps:
      - name: Checkout repo
        uses: actions/checkout@v4
      - name: Setup Node.js 24
        uses: actions/setup-node@v4
        with:
          node-version: '24'
      - name: Setup JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - name: Clone ZCode v3.14.3 and apply adaptation patch
        run: |
          git clone --depth 1 --branch v3.14.3 https://github.com/zai-org/ZCode.git ZCode
          cd ZCode
          git apply ../patches/zcode-adaptations.patch
          cd ..
      - name: Install scriptc (npm)
        run: |
          mkdir -p scriptc-try
          cd scriptc-try
          npm init -y >/dev/null 2>&1 || true
          npm install scriptc@0.1.7 --no-audit --no-fund
          cd ..
      - name: Install minimal type deps (Node types + undici for shims)
        run: |
          mkdir -p zfull/node_modules/@types /tmp/nt
          cd /tmp/nt
          npm init -y >/dev/null 2>&1 || true
          npm install --no-audit --no-fund @types/node@25.6.0
          cd "$GITHUB_WORKSPACE"
          ln -sfn /tmp/nt/node_modules/@types/node zfull/node_modules/@types/node
          ln -sfn /tmp/nt/node_modules/undici-types zfull/node_modules/undici-types
      - name: Install zig (x86_64 linux)
        run: |
          curl -fsSL -o /tmp/zig.tar.xz https://ziglang.org/download/0.16.0/zig-x86_64-linux-0.16.0.tar.xz
          tar -xf /tmp/zig.tar.xz -C /tmp
          ZIGDIR="$(ls -d /tmp/zig-* | head -n1)"
          echo "$ZIGDIR" >> "$GITHUB_PATH"
          "$ZIGDIR/zig" version
      - name: Install Android NDK r27c
        run: |
          curl -fsSL -o /tmp/ndk.zip https://dl.google.com/android/repository/android-ndk-r27c-linux.zip
          unzip -q /tmp/ndk.zip -d /tmp/ndk
          echo "ANDROID_NDK_ROOT=/tmp/ndk/android-ndk-r27c" >> "$GITHUB_ENV"
      - name: Install Android SDK components (cmdline-tools)
        run: |
          mkdir -p /tmp/android
          curl -fsSL -o /tmp/android/cmdline.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
          unzip -q /tmp/android/cmdline.zip -d /tmp/android/cmdline
          yes | /tmp/android/cmdline/cmdline-tools/bin/sdkmanager --sdk_root=/tmp/android --licenses >/dev/null 2>&1 || true
          yes | /tmp/android/cmdline/cmdline-tools/bin/sdkmanager --sdk_root=/tmp/android "platforms;android-34" "build-tools;34.0.0" >/dev/null 2>&1
          ls /tmp/android/build-tools/ /tmp/android/platforms/
      - name: Build rpc static archive
        run: |
          cd zfull
          mkdir -p out
          SCRIPTC_CC=zigcc SCRIPTC_TARGET=aarch64-linux-android node ../scriptc-try/node_modules/.bin/scriptc build --lib --profile profiles/rpc.profile.json
      - name: Link libzcodecore.so (runtime + JNI shim)
        run: |
          WS=$GITHUB_WORKSPACE
          NDK=/tmp/ndk/android-ndk-r27c
          TC=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin
          SYSROOT="$NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot"
          cd $WS/zfull/profiles
          $TC/ld.lld -r --whole-archive .scriptc/rpc-probe.lib.a -o /tmp/combined.o
          $TC/clang --target=aarch64-linux-android26 --sysroot="$SYSROOT" -O1 -c $WS/android/app/com/zcode/rpc/zcode_android_jni.c -o /tmp/jni.o
          $TC/clang --target=aarch64-linux-android26 --sysroot="$SYSROOT" -fuse-ld=lld -shared -rtlib=compiler-rt --unwindlib=none -Wl,-Bsymbolic -o /tmp/libzcodecore.so /tmp/jni.o /tmp/combined.o -lc -lm -llog
          ls -la /tmp/libzcodecore.so
          $TC/llvm-readelf -sW /tmp/libzcodecore.so | grep -E 'Java_|zr_' | head -16
      - name: Build APK (javac + d8 + aapt2 + zipalign + apksigner)
        run: |
          WS=$GITHUB_WORKSPACE
          BT=/tmp/android/build-tools/34.0.0
          AJ=/tmp/android/platforms/android-34/android.jar
          mkdir -p /tmp/apk/classes /tmp/apk/dex
          javac -source 17 -target 17 -classpath "$AJ" -d /tmp/apk/classes $WS/android/app/com/zcode/rpc/MainActivity.java $WS/android/app/com/zcode/rpc/NativeCore.java
          "$BT/d8" --min-api 26 --lib "$AJ" --output /tmp/apk/dex /tmp/apk/classes/com/zcode/rpc/*.class
          "$BT/aapt2" link -I "$AJ" --manifest $WS/android/AndroidManifest.xml --min-sdk-version 26 --target-sdk-version 34 -o /tmp/apk/app.unsigned.apk
          python3 - <<'PY'
          import zipfile
          zf = zipfile.ZipFile('/tmp/apk/app.unsigned.apk', 'a')
          zf.write('/tmp/apk/dex/classes.dex', 'classes.dex')
          zf.write('/tmp/libzcodecore.so', 'lib/arm64-v8a/libzcodecore.so')
          zf.close()
          print('zip updated')
          PY
          "$BT/zipalign" -f 4 /tmp/apk/app.unsigned.apk /tmp/apk/app.aligned.apk
          keytool -genkeypair -keystore /tmp/apk/debug.keystore -alias androiddebugkey -storepass android -keypass android -dname "CN=Android Debug,O=Android,C=US" -keyalg RSA -keysize 2048 -validity 10000
          "$BT/apksigner" sign --ks /tmp/apk/debug.keystore --ks-pass pass:android --key-pass pass:android --ks-key-alias androiddebugkey --out /tmp/apk/zcode-rpc-debug.apk /tmp/apk/app.aligned.apk
          ls -la /tmp/apk/*.apk
      - name: Upload APK
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: apk-aarch64-zcode-rpc
          path: /tmp/apk/zcode-rpc-debug.apk
          if-no-files-found: warn
'''.split('\n')

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
inserted = 0
for ln in lines:
    if ln == '  coverage-sweep:':
        out.extend(JOB)
        inserted += 1
    out.append(ln)

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))
v = io.open(P, encoding='utf-8').read()
print('inserted jobs:', inserted)
print('apk job count:', v.count('apk-aarch64:'))