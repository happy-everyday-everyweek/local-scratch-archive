# Fix A (zod vendor, both copies): core.ts:27 `let _E = "captureStackTrace" in Error ? ...`
# fails the module-cycle inert-top-level gate (a BinaryExpression `in` needs both
# sides primitive-typed; `Error` is not). `typeof Error.captureStackTrace === "function"`
# is inert (COERCING_FREE `===`, dts-rooted property access) and matches the
# actual intent (the code CALLS captureStackTrace later, so it needs a function).
# Fix B (adaptations patch): the telemetry hunk's `Timeout` global no longer
# exists under the workspace's @types/node, so the native tsc failed (TS2304).
# Use `ReturnType<typeof setTimeout>` — accepted by both toolchains.
import io

BASE = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa'

OLD_A = ('let _E: (ErrorConstructor & { stackTraceLimit?: number }) | null = '
         '"captureStackTrace" in Error ? Error : null;')
NEW_A = ('let _E: (ErrorConstructor & { stackTraceLimit?: number }) | null = '
         'typeof Error.captureStackTrace === "function" ? Error : null;')

for rel in ('zgh/zfull/vendor/zod/src/v4/core/core.ts',
            'zfull/vendor/zod/src/v4/core/core.ts'):
    p = BASE + '/' + rel
    s = io.open(p, encoding='utf-8').read()
    assert s.count(OLD_A) == 1, (rel, s.count(OLD_A))
    io.open(p, 'w', encoding='utf-8').write(s.replace(OLD_A, NEW_A, 1))
    print('fixed core.ts:', rel)

OLD_B = '+  let timeout: Timeout | undefined;'
NEW_B = '+  let timeout: ReturnType<typeof setTimeout> | undefined;'
p2 = BASE + '/zgh/patches/zcode-adaptations.patch'
s2 = io.open(p2, encoding='utf-8').read()
assert s2.count(OLD_B) == 1, ('patch', s2.count(OLD_B))
io.open(p2, 'w', encoding='utf-8').write(s2.replace(OLD_B, NEW_B, 1))
print('fixed telemetry hunk in patch')