# v5.28: add zod-js2-probe (named-import variant) to lib-matrix.
import io
import shutil

BASE = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa'

shutil.copyfile(BASE + '/zfull/entries/zod-js2-probe.ts', BASE + '/zgh/zfull/entries/zod-js2-probe.ts')
shutil.copyfile(BASE + '/zfull/profiles/zod-js2-probe.profile.json', BASE + '/zgh/zfull/profiles/zod-js2-probe.profile.json')
print('files synced to zgh')

P = BASE + '/zgh/.github/workflows/build.yml'
s = io.open(P, encoding='utf-8').read()
assert 'zod-js2-probe' not in s, 'workflow already patched'
a = '          run_one zod-js-probe profiles/zod-js-probe.profile.json || true\n'
assert s.count(a) == 1, ('anchor', s.count(a))
s = s.replace(a, a + '          run_one zod-js2-probe profiles/zod-js2-probe.profile.json || true\n', 1)
io.open(P, 'w', encoding='utf-8').write(s)
print('workflow patched: zod-js2-probe added')