# Insert a diagnostics patch step into coverage-sweep, right after its
# "Install scriptc (npm)" step (the second occurrence of the install line).
# The step patches lowerer.js so the badType final throw prints the source
# file + position + type text before crashing.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

DIAG = '''      - name: Patch scriptc for diagnostics (locate badType source)
        run: |
          python3 - <<'PYEOF'
          import io
          p = "scriptc-try/node_modules/@scriptc/compiler/dist/frontend/lowering/lowerer.js"
          s = io.open(p, encoding="utf-8").read().split(chr(10))
          assert "throw new PoisonError();" in s[4221], s[4221]
          s.insert(4221, '        try { console.error("[scriptc-diag] badType at", node && node.getSourceFile ? node.getSourceFile().fileName : "?", node && node.getStart ? node.getStart() : "?", this.checker.typeToString(type)); } catch (e) {}')
          io.open(p, "w", encoding="utf-8").write(chr(10).join(s))
          print("diag inserted")
          PYEOF'''.split('\n')

INSTALL_LINE = 'npm install scriptc@0.1.7 --no-audit --no-fund'

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
seen = 0
pending = None
for ln in lines:
    out.append(ln)
    if pending is not None and ln.strip() == 'cd ..':
        out.extend(pending)
        pending = None
        continue
    if INSTALL_LINE in ln and 'name:' not in ln:
        seen += 1
        if seen == 2:
            pending = DIAG

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))
v = io.open(P, encoding='utf-8').read()
print('installs seen:', seen)
print('diag steps:', v.count('Patch scriptc for diagnostics'))
print('PYEOF count:', v.count('PYEOF'))