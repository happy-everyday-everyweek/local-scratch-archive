# v5.26: in lib-matrix, build the ZCode workspace dists before the library
# experiments. Workspace packages (@zcode/*) are evaluated by the library
# lane's static-or-refuse rule and currently fail eligibility with "ships
# no own .d.ts declaration surface" because their dist/ folders are never
# built; `pnpm -r build` produces the real dist (.d.ts + JS). Also drops a
# copy of the zod vendor note into the log dir for completeness.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'
s = io.open(P, encoding='utf-8').read()
assert 'Build ZCode dists' not in s, 'workflow already patched?'

anchor = '      - name: Link zod into zfull\n'
assert s.count(anchor) == 1, ('lib-matrix anchor', s.count(anchor))

STEP = '''      - name: Build ZCode dists (workspace package eligibility)
        run: |
          mkdir -p lib-logs
          cd ZCode
          pnpm -r build > ../lib-logs/zcode-build.log 2>&1 || true
          tail -8 ../lib-logs/zcode-build.log || true
          cd ..
'''

s = s.replace(anchor, STEP + anchor, 1)
io.open(P, 'w', encoding='utf-8').write(s)

v = io.open(P, encoding='utf-8').read()
print('build-dists steps:', v.count('Build ZCode dists'))