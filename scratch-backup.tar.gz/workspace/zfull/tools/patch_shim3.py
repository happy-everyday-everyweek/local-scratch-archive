p = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zfull/shims/dom-globals.ts'
s = open(p).read()


def rep(old, new):
    global s
    assert old in s, 'MISSING: ' + old[:60]
    s = s.replace(old, new)


rep('''    remove(): void;
    scrollIntoView(options?: unknown): void;
  }''', '''    remove(): void;
    scrollIntoView(options?: unknown): void;
    readonly children?: Element[];
    readonly isConnected?: boolean;
    readonly clientWidth?: number;
    readonly clientHeight?: number;
    append(node: unknown): void;
  }''')

rep('''    click(): void;
    focus(): void;
  }''', '''    click(): void;
    focus(): void;
    setAttribute(name: string, value: string): void;
  }''')

rep('''    readonly value?: string;
    checked?: boolean;
  }''', '''    readonly value?: string;
    checked?: boolean;
    disabled?: boolean;
  }''')

rep('''    createElement(tag: string): HTMLElement;
    querySelectorAll(selectors: string): Element[];''', '''    createElement(tag: string): HTMLElement;
    querySelectorAll(selectors: string): Element[];
    elementsFromPoint(x: number, y: number): Element[];''')

open(p, 'w').write(s)
s2 = open(p).read()
print('shim v3 written, len =', len(s2))
for name in ['children', 'isConnected', 'clientWidth', 'clientHeight', 'append', 'setAttribute', 'disabled', 'elementsFromPoint']:
    print(name, ':', name in s2)