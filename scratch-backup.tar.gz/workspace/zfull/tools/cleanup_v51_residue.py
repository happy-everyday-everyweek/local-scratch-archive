# Second-pass cleanup: the previous unpatch removed only the first three lines
# of each jsx step (it stopped at the `<<'PYEOF'` opener). This script removes
# the leftover python body of each block: starting at the line containing the
# tsc-codes.js path (plus the stray `import io` line just above it), through
# the closing `PYEOF` line.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
mode = 0  # 1 = skipping residue
removed = 0

for ln in lines:
    s = ln.strip()
    if mode == 0:
        if 'p = "scriptc-try/node_modules/@scriptc/compiler/dist/frontend/tsc-codes.js"' in ln:
            # drop the just-appended stray 'import io' line if present
            if out and out[-1].strip() == 'import io':
                out.pop()
            mode = 1
            removed += 1
            continue
        out.append(ln)
    else:
        if s == 'PYEOF':
            mode = 0
        continue

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))

v = io.open(P, encoding='utf-8').read()
print('residue blocks removed:', removed)
print('jsx refs remain:', v.count('jsx'))
print('PYEOF refs remain:', v.count('PYEOF'))
print('tsc-codes refs remain:', v.count('tsc-codes'))