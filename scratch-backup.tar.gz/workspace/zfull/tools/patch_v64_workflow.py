# v5.22: add ci/android_ucontext_stubs.c to both link lines (compile step +
# object) so the three fail-fast ucontext traps resolve the references
# inside the re-included scr_async.c. Four edits, mirroring the v5.21
# child-stubs wiring.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'
s = io.open(P, encoding='utf-8').read()
assert 'ucontext_stubs' not in s, 'workflow already patched?'

# 1) lib segment: compile the ucontext stubs right after the child stubs
lib_compile_old = ('          $TC/clang --target=aarch64-linux-android26 '
                   '--sysroot="$NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot" '
                   '-O1 -fPIC -c "$GITHUB_WORKSPACE/ci/android_child_stubs.c" -o /tmp/child_stubs.o\n')
lib_compile_new = lib_compile_old + (
    '          $TC/clang --target=aarch64-linux-android26 '
    '--sysroot="$NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot" '
    '-O1 -fPIC -c "$GITHUB_WORKSPACE/ci/android_ucontext_stubs.c" -o /tmp/ucontext_stubs.o\n')
assert s.count(lib_compile_old) == 1, ('lib compile anchor', s.count(lib_compile_old))
s = s.replace(lib_compile_old, lib_compile_new, 1)

# 2) lib segment: add the ucontext stubs object to the link line
lib_link_old = '-o ../out/libzcode_rpc.so /tmp/child_stubs.o /tmp/combined.o -lc -lm'
lib_link_new = '-o ../out/libzcode_rpc.so /tmp/child_stubs.o /tmp/ucontext_stubs.o /tmp/combined.o -lc -lm'
assert s.count(lib_link_old) == 1, ('lib link anchor', s.count(lib_link_old))
s = s.replace(lib_link_old, lib_link_new, 1)

# 3) apk segment: compile the ucontext stubs right after the child stubs
apk_compile_old = ('          $TC/clang --target=aarch64-linux-android26 '
                   '--sysroot="$SYSROOT" '
                   '-O1 -fPIC -c $WS/ci/android_child_stubs.c -o /tmp/child_stubs.o\n')
apk_compile_new = apk_compile_old + (
    '          $TC/clang --target=aarch64-linux-android26 --sysroot="$SYSROOT" '
    '-O1 -fPIC -c $WS/ci/android_ucontext_stubs.c -o /tmp/ucontext_stubs.o\n')
assert s.count(apk_compile_old) == 1, ('apk compile anchor', s.count(apk_compile_old))
s = s.replace(apk_compile_old, apk_compile_new, 1)

# 4) apk segment: add the ucontext stubs object to the link line
apk_link_old = '-o /tmp/libzcodecore.so /tmp/jni.o /tmp/child_stubs.o /tmp/combined.o -lc -lm -llog'
apk_link_new = '-o /tmp/libzcodecore.so /tmp/jni.o /tmp/child_stubs.o /tmp/ucontext_stubs.o /tmp/combined.o -lc -lm -llog'
assert s.count(apk_link_old) == 1, ('apk link anchor', s.count(apk_link_old))
s = s.replace(apk_link_old, apk_link_new, 1)

io.open(P, 'w', encoding='utf-8').write(s)
v = io.open(P, encoding='utf-8').read()
print('ucontext_stubs refs:', v.count('ucontext_stubs'))
print('child_stubs refs:', v.count('child_stubs'))