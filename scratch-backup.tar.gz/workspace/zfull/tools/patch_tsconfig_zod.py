# Add the zod -> vendored-源码 path mapping to both tsconfig copies
# (zgh = CI/publish tree with relative paths; zfull = local copy). The zod
# package's shipped .cjs distribution trips SC1013 (require-order), so the
# library lane's official hint applies: vendor the code as project modules.
import io
import json

BASE = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa'
LINE = '      "zod": ["./vendor/zod/src/index.ts"],\n'

for rel in ('zgh/zfull/tsconfig.json', 'zfull/tsconfig.json'):
    p = BASE + '/' + rel
    s = io.open(p, encoding='utf-8').read()
    anchor = '    "paths": {\n'
    assert s.count(anchor) == 1, (rel, s.count(anchor))
    assert '"zod":' not in s, rel + ' already patched'
    s = s.replace(anchor, anchor + LINE, 1)
    io.open(p, 'w', encoding='utf-8').write(s)
    json.loads(io.open(p, encoding='utf-8').read())
    print('patched + json-ok:', rel)