# Patch zgh/.github/workflows/build.yml for v5:
# - link undici-types next to @types/node (shim imports import("undici-types"))
# Line-level edit, indent derived from the anchor line.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

s = io.open(P, encoding='utf-8').read()
lines = s.split('\n')
out = []
changed = []

for i, ln in enumerate(lines):
    if 'name: Link @types/node' in ln and 'undici-types' not in ln:
        ln = ln.replace('Link @types/node (so scriptc adopts real Node types)',
                        'Link @types/node + undici-types (so scriptc adopts real Node types)')
        changed.append('renamed step title (line %d)' % (i + 1))
    out.append(ln)
    if 'ln -sfn' in ln and '@types/node' in ln and 'undici' not in ln:
        indent = ln[:len(ln) - len(ln.lstrip())]
        out.append(indent + 'test -d "$PWD/ZCode/node_modules/undici-types" || { echo \'undici-types missing\'; exit 1; }')
        out.append(indent + 'ln -sfn "$PWD/ZCode/node_modules/undici-types" zfull/node_modules/undici-types')
        changed.append('inserted undici-types link after line %d' % (i + 1))
    if ln.strip().startswith('ls -la zfull/node_modules/@types/') and 'undici' not in ln:
        indent = ln[:len(ln) - len(ln.lstrip())]
        out.append(indent + 'ls -la zfull/node_modules/undici-types/ 2>/dev/null || true')
        changed.append('added undici ls after line %d' % (i + 1))

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))
print('CHANGED:', changed if changed else 'NONE')

# verify
s2 = io.open(P, encoding='utf-8').read()
for probe in ['undici-types (so scriptc', 'ln -sfn "$PWD/ZCode/node_modules/undici-types" zfull/node_modules/undici-types']:
    print('OK' if probe in s2 else 'MISSING', '->', probe[:70])
