# v5.15: fix lib job upload path (artifact lives in zfull/profiles/.scriptc/)
# and add a "Link aarch64 shared library" step after the archive build.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

LINK_BLOCK = '''      - name: Link aarch64 shared library (.so)
        run: |
          NDK=/tmp/ndk/android-ndk-r27c
          TC=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin
          cd zfull/profiles
          $TC/ld.lld -r .scriptc/rpc-probe.lib.a -o /tmp/combined.o
          $TC/clang --target=aarch64-linux-android26 --sysroot="$NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot" -fuse-ld=lld -shared -rtlib=compiler-rt --unwindlib=none -Wl,-Bsymbolic -o ../out/libzcode_rpc.so /tmp/combined.o -lc -lm
          echo '--- dynamic section ---'
          $TC/llvm-readelf -d ../out/libzcode_rpc.so | head -16 || true
          echo '--- exported symbols ---'
          $TC/llvm-nm -D ../out/libzcode_rpc.so 2>/dev/null | head -24 || true
          ls -la ../out/
'''.split('\n')

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
i = 0
changed = []
while i < len(lines):
    ln = lines[i]
    out.append(ln)
    if ln.strip() == "find . -name '*.lib.a' -o -name '*.a' | head":
        out.extend(LINK_BLOCK)
        changed.append('link block after find-line %d' % (i + 1))
    if ln == '            zfull/.scriptc/':
        out.pop()
        out.append('            zfull/profiles/.scriptc/')
        changed.append('upload path fixed at line %d' % (i + 1))
    i += 1

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))
v = io.open(P, encoding='utf-8').read()
print('changes:', changed)
print('profiles/.scriptc in upload:', 'zfull/profiles/.scriptc/' in v)
print('link block count:', v.count('Link aarch64 shared library'))