# v5.27a: add the zod-js comparison experiment.
# (1) Both tsconfig copies gain "zod-js" -> vendored ESM dist (JS) plus
#     allowJs (the dist has no .d.ts — inference mode).
# (2) lib-matrix builds zod-js-probe alongside zod-probe.
import io
import json

BASE = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa'

for rel in ('zgh/zfull/tsconfig.json', 'zfull/tsconfig.json'):
    p = BASE + '/' + rel
    s = io.open(p, encoding='utf-8').read()
    assert '"zod-js"' not in s, rel + ' already patched'
    a1 = '      "zod": ["./vendor/zod/src/index.ts"],\n'
    assert s.count(a1) == 1, (rel, 'zod anchor')
    s = s.replace(a1, a1 + '      "zod-js": ["./vendor/zod-js/index.js"],\n', 1)
    a2 = '    "strict": true,\n'
    assert s.count(a2) == 1, (rel, 'strict anchor')
    s = s.replace(a2, a2 + '    "allowJs": true,\n', 1)
    io.open(p, 'w', encoding='utf-8').write(s)
    json.loads(io.open(p, encoding='utf-8').read())
    print('tsconfig patched:', rel)

P = BASE + '/zgh/.github/workflows/build.yml'
s = io.open(P, encoding='utf-8').read()
assert 'zod-js-probe' not in s, 'workflow already patched'
a = '          run_one zod-probe profiles/zod-probe.profile.json || true\n'
assert s.count(a) == 1, ('run_one anchor', s.count(a))
s = s.replace(a, a + '          run_one zod-js-probe profiles/zod-js-probe.profile.json || true\n', 1)
io.open(P, 'w', encoding='utf-8').write(s)
print('workflow patched: zod-js-probe added to lib-matrix')