# Insert "Install ZCode workspace deps (pnpm)" + "Re-link" steps into the
# emit-c job, right after its "Install and link minimal type deps" step.
# The emit jobs previously had no node_modules, so zod & friends failed to
# resolve ("nothing installed resolves it"); coverage-sweep installs deps and
# resolves fine.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

BLOCK = '''      - name: Install ZCode workspace deps (pnpm)
        run: |
          npm i -g pnpm@10.33.2 >/dev/null 2>&1 || true
          cd ZCode
          pnpm install --ignore-scripts --no-frozen-lockfile
          cd ..
      - name: Re-link @types/node + undici-types from ZCode node_modules
        run: |
          ln -sfn "$PWD/ZCode/node_modules/@types/node" zfull/node_modules/@types/node
          ln -sfn "$PWD/ZCode/node_modules/undici-types" zfull/node_modules/undici-types
          ls -la zfull/node_modules/
'''.split('\n')

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
inserted = 0
for ln in lines:
    out.append(ln)
    if 'ls -la zfull/node_modules/ zfull/node_modules/@types/' in ln:
        out.extend(BLOCK)
        inserted += 1

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))
v = io.open(P, encoding='utf-8').read()
print('inserted blocks:', inserted)
print('pnpm install count:', v.count('pnpm install --ignore-scripts --no-frozen-lockfile'))