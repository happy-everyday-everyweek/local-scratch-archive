# Scan vendored zod for module-level import cycles (SCCs) and, per member,
# flag top-level statements that look "non-inert" (would trip SC1016's
# declaration-only gate). Heuristic pass for review — not exact.
import io
import os
import re
import sys

SRC = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/zfull/vendor/zod/src'

files = []
for dirpath, _, filenames in os.walk(SRC):
    for fn in filenames:
        if fn.endswith('.ts'):
            files.append(os.path.normpath(os.path.join(dirpath, fn)))

fileset = set(files)

def resolve(spec, base):
    if not spec.startswith('.'):
        return None
    p = os.path.normpath(os.path.join(os.path.dirname(base), spec))
    for cand in (p[:-3] + '.ts' if p.endswith('.js') else p, p + '.ts', p + '/index.ts'):
        if cand in fileset:
            return cand
    return None

edges = {}
noninert = {}
imp_re = re.compile(r'^\s*(?:import|export)\s[^;\n]*?from\s+"([^"]+)"')
for f in files:
    text = io.open(f, encoding='utf-8').read()
    deps = set()
    # whole-statement `import type` and `export type` are erased
    for m in re.finditer(r'^(import|export)\s+(type\s+)?(?:[^;\n]*?)\bfrom\s+"([^"]+)"', text, re.M):
        if m.group(2):
            continue
        d = resolve(m.group(3), f)
        if d:
            deps.add(d)
    # side-effect imports (import "x") count as edges
    for m in re.finditer(r'^import\s+"([^"]+)"', text, re.M):
        d = resolve(m.group(1), f)
        if d:
            deps.add(d)
    edges[f] = deps
    # top-level lines that don't start with a declaration keyword
    bad = []
    for i, ln in enumerate(text.split('\n'), 1):
        if not ln or ln[0] in ' \t/}\n#*':
            continue
        s = ln.strip()
        if (s.startswith(('import ', 'export ', 'function ', 'interface ', 'type ', 'declare ', 'class ', 'enum ', 'namespace ', 'async function'))
                or s.startswith('//') or s.startswith('/*') or s.startswith('*')):
            continue
        if re.match(r'(let|const|var)\s', s):
            if '=' in s and re.search(r'[\(\[\{\?]|typeof |new ', s.split('=', 1)[1]):
                bad.append((i, s[:100]))
            continue
        bad.append((i, s[:100]))
    noninert[f] = bad

# Tarjan SCC
index = {}
low = {}
on = set()
stack = []
sccs = []
counter = [0]
def strongconnect(v):
    index[v] = counter[0]
    low[v] = counter[0]
    counter[0] += 1
    stack.append(v)
    on.add(v)
    for w in edges.get(v, ()):
        if w not in index:
            strongconnect(w)
            low[v] = min(low[v], low[w])
        elif w in on:
            low[v] = min(low[v], index[w])
    if low[v] == index[v]:
        comp = []
        while True:
            w = stack.pop()
            on.discard(w)
            comp.append(w)
            if w == v:
                break
        sccs.append(comp)

for f in files:
    if f not in index:
        strongconnect(f)

print('total modules:', len(files))
cycles = [c for c in sccs if len(c) > 1]
print('cycles (SCC>1):', len(cycles))
for n, comp in enumerate(cycles, 1):
    print('\n=== CYCLE %d (%d modules) ===' % (n, len(comp)))
    for m in comp:
        rel = m[len(SRC) + 1:]
        flags = noninert.get(m, [])
        print('  -', rel, '| non-inert candidates:', len(flags))
        for i, s in flags[:8]:
            print('      %5d: %s' % (i, s))