# Rewrite @zcode/zcode-cua path mappings from .d.ts to .js so scriptc sees a
# runtime implementation (the package ships both; the .js files are the code).
import io, re, json

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zfull/tsconfig.json'
s = io.open(P, encoding='utf-8').read()
new, n = re.subn(r'(zcode-cua/(?:[a-z-]+))\.d\.ts', r'\1.js', s)
io.open(P, 'w', encoding='utf-8').write(new)
print('replacements:', n)

chk = json.load(io.open(P, encoding='utf-8'))
paths = chk['compilerOptions']['paths']
mine = {k: v[0].split('/')[-1] for k, v in paths.items() if 'zcode-cua' in k}
for k in sorted(mine):
    print(k, '->', mine[k])