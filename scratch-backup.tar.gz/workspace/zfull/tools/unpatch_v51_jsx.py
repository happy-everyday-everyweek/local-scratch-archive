# Remove the v5.1 "Patch scriptc to adopt tsconfig jsx" steps from the workflow.
# That approach hit scriptc's InternalCompilerError (serializeOptions does not
# handle the enum-valued 'jsx' option), so it is abandoned in favor of the
# tui type-facade (zfull/compat/tui.ts). This script deletes the step blocks.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
skipping = False
removed = 0

for ln in lines:
    if 'name: Patch scriptc to adopt tsconfig jsx' in ln:
        skipping = True
        removed += 1
        continue
    if skipping:
        if 'PYEOF' in ln:
            skipping = False
        continue
    out.append(ln)

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))

v = io.open(P, encoding='utf-8').read()
print('removed blocks:', removed)
print('jsx refs remain:', v.count('jsx'))
print('PYEOF refs remain:', v.count('PYEOF'))