# Prepare the zod-js vendor: the shipped ESM dist compiled as plain project
# JS (no .d.ts — inference mode). Steps: strip all .d.ts (so tsgo infers
# from the JS instead of reading declarations), break the core<->util cycle
# edge the same way as the TS vendor (runtime read of the global slot), then
# mirror the tree to zfull/vendor/zod-js.
import io
import os
import shutil

BASE = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa'
DST = BASE + '/zgh/zfull/vendor/zod-js'

removed = 0
for root, dirs, files in os.walk(DST):
    for fn in files:
        if fn.endswith('.d.ts'):
            os.remove(os.path.join(root, fn))
            removed += 1
print('removed .d.ts:', removed)

p = DST + '/v4/core/util.js'
s = io.open(p, encoding='utf-8').read()
o1 = 'import { globalConfig } from "./core.js";\n'
assert s.count(o1) == 1, s.count(o1)
s = s.replace(o1, '', 1)
o2 = '    if (globalConfig.jitless) {'
assert s.count(o2) == 1, s.count(o2)
s = s.replace(o2, '    if (globalThis.__zod_globalConfig?.jitless) {', 1)
io.open(p, 'w', encoding='utf-8').write(s)
print('util.js cycle edge fixed')

dst2 = BASE + '/zfull/vendor/zod-js'
if os.path.isdir(dst2):
    shutil.rmtree(dst2)
shutil.copytree(DST, dst2)
print('mirrored to zfull/vendor/zod-js:', sum(len(f) for _, _, f in os.walk(dst2)))