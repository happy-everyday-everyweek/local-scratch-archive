# Break the zod core<->util module cycle by erasing util's single value
# edge. util.ts imports { globalConfig } from "./core.js" only for one
# runtime read (allowsEval's jitless check, inside a function body); every
# other util import is already type-only. Removing that value import makes
# all of util's imports erased (no module edge), so the SCC collapses and
# core.ts's top level no longer needs to pass the declaration-only gate.
# The read becomes a runtime lookup of the same global slot core.ts
# initializes (semantics: same object, read at use time — core has fully
# initialized before any allowsEval call can happen).
import io

BASE = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa'

OLD1 = ('import { globalConfig } from "./core.js";\n'
        'import type { $ZodConfig } from "./core.js";\n')
NEW1 = 'import type { $ZodConfig } from "./core.js";\n'

OLD2 = '  if (globalConfig.jitless) {'
NEW2 = '  if (((globalThis as any).__zod_globalConfig as $ZodConfig | undefined)?.jitless) {'

for rel in ('zgh/zfull/vendor/zod/src/v4/core/util.ts',
            'zfull/vendor/zod/src/v4/core/util.ts'):
    p = BASE + '/' + rel
    s = io.open(p, encoding='utf-8').read()
    assert s.count(OLD1) == 1, (rel, 'import', s.count(OLD1))
    assert s.count(OLD2) == 1, (rel, 'use', s.count(OLD2))
    s = s.replace(OLD1, NEW1, 1)
    s = s.replace(OLD2, NEW2, 1)
    io.open(p, 'w', encoding='utf-8').write(s)
    print('cycle-edge broken:', rel)