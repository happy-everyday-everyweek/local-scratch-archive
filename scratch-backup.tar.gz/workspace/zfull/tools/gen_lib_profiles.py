# Generate library-mode profiles for the 16 zod-blocked packages. Empty
# exports lists: this round's goal is "compiles as a library archive"
# (init/collect only; callable probes come later per package). The entry
# modules are the existing export:* barrels under zfull/entries/.
import io
import json
import os

B = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zfull'

PKGS = {
    'core': 'zco',
    'contracts': 'zct',
    'shared': 'zsh',
    'dynamic-workflow': 'zdw',
    'dynamic-workflow-runtime': 'zdr',
    'adapters': 'zad',
    'bootstrap': 'zbp',
    'telemetry': 'ztl',
    'cli': 'zcl',
    'services': 'zsv',
    'provider': 'zpv',
    'provider-node': 'zpn',
    'client': 'zlt',
    'server': 'zsr',
    'zcode-server-cli': 'zsc',
    'node-repl-host': 'zrh',
}

made = 0
for pkg, pfx in sorted(PKGS.items()):
    prof = {
        'profile_format': 1,
        'name': 'zcode-' + pkg,
        'entry': '../entries/%s.ts' % pkg,
        'emission': 'llvm',
        'abi': {
            'prefix': pfx + '_',
            'init_symbol': pfx + '_init',
            'sink_register_symbol': pfx + '_set_panic_sink',
            'collect_symbol': pfx + '_collect',
            'result_reset_symbol': None,
        },
        'exports': [],
    }
    path = os.path.join(B, 'profiles', 'lib-%s.profile.json' % pkg)
    io.open(path, 'w', encoding='utf-8').write(json.dumps(prof, indent=2) + '\n')
    made += 1
print('profiles generated:', made)