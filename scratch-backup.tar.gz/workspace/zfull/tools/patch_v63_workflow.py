# v5.21: compile ci/android_child_stubs.c and add it to both link lines.
# The stubs supply the eight scr_children_* hooks that the re-included
# scr_async.c references (scr_child.c itself stays excluded: posix_spawn*
# is absent from bionic), so the linked .so resolves every non-system
# symbol. Four edits: (1) lib segment compile step, (2) lib link line,
# (3) apk segment compile step, (4) apk link line.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'
s = io.open(P, encoding='utf-8').read()
assert 'android_child_stubs' not in s, 'workflow already patched?'

# 1) lib segment: compile the stubs right after the archive merge
lib_old = ('          cd zfull/profiles\n'
           '          $TC/ld.lld -r --whole-archive .scriptc/rpc-probe.lib.a -o /tmp/combined.o\n')
lib_new = lib_old + (
    '          $TC/clang --target=aarch64-linux-android26 '
    '--sysroot="$NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot" '
    '-O1 -fPIC -c "$GITHUB_WORKSPACE/ci/android_child_stubs.c" -o /tmp/child_stubs.o\n')
assert s.count(lib_old) == 1, ('lib merge anchor', s.count(lib_old))
s = s.replace(lib_old, lib_new, 1)

# 2) lib segment: add the stubs object to the shared-library link line
lib_link_old = '-o ../out/libzcode_rpc.so /tmp/combined.o -lc -lm'
lib_link_new = '-o ../out/libzcode_rpc.so /tmp/child_stubs.o /tmp/combined.o -lc -lm'
assert s.count(lib_link_old) == 1, ('lib link anchor', s.count(lib_link_old))
s = s.replace(lib_link_old, lib_link_new, 1)

# 3) apk segment: compile the stubs right after the archive merge
apk_old = ('          cd $WS/zfull/profiles\n'
           '          $TC/ld.lld -r --whole-archive .scriptc/rpc-probe.lib.a -o /tmp/combined.o\n')
apk_new = apk_old + (
    '          $TC/clang --target=aarch64-linux-android26 --sysroot="$SYSROOT" '
    '-O1 -fPIC -c $WS/ci/android_child_stubs.c -o /tmp/child_stubs.o\n')
assert s.count(apk_old) == 1, ('apk merge anchor', s.count(apk_old))
s = s.replace(apk_old, apk_new, 1)

# 4) apk segment: add the stubs object to the shared-library link line
apk_link_old = '-o /tmp/libzcodecore.so /tmp/jni.o /tmp/combined.o -lc -lm -llog'
apk_link_new = '-o /tmp/libzcodecore.so /tmp/jni.o /tmp/child_stubs.o /tmp/combined.o -lc -lm -llog'
assert s.count(apk_link_old) == 1, ('apk link anchor', s.count(apk_link_old))
s = s.replace(apk_link_old, apk_link_new, 1)

io.open(P, 'w', encoding='utf-8').write(s)
v = io.open(P, encoding='utf-8').read()
print('android_child_stubs refs:', v.count('android_child_stubs'))
print('child_stubs.o refs:', v.count('child_stubs.o'))