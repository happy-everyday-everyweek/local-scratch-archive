# v5.17: fix the partial link to pull ALL archive members in
# (`ld.lld -r` without --whole-archive left combined.o nearly empty), and add
# a full-symtab check for zr_* in the final .so.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
changed = []
for i, ln in enumerate(lines):
    new = ln
    if '$TC/ld.lld -r .scriptc/rpc-probe.lib.a -o /tmp/combined.o' in ln:
        new = ln.replace("$TC/ld.lld -r .scriptc/rpc-probe.lib.a -o /tmp/combined.o",
                         "$TC/ld.lld -r --whole-archive .scriptc/rpc-probe.lib.a -o /tmp/combined.o")
        changed.append('whole-archive added (line %d)' % (i + 1))
    out.append(new)
    if ln.strip() == '$TC/llvm-nm -D ../out/libzcode_rpc.so 2>/dev/null | head -24 || true':
        indent = ln[:len(ln) - len(ln.lstrip())]
        out.append(indent + "echo '--- .so full symtab zr ---'")
        out.append(indent + "$TC/llvm-readelf -sW ../out/libzcode_rpc.so 2>/dev/null | grep -i 'zr_' | head -24 || true")
        changed.append('symtab check added (line %d)' % (i + 1))

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))
v = io.open(P, encoding='utf-8').read()
print('changes:', changed)
print('whole count:', v.count('--whole-archive'))
print('symtab check count:', v.count('.so full symtab zr'))