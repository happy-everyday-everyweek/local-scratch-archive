#!/bin/sh
# zcode_native_sync.sh — regenerate the adaptation patch, refresh the publish tree,
# and push to happy-everyday-everyweek/zcode-native (triggers CI).
WS=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa
cd "$WS/ZCode" || exit 1
echo '[1/4] regenerate patch...'
git diff HEAD > "$WS/zgh/patches/zcode-adaptations.patch"
wc -l "$WS/zgh/patches/zcode-adaptations.patch"
echo '[2/4] refresh zfull files...'
cp "$WS/zfull/entries/"*.ts "$WS/zgh/zfull/entries/"
cp "$WS/zfull/profiles/"*.json "$WS/zgh/zfull/profiles/" 2>/dev/null
cp "$WS/zfull/shims/"*.ts "$WS/zgh/zfull/shims/"
mkdir -p "$WS/zgh/zfull/compat"
cp "$WS/zfull/compat/"*.ts "$WS/zgh/zfull/compat/" 2>/dev/null
cp "$WS/zfull/PLAN.md" "$WS/zgh/zfull/"
echo '[3/4] regenerate relative tsconfig...'
sed 's|/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/ZCode/|../ZCode/|g' \
  "$WS/zfull/tsconfig.json" > "$WS/zgh/zfull/tsconfig.json"
echo '[4/4] push...'
python3 /root/zcode_native_push.py 2>&1 | tail -8
echo SYNC-DONE