# v5.16: upload hidden files (the .lib.a lives in profiles/.scriptc/), and add
# symbol diagnostics around the archive / object / .so in the link step.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
changed = []
for i, ln in enumerate(lines):
    out.append(ln)
    if ln.strip() == "$TC/ld.lld -r .scriptc/rpc-probe.lib.a -o /tmp/combined.o":
        indent = ln[:len(ln) - len(ln.lstrip())]
        out.append(indent + "echo '--- lib.a symbols ---'")
        out.append(indent + "$TC/llvm-nm .scriptc/rpc-probe.lib.a 2>/dev/null | head -40 || true")
        out.append(indent + "echo '--- combined.o defined symbols ---'")
        out.append(indent + "$TC/llvm-nm /tmp/combined.o 2>/dev/null | grep -v ' U ' | head -40 || true")
        changed.append('nm diagnostics after lld -r (line %d)' % (i + 1))
    if ln.strip() == 'if-no-files-found: warn' and i > 100:
        # only the lib job's upload block (the last one before lib-aarch64's end)
        pass
    if ln.strip() == 'path: |':
        # peek ahead for lib upload path
        lookahead = '\n'.join(lines[i:i+4])
        if 'zfull/profiles/.scriptc/' in lookahead:
            indent = ln[:len(ln) - len(ln.lstrip())]
            # append include-hidden-files after the upload block's if-no-files-found? simpler: insert right after path list end -- handled below
            pass
# second pass: add include-hidden-files to the lib upload block
lines2 = out
out2 = []
for i, ln in enumerate(lines2):
    out2.append(ln)
    if ln.strip() == 'if-no-files-found: warn':
        # check previous ~6 lines for the lib paths
        ctx = '\n'.join(lines2[max(0, i - 6):i])
        if 'zfull/profiles/.scriptc/' in ctx:
            indent = ln[:len(ln) - len(ln.lstrip())]
            out2.append(indent + 'include-hidden-files: true')
            changed.append('include-hidden-files added (line %d)' % (i + 1))

io.open(P, 'w', encoding='utf-8').write('\n'.join(out2))
v = io.open(P, encoding='utf-8').read()
print('changes:', changed)
print('hidden flag count:', v.count('include-hidden-files: true'))
print('nm diag count:', v.count('lib.a symbols'))