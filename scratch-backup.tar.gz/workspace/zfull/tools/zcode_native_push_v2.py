#!/usr/bin/env python3
"""v2: resumable, content-addressed push of the zgh/ tree (Git Data API).

Improvements over v1: per-file git-blob sha1; a local path->sha cache in
zgh-logs/push-blob-cache.json; remote existence check (GET /git/blobs/{sha})
before POST; cache flushed every few files, so an interrupted run resumes
without re-uploading completed blobs. Unbuffered output.
"""
import base64
import hashlib
import json
import os
import socket
import time
import urllib.error
import urllib.request

OWNER, REPO = 'happy-everyday-everyweek', 'zcode-native'
BASE = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa'
WORK = BASE + '/zgh'
CACHE = BASE + '/zgh-logs/push-blob-cache.json'
ROOT = 'https://api.github.com/repos/%s/%s' % (OWNER, REPO)
socket.setdefaulttimeout(30)
TOK = None
for line in open('/root/.git-credentials'):
    line = line.strip()
    if 'github.com' in line:
        TOK = line.split('://', 1)[1].split(':', 1)[1].split('@', 1)[0]
HEAD = {
    'Authorization': 'token ' + TOK,
    'Accept': 'application/vnd.github+json',
    'User-Agent': 'operit-agent',
}


def log(*args):
    print(*args, flush=True)


def api(method, url, payload=None, attempts=4):
    data = json.dumps(payload).encode() if payload is not None else None
    for i in range(attempts):
        req = urllib.request.Request(url, data=data, headers=HEAD, method=method)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.status, json.loads(resp.read().decode() or '{}')
        except urllib.error.HTTPError as e:
            try:
                body = json.loads(e.read().decode())
            except Exception:
                body = {'raw': 'http error'}
            if e.code in (502, 503, 504) and i < attempts - 1:
                time.sleep(2)
                continue
            return e.code, body
        except Exception as e:
            if i < attempts - 1:
                time.sleep(2)
                continue
            return -1, {'error': repr(e)}
    return -1, {'error': 'exhausted'}


files = []
for dirpath, dirnames, filenames in os.walk(WORK):
    for fn in filenames:
        fp = os.path.join(dirpath, fn)
        rel = os.path.relpath(fp, WORK).replace(os.sep, '/')
        files.append((rel, fp))
files.sort()
log('total files:', len(files))

cache = {}
if os.path.exists(CACHE):
    try:
        cache = json.load(open(CACHE))
        log('cache entries:', len(cache))
    except Exception as e:
        log('cache load failed:', e)
        cache = {}


def save_cache():
    tmp = CACHE + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(cache, f)
    os.replace(tmp, CACHE)


st, resp = api('GET', ROOT + '/git/ref/heads/main')
if st == 200:
    base_commit = resp['object']['sha']
    log('base commit:', base_commit)
else:
    base_commit = None
    log('no main ref yet; will create root commit')

items = []
done = 0
for rel, fp in files:
    data = open(fp, 'rb').read()
    sha = hashlib.sha1(('blob %d' % len(data)).encode() + b'\0' + data).hexdigest()
    if cache.get(rel) != sha:
        st, resp = api('GET', ROOT + '/git/blobs/' + sha, attempts=2)
        if st != 200:
            st2, resp2 = api('POST', ROOT + '/git/blobs',
                             {'content': base64.b64encode(data).decode(), 'encoding': 'base64'})
            if st2 != 201:
                log('BLOB FAIL', rel, st2, resp2)
                save_cache()
                raise SystemExit(1)
            sha = resp2['sha']
        cache[rel] = sha
        done += 1
        if done % 5 == 0:
            save_cache()
        log('blob ok:', rel)
    items.append({'path': rel, 'mode': '100644', 'type': 'blob', 'sha': cache[rel]})
save_cache()
log('blobs complete; entries:', len(items))

st, resp = api('POST', ROOT + '/git/trees', {'tree': items})
if st != 201:
    log('TREE FAIL', st, resp)
    raise SystemExit(1)
tree_sha = resp['sha']
log('tree:', tree_sha)
st, resp = api('POST', ROOT + '/git/commits', {
    'message': 'zcode-native sync (resumable push v2)',
    'tree': tree_sha,
    'parents': [base_commit] if base_commit else [],
})
if st != 201:
    log('COMMIT FAIL', st, resp)
    raise SystemExit(1)
commit_sha = resp['sha']
log('commit:', commit_sha)
st, resp = api('PATCH', ROOT + '/git/refs/heads/main', {'sha': commit_sha, 'force': True})
log('ref status:', st)
if st not in (200, 201):
    log('REF FAIL', st, resp)
    raise SystemExit(1)
log('DONE main ->', commit_sha)