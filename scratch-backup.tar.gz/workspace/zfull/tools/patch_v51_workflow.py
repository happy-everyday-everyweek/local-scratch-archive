# Patch zgh/.github/workflows/build.yml for v5.1:
# 1) emit-c job: add "install minimal type deps + link" step (Node types + undici)
#    and a scriptc jsx-adoption patch step, right after its "Install scriptc" step.
# 2) coverage-sweep job: add the same scriptc jsx-adoption patch step after its
#    "Install scriptc" step (its type-deps link step already exists).
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

JSX_BLOCK = '''      - name: Patch scriptc to adopt tsconfig jsx (tui .tsx preflight)
        run: |
          python3 - <<'PYEOF'
          import io
          p = "scriptc-try/node_modules/@scriptc/compiler/dist/frontend/tsc-codes.js"
          s = io.open(p, encoding="utf-8").read()
          if '"jsx",' not in s:
              old = 'export const ADOPTED_OPTIONS = [\\n'
              assert old in s, "marker missing"
              s = s.replace(old, old + '    "jsx",\\n', 1)
              io.open(p, "w", encoding="utf-8").write(s)
          print('jsx adopted:', '"jsx",' in io.open(p, encoding='utf-8').read())
          PYEOF'''.split('\n')

DEPS_BLOCK = '''      - name: Install and link minimal type deps (Node types + undici for shims)
        run: |
          mkdir -p zfull/node_modules/@types /tmp/nt
          cd /tmp/nt
          npm init -y >/dev/null 2>&1 || true
          npm install --no-audit --no-fund @types/node@25.6.0
          cd "$GITHUB_WORKSPACE"
          ln -sfn /tmp/nt/node_modules/@types/node zfull/node_modules/@types/node
          ln -sfn /tmp/nt/node_modules/undici-types zfull/node_modules/undici-types
          ls -la zfull/node_modules/ zfull/node_modules/@types/
'''.split('\n')

INSTALL_LINE = 'npm install scriptc@0.1.6 --no-audit --no-fund'

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
seen = 0
pending = None

for ln in lines:
    out.append(ln)
    if pending is not None and ln.strip() == 'cd ..':
        out.extend(pending)
        pending = None
        continue
    if INSTALL_LINE in ln and 'name:' not in ln:
        seen += 1
        pending = (DEPS_BLOCK + JSX_BLOCK) if seen == 1 else JSX_BLOCK

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))

verify = io.open(P, encoding='utf-8').read()
print('installs seen:', seen)
print('jsx patch steps:', verify.count('Patch scriptc to adopt tsconfig jsx'))
print('deps steps:', verify.count('Install and link minimal type deps'))
print('jsx adopted line for python check:', '"jsx",' in verify)
