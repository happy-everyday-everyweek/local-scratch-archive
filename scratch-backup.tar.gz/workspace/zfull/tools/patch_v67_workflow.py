# v5.25: append the 'lib-matrix' job — the first real library-mode builds
# for the zod-blocked packages (zod-probe + contracts + shared + core +
# client). Library mode runs npm-static automatically (static-or-refuse),
# so these logs tell us exactly where zod and the packages stand.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'
s = io.open(P, encoding='utf-8').read()
assert 'lib-matrix' not in s, 'workflow already patched?'

JOB = '''  lib-matrix:
    runs-on: ubuntu-latest
    timeout-minutes: 300
    steps:
      - name: Checkout repo
        uses: actions/checkout@v4
      - name: Setup Node.js 24
        uses: actions/setup-node@v4
        with:
          node-version: '24'
      - name: Clone ZCode v3.14.3 and apply adaptation patch
        run: |
          git clone --depth 1 --branch v3.14.3 https://github.com/zai-org/ZCode.git ZCode
          cd ZCode
          git apply ../patches/zcode-adaptations.patch
          echo "ZCode ready."
      - name: Fix type-only imports (scriptc module linker bindings)
        run: python3 ci/fix_type_only_imports.py ZCode
      - name: Install scriptc (npm)
        run: |
          mkdir -p scriptc-try
          cd scriptc-try
          npm init -y >/dev/null 2>&1 || true
          npm install scriptc@0.1.7 --no-audit --no-fund
          cd ..
      - name: Patch scriptc lib runtime (re-include async + child units)
        run: python3 ci/patch_scriptc_lib_runtime.py "$GITHUB_WORKSPACE/scriptc-try"
      - name: Install minimal type deps (Node types + undici for shims)
        run: |
          mkdir -p zfull/node_modules/@types /tmp/nt
          cd /tmp/nt
          npm init -y >/dev/null 2>&1 || true
          npm install --no-audit --no-fund @types/node@25.6.0
          cd "$GITHUB_WORKSPACE"
          ln -sfn /tmp/nt/node_modules/@types/node zfull/node_modules/@types/node
          ln -sfn /tmp/nt/node_modules/undici-types zfull/node_modules/undici-types
      - name: Install zig (x86_64 linux)
        run: |
          curl -fsSL -o /tmp/zig.tar.xz https://ziglang.org/download/0.16.0/zig-x86_64-linux-0.16.0.tar.xz
          tar -xf /tmp/zig.tar.xz -C /tmp
          ZIGDIR="$(ls -d /tmp/zig-* | head -n1)"
          echo "$ZIGDIR" >> "$GITHUB_PATH"
          "$ZIGDIR/zig" version
      - name: Install Android NDK r27c
        run: |
          curl -fsSL -o /tmp/ndk.zip https://dl.google.com/android/repository/android-ndk-r27c-linux.zip
          unzip -q /tmp/ndk.zip -d /tmp/ndk
          echo "ANDROID_NDK_ROOT=/tmp/ndk/android-ndk-r27c" >> "$GITHUB_ENV"
      - name: Install ZCode workspace deps (pnpm)
        run: |
          npm i -g pnpm@10.33.2 >/dev/null 2>&1 || true
          cd ZCode
          pnpm install --ignore-scripts --no-frozen-lockfile
          cd ..
      - name: Link zod into zfull
        run: |
          test -d "$PWD/ZCode/node_modules/zod" || { echo 'zod missing'; exit 1; }
          ln -sfn "$PWD/ZCode/node_modules/zod" zfull/node_modules/zod
          ls -la zfull/node_modules/ | head -12
      - name: Build library experiments
        run: |
          cd zfull
          mkdir -p ../lib-logs
          run_one() {
            local name="$1"
            local prof="$2"
            echo "===== BUILD $name ====="
            SCRIPTC_CC=zigcc SCRIPTC_TARGET=aarch64-linux-android timeout 1800 node ../scriptc-try/node_modules/.bin/scriptc build --lib --profile "$prof" > "../lib-logs/$name.log" 2>&1
            local rc=$?
            echo "$name exit=$rc"
            tail -8 "../lib-logs/$name.log" || true
          }
          run_one zod-probe profiles/zod-probe.profile.json || true
          run_one contracts profiles/lib-contracts.profile.json || true
          run_one shared profiles/lib-shared.profile.json || true
          run_one core profiles/lib-core.profile.json || true
          run_one client profiles/lib-client.profile.json || true
          echo DONE-LIB-MATRIX
      - name: Upload lib-matrix logs
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: lib-matrix-logs
          path: lib-logs/
          if-no-files-found: warn
'''

s = s.rstrip('\n') + '\n\n' + JOB
io.open(P, 'w', encoding='utf-8').write(s)

v = io.open(P, encoding='utf-8').read()
print('lib-matrix jobs:', v.count('  lib-matrix:'))
print('total job markers:', v.count('\\n  emit-c:'), v.count('\\n  lib-aarch64:'), v.count('\\n  apk-aarch64:'), v.count('\\n  coverage-sweep:'), v.count('\\n  lib-matrix:'))