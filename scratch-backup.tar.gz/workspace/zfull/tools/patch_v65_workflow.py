# v5.23: use the fixed signing keystore (ci/zcode-rpc-debug.keystore) instead
# of generating a random one every build, so APKs from different CI runs have
# a stable signature and can be reinstalled over each other.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'
s = io.open(P, encoding='utf-8').read()

old = ('          keytool -genkeypair -keystore /tmp/apk/debug.keystore -alias androiddebugkey '
       '-storepass android -keypass android -dname "CN=Android Debug,O=Android,C=US" '
       '-keyalg RSA -keysize 2048 -validity 10000\n')
new = '          cp "$GITHUB_WORKSPACE/ci/zcode-rpc-debug.keystore" /tmp/apk/debug.keystore\n'
assert s.count(old) == 1, ('keytool anchor', s.count(old))
s = s.replace(old, new, 1)

io.open(P, 'w', encoding='utf-8').write(s)
v = io.open(P, encoding='utf-8').read()
print('fixed keystore refs:', v.count('zcode-rpc-debug.keystore'))
print('keytool lines left:', v.count('keytool -genkeypair'))