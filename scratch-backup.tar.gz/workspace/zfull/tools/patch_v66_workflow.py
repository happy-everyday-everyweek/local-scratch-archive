# v5.24: (1) run ci/fix_type_only_imports.py on the ZCode checkout in both
# library-building jobs (fixes the SC4013 module binding holes); (2) extend
# the post-link checks with a "module binding holes" scan that fails the job
# if the .so still contains generated 'does not provide an export named'
# instances.
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'
s = io.open(P, encoding='utf-8').read()
assert 'fix_type_only_imports' not in s, 'workflow already patched?'

LIB, APK, COV = '  lib-aarch64:', '  apk-aarch64:', '  coverage-sweep:'
li, ai, ci = s.index(LIB), s.index(APK), s.index(COV)
head, libseg, apkseg, tail = s[:li], s[li:ai], s[ai:ci], s[ci:]

FIX_STEP = (
    '      - name: Fix type-only imports (scriptc module linker bindings)\n'
    '        run: python3 ci/fix_type_only_imports.py ZCode\n'
)
anchor = '      - name: Install scriptc (npm)\n'
assert libseg.count(anchor) == 1, ('lib anchor', libseg.count(anchor))
assert apkseg.count(anchor) == 1, ('apk anchor', apkseg.count(anchor))
libseg = libseg.replace(anchor, FIX_STEP + anchor, 1)
apkseg = apkseg.replace(anchor, FIX_STEP + anchor, 1)


def holes_block(target):
    return (
        "          echo '=== module binding holes check ==='\n"
        "          H=$(strings -a " + target
        + " | grep -o \"does not provide an export named '[^']*'\" | sort -u || true)\n"
        "          if [ -n \"$H\" ]; then echo 'MODULE BINDING HOLES:'; echo \"$H\"; exit 1; fi\n"
        "          echo 'no module binding holes'\n"
    )


unresolved_tail = "          echo 'no unresolved scr_* symbols'\n"
assert libseg.count(unresolved_tail) == 1, ('lib tail', libseg.count(unresolved_tail))
assert apkseg.count(unresolved_tail) == 1, ('apk tail', apkseg.count(unresolved_tail))
libseg = libseg.replace(unresolved_tail, unresolved_tail + holes_block('../out/libzcode_rpc.so'), 1)
apkseg = apkseg.replace(unresolved_tail, unresolved_tail + holes_block('/tmp/libzcodecore.so'), 1)

s2 = head + libseg + apkseg + tail
io.open(P, 'w', encoding='utf-8').write(s2)

v = io.open(P, encoding='utf-8').read()
print('fix steps:', v.count('fix_type_only_imports'))
print('holes checks:', v.count('module binding holes check'))