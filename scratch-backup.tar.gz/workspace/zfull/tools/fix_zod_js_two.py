# Fix the two SC0001 inference errors in the zod-js vendor (both copies):
# 1) schemas.js: `push({ ...unrecIssue, keys: aggregated })` — `unrecIssue`
#    starts as an uninitialized `let` (inferred loose), so spread is refused.
#    Object.assign({}, unrecIssue, {keys}) is the exact same shallow copy.
# 2) to-json-schema.js: `{ [keyword]: branches }` — `keyword` may be
#    undefined from find(); guard it before the computed property (the
#    existing length check already returns for multi-key unions; keyword
#    undefined means the single key is not a union key — the later map
#    would have thrown anyway, so returning here matches runtime behavior
#    for a case that cannot produce a valid fold).
import io

BASE = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa'

FILES = [
    ('/vendor/zod-js/v4/core/schemas.js',
     'result.issues.push({ ...unrecIssue, keys: aggregated });',
     'result.issues.push(Object.assign({}, unrecIssue, { keys: aggregated }));'),
    ('/vendor/zod-js/v4/core/to-json-schema.js',
     '        const keyword = UNION_KEYS.find((k) => Array.isArray(union[k]));\n',
     '        const keyword = UNION_KEYS.find((k) => Array.isArray(union[k]));\n        if (keyword === undefined)\n            return;\n'),
]

for prefix in ('/zgh/zfull', '/zfull'):
    for rel, old, new in FILES:
        p = BASE + prefix + rel
        s = io.open(p, encoding='utf-8').read()
        assert s.count(old) == 1, (p, s.count(old))
        io.open(p, 'w', encoding='utf-8').write(s.replace(old, new, 1))
        print('fixed:', prefix + rel)