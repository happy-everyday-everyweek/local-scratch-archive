# v5.19: (1) insert a 'Patch scriptc lib runtime' step after the scriptc
# install step in both lib-aarch64 and apk-aarch64 jobs (calls
# ci/patch_scriptc_lib_runtime.py to re-include scr_async.c + scr_child.c in
# the library runtime, fixing the dlopen 'cannot locate symbol
# "scr_promise_settled_ref"' failure); (2) append an unresolved-symbols check
# to both link steps (fail the job if any scr_* symbol stays undefined in the
# linked .so).
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'
s = io.open(P, encoding='utf-8').read()
assert 'patch_scriptc_lib_runtime' not in s, 'workflow already patched?'

LIB, APK, COV = '  lib-aarch64:', '  apk-aarch64:', '  coverage-sweep:'
li, ai, ci = s.index(LIB), s.index(APK), s.index(COV)
head, libseg, apkseg, tail = s[:li], s[li:ai], s[ai:ci], s[ci:]

PATCH_STEP = (
    '      - name: Patch scriptc lib runtime (re-include async + child units)\n'
    '        run: python3 ci/patch_scriptc_lib_runtime.py '
    '"$GITHUB_WORKSPACE/scriptc-try/node_modules/scriptc/dist/backend/native-toolchain.js"\n'
)
anchor = '      - name: Install minimal type deps (Node types + undici for shims)\n'
assert libseg.count(anchor) == 1, ('lib anchor', libseg.count(anchor))
assert apkseg.count(anchor) == 1, ('apk anchor', apkseg.count(anchor))
libseg = libseg.replace(anchor, PATCH_STEP + anchor, 1)
apkseg = apkseg.replace(anchor, PATCH_STEP + anchor, 1)


def check_block(target):
    return (
        "          echo '=== unresolved symbols check ==='\n"
        "          $TC/llvm-readelf -sW " + target
        + " | awk '$7==\"UND\" && $8 != \"\" {print $8}' | grep -v '@' | sort -u | tee /tmp/und.txt || true\n"
        "          if grep -q 'scr_' /tmp/und.txt; then echo 'UNRESOLVED scr_* SYMBOLS:'; cat /tmp/und.txt; exit 1; fi\n"
        "          echo 'no unresolved scr_* symbols'\n"
    )


lib_anchor = '          ls -la ../out/\n'
apk_anchor = "          $TC/llvm-readelf -sW /tmp/libzcodecore.so | grep -E 'Java_|zr_' | head -16\n"
assert libseg.count(lib_anchor) == 1, ('lib link anchor', libseg.count(lib_anchor))
assert apkseg.count(apk_anchor) == 1, ('apk link anchor', apkseg.count(apk_anchor))
libseg = libseg.replace(lib_anchor, lib_anchor + check_block('../out/libzcode_rpc.so'), 1)
apkseg = apkseg.replace(apk_anchor, apk_anchor + check_block('/tmp/libzcodecore.so'), 1)

s2 = head + libseg + apkseg + tail
io.open(P, 'w', encoding='utf-8').write(s2)

v = io.open(P, encoding='utf-8').read()
print('patch steps inserted:', v.count('Patch scriptc lib runtime'))
print('unresolved checks:', v.count('unresolved symbols check'))
print('jobs:', v.count('\n  lib-aarch64:'), v.count('\n  apk-aarch64:'), v.count('\n  coverage-sweep:'))