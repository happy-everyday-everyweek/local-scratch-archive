p = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zfull/shims/dom-globals.ts'
s = open(p).read()


def rep(old, new):
    global s
    assert old in s, 'MISSING: ' + old[:60]
    s = s.replace(old, new)


rep('readonly tagName?: string;', 'readonly tagName: string;')
rep('readonly outerHTML?: string;', 'readonly outerHTML: string;')
rep('readonly documentElement?: Element;', 'readonly documentElement: Element;')

open(p, 'w').write(s)
s2 = open(p).read()
print('tagName required:', 'readonly tagName: string;' in s2)
print('outerHTML required:', 'readonly outerHTML: string;' in s2)
print('documentElement required:', 'readonly documentElement: Element;' in s2)
print('len:', len(s2))