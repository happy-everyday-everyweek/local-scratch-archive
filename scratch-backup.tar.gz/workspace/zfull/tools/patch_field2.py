p = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/ZCode/packages/rpc/src/foundation.ts'
s = open(p).read()
assert 'readonly event: Event<T> = (listener' not in s, 'already fielded'
i = s.index('  get event(): Event<T> {')
j = s.index('  fire(event: T): void {', i)
new_block = '''  readonly event: Event<T> = (listener: (e: T) => void) => {
    if (this.disposed) {
      return { dispose() {} };
    }
    const isFirst = this.listeners.length === 0;
    if (!this.listeners.includes(listener)) {
      this.listeners.push(listener);
    }
    if (isFirst) {
      this.options?.onWillAddFirstListener?.();
    }
    return toDisposable(() => {
      const index = this.listeners.indexOf(listener);
      if (index !== -1) {
        this.listeners.splice(index, 1);
      }
      if (this.listeners.length === 0) {
        this.options?.onDidRemoveLastListener?.();
      }
    });
  };

'''
s = s[:i] + new_block + s[j:]
open(p, 'w').write(s)
s2 = open(p).read()
print('field present:', 'readonly event: Event<T> = (listener' in s2)
print('getter gone:', 'get event' not in s2)
print('fire intact:', 'fire(event: T): void {' in s2)
print('len:', len(s2))