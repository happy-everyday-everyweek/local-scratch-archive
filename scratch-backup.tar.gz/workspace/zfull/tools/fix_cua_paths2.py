# Re-point @zcode/zcode-cua path mappings at the synthesized compat/zcua modules.
import io, re, json

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zfull/tsconfig.json'
s = io.open(P, encoding='utf-8').read()
mapping = {
    '@zcode/zcode-cua': 'index.ts',
    '@zcode/zcode-cua/frame-contract': 'frame-contract.ts',
    '@zcode/zcode-cua/host-display-contract': 'host-display-contract.ts',
    '@zcode/zcode-cua/request-access-contract': 'request-access-contract.ts',
    '@zcode/zcode-cua/pip-session': 'pip-session.ts',
    '@zcode/zcode-cua/pip-session/node': 'pip-session-node.ts',
    '@zcode/zcode-cua/broker': 'broker.ts',
    '@zcode/zcode-cua/broker/server': 'broker-server.ts',
    '@zcode/zcode-cua/broker/ports': 'broker-ports.ts',
    '@zcode/zcode-cua/broker/socketPath': 'broker-socket-path.ts',
    '@zcode/zcode-cua/broker/helperConstants': 'broker-helper-constants.ts',
    '@zcode/zcode-cua/broker/helperHealth': 'broker-helper-health.ts',
}
total = 0
for key, fname in mapping.items():
    pat = re.compile(r'("' + re.escape(key) + r'":\s*\[")[^"]*("\])')
    s, n = pat.subn(lambda m: m.group(1) + './compat/zcua/' + fname + m.group(2), s)
    total += n
io.open(P, 'w', encoding='utf-8').write(s)
print('replaced:', total)
d = json.load(io.open(P, encoding='utf-8'))
mine = {k: v[0] for k, v in d['compilerOptions']['paths'].items() if 'zcode-cua' in k}
for k in sorted(mine):
    print(k, '->', mine[k])