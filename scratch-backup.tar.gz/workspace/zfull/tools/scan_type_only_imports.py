# Scan ZCode rpc/src for "bare" imports of type-only symbols (interface/type
# without a value-side declaration). Those must carry the `type` modifier for
# scriptc's module linker, otherwise the runtime binding check fails with
# SC4013 ("does not provide an export named ..."). Deterministic, read-only.
import re
import glob

SRC = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/ZCode/packages/rpc/src'

files = sorted(glob.glob(SRC + '/**/*.ts', recursive=True))
print('files:', len(files))

kinds = {}
for f in files:
    text = open(f, encoding='utf-8').read()
    for m in re.finditer(
            r'^export\s+(abstract\s+class|class|function|const|let|var|enum|namespace|interface|type)\s+([A-Za-z_$][\w$]*)',
            text, re.M):
        kind = 'class' if m.group(1).startswith('abstract') else m.group(1)
        kinds.setdefault(m.group(2), set()).add(kind)

imp_re = re.compile(r'import\s+(type\s+)?\{([^}]*)\}\s*from\s*["\']([^"\']+)["\']', re.S)

issues = []
unknown = []
for f in files:
    text = open(f, encoding='utf-8').read()
    for m in imp_re.finditer(text):
        if m.group(1):
            continue  # whole-statement `import type` — fine
        inner, mod = m.group(2), m.group(3)
        line = text[:m.start()].count('\n') + 1
        for part in inner.split(','):
            p = part.strip()
            if not p or p.startswith('type ') or p.startswith('* as') or p.startswith('default'):
                continue
            name = p.split(' as ')[0].strip()
            ks = kinds.get(name)
            if ks is None:
                unknown.append((f, line, name, mod))
            elif not (ks - {'interface', 'type'}):
                issues.append((f, line, name, mod, ','.join(sorted(ks))))

print()
print('=== NEEDS type modifier ===')
for f, l, n, mod, k in issues:
    print('%-28s line %-4s %-22s from %-24s [%s]' % (f.replace(SRC + '/', ''), l, n, mod, k))
print()
print('=== UNKNOWN (no export found in rpc/src) ===')
for f, l, n, mod in unknown:
    print('%-28s line %-4s %-22s from %s' % (f.replace(SRC + '/', ''), l, n, mod))
