# Insert "Generate dynamic-workflow libs" + "Build core dependency-chain dist"
# into the emit-c job, right after its "Re-link ... from ZCode node_modules"
# step (anchored on the trailing `ls -la zfull/node_modules/` line).
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

BLOCK = '''      - name: Generate dynamic-workflow libs (gitignored generated file)
        run: |
          cd ZCode/apps/zcode-cli/packages/dynamic-workflow
          node scripts/generate-libs.mjs
          cd -
      - name: Build core dependency-chain dist (contracts, shared, core, ...)
        run: |
          cd ZCode
          pnpm --filter @zcode/core... build
          cd ..
'''.split('\n')

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
inserted = 0
for ln in lines:
    out.append(ln)
    if ln.strip() == 'ls -la zfull/node_modules/':
        out.extend(BLOCK)
        inserted += 1

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))
v = io.open(P, encoding='utf-8').read()
print('inserted blocks:', inserted)
print('generate-libs count:', v.count('generate-libs.mjs'))
print('build-dist count:', v.count('pnpm --filter @zcode/core... build'))