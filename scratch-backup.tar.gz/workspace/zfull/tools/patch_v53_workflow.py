# Insert a "poison-escape catch" patch step right after the diagnostics step
# (anchored on `print("diag inserted")` + its PYEOF). The new step patches
# lowerer.js so the scan-phase `promoteNode(fn)` call catches PoisonError the
# same way the rest of the lowerer does (poison = skip the statement; the
# escape is a scriptc bug that crashes coverage).
import io

P = '/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zgh/.github/workflows/build.yml'

BLOCK = '''      - name: Patch scriptc for poison-escape (scan-phase PoisonError catch)
        run: |
          python3 - <<'PYEOF'
          import io
          p = "scriptc-try/node_modules/@scriptc/compiler/dist/frontend/lowering/lowerer.js"
          lines = io.open(p, encoding="utf-8").read().split(chr(10))
          idx = None
          for i, ln in enumerate(lines):
              if "promoteNode(fn);" in ln:
                  idx = i
                  break
          assert idx is not None, "promoteNode(fn) not found"
          assert "if (fn)" in lines[idx - 1], lines[idx - 1]
          lines[idx - 1] = lines[idx - 1].rstrip() + " {"
          lines[idx] = "                    try { promoteNode(fn); } catch (e) { if (!(e instanceof PoisonError)) throw e; }"
          lines.insert(idx + 1, "                }")
          io.open(p, "w", encoding="utf-8").write(chr(10).join(lines))
          print("poison-escape patch applied")
          PYEOF'''.split('\n')

lines = io.open(P, encoding='utf-8').read().split('\n')
out = []
state = 0  # 1 = seen 'diag inserted', waiting for its PYEOF
inserted = 0
for ln in lines:
    out.append(ln)
    if state == 0 and 'print("diag inserted")' in ln:
        state = 1
        continue
    if state == 1 and ln.strip() == 'PYEOF':
        out.extend(BLOCK)
        inserted += 1
        state = 2

io.open(P, 'w', encoding='utf-8').write('\n'.join(out))
v = io.open(P, encoding='utf-8').read()
print('inserted blocks:', inserted)
print('poison-escape steps:', v.count('Patch scriptc for poison-escape'))