#!/bin/sh
# Sync local working tree -> zgh publish tree -> push (triggers GHA).
WS=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa
PORT="$WS/zcode-port"
cd "$WS/ZCode" || exit 1
[ "$1" = "--no-patch" ] || { git diff HEAD > "$WS/zgh/patches/zcode-adaptations.patch"; wc -l "$WS/zgh/patches/zcode-adaptations.patch"; }
cp "$WS/zfull/entries/"*.ts "$WS/zgh/zfull/entries/"
cp "$PORT/port-entry.ts" "$WS/zgh/zfull/entries/port-entry.ts"
cp "$PORT/port-cli.ts" "$WS/zgh/zfull/entries/port-cli.ts"
cp "$PORT/profile.json" "$WS/zgh/zfull/profiles/lib-port.profile.json"
cp "$WS/zfull/profiles/"*.json "$WS/zgh/zfull/profiles/" 2>/dev/null
cp "$WS/zfull/shims/"*.ts "$WS/zgh/zfull/shims/" 2>/dev/null
cp -r "$WS/zfull/compat/." "$WS/zgh/zfull/compat/"
cp -r "$WS/zfull/vendor/." "$WS/zgh/zfull/vendor/" 2>/dev/null
cp "$WS/zfull/PLAN.md" "$WS/zgh/zfull/" 2>/dev/null
sed "s|$WS/ZCode/|../ZCode/|g" "$WS/zfull/tsconfig.json" > "$WS/zgh/zfull/tsconfig.json"
python3 "$WS/zfull/tools/zcode_native_push_v2.py" | tail -6
