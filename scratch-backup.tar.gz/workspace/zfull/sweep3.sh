#!/bin/sh
# sweep3: full re-scan of all 22 entries with finalized config
# (zod global mapping removed, zcode-cua mappings added, shim v2 + shim imports in every entry)
cd /data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zfull || exit 1
SC=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scriptc-try/node_modules/.bin/scriptc
ZF=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zfull
for name in core contracts shared shared-types dynamic-workflow dynamic-workflow-runtime adapters bootstrap telemetry i18n cli tui services provider provider-node rpc client server zcode-server-cli model-option-map formal-proof node-repl-host; do
  echo "[$(date +%H:%M:%S)] START $name"
  timeout 2400 node "$SC" coverage "$ZF/entries/$name.ts" > "$ZF/reports2/$name.cov.log" 2>&1
  echo "[$(date +%H:%M:%S)] DONE $name rc=$? bytes=$(wc -c < "$ZF/reports2/$name.cov.log")"
done
echo "[$(date +%H:%M:%S)] SWEEP3 DONE"