class ZBase {
  _parse(input: any): unknown {
    const ks = Object.keys(input);
    return ks.length;
  }
}

export function probe(b: ZBase, x: any): number {
  return b._parse(x) as number;
}
