class ZodError {
  issues: string[] = [];
}

interface SafeParseSuccess<T> {
  success: true;
  readonly data: T;
}

interface SafeParseError<T = unknown> {
  success: false;
  error: ZodError;
  data?: T;
}

type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseError<T>;

// A: build an 'any' record with a boxed error instance
class C1<O = any> {
  m(): SafeParseResult<O> {
    const err: any = new ZodError();
    const e: any = { success: false, error: err };
    const r: SafeParseResult<O> = e;
    return r;
  }
}

// B: baseline
class C2<O = any> {
  m(): SafeParseResult<O> {
    const e: SafeParseError<O> = { success: false, error: new ZodError() };
    return e;
  }
}

// C: helper returning any
function errOfAny(e: ZodError): any {
  const out: any = { success: false, error: e };
  return out;
}
class C3<O = any> {
  m(): SafeParseResult<O> {
    const r: SafeParseResult<O> = errOfAny(new ZodError());
    return r;
  }
}

// D: all-unknown record + cast
class C4<O = any> {
  m(): SafeParseResult<O> {
    const e: { success: false; error: unknown } = { success: false, error: new ZodError() };
    const r: SafeParseResult<O> = e as SafeParseResult<O>;
    return r;
  }
}

// E: double cast through unknown
class C5<O = any> {
  m(): SafeParseResult<O> {
    const r = { success: false, error: new ZodError() } as unknown as SafeParseResult<O>;
    return r;
  }
}

// F: any-typed record holding the instance directly (implicit coercion)
class C6<O = any> {
  m(): SafeParseResult<O> {
    const e: any = { success: false, error: new ZodError() };
    const r: SafeParseResult<O> = e;
    return r;
  }
}

export function probeAll(a: C1<any>, b: C2<any>, c: C3<any>, d: C4<any>, e: C5<any>, f: C6<any>): boolean {
  return a.m().success && b.m().success && c.m().success && d.m().success && e.m().success && f.m().success;
}
