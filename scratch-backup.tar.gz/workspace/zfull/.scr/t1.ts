class ZodError {
  issues: string[] = [];
}

interface SafeParseSuccess<T> {
  success: true;
  readonly data: T;
}

interface SafeParseError<T = unknown> {
  success: false;
  error: ZodError;
  data?: T;
}

type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseError<T>;

class ZodType<O = any> {
  _parse(input: unknown): unknown {
    return input;
  }

  safeParse(input: any): SafeParseResult<O> {
    const value = this._parse(input);
    const e: SafeParseError<O> = { success: false, error: new ZodError() };
    return e;
  }
}

export function probe(x: ZodType<any>): boolean {
  return x.safeParse(1).success;
}
