function castTo<X>(v: unknown): X {
  return v as X;
}

class C<O = any> {
  m(input: any): O {
    const value = input as unknown;
    return castTo<O>(value);
  }
}

export function probe(c: C<any>): boolean {
  return c.m(1) ? true : false;
}
