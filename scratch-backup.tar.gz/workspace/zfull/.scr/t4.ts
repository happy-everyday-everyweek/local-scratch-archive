class ZodError {
  issues: string[] = [];
}

interface SafeParseSuccess<T> {
  success: true;
  readonly data: T;
}

interface SafeParseError<T = unknown> {
  success: false;
  error: ZodError;
  data?: T;
}

type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseError<T>;

// H1: unknown-param identity helper with a union assert
function castSafeParse1<X>(v: unknown): SafeParseResult<X> {
  return v as SafeParseResult<X>;
}

// H2: typed-param identity helper, no cast at all
function castSafeParse2<X>(v: SafeParseResult<X>): SafeParseResult<X> {
  return v;
}

// S-d: success helper building a dyn-data record and assert-casting it
function okOf<X>(value: unknown): SafeParseResult<X> {
  const ok: { success: true; data: unknown } = { success: true, data: value };
  return ok as SafeParseResult<X>;
}

// E-d: error helper building a dyn-error record and assert-casting it
function errOf<X>(error: ZodError): SafeParseResult<X> {
  const e: { success: false; error: unknown } = { success: false, error: error };
  return e as SafeParseResult<X>;
}

class C1<O = any> {
  _parse(input: unknown): unknown {
    return input;
  }
  m(input: any): SafeParseResult<O> {
    const value = this._parse(input);
    if (input === null) {
      return errOf<O>(new ZodError());
    }
    return okOf<O>(value);
  }
}

class C2<O = any> {
  _parse(input: unknown): unknown {
    return input;
  }
  m(input: any): SafeParseResult<O> {
    const value = this._parse(input);
    const e: { success: false; error: unknown } = { success: false, error: new ZodError() };
    if (input === null) {
      return castSafeParse1<O>(e);
    }
    const ok: { success: true; data: unknown } = { success: true, data: value };
    return castSafeParse1<O>(ok);
  }
}

export function probeAll(a: C1<any>, b: C2<any>): boolean {
  return a.m(1).success && b.m(1).success;
}
