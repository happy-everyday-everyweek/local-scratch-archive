class ZBase {
  _parse(input: any): unknown {
    return Object.keys(input).length;
  }
}

class ZodType<O = any> extends ZBase {
  safeParse(input: any): string {
    const v = this._parse(input);
    if (input === null) {
      return "err";
    }
    return String(v as number);
  }
}

export function probe(z: ZodType<any>, x: any): string {
  return z.safeParse(x);
}
