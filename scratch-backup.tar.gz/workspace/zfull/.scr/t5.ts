class ZodError {
  issues: string[] = [];
}

interface SafeParseSuccess<T> {
  success: true;
  readonly data: T;
}

interface SafeParseError<T = unknown> {
  success: false;
  error: ZodError;
  data?: T;
}

type SafeParseResult<T> = SafeParseSuccess<T> | SafeParseError<T>;

// F1: boolean-typed locals
function okOf1<X>(value: unknown): SafeParseResult<X> {
  const ok: { success: boolean; data: unknown } = { success: true, data: value };
  return ok as SafeParseResult<X>;
}
function errOf1<X>(error: ZodError): SafeParseResult<X> {
  const e: { success: boolean; error: unknown } = { success: false, error: error };
  return e as SafeParseResult<X>;
}

class C1<O = any> {
  _parse(input: unknown): unknown {
    return input;
  }
  m(input: any): SafeParseResult<O> {
    const value = this._parse(input);
    if (input === null) {
      return errOf1<O>(new ZodError());
    }
    return okOf1<O>(value);
  }
}

export function probeAll(a: C1<any>): boolean {
  return a.m(1).success;
}
