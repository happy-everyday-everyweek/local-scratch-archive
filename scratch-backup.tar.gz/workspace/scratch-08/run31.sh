#!/bin/bash
S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
BF=/tmp/abuild/zcode-android-arm64-v2
TW=/tmp/zv2/node-test
OUT=$S/step31.txt
{
echo '=== A: android appended region ==='
python3 - "$BF" <<'PYEOF'
import sys,struct
data=open(sys.argv[1],'rb').read()
off=0x2b70000
seg=data[off:off+0x60]
print('first 0x60 bytes:')
print(seg.hex())
i=data.find(b'NODE_SEA_BLOB', off, off+0x10000)
print('name offset', hex(i))
hdr=i-12
ns,ds,ty=struct.unpack('<III', data[hdr:hdr+12])
print('hdr at',hex(hdr),'namesz',ns,'descsz',ds,'type',hex(ty))
print('name bytes:', data[i:i+20])
desc=hdr+12+((ns+3)&~3)
print('desc off',hex(desc),'desc end',hex(desc+ds))
print('seg end', hex(off+0x225f5a0), 'file size', hex(len(data)))
print('desc within seg?', desc+ds<=off+0x225f5a0, ' desc within file?', desc+ds<=len(data))
print('bytes 24 before hdr:', data[hdr-0x18:hdr].hex())
PYEOF
echo '=== B: twin appended region ==='
python3 - "$TW" <<'PYEOF'
import sys,struct
data=open(sys.argv[1],'rb').read()
off=0x7420000
i=data.find(b'NODE_SEA_BLOB', off, off+0x100000)
print('name offset', hex(i))
hdr=i-12
ns,ds,ty=struct.unpack('<III', data[hdr:hdr+12])
print('hdr at',hex(hdr),'namesz',ns,'descsz',ds,'type',hex(ty))
desc=hdr+12+((ns+3)&~3)
print('desc off',hex(desc),'desc end',hex(desc+ds))
print('seg end', hex(off+0x1dcb408), 'file size', hex(len(data)))
print('desc within seg?', desc+ds<=off+0x1dcb408)
print('first 0x60 of region:', data[off:off+0x60].hex())
PYEOF
echo '=== C: simulate scan android ==='
python3 - "$BF" <<'PYEOF'
import sys,struct
data=open(sys.argv[1],'rb').read()
def sim(data,start,size,cap=400):
    end=start+size
    pos=start
    n=0
    while pos+12<=end and n<cap:
        ns,ds=struct.unpack('<II', data[pos:pos+8])
        name=data[pos+12:pos+20]
        m = ns!=0 and ds!=0 and name==b'NODE_SEA'
        print(hex(pos),'ns',ns,'ds',ds,'name',name,'MATCH' if m else '')
        if m: return True
        pos=pos+12+((ns+3)&~3)+((ds+3)&~3)
        n+=1
    print('scan ended; iters',n,'last pos',hex(pos))
    return False
print('-- android region:')
sim(data,0x2b70000,0x225f5a0)
PYEOF
echo '=== D: simulate scan twin ==='
python3 - "$TW" <<'PYEOF'
import sys,struct
data=open(sys.argv[1],'rb').read()
def sim(data,start,size,cap=400):
    end=start+size
    pos=start
    n=0
    while pos+12<=end and n<cap:
        ns,ds=struct.unpack('<II', data[pos:pos+8])
        name=data[pos+12:pos+20]
        m = ns!=0 and ds!=0 and name==b'NODE_SEA'
        print(hex(pos),'ns',ns,'ds',ds,'name',name,'MATCH' if m else '')
        if m: return True
        pos=pos+12+((ns+3)&~3)+((ds+3)&~3)
        n+=1
    print('scan ended; iters',n,'last pos',hex(pos))
    return False
print('-- twin region:')
sim(data,0x7420000,0x1dcb408)
PYEOF
echo '=== E: android strings ==='
python3 - "$BF" <<'PYEOF'
import subprocess,sys
bf=sys.argv[1]
secs=subprocess.run(['objdump','-h',bf],capture_output=True,text=True).stdout
sec=[]
for line in secs.splitlines():
    p=line.split()
    if len(p)>=6:
        try:
            sz=int(p[2],16); vma=int(p[3],16); off=int(p[5],16)
        except: continue
        sec.append((p[1],vma,off,sz))
def va2off(va):
    for n,a,o,s in sec:
        if a<=va<a+s and s>0: return o+(va-a),n
    return None,None
data=open(bf,'rb').read()
for va in [0x48d00a,0x2a9a5c8,0x50bbc1,0x44ca31]:
    off,n=va2off(va)
    if off is None: print(hex(va),'unmapped'); continue
    buf=data[off:off+96].split(bytes([0]))[0]
    print(hex(va),'|',n,'|',repr(buf[:96]))
PYEOF
echo '=== F: twin finder disasm ==='
SYM2=$(nm "$TW" 2>/dev/null | grep ' T ' | grep 'FindSingleExecutableBlob' | awk '{print $3}' | head -1)
echo "SYM2=$SYM2"
if [ -n "$SYM2" ]; then
  objdump -d "$TW" --disassemble="$SYM2" > $S/s31_twin_finder.txt 2>/dev/null
  wc -l $S/s31_twin_finder.txt
  head -100 $S/s31_twin_finder.txt
fi
echo '=== G: end ==='
} > "$OUT" 2>&1
echo "DONE31:$OUT"