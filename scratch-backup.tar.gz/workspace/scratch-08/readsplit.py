#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""大文件安全拆分器（用于含超长行的日志，避免阅读工具 OOM）。

用法:
  python3 readsplit.py <输入文件> <输出文件> [起始行] [结束行] [单行截断长度]

说明:
  - 行号从 1 开始，含起始与结束行；省略则为全部。
  - 超过截断长度的行会被截断并标注；超长行按 64KB 分块读取，不会占满内存。
"""
import sys

def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    inp = sys.argv[1]
    outp = sys.argv[2]
    start = int(sys.argv[3]) if len(sys.argv) > 3 else None
    end = int(sys.argv[4]) if len(sys.argv) > 4 else None
    cap = int(sys.argv[5]) if len(sys.argv) > 5 else 1200

    seen = 0
    written = 0
    with open(inp, "r", errors="replace", newline="") as f, open(outp, "w") as o:
        while True:
            piece = f.readline(1 << 16)
            if piece == "":
                break
            if piece.endswith("\n"):
                line = piece[:-1]
                if len(line) > cap:
                    line = line[:cap] + "...[TRUNCATED:{}]".format(len(line))
            else:
                head = piece[:cap]
                truncated = len(piece) > cap
                while True:
                    more = f.readline(1 << 16)
                    if more == "" or more.endswith("\n"):
                        break
                line = head + ("...[TRUNCATED-LONG-LINE]" if truncated else "")
            seen += 1
            if (start is None or seen >= start) and (end is None or seen <= end):
                o.write(line + "\n")
                written += 1
            if end is not None and seen >= end:
                break
    print("seen_lines={} written_lines={} -> {}".format(seen, written, outp))
    return 0

if __name__ == "__main__":
    sys.exit(main())