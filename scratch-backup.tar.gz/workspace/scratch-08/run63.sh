S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
python3 - <<'PYEOF'
import json, os
cfgd = "/tmp/zv2/smoke-home/.zcode/v2"
os.makedirs(cfgd, exist_ok=True)
cfg = os.path.join(cfgd, "provider_config.json")
with open(cfg, "w") as f:
    json.dump({
      "schemaVersion": 1,
      "config": {
        "providerOrder": ["smoke"],
        "providerConfigRules": {
          "providerRules": [
            {
              "providerId": "smoke",
              "providerName": "Smoke",
              "config": {
                "group": "standard-personal",
                "access": {"type": "api-key", "apiKey": "sk-smoke"},
                "api": {"type": "openai-chat-completions", "baseUrl": "http://127.0.0.1:8299/v1"},
                "personalModelIds": ["smoke-model"],
                "modelOrder": ["smoke-model"]
              }
            }
          ]
        },
        "modelConfigRules": {
          "providerModelRules": [
            {"providerId": "smoke", "modelId": "smoke-model", "config": {"properties": {"contextWindow": 200000}, "optionSpecs": {"reasoningLevel": {"values": ["disabled", "enabled"], "map": "{}"}}}}
          ],
          "manualProviderModelRules": []
        }
      }
    }, f, ensure_ascii=False, indent=2)
print("wrote", cfg, os.path.getsize(cfg))
PYEOF
python3 $S/mock_model.py > /tmp/zv2/mock.log 2>&1 &
MOCKPID=$!
sleep 1
python3 $S/smoke2.py > $S/step65_smoke.txt 2>&1
kill $MOCKPID 2>/dev/null
cat $S/step65_smoke.txt
echo '=== analyze ==='
python3 - <<'PYEOF'
import json, os
os.makedirs('/tmp/zv2/frames', exist_ok=True)
try:
    os.remove('/tmp/zv2/frames/events.ndjson')
except Exception:
    pass
lines = [l.rstrip('\n') for l in open('/tmp/zv2/smoke-out.txt') if l.strip()]
print('total lines', len(lines))
counts = {}
shown = set()
for l in lines:
    tag, _, body = l.partition(' ')
    try:
        j = json.loads(body)
    except Exception:
        continue
    if 'method' in j and 'id' in j:
        print('REVERSE-REQ', j.get('id'), j.get('method'))
    elif 'id' in j:
        if isinstance(j.get('result'), dict) and len(body) > 2000:
            open('/tmp/zv2/frames/id%s.json' % j['id'], 'w').write(json.dumps(j['result'], ensure_ascii=False, indent=1))
        print('RESP', j['id'], 'err' if 'error' in j else 'ok', 'len=%d' % len(body))
        if 'error' in j:
            print('   ', str(j['error'])[:250])
    elif 'method' in j:
        m = j['method']
        counts[m] = counts.get(m, 0) + 1
        if m == 'session/event':
            with open('/tmp/zv2/frames/events.ndjson', 'a') as f:
                f.write(body + '\n')
            p = j.get('params', {})
            t = p.get('type')
            if t and t not in shown:
                shown.add(t)
                print('EVT-FIRST', t, json.dumps(p.get('payload'), ensure_ascii=False)[:700])
            elif t:
                print('EVT', t, 'seq', p.get('seq'))
print('counts:', counts)
PYEOF
ls -la /tmp/zv2/frames