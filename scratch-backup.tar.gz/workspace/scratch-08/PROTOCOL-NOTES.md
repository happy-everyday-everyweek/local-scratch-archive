# ZCode 协议对接参考（v3.14.3 真实运行时验证版）

本文件由 Linux 侧冒烟测试得出（真 app-server + 真帧样例 + 本地模拟模型端到端验证）。
移动端 Kotlin 客户端、未来云端入口都以此为准。

## 1. 传输与启动

- 启动：`zcode app-server --stdio`（NDJSON over stdio，每行一个 JSON）
- 请求：`{"id":n,"method":"...","params":{...}}`
- 响应：`{"id":n,"result":{...}}` 或 `{"id":n,"error":{"code":..,"message":..,"data":..}}`
- 通知（服务端→客户端，无 id）：`{"method":"...","params":{...}}`
- 反向请求（服务端→客户端，有 id + method）：**必须应答** `{"id":<原样>,"result":{...}}`，否则 15s 超时
- stderr 是日志通道，stdout 只走帧

## 2. 反向请求应答表（已验证）

| method | 应答 |
| --- | --- |
| session/requestRuntimePreferences | `{"nativeSearchEnhancementsEnabled":true,"memoryEnabled":false,"askUserQuestionAutoResolutionEnabled":true,"modelContextBudgetStrategy":"preflight-v1"}` |
| interaction/requestProviderRuntimeHeaders | `{"headersApplied":false,"errorMessage":"Provider request auth is unavailable"}` |
| interaction/requestOfficialMcpAuthHeaders | `{"ok":false,"reason":"official_auth_unavailable"}` |
| interaction/browserList | `{"browsers":[]}` |
| interaction/requestPermission | 展示给用户的权限选项（options[].response 即应答体）；自动放行时 `{"decision":"allow"}`，拒绝 `{"decision":"deny"}` |
| interaction/requestUserInput | `{"action":"accept","content":{"answers":{"<问题>":"<答案>"}}}` 或 `{"action":"decline"}` |

## 3. 会话链路（已验证）

1. `session/create` params: `{workspace:{workspacePath,workspaceKey},mode?,model?:{providerId,modelId,options:{reasoningLevel}},thoughtLevel?}`
   → result = **完整快照**（messages/projection/protocol/runtime/session/settings/slashCommands/todos）
2. `session/subscribe` params: `{sessionId,deliveryKind:"desktop-continuous",includeSnapshot:true}`
   → `{sessionId,eventSeq,events[],snapshot?}`
3. `session/send` params: `{sessionId,content,modelSelection:{providerId,modelId,options:{reasoningLevel}}}`
   → `{accepted:true,sessionId,stateRevision}`
   - 注意：**必须带 modelSelection（含 reasoningLevel）**，否则模型创建报 "Reasoning level is required"
4. `session/list` params: `{workspace?,includeArchived?,limit?}` → `{sessions:[{sessionId,title,titleSource,status,mode,sessionKind,workspace,createdAt,updatedAt,traceId}]}`
5. `session/messages` params: `{sessionId}` → `{messages:[...]}`（实时刷新用；消息为 opencode 风格命名：info.id/sessionID、part.id/sessionID/messageID）
6. `session/setMode` `{sessionId,mode}` / `session/setThoughtLevel` `{sessionId,thoughtLevel,persistAsWorkspaceLastUsed:true}` / `session/setModel` `{sessionId,model:{providerId,modelId,options:{reasoningLevel}},persistAsWorkspaceLastUsed:true}`
   → 均返回**完整快照**（可直接刷新 UI）
7. `session/stop` `{sessionId}` → `{}`
8. `session/compact` `{sessionId,instructions?}`
9. `session/close` `{sessionId}`
10. v4 停止（与桌面一致）：`v4/command` params=`{commandId,clientId,sessionId,type:"stop",payload:{},issuedAt}` → `{commandId,status:"accepted",revisionAtDecision,...}`

## 4. 事件（session/event 通知）

外层：`{"method":"session/event","params":{...event}}`
event 字段：`{deliveryKind,eventId,seq,sessionId,turnId?,timestamp,traceId?,type,payload}`

已验证类型与 payload：

- `session.titleUpdated` `{previousTitle,source,title}`
- `session.updated` 多形态：
  - 模型请求遥测（含 baseURL/requestId/modelCall，可忽略）
  - `{messageCount,providerId,modelId,toolCount,iteration}`（步数进度）
  - `{content,stopReason,usage{inputTokens,outputTokens,totalTokens,cacheReadTokens,reasoningTokens},cacheHit{...},contextUsageBreakdown[],toolCallCount}`（单步完成）
  - `{mode,planEnabled,previousMode,source:"command"}`（模式切换）
  - `{contextWindow,modelSelection,effectiveReasoningLevel,supportedThoughtLevels}`（模型切换）
- `turn.started` `{turnNumber,input,messageId,inputId,queryId,foregroundExecutionId,intent{...}}`
- `turn.completed` `{response,tokenCount,usage{...},toolCallCount,duration,resultType:"success"|"cancelled"|"error_*",cacheStats,inputId}`
- `turn.failed` `{error{type,code,message,detail,...},turnPhase}`
- `model.streaming`（流式渲染的核心）`{assistantMessageId,kind,delta,done?,input?,toolCallId?,toolName?,partId?}`
  - kind: `start/finish/error/text_start/text_delta/text_end/reasoning_start/reasoning_delta/reasoning_end/tool_input_start/tool_input_delta/tool_input_end/tool_call`
  - 文本增量：`kind:"text_delta",delta:"..."`（会被批量合并成大块）
  - 工具参数：`tool_input_start`→`tool_input_delta`(delta=参数 JSON 字符串)→`tool_input_end`→`tool_call`(input=完整对象)
- `tool.updated` 按 kind：
  - `scheduled` `{toolCallId,assistantMessageId,toolName,dependencies,schedule,inputOmitted:true,inputRef}`
  - `started` `{toolCallId,toolName,startedAt,readOnly,sideEffectScope}`
  - `result` `{toolCallId,result{success,content,perf{totalMs,detail{...}},truncated,budgetStrategy},duration}`
  - `error` `{toolCallId,error{...}}`
  - `batch` `{toolCallIds,successCount,errorCount}`
- `streamRecovery.updated`（可忽略/诊断）
- 另有通知频道（非 session/event）：`state.updated`（settings 补丁，含 mode/model.available/thoughtLevel/permission）、`process/mcpTelemetry`、`computer-use/operation-event`、`v4/telemetry/event`、`startup/storageState`（可忽略）

## 5. 消息结构（实时）

```json
{"info":{"id":"msg_..","sessionID":"sess_..","role":"user|assistant",
  "time":{"created":ms,"completed":ms?},
  "parentID":"..","modelId":"..","providerId":"..","mode":"..","agent":"zcode-agent",
  "tokens":{...},"finish":"stop|tool-calls|..","semantics":{...},"anchor":{...},
  "contextSnapshot":{...},"tools":{...},"metadata":{...}},
 "parts":[ ... ]}
```
parts（实时命名）：
- text `{type:"text",text,time:{start,end},id,sessionID,messageID}`
- reasoning `{type:"reasoning",text,...}`（若有）
- tool `{type:"tool",callID,tool:"Bash",state:{status:"completed|running|error",input:{},output:"",title,metadata{},time{start,end}},id,sessionID,messageID}`
- step-start / step-finish / timeline / file 等（可跳过或轻渲染）
注：set*/create/subscribe 返回的 snapshot 里消息用新命名（messageId/sessionId/parentMessageId、partId），两种都要兼容。
部分字段双命名（id|messageId、sessionID|sessionId、messageID|messageId、callID|callId）。

## 6. 供应商配置（个人文件，设置页写这个）

路径：`{ZCODE_DATA_BASE_DIR|HOME}/.zcode/v2/provider_config.json`

```json
{"schemaVersion":1,
 "config":{
   "providerOrder":["<providerId>"],
   "providerConfigRules":{"providerRules":[{
     "providerId":"myai","providerName":"MyAI",
     "config":{
       "group":"standard-personal",
       "access":{"type":"api-key","apiKey":"sk-..."},
       "api":{"type":"openai-chat-completions","baseUrl":"https://.../v1"},
       "personalModelIds":["model-a"],
       "modelOrder":["model-a"]}}]},
   "modelConfigRules":{"providerModelRules":[{
     "providerId":"myai","modelId":"model-a",
     "config":{"properties":{"contextWindow":200000},
       "optionSpecs":{"reasoningLevel":{"values":["disabled","enabled"],"map":"{}"}}}}],
     "manualProviderModelRules":[]}}}
```

关键规则：
- api.type ∈ `anthropic-messages|openai-chat-completions|openai-responses`
- 每个模型**必须**声明 optionSpecs.reasoningLevel.values（选择校验强制要求 reasoningLevel 且属于 values）
- 选择（create/send/setModel）必须携带 options.reasoningLevel

## 7. 启动环境变量（Android 端 spawn 用）

- `HOME=<appfiles>/home`
- `ZCODE_DATA_BASE_DIR=<appfiles>/data`（配置目录 = data/.zcode/v2）
- `ZCODE_STORAGE_DIR=<appfiles>/storage`
- `ZCODE_BUILTIN_PROVIDER_CONFIG_FILE=<coreDir>/provider/zcode-builtin.json`（兜底，避免 SEA 内嵌资产缺失）
- `TMPDIR=<appfiles>/tmp`
- `LD_LIBRARY_PATH=<coreDir>/lib`

## 8. 渲染策略（移动端）

- 发送后：turn.started → 状态 running；订阅流里 `model.streaming` text_delta 追加到“流式缓冲”（按 assistantMessageId）；tool.updated 驱动工具卡片状态
- 期间周期性（~700ms）调用 `session/messages` 刷新（组件级更新）；turn.completed/turn.failed 后立即刷新一次
- 最终消息结构以 `session/messages` 为准；Markdown 渲染（Markwon）
- 模式：Yolo→yolo；Build→build；Chat→plan（保守只读语义，必要时可改）
