#!/bin/bash
S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
OUT=$S/step36.txt
{
cd /data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zcode-core-apk
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-arm64
export GRADLE_USER_HOME=/root/.gradle
echo '=== build start ==='
/root/gradle/gradle-9.2.1/bin/gradle assembleDebug --console=plain > $S/build36.log 2>&1
echo "gradle_exit=$?"
tail -40 $S/build36.log
echo '=== outputs ==='
ls -l app/build/outputs/apk/debug/ 2>&1
} > "$OUT" 2>&1
APK=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/zcode-core-apk/app/build/outputs/apk/debug/app-debug.apk
if [ -f "$APK" ]; then
  cp -f "$APK" /sdcard/Download/zcode-native/ZCodeCore-v4.apk
  echo '=== deliver ==='
  ls -l /sdcard/Download/zcode-native/
  sha256sum /sdcard/Download/zcode-native/ZCodeCore-v4.apk
else
  echo 'BUILD FAILED - no apk'
fi
echo "DONE36"