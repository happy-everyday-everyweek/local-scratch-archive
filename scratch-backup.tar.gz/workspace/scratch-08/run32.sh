#!/bin/bash
S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
BF=/tmp/abuild/zcode-android-arm64-v2
OUT=$S/step32.txt
{
echo '=== A: NDK search ==='
ls /root/Android 2>&1 | head -30
for d in /root/Android /root /opt /usr/local /home; do
  find $d -maxdepth 4 \( -iname '*ndk*' -o -iname 'aarch64-linux-android*' \) 2>/dev/null | head -10
done | sort -u | head -30
echo '=== B: callback area bytes ==='
python3 - "$BF" <<'PYEOF'
import sys
data=open(sys.argv[1],'rb').read()
print('callback 0x1813888:', data[0x1813888:0x18138a8].hex())
print('callsite 0x18137a0:', data[0x18137a0:0x18137b8].hex())
PYEOF
echo '=== C: getauxval plt ==='
objdump -d --section=.plt "$BF" 2>/dev/null | grep -B1 -A3 'getauxval' | head -16
echo '=== D: cave scan (zeros>=64) ==='
python3 - "$BF" <<'PYEOF'
import sys,re
data=open(sys.argv[1],'rb').read(0x2a829c0)
runs=[]
for m in re.finditer(b'\x00{64,}', data):
    runs.append((m.start(), m.end()-m.start()))
print('total runs>=64:', len(runs))
for s,l in runs[:80]:
    pre=data[s-8:s].hex() if s>=8 else ''
    post=data[s+l:s+l+8].hex()
    print(hex(s), l, 'pre:', pre, 'post:', post)
PYEOF
echo '=== E: page zeros 0x1813000-0x1814000 ==='
python3 - "$BF" <<'PYEOF'
import sys,re
data=open(sys.argv[1],'rb').read()
seg=data[0x1813000:0x1814000]
cnt=0
for m in re.finditer(b'\x00{16,}', seg):
    print(hex(0x1813000+m.start()), m.end()-m.start())
    cnt+=1
print('runs16+ in page:', cnt)
PYEOF
echo '=== F: end ==='
} > "$OUT" 2>&1
echo "DONE32:$OUT"