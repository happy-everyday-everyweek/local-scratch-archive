#!/usr/bin/env python3
# smoke4: 验证用户级 技能/命令/子智能体 文件被运行时读取
import json, os, subprocess, sys, threading, time
BASE = "/tmp/zv2"
OUT = os.path.join(BASE, "smoke4-out.txt")
HOME = os.path.join(BASE, "smoke-home")
WS = os.path.join(BASE, "smoke-ws")
node = None
for c in ["node", "/usr/local/bin/node", "/usr/bin/node"]:
    try:
        r = subprocess.run([c, "--version"], capture_output=True, text=True, timeout=10)
        if r.returncode == 0:
            node = c
            break
    except Exception:
        pass
if not node:
    print("NO_NODE"); sys.exit(0)
env = dict(os.environ)
env["HOME"] = HOME
p = subprocess.Popen([node, os.path.join(BASE, "zcode.cjs"), "app-server", "--stdio"],
                     cwd=BASE, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, text=True, bufsize=1)
out = []
def rd(stream, tag):
    try:
        for line in stream:
            out.append(tag + " " + line.rstrip("\n"))
    except Exception:
        pass
threading.Thread(target=rd, args=(p.stdout, "OUT"), daemon=True).start()
threading.Thread(target=rd, args=(p.stderr, "ERR"), daemon=True).start()
def send(obj):
    try:
        p.stdin.write(json.dumps(obj) + "\n")
        p.stdin.flush()
    except Exception as e:
        out.append("ERR send failed: %s" % e)
answered = set()
def pump():
    for l in list(out):
        if not l.startswith("OUT "):
            continue
        body = l[4:]
        try:
            j = json.loads(body)
        except Exception:
            continue
        if "method" in j and "id" in j:
            rid = j["id"]
            if rid in answered:
                continue
            answered.add(rid)
            m = j["method"]
            if m == "session/requestRuntimePreferences":
                res = {"nativeSearchEnhancementsEnabled": True, "memoryEnabled": False,
                       "askUserQuestionAutoResolutionEnabled": True,
                       "modelContextBudgetStrategy": "preflight-v1"}
            elif m == "interaction/requestProviderRuntimeHeaders":
                res = {"headersApplied": False, "errorMessage": "Provider request auth is unavailable"}
            elif m == "interaction/requestOfficialMcpAuthHeaders":
                res = {"ok": False, "reason": "official_auth_unavailable"}
            elif m == "interaction/browserList":
                res = {"browsers": []}
            else:
                res = {}
            send({"id": rid, "result": res})
            print("answered %s %s" % (rid, m))
def nap(sec):
    end = time.time() + sec
    while time.time() < end:
        pump()
        time.sleep(0.25)
def wait_for_id(wanted, timeout):
    end = time.time() + timeout
    while time.time() < end:
        pump()
        for l in list(out):
            if l.startswith("OUT "):
                try:
                    j = json.loads(l[4:])
                except Exception:
                    continue
                if j.get("id") == wanted and ("result" in j or "error" in j):
                    return j
        time.sleep(0.25)
    return None
def dump(name, r, limit=3000):
    print("=== %s ===" % name)
    if r is None:
        print("TIMEOUT")
        return None
    if "error" in r:
        print("ERROR:", json.dumps(r["error"], ensure_ascii=False)[:500])
        return None
    body = json.dumps(r.get("result"), ensure_ascii=False, indent=1)
    print(body[:limit])
    os.makedirs("/tmp/zv2/frames", exist_ok=True)
    open("/tmp/zv2/frames/%s.json" % name, "w").write(body)
    return r.get("result")
WREF = {"workspacePath": WS, "workspaceKey": WS}
send({"id": 1, "method": "runtime/capabilities", "params": {}})
wait_for_id(1, 10)
send({"id": 31, "method": "skills/referenceCatalog", "params": {"workspace": WREF}})
dump("skills_catalog2", wait_for_id(31, 30))
send({"id": 32, "method": "session/create", "params": {"workspace": WREF, "titleGenerationEnabled": False, "model": {"providerId": "smoke", "modelId": "smoke-model", "options": {"reasoningLevel": "disabled"}}}})
r2 = wait_for_id(32, 60)
res = dump("session_create2", r2, limit=6000)
sid = None
if isinstance(res, dict):
    sess = res.get("session")
    if isinstance(sess, dict):
        sid = sess.get("sessionId")
    if not sid and isinstance(res.get("snapshot"), dict):
        sid = (res["snapshot"].get("session") or {}).get("sessionId")
    sc = res.get("slashCommands") or (res.get("snapshot") or {}).get("slashCommands")
    print("SLASH_COMMANDS:", json.dumps(sc, ensure_ascii=False)[:800])
print("SID:", sid)
if sid:
    send({"id": 33, "method": "session/subagents", "params": {"sessionId": sid}})
    dump("session_subagents2", wait_for_id(33, 30))
nap(2)
try: p.stdin.close()
except Exception: pass
time.sleep(1)
try: p.terminate()
except Exception: pass
time.sleep(1)
try: p.kill()
except Exception: pass
with open(OUT, "w") as f:
    f.write("\n".join(out))
print("DONE")
