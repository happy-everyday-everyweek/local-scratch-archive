#!/usr/bin/env python3
import json, os, subprocess, sys, threading, time

BASE = "/tmp/zv2"
OUT = os.path.join(BASE, "smoke-out.txt")
HOME = os.path.join(BASE, "smoke-home")
WS = os.path.join(BASE, "smoke-ws")
os.makedirs(HOME, exist_ok=True)
os.makedirs(WS, exist_ok=True)
cfgd = os.path.join(HOME, ".zcode", "v2")
os.makedirs(cfgd, exist_ok=True)
cfg = os.path.join(cfgd, "config.json")
if not os.path.exists(cfg):
    with open(cfg, "w") as f:
        json.dump({
          "provider": {
            "smoke": {
              "name": "Smoke",
              "kind": "openai-compatible",
              "options": {"baseURL": "http://127.0.0.1:9/v1", "apiKey": "sk-smoke"},
              "models": {"smoke-model": {"name": "Smoke Model"}},
              "source": "custom"
            }
          }
        }, f, ensure_ascii=False, indent=2)

node = None
for c in ["node", "/usr/local/bin/node", "/usr/bin/node"]:
    try:
        r = subprocess.run([c, "--version"], capture_output=True, text=True, timeout=10)
        if r.returncode == 0:
            node = c
            break
    except Exception:
        pass
if not node:
    print("NO_NODE")
    sys.exit(0)
print("NODE:", node)

env = dict(os.environ)
env["HOME"] = HOME

p = subprocess.Popen([node, os.path.join(BASE, "zcode.cjs"), "app-server", "--stdio"],
                     cwd=BASE, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, text=True, bufsize=1)
out = []

def rd(stream, tag):
    try:
        for line in stream:
            out.append(tag + " " + line.rstrip("\n"))
    except Exception:
        pass

threading.Thread(target=rd, args=(p.stdout, "OUT"), daemon=True).start()
threading.Thread(target=rd, args=(p.stderr, "ERR"), daemon=True).start()

def send(obj):
    try:
        p.stdin.write(json.dumps(obj) + "\n")
        p.stdin.flush()
    except Exception as e:
        out.append("ERR send failed: %s" % e)

send({"id": 1, "method": "runtime/capabilities", "params": {}})
time.sleep(2)
send({"id": 2, "method": "session/create", "params": {"workspace": {"workspacePath": WS, "workspaceKey": WS}, "titleGenerationEnabled": False, "model": {"providerId": "smoke", "modelId": "smoke-model"}}})
resp2 = None
deadline = time.time() + 30
while time.time() < deadline:
    for l in list(out):
        if l.startswith("OUT ") and '"id"' in l:
            try:
                j = json.loads(l[4:])
            except Exception:
                continue
            if j.get("id") == 2:
                resp2 = j
    if resp2 is not None:
        break
    time.sleep(0.5)
print("RESP2:", (json.dumps(resp2, ensure_ascii=False)[:600] if resp2 else None))

sid = None
if resp2 and isinstance(resp2.get("result"), dict):
    res = resp2["result"]
    sess = res.get("session")
    if isinstance(sess, dict):
        sid = sess.get("sessionId")
    if not sid and isinstance(res.get("snapshot"), dict):
        sid = (res["snapshot"].get("session") or {}).get("sessionId")
print("SID:", sid)

if sid:
    send({"id": 3, "method": "session/subscribe", "params": {"sessionId": sid, "deliveryKind": "desktop-continuous", "includeSnapshot": True}})
    time.sleep(2.5)
    send({"id": 4, "method": "session/send", "params": {"sessionId": sid, "content": "hello from smoke"}})
    time.sleep(12)
    send({"id": 5, "method": "session/list", "params": {}})
    time.sleep(2)
    send({"id": 6, "method": "session/messages", "params": {"sessionId": sid}})
    time.sleep(2)
    send({"id": 7, "method": "v4/command", "params": {"commandId": "smoke-cmd-1", "clientId": "smoke", "sessionId": sid, "type": "stop", "payload": {}, "issuedAt": int(time.time() * 1000)}})
    time.sleep(3)
    send({"id": 8, "method": "session/stop", "params": {"sessionId": sid}})
    time.sleep(3)

try:
    p.stdin.close()
except Exception:
    pass
time.sleep(1)
try:
    p.terminate()
except Exception:
    pass
time.sleep(1)
try:
    p.kill()
except Exception:
    pass

with open(OUT, "w") as f:
    f.write("\n".join(out))
print("TOTAL_LINES:", len(out))
print("OUT_FILE:", OUT)
