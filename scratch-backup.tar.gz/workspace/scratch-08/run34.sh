#!/bin/bash
S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
BF=/tmp/abuild/zcode-android-arm64-v2
TW=/tmp/zv2/node-test
OUT=$S/step34.txt
{
echo '=== A: assemble cave v3 ==='
cat > /tmp/cave_fixB.s <<'EOF'
.text
.globl cave
cave:
	bti c
	stp x19, x20, [sp, #-32]!
	str x30, [sp, #16]
	mov x19, x2
	mov w0, #3
	.word 0x94000000
	mov x20, x0
	mov w0, #4
	.word 0x94000000
	mov w12, w0
	ldr x10, [x20, #16]
	sub x11, x20, x10
	str x11, [x19]
	str x20, [x19, #16]
	strh w12, [x19, #24]
	mov w0, #1
	ldr x30, [sp, #16]
	ldp x19, x20, [sp], #32
	ret
EOF
as -o /tmp/cave_fixB.o /tmp/cave_fixB.s && objcopy -O binary --only-section=.text /tmp/cave_fixB.o /tmp/cave_fixB.bin && echo asm_ok
ls -l /tmp/cave_fixB.bin
od -A x -t x4 /tmp/cave_fixB.bin | head -10
objdump -D -b binary -m aarch64 /tmp/cave_fixB.bin 2>/dev/null | head -40
echo '=== B: android cave context ==='
python3 - "$BF" <<'PYEOF'
import sys
data=open(sys.argv[1],'rb').read()
for off in [0x216ac3c, 0x216ac5c, 0x216af70, 0x216b090]:
    print(hex(off), data[off:off+64].hex())
PYEOF
echo '=== C: twin cave context ==='
python3 - "$TW" <<'PYEOF'
import sys
data=open(sys.argv[1],'rb').read()
for off in [0x271e584, 0x271e5c4, 0x271ef60, 0x271f900]:
    print(hex(off), data[off:off+64].hex())
PYEOF
echo '=== D: patch twin ==='
python3 - "$TW" <<'PYEOF'
import sys,struct
TW=sys.argv[1]
data=bytearray(open(TW,'rb').read())
cave_bin=open('/tmp/cave_fixB.bin','rb').read()
assert len(cave_bin)==76, ('cave len',len(cave_bin))
CB=0x271e5c4
CB_VA=CB+0x400000
assert data[CB:CB+80]==b'\x00'*80, 'twin cave area not zero!'
def enc_bl(pc,target):
    d=(target-pc)>>2
    return 0x94000000|(d&0x3FFFFFF)
cb=bytearray(cave_bin)
cb[20:24]=struct.pack('<I', enc_bl(CB_VA+20, 0x73ae70))
cb[32:36]=struct.pack('<I', enc_bl(CB_VA+32, 0x73ae70))
data[CB:CB+76]=cb
assert data[0x5be480:0x5be484]==bytes.fromhex('5f2403d5'), 'twin cb head mismatch'
d=(CB_VA-0x9be484)>>2
bword=0x14000000|(d&0x3FFFFFF)
data[0x5be484:0x5be488]=struct.pack('<I',bword)
open('/tmp/zv2/node-test-fixB','wb').write(data)
print('twin patched. b=',hex(bword),'bl1=',hex(enc_bl(CB_VA+20,0x73ae70)))
PYEOF
chmod +x /tmp/zv2/node-test-fixB
echo '=== E: verify twin patch ==='
python3 - <<'PYEOF'
d=open('/tmp/zv2/node-test-fixB','rb').read()
print('cb head:', d[0x5be480:0x5be498].hex())
print('cave   :', d[0x271e5c4:0x271e610].hex())
PYEOF
objdump -d --start-address=0x9be480 --stop-address=0x9be490 /tmp/zv2/node-test-fixB 2>/dev/null | head -12
objdump -d --start-address=0x2b1e5c4 --stop-address=0x2b1e610 /tmp/zv2/node-test-fixB 2>/dev/null | head -30
echo '=== F: run twin-fixB ==='
timeout 90 /tmp/zv2/node-test-fixB --version > /tmp/twinfixB.out 2>&1; echo "fixB_exit=$?"
head -20 /tmp/twinfixB.out
echo '--- also unpatched twin (control) ---'
timeout 90 "$TW" --version > /tmp/twinctl.out 2>&1; echo "ctl_exit=$?"
head -5 /tmp/twinctl.out
echo '=== G: patch android ==='
python3 - "$BF" <<'PYEOF'
import sys,struct
BF=sys.argv[1]
data=bytearray(open(BF,'rb').read())
cave_bin=open('/tmp/cave_fixB.bin','rb').read()
CB=0x216ac5c
assert data[CB:CB+80]==b'\x00'*80, 'android cave area not zero!'
def enc_bl(pc,target):
    d=(target-pc)>>2
    return 0x94000000|(d&0x3FFFFFF)
cb=bytearray(cave_bin)
cb[20:24]=struct.pack('<I', enc_bl(CB+20, 0x2a7d970))
cb[32:36]=struct.pack('<I', enc_bl(CB+32, 0x2a7d970))
data[CB:CB+76]=cb
assert data[0x1813888:0x181388c]==bytes.fromhex('5f2403d5'), 'android cb head mismatch'
d=(CB-0x181388c)>>2
bword=0x14000000|(d&0x3FFFFFF)
data[0x181388c:0x1813890]=struct.pack('<I',bword)
open('/tmp/abuild/zcode-fixB','wb').write(data)
print('android patched. b=',hex(bword))
PYEOF
echo '=== H: verify android patch ==='
python3 - <<'PYEOF'
import hashlib
d=open('/tmp/abuild/zcode-fixB','rb').read()
print('size',len(d),'sha256',hashlib.sha256(d).hexdigest())
print('cb head:', d[0x1813888:0x18138a0].hex())
print('cave   :', d[0x216ac5c:0x216aca8].hex())
PYEOF
objdump -d --start-address=0x1813888 --stop-address=0x1813898 /tmp/abuild/zcode-fixB 2>/dev/null | head -12
objdump -d --start-address=0x216ac5c --stop-address=0x216aca8 /tmp/abuild/zcode-fixB 2>/dev/null | head -30
echo '=== I: end ==='
} > "$OUT" 2>&1
echo "DONE34:$OUT"