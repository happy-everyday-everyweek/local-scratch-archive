S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
R=/home/zcode-cli-src
O=$S/step60.txt
idx=$R/packages/shared/src/zcode-protocol/index.ts
shared=$R/packages/shared/src
{
echo '=== A: locate schemas ==='
grep -rn 'zcodeWorkspaceRefSchema =\|zcodeSessionInfoSchema =\|zcodeSessionModeSchema =\|zcodeSessionPersistenceSchema =\|zcodeMessageWithPartsSchema =\|zcodeMessagePartSchema =' $shared 2>/dev/null | head -60
echo '=== A2: formatModelPickerValue ==='
grep -n -B2 -A18 'export function formatModelPickerValue' $shared/model-selection.ts | head -40
echo '=== B: index 1000-1130 ==='
sed -n '1000,1130p' "$idx"
echo '=== B2: index 1130-1260 ==='
sed -n '1130,1260p' "$idx"
echo '=== C: payload schemas 1260-1445 ==='
sed -n '1260,1445p' "$idx"
echo '=== D: permission area 520-640 ==='
sed -n '520,640p' "$idx"
echo '=== E: command.ts 240-355 ==='
sed -n '240,355p' "$R/packages/shared/src/zcode-protocol-v4/command.ts"
echo '=== F: v4 command params/result in transport ==='
grep -n 'command\|Command' $R/packages/shared/src/zcode-protocol-v4/transport.ts | grep -i 'param\|result\|schema\|subscribe\|method' | head -60
echo '=== G: interaction-broker ==='
cat "$R/apps/zcode-cli/packages/bootstrap/src/zcode-protocol/interaction-broker.ts"
echo '=== H: desktop/UI permission answer ==='
grep -rn 'requestPermission' $R/packages/desktop/src $R/packages/ui/src 2>/dev/null | head -40
grep -rn 'resolvePermission\|respondToPermission\|permissionResponse' $R/packages/services/src $R/packages/desktop/src 2>/dev/null | head -40
echo '=== I: chat mode search ==='
grep -rni 'chat mode\|"chat"' $shared $R/apps/zcode-cli/packages/tui/src 2>/dev/null | head -40
echo '=== J: getAppConfigDir ==='
grep -rn 'function getAppConfigDir\|const getAppConfigDir\|getAppConfigDir =' $shared $R/packages/services/src 2>/dev/null | head -10
echo '=== K: config reader shape 95-200 ==='
sed -n '95,200p' "$R/packages/services/src/model-provider/legacyZCodeConfigProviderReader.ts"
echo '=== K2: reader shape 300-470 ==='
sed -n '300,470p' "$R/packages/services/src/model-provider/legacyZCodeConfigProviderReader.ts"
echo '=== L: stop legacy wire ==='
grep -rn 'session/stop\|sessionStop' $R/apps/zcode-cli/packages/bootstrap/src/zcode-protocol/ 2>/dev/null | head -30
echo '=== M: reasoningLevel specs ==='
grep -rn 'reasoningLevel:' $R/apps/zcode-cli/packages $R/packages 2>/dev/null | head -40
echo '=== N: tmp env for smoke ==='
ls -la /tmp/zv2 2>/dev/null | head -40
ls /tmp 2>/dev/null | head -40
echo '=== O: legacy types part/message ==='
grep -n 'Part\|part' "$shared/zcode-protocol-legacy-types.ts" | head -100
echo '=== Z: end ==='
} > "$O" 2>&1
echo DONE60
wc -l "$O"