#!/bin/bash
S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
BF=/tmp/abuild/zcode-android-arm64-v2
TW=/tmp/zv2/node-test
OUT=$S/step33.txt
{
echo '=== A: android section bounds ==='
objdump -h "$BF" 2>/dev/null | head -40
echo '=== B: android ret+zeros candidates (>=48) ==='
python3 - "$BF" <<'PYEOF'
import sys,re
data=open(sys.argv[1],'rb').read(0x2a829c0)
cand=[]
for m in re.finditer(re.escape(bytes.fromhex('c0035fd6'))+b'\x00{48,}', data):
    s=m.start()
    l=len(m.group())-4
    cand.append((s+4,l))
print('ret+zeros candidates:', len(cand))
for o,l in cand[:40]:
    print(hex(o), l, 'pre32:', data[o-32:o].hex())
PYEOF
echo '=== C: android nop runs ==='
python3 - "$BF" <<'PYEOF'
import sys,re
data=open(sys.argv[1],'rb').read(0x2a829c0)
nop=bytes.fromhex('1f2003d5')
runs=[]
i=0
while True:
    j=data.find(nop*8,i)
    if j<0: break
    runs.append(j); i=j+1
print('nop8+ runs:', len(runs))
for o in runs[:25]:
    print(hex(o), 'pre32:', data[o-32:o].hex())
PYEOF
echo '=== D: assembler check ==='
command -v as objcopy objdump
as --version 2>/dev/null | head -1
cat > /tmp/cave_fixB.s <<'EOF'
.text
.globl cave
cave:
	bti c
	stp x19, x30, [sp, #-16]!
	mov x19, x2
	mov w0, #3
	.word 0x94000000
	mov x9, x0
	ldr x10, [x9, #8]
	sub x11, x9, x10
	ldrh w12, [x11, #56]
	str x11, [x19]
	str x9, [x19, #16]
	strh w12, [x19, #24]
	mov w0, #1
	ldp x19, x30, [sp], #16
	ret
EOF
as -o /tmp/cave_fixB.o /tmp/cave_fixB.s && objcopy -O binary --only-section=.text /tmp/cave_fixB.o /tmp/cave_fixB.bin && echo 'cave asm ok' && xxd /tmp/cave_fixB.bin && objdump -D -b binary -m aarch64 /tmp/cave_fixB.bin 2>/dev/null | head -40
echo '=== E: twin callback & plt ==='
python3 - "$TW" <<'PYEOF'
import sys
data=open(sys.argv[1],'rb').read()
print('twin file0x5be480 (va0x9be480):', data[0x5be480:0x5be4a0].hex())
print('twin file0x5be470:', data[0x5be470:0x5be480].hex())
PYEOF
objdump -d --section=.plt "$TW" 2>/dev/null | grep -B1 -A3 'getauxval' | head -12
echo '=== F: twin ret+zeros candidates ==='
python3 - "$TW" <<'PYEOF'
import sys,re
data=open(sys.argv[1],'rb').read()
cand=[]
for m in re.finditer(re.escape(bytes.fromhex('c0035fd6'))+b'\x00{48,}', data):
    s=m.start()
    l=len(m.group())-4
    cand.append((s+4,l))
print('twin ret+zeros candidates:', len(cand))
for o,l in cand[:40]:
    print(hex(o), l, 'pre32:', data[o-32:o].hex())
PYEOF
echo '=== G: end ==='
} > "$OUT" 2>&1
echo "DONE33:$OUT"