#!/usr/bin/env python3
import json, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = 8299


def has_tool_result(req):
    for m in req.get('messages', []) or []:
        if not isinstance(m, dict):
            continue
        if m.get('role') == 'tool':
            return True
        content = m.get('content')
        if isinstance(content, list):
            for c in content:
                if isinstance(c, dict) and c.get('type') in ('tool-result', 'tool_result'):
                    return True
        if isinstance(content, str) and 'smoke-hi' in content:
            return True
    return False


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def do_GET(self):
        self.send_response(404)
        self.send_header('Content-Length', '0')
        self.end_headers()

    def do_POST(self):
        self.close_connection = True
        ln = int(self.headers.get('Content-Length', 0) or 0)
        body = self.rfile.read(ln) if ln else b''
        try:
            req = json.loads(body.decode('utf-8'))
        except Exception:
            req = {}
        if self.path.endswith('/chat/completions'):
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'close')
            self.end_headers()
            model = req.get('model', 'smoke-model')
            base = {"id": "chatcmpl-smoke", "object": "chat.completion.chunk",
                    "created": int(time.time()), "model": model}

            def chunk(obj):
                self.wfile.write(('data: ' + json.dumps(obj, ensure_ascii=False) + '\n\n').encode('utf-8'))
                self.wfile.flush()

            if not has_tool_result(req):
                chunk({**base, "choices": [{"index": 0, "delta": {"role": "assistant", "content": ""}, "finish_reason": None}]})
                chunk({**base, "choices": [{"index": 0, "delta": {"tool_calls": [{"index": 0, "id": "call_smoke_1", "type": "function",
                                                                                 "function": {"name": "Bash", "arguments": "{\"command\":\"echo smoke-hi\"}"}}]},
                                            "finish_reason": None}]})
                chunk({**base, "choices": [{"index": 0, "delta": {}, "finish_reason": "tool_calls"}]})
                chunk({**base, "choices": [], "usage": {"prompt_tokens": 20, "completion_tokens": 8, "total_tokens": 28}})
                self.wfile.write(b'data: [DONE]\n\n')
                self.wfile.flush()
            else:
                chunk({**base, "choices": [{"index": 0, "delta": {"role": "assistant", "content": ""}, "finish_reason": None}]})
                text = "工具已执行完毕，冒烟测试完成。"
                for ch in text:
                    chunk({**base, "choices": [{"index": 0, "delta": {"content": ch}, "finish_reason": None}]})
                    time.sleep(0.008)
                chunk({**base, "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]})
                chunk({**base, "choices": [], "usage": {"prompt_tokens": 30, "completion_tokens": 12, "total_tokens": 42}})
                self.wfile.write(b'data: [DONE]\n\n')
                self.wfile.flush()
        else:
            self.send_response(404)
            self.send_header('Content-Length', '0')
            self.end_headers()


print("mock model listening on", PORT)
ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()