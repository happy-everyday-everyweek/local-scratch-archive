#!/usr/bin/env python3
# smoke6: 定位斜杠命令的数据来源（readPresentation / create / subscribe）
import json, os, subprocess, sys, threading, time
BASE = "/tmp/zv2"
HOME = os.path.join(BASE, "smoke-home")
WS = os.path.join(BASE, "smoke-ws")
node = None
for c in ["node", "/usr/local/bin/node", "/usr/bin/node"]:
    try:
        r = subprocess.run([c, "--version"], capture_output=True, text=True, timeout=10)
        if r.returncode == 0:
            node = c
            break
    except Exception:
        pass
if not node:
    print("NO_NODE"); sys.exit(0)
env = dict(os.environ)
env["HOME"] = HOME
p = subprocess.Popen([node, os.path.join(BASE, "zcode.cjs"), "app-server", "--stdio"],
                     cwd=BASE, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, text=True, bufsize=1)
out = []
def rd(stream, tag):
    try:
        for line in stream:
            out.append(tag + " " + line.rstrip("\n"))
    except Exception:
        pass
threading.Thread(target=rd, args=(p.stdout, "OUT"), daemon=True).start()
threading.Thread(target=rd, args=(p.stderr, "ERR"), daemon=True).start()
def send(obj):
    try:
        p.stdin.write(json.dumps(obj) + "\n")
        p.stdin.flush()
    except Exception as e:
        out.append("ERR send failed: %s" % e)
answered = set()
def pump():
    for l in list(out):
        if not l.startswith("OUT "):
            continue
        body = l[4:]
        try:
            j = json.loads(body)
        except Exception:
            continue
        if "method" in j and "id" in j:
            rid = j["id"]
            if rid in answered:
                continue
            answered.add(rid)
            m = j["method"]
            if m == "session/requestRuntimePreferences":
                res = {"nativeSearchEnhancementsEnabled": True, "memoryEnabled": False,
                       "askUserQuestionAutoResolutionEnabled": True,
                       "modelContextBudgetStrategy": "preflight-v1"}
            else:
                res = {}
            send({"id": rid, "result": res})
            print("answered %s %s" % (rid, m))
def wait_for_id(wanted, timeout):
    end = time.time() + timeout
    while time.time() < end:
        pump()
        for l in list(out):
            if l.startswith("OUT "):
                try:
                    j = json.loads(l[4:])
                except Exception:
                    continue
                if j.get("id") == wanted and ("result" in j or "error" in j):
                    return j
        time.sleep(0.25)
    return None
def brief(name, r):
    print("=== %s ===" % name)
    if r is None:
        print("TIMEOUT")
        return None
    if "error" in r:
        print("ERROR:", json.dumps(r["error"], ensure_ascii=False)[:300])
        return None
    return r.get("result")
WREF = {"workspacePath": WS, "workspaceKey": WS}
# 1. capabilities（确认服务可用）
send({"id": 1, "method": "runtime/capabilities", "params": {}})
brief("capabilities", wait_for_id(1, 15))
# 2. readPresentation（无会话，15s 超时）
send({"id": 2, "method": "workspace/readPresentation", "params": {"workspace": WREF}})
r2 = brief("readPresentation-before-session", wait_for_id(2, 15))
if r2:
    print("slashCommands:", json.dumps(r2.get("slashCommands", []), ensure_ascii=False)[:600])
# 3. create
send({"id": 3, "method": "session/create", "params": {"workspace": WREF, "titleGenerationEnabled": False, "model": {"providerId": "smoke", "modelId": "smoke-model", "options": {"reasoningLevel": "disabled"}}}})
r3 = brief("session/create", wait_for_id(3, 60))
sid = None
if r3:
    sid = (r3.get("session") or {}).get("sessionId")
    print("create slashCommands:", json.dumps(r3.get("slashCommands", []), ensure_ascii=False)[:600])
print("SID:", sid)
# 4. subscribe（检查 snapshot 里的 slashCommands）
if sid:
    send({"id": 4, "method": "session/subscribe", "params": {"sessionId": sid, "deliveryKind": "desktop-continuous", "includeSnapshot": True}})
    r4 = brief("session/subscribe", wait_for_id(4, 30))
    if r4:
        snap = r4.get("snapshot") or {}
        print("subscribe top keys:", list(r4.keys()))
        print("snapshot keys:", list(snap.keys()))
        print("snapshot.slashCommands:", json.dumps(snap.get("slashCommands", []), ensure_ascii=False)[:600])
# 5. readPresentation again（会话后）
send({"id": 5, "method": "workspace/readPresentation", "params": {"workspace": WREF}})
r5 = brief("readPresentation-after-session", wait_for_id(5, 15))
if r5:
    print("slashCommands:", json.dumps(r5.get("slashCommands", []), ensure_ascii=False)[:600])
try: p.stdin.close()
except Exception: pass
time.sleep(1)
try: p.terminate()
except Exception: pass
time.sleep(1)
try: p.kill()
except Exception: pass
with open(os.path.join(BASE, "smoke6-out.txt"), "w") as f:
    f.write("\n".join(out))
print("DONE")