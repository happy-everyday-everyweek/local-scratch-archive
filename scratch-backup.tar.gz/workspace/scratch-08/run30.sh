#!/bin/bash
S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
BF=/tmp/abuild/zcode-android-arm64-v2
TW=/tmp/zv2/node-test
OUT=$S/step30b.txt
{
echo '=== A: tool check ==='
command -v addr2line objdump nm readelf
echo '=== B: twin sea symbols ==='
nm -C "$TW" 2>/dev/null | grep -iE 'FindSingleExecutable|IsSingleExecutable' | head -30
echo '=== C: twin addr2line ==='
for a in $(nm "$TW" 2>/dev/null | grep -iE 'FindSingleExecutableBlob|IsSingleExecutable' | awk '{print $1}' | head -6); do
  echo "-- $a"
  addr2line -e "$TW" -f -C -i "0x$a" | head -14
done
echo '=== D: twin finder disasm ==='
SYM=$(nm "$TW" 2>/dev/null | grep -E 'FindSingleExecutableBlob' | head -1 | awk '{print $NF}')
echo "SYM=$SYM"
if [ -n "$SYM" ]; then
  objdump -d "$TW" --disassemble="$SYM" > "$S/s30_twin_finder.txt" 2>/dev/null
  wc -l "$S/s30_twin_finder.txt"
  head -120 "$S/s30_twin_finder.txt"
fi
echo '=== E: twin finder source lines ==='
if [ -n "$SYM" ]; then
  objdump -dl "$TW" --disassemble="$SYM" 2>/dev/null | grep -E '^/|:' | head -80
fi
echo '=== F: android finder region ==='
objdump -d --start-address=0x1813600 --stop-address=0x1813e00 "$BF" > "$S/s30_and_finder.txt" 2>/dev/null
wc -l "$S/s30_and_finder.txt"
head -200 "$S/s30_and_finder.txt"
echo '=== G: android imports ==='
objdump -T "$BF" 2>/dev/null | grep -iE 'iterate|auxval|fopen|fread|readlink|mmap|fstat' | head -40
echo '=== H: android PHDRs ==='
readelf -lW "$BF" 2>/dev/null | head -70
echo '=== I: twin PHDRs ==='
readelf -lW "$TW" 2>/dev/null | head -70
echo '=== J: end ==='
} > "$OUT" 2>&1
echo "DONE30:$OUT"
