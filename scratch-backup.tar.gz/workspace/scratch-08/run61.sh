S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
R=/home/zcode-cli-src
O=$S/step61.txt
I=$R/packages/shared/src/zcode-protocol/index.ts
{
echo '=== A: paths.ts ==='
sed -n '1,70p' "$R/packages/services/src/paths.ts"
echo '=== B: userinput & permission schema locate ==='
grep -rn 'zcodeUserInputResponseSchema\|zcodeUserInputQuestionSchema\|zcodeUserInputQuestion\b' $R/packages/shared/src 2>/dev/null | head -30
grep -rn 'zcodePermissionResponseSchema =\|zcodePermissionDecisionSchema =' $R/packages/shared/src 2>/dev/null | head -20
echo '=== C: stop/compact params ==='
grep -n 'StopParams\|CompactParams\|SessionStop\|SessionCompact' $I | head -40
for name in zcodeSessionCompactParamsSchema zcodeSessionStopParamsSchema; do
  L=$(grep -n "export const $name" "$I" | head -1 | cut -d: -f1)
  if [ -n "$L" ]; then echo "--- $name @ $L ---"; sed -n "${L},$((L+16))p" "$I"; fi
done
echo '=== D: runtime state & status ==='
L=$(grep -n 'zcodeSessionRuntimeStateSchema =' "$I" | head -1 | cut -d: -f1)
if [ -n "$L" ]; then echo "runtime @ $L"; sed -n "${L},$((L+70))p" "$I"; fi
L=$(grep -n 'zcodeSessionStatusSchema =' "$I" | head -1 | cut -d: -f1)
if [ -n "$L" ]; then echo "status @ $L"; sed -n "${L},$((L+14))p" "$I"; fi
echo '=== E: v4 command wire ==='
grep -n 'command' $R/packages/shared/src/zcode-protocol-v4/transport.ts | head -60
sed -n '360,420p' $R/packages/shared/src/zcode-protocol-v4/transport.ts
grep -n 'v4/command\|commandEnvelope\|CommandEnvelope\|commands' $R/apps/zcode-cli/packages/bootstrap/src/zcode-protocol-v4/v4-gateway.ts | head -40
echo '=== F: userinput schema dump ==='
F=$(grep -rln 'export const zcodeUserInputResponseSchema' $R/packages/shared/src 2>/dev/null | head -1)
if [ -n "$F" ]; then echo "file=$F"; L=$(grep -n 'export const zcodeUserInputResponseSchema' "$F" | head -1 | cut -d: -f1); sed -n "$((L>40?L-40:1)),$((L+30))p" "$F"; fi
echo '=== G: permission response schema dump ==='
F=$(grep -rln 'export const zcodePermissionResponseSchema' $R/packages/shared/src 2>/dev/null | head -1)
if [ -n "$F" ]; then echo "file=$F"; L=$(grep -n 'export const zcodePermissionResponseSchema' "$F" | head -1 | cut -d: -f1); sed -n "$((L>40?L-40:1)),$((L+40))p" "$F"; fi
echo '=== H: permission decision ==='
F=$(grep -rln 'zcodePermissionDecisionSchema' $R/packages/shared/src 2>/dev/null | head -1)
if [ -n "$F" ]; then echo "file=$F"; L=$(grep -n 'zcodePermissionDecisionSchema =' "$F" | head -1 | cut -d: -f1); sed -n "$((L>10?L-10:1)),$((L+14))p" "$F"; fi
echo '=== Z: end ==='
} > "$O" 2>&1
echo DONE61
wc -l "$O"
echo '=== smoke env ==='
command -v node || true
node --version 2>&1 | head -2 || true
python3 "$S/smoke.py" > "$S/step61_smoke.txt" 2>&1
echo SMOKE_DONE
wc -l "$S/step61_smoke.txt"