#!/usr/bin/env python3
# smoke3: 实测 设置功能组的协议方法（plugins/mcp/skills/workflows/usage/subagents）
import json, os, subprocess, sys, threading, time
BASE = "/tmp/zv2"
OUT = os.path.join(BASE, "smoke3-out.txt")
HOME = os.path.join(BASE, "smoke-home")
WS = os.path.join(BASE, "smoke-ws")
os.makedirs(HOME, exist_ok=True)
os.makedirs(WS, exist_ok=True)
node = None
for c in ["node", "/usr/local/bin/node", "/usr/bin/node"]:
    try:
        r = subprocess.run([c, "--version"], capture_output=True, text=True, timeout=10)
        if r.returncode == 0:
            node = c
            break
    except Exception:
        pass
if not node:
    print("NO_NODE"); sys.exit(0)
print("NODE:", node)
env = dict(os.environ)
env["HOME"] = HOME
p = subprocess.Popen([node, os.path.join(BASE, "zcode.cjs"), "app-server", "--stdio"],
                     cwd=BASE, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, text=True, bufsize=1)
out = []
def rd(stream, tag):
    try:
        for line in stream:
            out.append(tag + " " + line.rstrip("\n"))
    except Exception:
        pass
threading.Thread(target=rd, args=(p.stdout, "OUT"), daemon=True).start()
threading.Thread(target=rd, args=(p.stderr, "ERR"), daemon=True).start()
def send(obj):
    try:
        p.stdin.write(json.dumps(obj) + "\n")
        p.stdin.flush()
    except Exception as e:
        out.append("ERR send failed: %s" % e)
answered = set()
def pump():
    for l in list(out):
        if not l.startswith("OUT "):
            continue
        body = l[4:]
        try:
            j = json.loads(body)
        except Exception:
            continue
        if "method" in j and "id" in j:
            rid = j["id"]
            if rid in answered:
                continue
            answered.add(rid)
            m = j["method"]
            if m == "session/requestRuntimePreferences":
                res = {"nativeSearchEnhancementsEnabled": True, "memoryEnabled": False,
                       "askUserQuestionAutoResolutionEnabled": True,
                       "modelContextBudgetStrategy": "preflight-v1"}
            elif m == "interaction/requestProviderRuntimeHeaders":
                res = {"headersApplied": False, "errorMessage": "Provider request auth is unavailable"}
            elif m == "interaction/requestOfficialMcpAuthHeaders":
                res = {"ok": False, "reason": "official_auth_unavailable"}
            elif m == "interaction/browserList":
                res = {"browsers": []}
            elif m == "interaction/requestPermission":
                res = {"decision": "deny", "reason": "smoke auto-deny"}
            elif m == "interaction/requestUserInput":
                res = {"action": "decline"}
            else:
                res = {}
            send({"id": rid, "result": res})
            print("answered %s %s" % (rid, m))
def nap(sec):
    end = time.time() + sec
    while time.time() < end:
        pump()
        time.sleep(0.25)
def wait_for_id(wanted, timeout):
    end = time.time() + timeout
    while time.time() < end:
        pump()
        for l in list(out):
            if l.startswith("OUT "):
                try:
                    j = json.loads(l[4:])
                except Exception:
                    continue
                if j.get("id") == wanted and ("result" in j or "error" in j):
                    return j
        time.sleep(0.25)
    return None
def dump(name, r):
    print("=== %s ===" % name)
    if r is None:
        print("TIMEOUT")
        return
    if "error" in r:
        print("ERROR:", json.dumps(r["error"], ensure_ascii=False)[:500])
        return
    body = json.dumps(r.get("result"), ensure_ascii=False, indent=1)
    print(body[:2400])
    os.makedirs("/tmp/zv2/frames", exist_ok=True)
    open("/tmp/zv2/frames/%s.json" % name, "w").write(body)
WREF = {"workspacePath": WS, "workspaceKey": WS}
send({"id": 1, "method": "runtime/capabilities", "params": {}})
dump("cap", wait_for_id(1, 10))
send({"id": 22, "method": "plugins/list", "params": {"workspace": WREF}})
dump("plugins_list", wait_for_id(22, 30))
send({"id": 23, "method": "plugins/overview", "params": {"workspace": WREF}})
dump("plugins_overview", wait_for_id(23, 30))
send({"id": 24, "method": "mcp/list", "params": {"workspace": WREF, "mode": "status"}})
dump("mcp_list", wait_for_id(24, 30))
send({"id": 25, "method": "skills/referenceCatalog", "params": {"workspace": WREF}})
dump("skills_catalog", wait_for_id(25, 30))
send({"id": 26, "method": "workflows/list", "params": {"workspace": WREF, "scope": "global"}})
dump("workflows_global", wait_for_id(26, 30))
send({"id": 27, "method": "workflows/list", "params": {"workspace": WREF}})
dump("workflows_project", wait_for_id(27, 30))
send({"id": 28, "method": "usage/stats", "params": {"range": "7d"}})
dump("usage_stats", wait_for_id(28, 30))
send({"id": 2, "method": "session/create", "params": {"workspace": WREF, "titleGenerationEnabled": False, "model": {"providerId": "smoke", "modelId": "smoke-model", "options": {"reasoningLevel": "disabled"}}}})
r2 = wait_for_id(2, 60)
sid = None
if r2 and isinstance(r2.get("result"), dict):
    res = r2["result"]
    sess = res.get("session")
    if isinstance(sess, dict):
        sid = sess.get("sessionId")
    if not sid and isinstance(res.get("snapshot"), dict):
        sid = (res["snapshot"].get("session") or {}).get("sessionId")
print("SID:", sid)
if sid:
    send({"id": 29, "method": "session/subagents", "params": {"sessionId": sid}})
    dump("session_subagents", wait_for_id(29, 30))
nap(2)
try: p.stdin.close()
except Exception: pass
time.sleep(1)
try: p.terminate()
except Exception: pass
time.sleep(1)
try: p.kill()
except Exception: pass
with open(OUT, "w") as f:
    f.write("\n".join(out))
print("TOTAL_LINES:", len(out), "ANSWERED:", len(answered))
