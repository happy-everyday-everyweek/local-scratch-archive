import "../shims/dom-globals.js";
export * from "@zcode/services/onboarding/onboardingRecord";
