#!/usr/bin/env python3
import json, os, subprocess, sys, threading, time

BASE = "/tmp/zv2"
OUT = os.path.join(BASE, "smoke-out.txt")
HOME = os.path.join(BASE, "smoke-home")
WS = os.path.join(BASE, "smoke-ws")
os.makedirs(HOME, exist_ok=True)
os.makedirs(WS, exist_ok=True)
cfgd = os.path.join(HOME, ".zcode", "v2")
os.makedirs(cfgd, exist_ok=True)
cfg = os.path.join(cfgd, "provider_config.json")
if not os.path.exists(cfg):
    with open(cfg, "w") as f:
        json.dump({
          "schemaVersion": "zcode.model-providers.v2",
          "providers": [
            {
              "id": "smoke",
              "name": "Smoke",
              "endpoints": {"anthropic": "", "openai": "", "gemini": "", "baseURL": "http://127.0.0.1:9/v1"},
              "apiFormat": "openai-chat-completions",
              "source": "custom",
              "apiKeyRequired": True,
              "apiKey": "sk-smoke",
              "defaultKind": "openai-compatible",
              "models": [
                {
                  "id": "smoke-model",
                  "name": "Smoke Model",
                  "kinds": ["openai-compatible"],
                  "defaultKind": "openai-compatible",
                  "modalities": {"input": ["text"], "output": ["text"]},
                  "contextWindow": 200000
                }
              ],
              "createdAt": 1759700000000,
              "updatedAt": 1759700000000
            }
          ]
        }, f, ensure_ascii=False, indent=2)
legacy_cfg = os.path.join(cfgd, "config.json")
try:
    with open(legacy_cfg, "w") as f:
        f.write("{}")
except Exception:
    pass

node = None
for c in ["node", "/usr/local/bin/node", "/usr/bin/node"]:
    try:
        r = subprocess.run([c, "--version"], capture_output=True, text=True, timeout=10)
        if r.returncode == 0:
            node = c
            break
    except Exception:
        pass
if not node:
    print("NO_NODE")
    sys.exit(0)
print("NODE:", node)

env = dict(os.environ)
env["HOME"] = HOME

p = subprocess.Popen([node, os.path.join(BASE, "zcode.cjs"), "app-server", "--stdio"],
                     cwd=BASE, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, text=True, bufsize=1)
out = []

def rd(stream, tag):
    try:
        for line in stream:
            out.append(tag + " " + line.rstrip("\n"))
    except Exception:
        pass

threading.Thread(target=rd, args=(p.stdout, "OUT"), daemon=True).start()
threading.Thread(target=rd, args=(p.stderr, "ERR"), daemon=True).start()

def send(obj):
    try:
        p.stdin.write(json.dumps(obj) + "\n")
        p.stdin.flush()
    except Exception as e:
        out.append("ERR send failed: %s" % e)

answered = set()

def pump():
    for l in list(out):
        if not l.startswith("OUT "):
            continue
        body = l[4:]
        try:
            j = json.loads(body)
        except Exception:
            continue
        if "method" in j and "id" in j:
            rid = j["id"]
            if rid in answered:
                continue
            answered.add(rid)
            m = j["method"]
            if m == "session/requestRuntimePreferences":
                res = {"nativeSearchEnhancementsEnabled": True, "memoryEnabled": False,
                       "askUserQuestionAutoResolutionEnabled": True,
                       "modelContextBudgetStrategy": "preflight-v1"}
            elif m == "interaction/requestProviderRuntimeHeaders":
                res = {"headersApplied": False, "errorMessage": "Provider request auth is unavailable"}
            elif m == "interaction/requestOfficialMcpAuthHeaders":
                res = {"ok": False, "reason": "official_auth_unavailable"}
            elif m == "interaction/browserList":
                res = {"browsers": []}
            elif m == "interaction/requestPermission":
                res = {"decision": "deny", "reason": "smoke auto-deny"}
            elif m == "interaction/requestUserInput":
                res = {"action": "decline"}
            else:
                res = {}
            send({"id": rid, "result": res})
            print("answered %s %s" % (rid, m))

def nap(sec):
    end = time.time() + sec
    while time.time() < end:
        pump()
        time.sleep(0.25)

def wait_for_id(wanted, timeout):
    end = time.time() + timeout
    while time.time() < end:
        pump()
        for l in list(out):
            if l.startswith("OUT "):
                try:
                    j = json.loads(l[4:])
                except Exception:
                    continue
                if j.get("id") == wanted and ("result" in j or "error" in j):
                    return j
        time.sleep(0.25)
    return None

send({"id": 1, "method": "runtime/capabilities", "params": {}})
r1 = wait_for_id(1, 10)
print("R1:", str(r1)[:200])

send({"id": 2, "method": "session/create", "params": {"workspace": {"workspacePath": WS, "workspaceKey": WS}, "titleGenerationEnabled": False, "model": {"providerId": "smoke", "modelId": "smoke-model", "options": {"reasoningLevel": "disabled"}}}})
r2 = wait_for_id(2, 60)
print("R2:", (json.dumps(r2, ensure_ascii=False)[:600] if r2 else None))

sid = None
if r2 and isinstance(r2.get("result"), dict):
    res = r2["result"]
    sess = res.get("session")
    if isinstance(sess, dict):
        sid = sess.get("sessionId")
    if not sid and isinstance(res.get("snapshot"), dict):
        sid = (res["snapshot"].get("session") or {}).get("sessionId")
print("SID:", sid)

if sid:
    send({"id": 3, "method": "session/subscribe", "params": {"sessionId": sid, "deliveryKind": "desktop-continuous", "includeSnapshot": True}})
    send({"id": 30, "method": "session/setMode", "params": {"sessionId": sid, "mode": "yolo"}})
    nap(2)
    send({"id": 4, "method": "session/send", "params": {"sessionId": sid, "content": "hello from smoke", "modelSelection": {"providerId": "smoke", "modelId": "smoke-model", "options": {"reasoningLevel": "disabled"}}}})
    nap(14)
    send({"id": 5, "method": "session/list", "params": {}})
    nap(2)
    send({"id": 6, "method": "session/messages", "params": {"sessionId": sid}})
    nap(2)
    send({"id": 7, "method": "v4/command", "params": {"commandId": "smoke-cmd-1", "clientId": "smoke", "sessionId": sid, "type": "stop", "payload": {}, "issuedAt": int(time.time() * 1000)}})
    nap(3)
    send({"id": 8, "method": "session/stop", "params": {"sessionId": sid}})
    nap(3)
    send({"id": 9, "method": "session/setMode", "params": {"sessionId": sid, "mode": "yolo"}})
    nap(2)
    send({"id": 10, "method": "session/setThoughtLevel", "params": {"sessionId": sid, "thoughtLevel": "enabled"}})
    nap(2)
    send({"id": 11, "method": "session/setModel", "params": {"sessionId": sid, "model": {"providerId": "smoke", "modelId": "smoke-model", "options": {"reasoningLevel": "enabled"}}, "persistAsWorkspaceLastUsed": True}})
    nap(2)
    nap(3)

try:
    p.stdin.close()
except Exception:
    pass
time.sleep(1)
try:
    p.terminate()
except Exception:
    pass
time.sleep(1)
try:
    p.kill()
except Exception:
    pass

with open(OUT, "w") as f:
    f.write("\n".join(out))
print("TOTAL_LINES:", len(out))
print("ANSWERED:", len(answered))
print("OUT_FILE:", OUT)