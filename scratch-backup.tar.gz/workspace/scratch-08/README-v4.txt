ZCode Core 正式版 v4
--------------------
文件: ZCodeCore-v4.apk（约 70.3 MB，较 v3 瘦身约 40 MB）

本版内容:
1. 原生单文件模式 = 已应用安卓修复的二进制（直接可用, --version -> 0.16.9）;
2. 兼容模式（node + zcode.cjs）保留为后备;
3. 移除探针冗余（hello 样例、重复二进制）, 首轮瘦身。

自检内容: 原生 --version / --help / doctor + 兼容 --version。

安装与测试:
1. 覆盖安装（首次启动会重新解包, 约 1-2 分钟）;
2. 打开应用后自动运行自检;
3. 日志位置: /sdcard/Android/media/com.zcode.core/logs/

后续可选方向:
- 深度瘦身（定制无 ICU 的 Node、精简脚本等）;
- 与手机端 UI 对接（协议/服务方式）。
