S=/data/user/0/com.ai.assistance.operit/files/workspace/0989ed71-87e4-413f-ad5d-c239ed0ee1fa/scratch-08
R=/home/zcode-cli-src
O=$S/step59.txt
idx=$R/packages/shared/src/zcode-protocol/index.ts
{
echo '=== A: agent mode state head ==='
sed -n '1,60p' "$R/packages/shared/src/zcode-agent-model-state.ts"
echo '=== B: refs & schemas ==='
for name in zcodeWorkspaceRefSchema zcodeSessionInfoSchema zcodeSessionModeSchema zcodeThoughtLevelOptionSchema zcodeModelOptionSchema zcodePermissionOptionSchema zcodeMessageWithPartsSchema zcodeSessionCreateResultSchema zcodeSessionReadResultSchema zcodeSessionMessagesResultSchema; do
  L=$(grep -n "export const $name" "$idx" | head -1 | cut -d: -f1)
  if [ -n "$L" ]; then
    echo "--- $name @ $L ---"
    sed -n "${L},$((L+45))p" "$idx"
  else
    echo "--- $name NOT FOUND ---"
  fi
done
echo '=== C: event union ==='
L=$(grep -n 'zcodeSessionEventSchema =' "$idx" | head -1 | cut -d: -f1)
echo "at $L"
if [ -n "$L" ]; then sed -n "${L},$((L+300))p" "$idx"; fi
echo '=== C2: EventSchema names ==='
grep -n 'EventSchema =' "$idx" | head -80
echo '=== D: envelope ==='
sed -n '115,150p' "$idx"
echo '=== E: method names ==='
sed -n '3540,3740p' "$idx"
echo '=== F: permission refs ==='
grep -n 'requestUserInput\|requestPermission' "$idx" | head -80
echo '=== F2: PartSchema names ==='
grep -n 'PartSchema =' "$idx" | head -80
echo '=== G: command.ts ==='
grep -n 'discriminatedUnion\|export const' "$R/packages/shared/src/zcode-protocol-v4/command.ts" | head -70
sed -n '355,455p' "$R/packages/shared/src/zcode-protocol-v4/command.ts"
echo '=== H: stop handler ==='
sed -n '285,345p' "$R/apps/zcode-cli/packages/bootstrap/src/zcode-protocol-v4/commands/handlers/session-flow.ts"
echo '=== I: provider schema refs ==='
grep -rn 'apiKeyRequired' "$R/packages/shared/src" "$R/packages/services/src" 2>/dev/null | head -20
grep -rn 'openai-compatible' "$R/packages/shared/src" 2>/dev/null | head -20
echo '=== J: config.json ==='
grep -rn 'config.json' "$R/packages/services/src" "$R/apps/zcode-cli/packages/bootstrap/src" "$R/apps/zcode-cli/packages/adapters/src" 2>/dev/null | head -40
echo '=== J2: session event name ==='
grep -rn '"session/event"' "$R/apps/zcode-cli/packages/bootstrap/src" "$R/packages/shared/src" 2>/dev/null | head -20
echo '=== K: ui maps ==='
grep -n 'fun ' /home/zcode-mobile-ui/app/src/main/java/com/zcode/mobileui/MainActivity.kt | head -160
echo '--- SettingsDetailActivity ---'
grep -n 'fun \|class ' /home/zcode-mobile-ui/app/src/main/java/com/zcode/mobileui/SettingsDetailActivity.kt | head -120
echo '--- SettingsViewBuilder ---'
grep -n 'fun \|class ' /home/zcode-mobile-ui/app/src/main/java/com/zcode/mobileui/SettingsViewBuilder.kt | head -120
echo '=== Z: end ==='
} > "$O" 2>&1
echo DONE59
wc -l "$O"
