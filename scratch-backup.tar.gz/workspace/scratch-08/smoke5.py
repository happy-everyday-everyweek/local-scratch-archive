#!/usr/bin/env python3
# smoke5: 验证 workspace/readPresentation（无会话时的斜杠命令来源）
import json, os, subprocess, sys, threading, time
BASE = "/tmp/zv2"
HOME = os.path.join(BASE, "smoke-home")
WS = os.path.join(BASE, "smoke-ws")
node = None
for c in ["node", "/usr/local/bin/node", "/usr/bin/node"]:
    try:
        r = subprocess.run([c, "--version"], capture_output=True, text=True, timeout=10)
        if r.returncode == 0:
            node = c
            break
    except Exception:
        pass
if not node:
    print("NO_NODE"); sys.exit(0)
env = dict(os.environ)
env["HOME"] = HOME
p = subprocess.Popen([node, os.path.join(BASE, "zcode.cjs"), "app-server", "--stdio"],
                     cwd=BASE, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE, text=True, bufsize=1)
out = []
def rd(stream, tag):
    try:
        for line in stream:
            out.append(tag + " " + line.rstrip("\n"))
    except Exception:
        pass
threading.Thread(target=rd, args=(p.stdout, "OUT"), daemon=True).start()
threading.Thread(target=rd, args=(p.stderr, "ERR"), daemon=True).start()
def send(obj):
    try:
        p.stdin.write(json.dumps(obj) + "\n")
        p.stdin.flush()
    except Exception as e:
        out.append("ERR send failed: %s" % e)
answered = set()
def pump():
    for l in list(out):
        if not l.startswith("OUT "):
            continue
        body = l[4:]
        try:
            j = json.loads(body)
        except Exception:
            continue
        if "method" in j and "id" in j:
            rid = j["id"]
            if rid in answered:
                continue
            answered.add(rid)
            send({"id": rid, "result": {}})
def wait_for_id(wanted, timeout):
    end = time.time() + timeout
    while time.time() < end:
        pump()
        for l in list(out):
            if l.startswith("OUT "):
                try:
                    j = json.loads(l[4:])
                except Exception:
                    continue
                if j.get("id") == wanted and ("result" in j or "error" in j):
                    return j
        time.sleep(0.25)
    return None
WREF = {"workspacePath": WS, "workspaceKey": WS}
send({"id": 1, "method": "workspace/readPresentation", "params": {"workspace": WREF}})
r = wait_for_id(1, 30)
print("=== readPresentation ===")
if r is None:
    print("TIMEOUT")
elif "error" in r:
    print("ERROR:", json.dumps(r["error"], ensure_ascii=False)[:400])
else:
    body = json.dumps(r.get("result"), ensure_ascii=False, indent=1)
    print(body[:2000])
    os.makedirs("/tmp/zv2/frames", exist_ok=True)
    open("/tmp/zv2/frames/read_presentation.json", "w").write(body)
try: p.stdin.close()
except Exception: pass
time.sleep(1)
try: p.terminate()
except Exception: pass
time.sleep(1)
try: p.kill()
except Exception: pass
with open(os.path.join(BASE, "smoke5-out.txt"), "w") as f:
    f.write("\n".join(out))
print("DONE")