import * as React from "react";

import { cn } from "../../lib/utils";

function Label({ className, ...props }: React.ComponentPropsWithoutRef<"label">) {
  return React.createElement("label", {
    ...props,
    "data-slot": "label",
    className: cn(
      "flex items-center gap-2 text-xs/relaxed leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50",
      className,
    ),
  });
}

export { Label };
