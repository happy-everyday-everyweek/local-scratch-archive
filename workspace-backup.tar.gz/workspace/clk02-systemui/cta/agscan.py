#!/usr/bin/env python3
from loguru import logger
logger.remove()
from androguard.core.dex import DEX

def main():
    import sys
    d = DEX(open(sys.argv[1], "rb").read())
    classes = list(d.get_classes())
    print("classes:", len(classes))
    hits = []
    n_const = 0
    for ci, cls in enumerate(classes):
        for m in cls.get_methods():
            code = m.get_code()
            if code is None:
                continue
            try:
                instrs = list(code.get_instructions())
            except Exception:
                continue
            for ins in instrs:
                try:
                    name = ins.get_name()
                except Exception:
                    continue
                if name in ("const-string", "const-string/jumbo"):
                    n_const += 1
                    try:
                        ref = ins.get_ref()
                        v = str(ref)
                    except Exception:
                        v = ""
                    if "system-signed" in v or "APK is not signed" in v:
                        hits.append((cls.get_name(), m.get_name(), v))
    print("const-string total:", n_const)
    for h in hits:
        print("HIT:", h)

if __name__ == "__main__":
    main()