#!/usr/bin/env python3
import sys
from loguru import logger
logger.remove()

from androguard.core.dex import DEX
from androguard.core.analysis.analysis import Analysis

TARGET = "Only system-signed APKs are allowed"

def main():
    for path in sys.argv[1:]:
        print("=== %s ===" % path)
        d = DEX(open(path, "rb").read())
        a = Analysis(d)
        a.create_xref()
        hits = 0
        try:
            found = list(a.find_strings(TARGET))
        except Exception as e:
            found = None
            print("find_strings failed:", e)
        if found is None:
            for s in d.get_strings():
                try:
                    v = s.get_value()
                except Exception:
                    continue
                if TARGET in v:
                    hits += 1
                    print("STRING at", hex(s.get_offset()))
                    try:
                        for m in s.get_xref_from():
                            print("  XREF_FROM:", m.get_class_name(), m.get_name(), m.get_descriptor())
                    except Exception as e:
                        print("  xref err:", e)
            if hits == 0:
                print("not found via iteration")
        else:
            for s in found:
                print("STRING:", s.get_value())
                for m in s.get_xref_from():
                    print("  XREF_FROM:", m.get_class_name(), m.get_name(), m.get_descriptor())
        print("done")

if __name__ == "__main__":
    main()