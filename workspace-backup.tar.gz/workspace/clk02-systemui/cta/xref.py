#!/usr/bin/env python3
import sys

TARGET = "Only system-signed APKs are allowed"

def main():
    for path in sys.argv[1:]:
        print("=== %s ===" % path)
        try:
            from androguard.core.dex import DEX
            d = DEX(open(path, "rb").read())
            found = False
            # try v4 API
            try:
                strings = list(d.get_strings())
            except Exception:
                strings = []
            for s in strings:
                try:
                    val = s.get_value()
                except Exception:
                    continue
                if TARGET in val:
                    found = True
                    print("STRING_OFFSET:", hex(s.get_offset()))
                    try:
                        from androguard.core.analysis.analysis import Analysis
                        a = Analysis(d)
                        a.create_xref()
                        for m in s.get_xref_from():
                            try:
                                print("  XREF_FROM:", m.get_class_name(), m.get_name(), m.get_descriptor())
                            except Exception:
                                print("  XREF_FROM:", m)
                    except Exception as e:
                        print("  xref analysis failed:", e)
                    break
            if not found:
                # fallback: raw scan
                data = open(path, "rb").read()
                idx = data.find(TARGET.encode("utf-8"))
                print("raw_found_at:", hex(idx) if idx >= 0 else "NOT FOUND")
        except Exception as e:
            print("ERROR:", e)

if __name__ == "__main__":
    main()