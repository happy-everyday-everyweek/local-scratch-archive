#!/usr/bin/env python3
import struct, sys
from loguru import logger
logger.remove()
from androguard.core.dex import DEX

TARGET = b"APK is not signed with system signature. Only system-signed APKs are allowed. Package: "

def read_uleb(data, off):
    result = 0; shift = 0
    while True:
        if off >= len(data):
            raise ValueError("oob")
        b = data[off]; off += 1
        result |= (b & 0x7f) << shift
        if not (b & 0x80):
            break
        shift += 7
        if shift > 63:
            raise ValueError("long")
    return result, off

def find_target(path):
    data = open(path, "rb").read()
    string_ids_size, string_ids_off = struct.unpack_from("<II", data, 0x38)
    for i in range(string_ids_size):
        (p,) = struct.unpack_from("<I", data, string_ids_off + i*4)
        try:
            size, o2 = read_uleb(data, p)
            if data[o2:o2+size] == TARGET:
                return i, data
        except Exception:
            continue
    return None, data

def loc_by_offset(d, target):
    for cls in d.get_classes():
        for m in cls.get_methods():
            code = m.get_code()
            if code is None:
                continue
            try:
                st = code.get_off() if hasattr(code, 'get_off') else code.offset
                ln = code.get_length() or 0
            except Exception:
                continue
            if st is not None and st <= target < st + ln:
                return (cls.get_name(), m.get_name(), hex(st), ln)
    return None

def main():
    for path in sys.argv[1:]:
        print("====== %s ======" % path)
        idx, data = find_target(path)
        if idx is None:
            print("  TARGET string not in this dex")
            continue
        print("  target idx:", idx)
        sub16 = struct.pack("<H", idx)
        sub32 = struct.pack("<I", idx)
        cands = []
        i = 0
        while True:
            j = data.find(b"\x1a", i)
            if j < 0: break
            if j+3 < len(data) and data[j+2:j+4] == sub16:
                cands.append((j, "1a"))
            i = j+1
        i = 0
        while True:
            j = data.find(b"\x1b", i)
            if j < 0: break
            if j+5 < len(data) and data[j+2:j+6] == sub32:
                cands.append((j, "1b"))
            i = j+1
        print("  candidates:", [(hex(o), k) for o, k in cands])
        if not cands:
            continue
        d = DEX(open(path, "rb").read())
        for off, kind in cands:
            owner = loc_by_offset(d, off)
            if owner:
                print("  HIT @ %#x [%s] -> %s :: %s (code %s len %s)" % (off, kind, owner[0], owner[1], owner[2], owner[3]))
            else:
                print("  HIT @ %#x [%s] -> no code owner" % (off, kind))

if __name__ == "__main__":
    main()