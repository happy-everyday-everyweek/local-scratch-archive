#!/usr/bin/env python3
import struct, sys

def read_uleb(data, off):
    result = 0; shift = 0
    while True:
        if off >= len(data):
            raise ValueError("uleb oob")
        b = data[off]; off += 1
        result |= (b & 0x7f) << shift
        if not (b & 0x80):
            break
        shift += 7
        if shift > 63:
            raise ValueError("uleb too long")
    return result, off

def main():
    path = sys.argv[1]
    data = open(path, "rb").read()
    string_ids_size, string_ids_off = struct.unpack_from("<II", data, 0x38)
    type_ids_size, type_ids_off = struct.unpack_from("<II", data, 0x40)
    method_ids_size, method_ids_off = struct.unpack_from("<II", data, 0x58)
    class_defs_size, class_defs_off = struct.unpack_from("<II", data, 0x60)

    strings = []
    for i in range(string_ids_size):
        (p,) = struct.unpack_from("<I", data, string_ids_off + i*4)
        try:
            size, o2 = read_uleb(data, p)
            strings.append(data[o2:o2+size])
        except Exception:
            strings.append(b"<err>")
    types = []
    for i in range(type_ids_size):
        (dstr,) = struct.unpack_from("<I", data, type_ids_off + i*4)
        types.append(strings[dstr].decode("utf-8", "replace"))
    methods = []
    for i in range(method_ids_size):
        cls, proto, name = struct.unpack_from("<HHI", data, method_ids_off + i*8)
        methods.append((cls, strings[name].decode("utf-8", "replace")))

    TARGET = b"APK is not signed with system signature. Only system-signed APKs are allowed. Package: "
    tgt_idx = None
    for i, s in enumerate(strings):
        if s == TARGET:
            tgt_idx = i
            print("target idx =", i)
            break
    if tgt_idx is None:
        print("TARGET NOT FOUND"); return
    sub16 = struct.pack("<H", tgt_idx)
    sub32 = struct.pack("<I", tgt_idx)

    cands = []
    i = 0
    while True:
        j = data.find(b"\x1a", i)
        if j < 0: break
        if j+3 < len(data) and data[j+2:j+4] == sub16:
            cands.append((j, "1a"))
        i = j+1
    i = 0
    while True:
        j = data.find(b"\x1b", i)
        if j < 0: break
        if j+5 < len(data) and data[j+2:j+6] == sub32:
            cands.append((j, "1b"))
        i = j+1
    print("candidates:", [(hex(o), k) for o, k in cands])

    ranges = []
    for ci in range(class_defs_size):
        cdef_off = class_defs_off + ci*32
        class_idx, _, _, _, _, _, class_data_off, _ = struct.unpack_from("<IIIIIIII", data, cdef_off)
        if class_data_off == 0 or class_data_off >= len(data):
            continue
        try:
            off = class_data_off
            _, off = read_uleb(data, off)
            _, off = read_uleb(data, off)
            dm, off = read_uleb(data, off)
            vm, off = read_uleb(data, off)
            if dm + vm > 200000:
                continue
            m_idx = 0
            for _ in range(dm + vm):
                d, off = read_uleb(data, off); m_idx += d
                _, off = read_uleb(data, off)
                code_off, off = read_uleb(data, off)
                if code_off == 0 or code_off >= len(data):
                    continue
                regs, ins, outs, tries, dbg, insns_size = struct.unpack_from("<HHHHII", data, code_off)
                if insns_size > 200000:
                    continue
                end = code_off + 16 + insns_size*2
                ranges.append((code_off, end, class_idx, m_idx))
        except Exception:
            continue

    print("total method ranges:", len(ranges))
    for cand_off, kind in cands:
        owner = None
        for s, e, ci, mi in ranges:
            if s <= cand_off < e:
                owner = (ci, mi)
                break
        if owner:
            ci, mi = owner
            m = methods[mi]
            print("HIT @ %#x [%s] -> %s :: %s" % (cand_off, kind, types[m[0]], m[1]))
        else:
            print("HIT @ %#x [%s] -> (no code owner)" % (cand_off, kind))

if __name__ == "__main__":
    main()