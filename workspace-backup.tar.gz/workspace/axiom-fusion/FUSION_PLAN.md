# vFlow × Operit × Shizuku 融合方案（FUSION_PLAN）

版本：v2（用户已修正需求，待对齐）
日期：2026-08-03

## 一、背景与目标

将三个 Android 开源项目融合为单个 APK：

- vFlow（GPL-2.0，约 1.2k★）：图形化屏幕自动化工作流工具。
- Operit（LGPL-3.0，约 6.4k★）：AI Agent + 聊天应用，自带工作流系统、多模型 AI 引擎、ADB/无障碍双权限模式。
- Shizuku（Apache-2.0，约 28.3k★）：adb/root 级系统 API 框架。

用户需求（v2 修正）：

1. 三者融合为一个应用；Shizuku 作为共同底层依赖直接内置，无需单独安装 Shizuku App。
2. Operit 整体搬入（不是只搬 AI 引擎）：其 AI 引擎、聊天、工具、工作流系统、设置等全部并入融合应用。
3. vFlow 的 AI 功能框架更换为 Operit 引擎。
4. 两边各自的工作流系统要融合（vFlow 的图形化动作模块工作流 + Operit 的 `plugins/workflow`、`core/workflow` 工作流系统）。
5. Operit 的 ADB 模式与无障碍模式要融合为"默认免配置"的自动适配（无需用户手动设置权限模式）。
6. Operit 的设置、Shizuku 的设置全部并到 vFlow 的设置页。
7. 整体 UI 风格沿用 vFlow；Operit 的界面需按 vFlow 风格大改（重写 Compose 主题/导航/组件风格）。

## 二、侦察结论（v1 保持有效，补充）

- vFlow 对权限模型："vFlow 对 Operit 有一定支持"需在方案定稿后验证（待查 vFlow 源码中 operit 引用）；Operit 工作流系统位于 app/src/main/java/com/ai/assistance/operit/plugins/workflow 与 core/workflow。
- vFlow 工程：AGP 9.0.1 / Kotlin 2.3.20 / compileSdk 36 / minSdk 29，Compose + AIDL + CMake，core 模块 dex 资产化。
- Operit 工程：app 模块超大，含 native（mnn/llama/quickjs）、人像（dragonbones/mmd/fbx）、终端、聊天、全 AI 前端与工具系统；完整搬入 = 主 APK 体量与编译时间显著上升。

## 三、总体方案（v2：Operit 整体搬入，单 APK 双应用）

产物：一个 APK，两个完整应用区共存，全部功能保留：

- 宿主壳与 UI 规范：vFlow。全局导航、主题、组件风格统一为 vFlow 风格，Operit 各界面按 vFlow 风格重写。
- Operit 整体搬入方式：把 Operit 的 app 模块改造为 Android library（`:operit-app`，去掉 applicationId，包名 com.ai.assistance.operit 保留），其全部子模块（llm/mnn、llama、quickjs、dragonbones、mmd、fbx、terminal、showerclient）以 library 形式并入；`:app`（vFlow 壳）依赖它。两套代码在同一 APK 中共存，Manifest 合并（Operit 的 Activity/Service/AccessibilityService/Provider 全部注册进主 Manifest，authority 与 applicationId 相关引用统一改写）。
- vFlow 的 AI 能力（聊天、AI 模块、模型配置）整体切换到 Operit 引擎，vFlow 自研轻量 AI 客户端退役。
- Shizuku 内置为公共依赖层（见 §五），同时承载 vFlow 特权执行与 Operit 特权工具。

## 四、Operit 整体搬入细节（:operit-app 模块化）

1. app 模块 library 化：源码、资源、Manifest 原样迁入 `:operit-app`（去掉 applicationId，namespace 保持 com.ai.assistance.operit）。原 applicationId 相关的 ContentProvider authority 等引用统一改为融合应用前缀（如 com.chaomixian.vflow.operit.*）。
2. 原生子模块随入：llm/mnn、llama、quickjs、terminal、dragonbones、mmd、fbx、showerclient 全部以 library 形式随 `:operit-app` 编译进同一 APK（native .so 打包策略统一）。
3. 入口共存：Operit 的 MainActivity/聊天/工具箱/设置/人像等通过主壳导航进入（见 §八 UI 统一）；Operit 的 Service（前台 AI 服务、无障碍服务、通知服务）与 Provider 全部注册进主 Manifest。
4. 依赖与版本目录合并：Operit 的 libs.versions.toml 与 vFlow 合并（AGP/Kotlin 以 vFlow 为准，三方库版本取较高者并逐项验证）；OkHttp/Compose/DataStore 等公共依赖统一版本。
5. vFlow 的 AI 能力切换到 Operit llmprovider 引擎（Operit 已整体在内，无需单独抽取）。

## 五、Shizuku 内置（:shizuku:* 模块 + 内嵌服务）

将 Shizuku 源码照搬为本地模块，替换 vFlow 与 Operit 两处的 Maven 依赖（dev.rikka.shizuku:api / provider 13.1.5）：

- 模块集：:shizuku:api、:shizuku:provider、:shizuku:aidl、:shizuku:shared、:shizuku:common、:shizuku:server、:shizuku:starter、:shizuku:server-shared、:shizuku:hidden-api-stub。
- 内置服务：把 Shizuku server 类编入融合 APK 自身 dex（沿用官方 --apk=self 机制），应用内提供"Shizuku 服务"入口，通过 ADB 或 root 启动内嵌 server，使 vFlow 特权模块与 Operit 特权工具（shell/剪贴板/输入等）即插即用，无需安装官方 Shizuku。
- 兼容策略：检测到系统已安装官方 Shizuku 时优先使用官方实例；未安装时走内嵌自启。
- :shizuku:manager 管理 UI 默认不并入（仅内置启动/授权逻辑）；如需完整管理界面另行拍板。

## 六、双工作流系统融合（已拍板：Operit 执行节点进 vFlow 工作流）

1. 现状确认：vFlow 已有 `OperitModule`（应用集成分类，"Operit 交互"，支持 EXTERNAL_CHAT 与 WORKFLOW_TRIGGER），当前通过跨进程广播与独立 Operit 应用交互。
2. 融合形态（已拍板）：Operit 的执行节点可添加到 vFlow 工作流中。做法：vFlow 的 ModuleRegistry 新增"Operit"分类注册点，把 Operit 工作流的执行单元（plugins/workflow 的节点/动作）适配为 vFlow 模块（复用 InputDefinition/OutputDefinition/execute 协议），在 vFlow 画布中可直接拖拽组合。
3. OperitModule 改造：融合后 Operit 在同一进程内，EXTERNAL_CHAT / WORKFLOW_TRIGGER 从跨进程广播改为进程内直调（调用 Operit 的 ChatRuntime / workflow 引擎），保留旧广播路径作为兼容开关。
4. 底层执行器统一：两种流程共享同一权限执行层（内嵌 Shizuku + 无障碍），输出统一的事件/状态模型。

## 七、工程结构（工作区根 = 融合工程根）

```
workspace/6a3a9fd5-.../
├── app/                  # vFlow 应用壳（application 模块，唯一入口，改造后）
├── core/                 # vFlow core（dex 资产，原样）
├── operit/               # Operit 全家（app library 化后的全部模块）
│   ├── app/              #   :operit-app（原 Operit app，改 library）
│   ├── llm/              #   mnn / llama
│   ├── quickjs/ terminal/ avator(dragonbones,mmd,fbx)/
│   └── showerclient/
├── shizuku/              # Shizuku 源码模块集（9 个模块）
├── gradle/               # 合并后的 version catalog + wrapper
├── settings.gradle.kts   # include 全部模块
├── FUSION_PLAN.md
└── sources/              # 三个上游仓库快照（只读参考）
```

构建统一：AGP 9.0.1、Kotlin 2.3.20、compileSdk 36、minSdk 29（Shizuku 与 Operit 子模块全部对齐）；Operit 用到的特有三方插件（DBFlow/Sqlite、QuickJS 等）按其仓库版本保留并验证与 AGP9 兼容。

## 八、UI 统一（vFlow 风格）与设置合并

1. 导航（已拍板）：全面采用 vFlow 导航样式，主壳底部导航 4 区 = 聊天 / 工作流 / 世界 / 设置。"世界"功能延到下一期，本期先留空页面占位。
2. 聊天界面（已拍板）：AI 回复内容的渲染组件用 Operit 的（仅做风格微调适配 vFlow 主题）；输入框及未发送状态（输入区）用 vFlow 现有的。
3. 主题基线：以 vFlow 现有 Compose 主题/导航组件为基座，Operit 页面重写为 vFlow 风格；抽取 `:ui-kit` 组件库（顶部栏、列表项、卡片、浮窗、设置行等）供两区复用。
4. 设置合并：vFlow 设置页新增分组：AI（Operit 模型配置/密钥/Provider）、权限（含 Shizuku 管理入口、无障碍、ADB 模式）、行为（沿用 vFlow 现有）；Operit 原设置项迁移进对应分组，删除重复项。
5. 模式默认免配置：权限诊断自检（root > 内嵌 Shizuku(ADB) > 无障碍）自动选择可用通道并提示一次性授权；授权状态统一显示在设置-权限页。

## 九、分阶段里程碑

- M1（骨架）：根工程多模块化；vFlow app/core 原样编译；Shizuku 模块并入编译通过；vFlow 依赖切到本地 Shizuku；产物与上游行为一致。
- M2（Operit 搬入）：Operit app 成功 library 化并随主壳编译启动（双应用区同 APK 可用），native 子模块打包验证。
- M3（Shizuku 内置 + 权限融合）：内嵌 server 自启（ADB/root）、ShizukuProvider 自连、权限自动诊断与无障碍回退打通，官方 Shizuku 兼容。
- M4（工作流融合）：双工作流互调与统一执行层打通（先做 1~2 个典型互调场景）。
- M5（AI 切换）：vFlow 聊天/AI 模块/模型配置切到 Operit 引擎，工具调用贯通。
- M6（UI 统一 + 设置合并）：vFlow 风格全面重写 Operit 界面，设置页合并完成。
- M7（收尾）：ProGuard、LICENSE 三件套、README、混淆产物验证、正式 APK。

## 十、风险与对策

- 双应用 Manifes 合并冲突（authority/权限/service 声明）：统一改写前缀 + AGP manifest 合并规则逐项处理。
- native 构建（mnn/llama/quickjs/opencv）在设备环境编译耗时且易受工具链影响：优先复用上游预编译产物策略（若仓库已提供 .so 则直接采用），本地编译作为回退。
- 版本冲突（AGP/Kotlin/依赖库）：以 vFlow 版本为主干，逐库升级验证；保留升级记录表。
- 体积：Operit 全家 + Shizuku server 预计 APK 增长 30~60MB，需确认可接受（或开 APK 拆分）。
- 许可证：GPL-2.0（vFlow）、LGPL-3.0（Operit）、Apache-2.0（Shizuku）；内嵌 Shizuku 不改其开源协议，分发保留三份 LICENSE 与版权声明，并声明"未修改上游模块的协议"。

## 十一、已拍板决策（v5 定稿：并入 PlanWeave + 4 区导航）

1. 导航（v5 更新）：全面 vFlow 风格，底部 4 区 = 对话 / 工作流 / 项目（PlanWeave）/ 设置；项目区即 PlanWeave 画布（WebView 加载 127.0.0.1:8787），不再是"世界占位"。默认启用 vFlow 液态玻璃风格 Tab 切换栏。
2. 工作流融合：Operit 执行节点注册进 vFlow 工作流（Operit 分类），OperitModule 改进程内直调。
3. 聊天界面：AI 回复渲染用 Operit 组件（轻改风格），输入框/未发送态用 vFlow 组件。
4. 本地模型（MNN/Llama）：本期不纳入编译。
5. 应用标识：Axiom（applicationId 改为 com.axiom.app；namespace 保持 com.chaomixian.vflow 以最小化代码改动，vFlow 类名/资源引用不变；v5.1 起不再沿用 vFlow 原包名，作为独立新应用安装，避免与原 vFlow 冲突）。
6. Shizuku 管理：不并入完整 manager UI，仅设置页提供权限管理入口（状态/启动/授权精简页）。
7. 编译验证节奏：每完成一个里程碑都在设备上真实编译验证。
8. Operit 暴露面：大部分 Operit UI 不暴露给用户；仅对暴露给用户的功能（设置、模型选择、插件、包管理）按 vFlow 风格重绘；其余内部功能保持可用但不开放界面。
9. 首启引导：重做 onboarding，覆盖更多权限申请（无障碍/Shizuku/悬浮窗等）与初始化步骤；图标沿用 vFlow。
10. PlanWeave 并入（v5）：项目区 = PlanWeave WebView 壳，服务由终端环境（proot Ubuntu + node24）常驻 web-bridge（/srv/planweave/planweave-web.sh，127.0.0.1:8787），页面打开前健康检查，未运行则通过 ShellManager 启动；UA 去 wv 标识、cleartext 已由 network_security_config 覆盖。

## 十二、执行状态

- M1（骨架）✅ 完成（2026-08-04）：
  - 根工程多模块化完成：settings.gradle.kts = vFlow(:app/:core) + Shizuku 9 模块(:server/:starter/:common/:aidl/:rish/:shared/:api/:provider/:server-shared)。
  - Shizuku 源码模块编译通过，vFlow app 依赖已从 Maven 切换到本地 project(:api/:provider)。
  - 应用名改为 Axiom；debug.keystore 沿用 vFlow。
  - 产物：app/build/outputs/apk/debug/ 下 5 个 ABI 变体 APK（arm64-v8a / armeabi-v7a / x86 / x86_64 / universal），已确认 Shizuku API 类与 ShizukuService 类打包进 dex。
- M1 环境工程（arm64 Linux 宿主适配）：
  - aapt2：build-tools/36.0.0 与 Gradle maven 缓存均替换为 ReVanced aapt2-arm64-v8a。
  - aidl：SDK 自带 aidl 为 x86_64，apt 安装 Ubuntu aidl(10.0.0) 替换；android-36 framework.aidl 需预处理（剥离行首 @ 注解）才能被 aidl10 解析。
  - cmake：SDK cmake/3.22.1 替换为系统 cmake 3.28.3（arm64），补齐 ninja（apt ninja-build）。
  - llvm-strip/objcopy/objdump：NDK 内工具替换为系统 llvm（arm64）。
  - 暂缓项：PP-OCRv5 本地 native（app/src/main/cpp）编译暂禁用（无 arm64 NDK），PpOcrV5Native 已加运行时降级（isNativeAvailable）；预编译 sherpa/ncnn .so 不受影响，OCR 功能待 arm64 NDK 接入后恢复。
- M1.5（PlanWeave 并入 + 4 区导航）✅ 完成（2026-08-05）：
  - 主壳底部导航改为 4 区：对话 / 工作流 / 项目 / 设置（MainTopLevelTab 移除 HOME、REPOSITORY，新增 PROJECTS）。
  - 新增 PlanWeaveScreen（app/ui/planweave/PlanWeaveScreen.kt）：WebView 加载 http://127.0.0.1:8787/，打开前健康检查（/api/health），未运行显示"启动服务/重试"（ShellManager 执行 /srv/planweave/planweave-web.sh start），UA 去 wv，返回键 goBack。
  - 字符串三语（zh/en/ja）补齐：title_projects + planweave_* 状态文案。
  - 注：Operit 模块（:operit-app 等）在 settings.gradle.kts 暂时注释——其 kapt 插件与 AGP9 内置 Kotlin 不兼容，M2 适配完成前保持 vFlow 壳可独立编译；源码与工程目录均保留在 operit/。
- M1.6（包名 + testOnly 修复）✅ 完成（2026-08-05）：
  - applicationId 由 com.chaomixian.vflow 改为 com.axiom.app（namespace 不变，vFlow 类名引用保留）。
  - 同步更新全部协议字符串：extension.MODULE_PROVIDER / EXECUTE_WORKFLOW_SHORTCUT / action.*（STOP_WORKFLOW、IME_INPUT、START/STOP/RESTART_CORE、CHECK_HEALTH、WORKFLOW_INSPECTOR_INSERT、extra.*）→ com.axiom.app.*；AppSwitchTriggerModule 排除包名、VFlowCoreBridge socket fallback 同步。
  - 修复"非正式版本"无法安装：此前用 -Pandroid.injected.build.abi 构建触发 AGP 注入 android:testOnly="true"；现 Manifest 显式 android:testOnly="false" + tools:replace，且构建不再使用 injected 参数。
  - 重新完整构建 5 个 ABI 变体成功（BUILD SUCCESSFUL 5m23s），已验证 merged manifest package=com.axiom.app / testOnly=false / debuggable=true，dex 含 PlanWeaveScreenKt 与 main_tab_projects，资源含 title_projects。
  - 产物：app/build/outputs/apk/debug/*.apk（5 变体）；arm64 副本 /sdcard/Download/Axiom/Axiom-1.5.3-pr1-arm64.apk（debug 签名）。

## 十三、M2 准备：代码核实事实与已拍板决策（v6，2026-08-05 需求对齐）

### A. Operit 模块盘点（代码核实，修正原 §七 描述）

- :operit-app（operit/app）：已 library 化，namespace com.ai.assistance.operit，minSdk26（未随根工程注入 29），compileSdk36，AGP library 插件。当前因 kapt 无法通过 AGP9 编译。
- 子模块实际为 5 个：:quickjs（native，arm64）、:showerclient、:dragonbones（native+compose）、:mmd（native，arm64）、:fbx。**原文档所述 llm/mnn、llama 独立模块不存在**——源码中仅有 data/mnn（MnnModelDownloadManager，模型下载管理，非本地推理引擎）；本地语音推理为 sherpa-ncnn / sherpa-mnn（构建期 git clone 源码编译）。
- terminal 不是内嵌模块：com.ai.assistance.operit.terminal.TerminalManager 引用外部独立应用 OperitTerminal（OperitTerminalManager 从 GitHub AAswordman/OperitTerminal 拉取）。PlanWeave 的 proot 终端环境与它无关。
- 包结构：api（chat/speech/voice）、core（application/avatar/chat/config/subpack/tools/workflow）、data（db/dao/mcp/mnn/model/preferences/repository/security/skill/updates）、integrations（externalchat/http/intent/tasker）、plugins（chatview/lifecycle/toolbox/toolpkg/workflow）、provider（3 个 DocumentsProvider）、services（assistant/core/floating/notification + FloatingChat/AIForeground/UIDebugger/ScreenCapture）、ui（features 18 个域）、util、widget。
- Manifest：MainActivity（launcher+VIEW/SEND/ASSIST/共享）、OperitAssistActivity、CrashReportActivity(:crash 进程)、DataRecoveryActivity(:repair 进程)、Tasker 集成 2 项、ScreenCaptureActivity、FloatingChatService、ScreenCaptureService、AIForegroundService、UIDebuggerService、通知监听、语音交互 2 服务、8+ Receiver、4 Provider（FileProvider/WorkspaceDocuments/MemoryDocuments/OperitDataDocuments+startup）。

### B. M2 技术硬骨头（已澄清事实）

1. **kapt 迁移（已拍板：迁移，必须保数据）**：operit 使用 Room(compiler) + ObjectBox(processor) 双 kapt 链，另有 io.objectbox Gradle 插件。AGP9 内置 Kotlin 不兼容 kapt。迁移策略：Room→KSP（AppDatabase v20：ChatEntity/MessageEntity/MessageVariantEntity + 现有 Migration 链），ObjectBox→官方插件机制（或评估降级为 Room 存储）。**硬性要求：迁移后原 Operit 用户数据必须完整保留并可读**——包括 Room 数据库（filesDir 内）与 ObjectBox 按 profile 分库（filesDir/objectbox、objectbox_<profileId>）。需做数据兼容验证清单（数据库升级路径、字段映射、导出导入兜底）。
2. **双 Application（已拍板：方案 A）**：单 APK 只能有一个 Application 类（android:name 只写一个）。Operit 有 OperitApplication（681 行：DB、WorkManager、Coil、语言、角色卡、AIForegroundService、分词器、虚拟屏、PDFBox 等）与 vFlow 的 VFlowApplication（日志/崩溃/遥测）。**确定方案 A**：新建 AxiomApplication 统一入口，按顺序执行 vFlow 初始化 + Operit 初始化（Operit 的 initializeMainApplication 拆为可被调用的方法）。
3. **assets 大文件（已拍板：随主 APK 打包，但可裁剪无用项）**：assets 内 shizuku.apk、accessibility.apk、desktop.apk、jks/pkcs12、models/、web/、dragonbones/ 等本来就是 APK 资源、运行时复制到 cache 使用。**已拍板**：融合后随主 APK 打包，接受体积；**但 ADB 工具、无障碍工具无需内置 apk**——融合应用自己就有 Shizuku（内置）+ 无障碍服务能力，直接自调，accessibility.apk / 相关辅助包可裁剪。逐项在 M2 资产清单中确认保留/裁剪。
4. **native 构建（已拍板：本期跳过本地 git clone 编译）**：sherpa-ncnn/WAMR 是构建期从 GitHub clone 源码编译；设备环境无 arm64 NDK，维持 M1 策略——本期 operit 编译时禁用 externalNativeBuild（或仅编 streamnative 无外部依赖部分），复用预编译 .so；PP-OCRv5 继续禁用。
5. **minSdk（已拍板：统一 29）**：operit 及子模块 minSdk26 → 29（与 vFlow 一致），接受放弃 Android 8~9；coreLibraryDesugaring 已开，风险可控。
6. **多语言（已拍板：暂停）**：新功能只维护中文默认语；operit 的多语 values-* 保留但不再扩展、不纳入新文案。

### C. M2 前先导修复（已拍板，2026-08-05）

1. 项目页（PlanWeave）状态文字未完全居中：状态页改全屏 Box 居中 + 文字 TextAlign.Center。
2. 设置页部分开关（动态取色/彩色卡片/应用缩放）调用 activity.recreate() 导致屏幕闪动：改为 Compose 状态即时生效，去 recreate。
3. 液态玻璃导航栏默认开启：isLiquidGlassNavBarEnabled 默认值 false→true（新装用户生效；已存偏好用户尊重其选择，不强制覆盖）。
4. 多语言暂停（见 B6）。

### D. 待下一轮确认/提出的问题

- 双 Application 方案 A/B 拍板（见 B2）——已拍板方案 A。
- 用户后续补充的其他问题。

### E. Operit 全模块事实澄清表（代码核实，逐项决策）

说明：以下为 operit/app 源码包（com.ai.assistance.operit）逐包盘点。决策列标记 = 【保】保留随融合编译 / 【裁】裁剪（功能由 vFlow 侧或融合壳替代）/ 【待】需用户拍板。默认未标注可裁剪的均【保】。

| 包 | 构成与事实 | 决策建议 |
|---|---|---|
| api/chat | AI 聊天核心：AIForegroundService（前台服务）、ChatRuntimeHolder/Slot（聊天运行时）、EnhancedAIService（增强服务）、enhance/（多服务管理、对话轮次、文件绑定、输入处理）、llmprovider/（模型配置、连接测试）等 74 文件 | 【保】AI 引擎核心，M5 切换的基础 |
| api/speech | 本地语音：SherpaMnnSpeechProvider、SherpaSpeechProvider、OnnxSileroVad（VAD）、TTS 相关 | 【保】语音能力保留（依赖 sherpa 预编译 .so） |
| api/voice | 语音交互服务入口 | 【保】 |
| core/application | OperitApplication（681 行启动链）、ActivityLifecycleManager、ForegroundServiceCompat | 【保】但并入 AxiomApplication（方案 A） |
| core/avatar | 虚拟人像：AvatarController/Model/Renderer/State 工厂 + 实现（dragonbones/mmd/fbx 渲染） | 【保】人像功能（M6 前不暴露 UI 也可后台可用） |
| core/chat | AIMessageManager（64KB 消息核心）、hooks/、plugins/ | 【保】聊天消息管线 |
| core/config | SystemPromptConfig、SystemToolPrompts(+Internal)、FunctionalPrompts | 【保】提示词体系（需与 vFlow 提示词调和，M5 任务） |
| core/subpack | ApkEditor/ApkReverseEngineer/ExeEditor/ExeIconChanger/KeyStoreHelper（APK/EXE 改包工具链） | 【待】用户是否保留 APK 逆向/改包能力（对应 assets 里的 desktop.apk 等） |
| core/tools | AIToolHandler（工具中枢）、ToolRegistration、ToolPackage、agent/（PhoneAgent 手机智能体 + Shower 虚拟屏 + VirtualDisplayManager）、calculator/、defaultTool/（standard 标准 + accessbility 无障碍两档工具集）等 100 文件 | 【保】工具系统是 Operit 灵魂；defaultTool 与 vFlow 模块系统并存，M5 统一 |
| core/workflow | WorkflowExecutor/Scheduler/SchedulerInitializer/Worker（Operit 工作流执行+调度） | 【保】M4 与 vFlow 工作流融合的对象 |
| data/announcement | 远程公告仓库 | 【保】（联网拉公告，可后续裁） |
| data/api | GitHubApiService、GitHubOAuthBrokerService、MarketStatsApiService | 【保】GitHub 登录/市场 |
| data/backup | RawSnapshotBackupManager、RoomDatabaseBackupManager、OperitBackupDirs | 【保】数据备份（与 M2 数据迁移强相关） |
| data/collects | 收藏/收集 | 【保】 |
| data/converter | 文档转换（PDF/Word 等） | 【保】 |
| data/dao + db | Room AppDatabase v20（Chat/Message/MessageVariant）+ ObjectBox（按 profile 分库） | 【保】kapt 迁移核心（B1） |
| data/exporter | 数据导出 | 【保】 |
| data/mcp | MCP 客户端/本地服务器/部署器 | 【保】MCP 能力（与 PlanWeave MCP 二期相关） |
| data/mnn | MnnModelDownloadManager（模型市场下载，非本地推理） | 【保】模型下载管理 |
| data/model | 50 个数据模型（AITool/CharacterCard/APIKey 等） | 【保】 |
| data/preferences | 32 个偏好管理器（角色卡、API、显示、语言等） | 【保】 |
| data/repository | 各领域仓库 | 【保】 |
| data/security | 插件黑名单等安全 | 【保】 |
| data/skill | 技能管理 | 【保】 |
| data/updates | 更新检查 | 【待】融合后更新源应指向 Axiom 发布源 |
| integrations/externalchat | 外部聊天请求执行/净化 | 【保】vFlow OperitModule 直调目标 |
| integrations/http | ExternalChatHttpServer（本地 HTTP 服务）、WebChat 桥 | 【保】HTTP 桥（与 PlanWeave 桥类似，可共存） |
| integrations/intent | ExternalChatReceiver（广播接收） | 【保】 |
| integrations/tasker | AIAgentTasker、WorkflowTasker（Tasker 插件集成） | 【裁】由 vFlow 触发器体系替代（GKD/应用切换/背面轻敲/WiFi/剪贴板/电量/定时/元素/电话/蓝牙/语音等全覆盖） |
| plugins | PluginRegistry + chatview/lifecycle/toolbox/toolpkg/workflow 插件体系 | 【保】插件生态 |
| provider | WorkspaceDocumentsProvider、MemoryDocumentsProvider、OperitDataDocumentsProvider（SAF 文档提供者） | 【保】SAF 能力（PlanWeave 二期也用到） |
| services | FloatingChatService、ChatServiceCore、UIDebuggerService、CloudEmbeddingService、TermuxCommandResultService、assistant/（语音交互 2 服务）、notification/（通知监听） | 【保】后台服务全部注册进主 Manifest |
| ui/features | 18 域：about/agreement/announcement/assistant/chat/demo/github/help/memory/packages/permission/settings/startup/token/toolbox/update/websession/workflow | 【裁】按 §十一-8：多数 UI 不暴露，仅设置/模型/插件/包管理按 vFlow 风格重绘；其余代码保留但无入口 |
| ui/common/components/floating/main/theme | 通用组件、浮动窗口、主题、导航壳 | 【待】融合后以 vFlow 壳为主，Operit 主题/组件按 M6 迁移；本期保留编译 |
| util | 71 个工具类（日志/路径/压缩/OCR 等） | 【保】 |
| widget | ToolPkg 桌面小组件、语音助手小组件（Glance） | 【待】用户是否保留小组件（vFlow 已有 20 个 Tile + 小组件） |
| core/tools/system/Terminal.kt 等 | 引用 com.ai.assistance.operit.terminal.TerminalManager——**已核实**：该包来自 OperitTerminalCore 库（AAswordman/OperitTerminal 的 submodule terminal-core），非外部 App。终端 = terminal-core 库 + 自带 ubuntu-noble-aarch64 rootfs（assets/ubuntu-noble-aarch64-pd-v4.18.0.tar.xz，解压至 {filesDir}/usr/var/lib/proot-distro/installed-rootfs/ubuntu），jni 含 pty.c（PTY 支持）、jniLibs arm64 预编译 .so。**已拍板**：terminal-core 源码已纳入融合工程 operit/terminal-core（68MB），M2 作为本地模块接入；PlanWeave 即走该 proot 终端。 |

### F. M2 待拍板清单（已逐项拍板，2026-08-05）

1. **core/subpack（APK/EXE 改包工具链）→ 保留**。理由：两个来源（Operit + vFlow 迁移）的数据可能用到；如遇风险，退化为"面向 AI 的空壳"：工具默认关闭、AI 不可见不可调、无用户入口，仅保数据兼容。
2. **data/updates（更新检查）→ 新建更新仓库**。需创建 Axiom 更新源仓库（GitHub），更新检查指向该仓库（后续落地）。
3. **integrations/tasker（Tasker 集成）→ 已拍板：裁掉**。理由：vFlow 触发器体系已全覆盖（70 个触发器文件：GKD 订阅/应用切换/背面轻敲/WiFi/剪贴板/电量/定时/元素/电话/应用安装卸载/应用事件/姿态/蓝牙/语音等），Tasker 插件能力由 vFlow 触发器替代；operit 的 AIAgentTasker/WorkflowTasker 不纳入融合编译（源码保留在 operit/ 不参与构建）。
4. **widget（桌面小组件）→ 两者都保留**（Operit ToolPkg 小组件 + vFlow 小组件并存）。
5. **ui 主题/导航 → 本期保留 Operit 自有主题**；聊天页"加号面板"、设置入口统一走 vFlow 加号区域并改成 vFlow UI；Operit 其余 UI 本期保留编译。
6. **外部 Terminal → 已核实并落盘**：终端 = OperitTerminalCore 库（terminal-core submodule）+ 自带 Ubuntu rootfs，解压进自身 filesDir。已把 terminal-core 源码（68MB，含 rootfs/pty/jniLibs）复制到融合工程 operit/terminal-core，M2 作为本地模块接入；PlanWeave 走该 proot 终端。已确认。
7. **assets 资产逐项 → 拍板**：shizuku.apk【裁】、accessibility.apk【裁】（融合应用自有无障碍+Shizuku）、desktop.apk【裁】（subpack 无外部 APK 依赖仍可工作）、**models/（语音模型）【必须保留】**、jks.jks / pkcs12.keystore【保留】、web/ dragonbones/ pets/ packages/ 等【保留】。
8. **更新源仓库（已拍板 2026-08-05）**：已创建 GitHub 仓库 happy-everyday-everyweek/**Axiom**（https://github.com/happy-everyday-everyweek/Axiom）作为 Axiom 代码与更新源仓库；data/updates 更新检查改指向该仓库（后续随代码上传落地）。Axiom-Releases 已删除。

### G. 研究专题方案（2026-08-05，待用户逐项确认）

#### G1. 首次使用引导流程（onboarding）方案（已确认 2026-08-05）

**现状盘点**
- vFlow 侧：OnboardingActivity（HorizontalPager 多页 + 免责声明页 + 创建"你好"教程工作流）、ConsentUpdateActivity（免责声明）、PermissionActivity（权限引导）
- Operit 侧：PermissionGuideScreen（3 页介绍 + 3 页引导：基本权限/存储/位置/权限级别【Standard→Accessibility→Shizuku→Root→Admin】）、startup/PluginLoadingScreen（启动插件加载动画）、agreement/（协议页）

**融合方案（Axiom 统一首启引导）**
1. 入口：MainActivity 检测首次运行 → 进入 AxiomOnboardingActivity（vFlow 风格 Compose）
2. 页面序列（8 页）：
   - P1 欢迎页（Axiom 品牌 + 三大能力简介：AI 对话/自动化工作流/项目画布）
   - P2 免责声明与隐私（合并 vFlow 免责 + Operit 协议）
   - P3 权限总览页（动态检测状态，可跳过后补）：无障碍、Shizuku/Root、悬浮窗、通知、存储
   - P4 权限引导·自动化通道（自动诊断 root > Shizuku > 无障碍，一键授权）
   - P5 权限引导·AI 基础（通知/悬浮窗/麦克风，用于对话与语音）
   - P6 模型网关初始配置（选择提供商 + 填 Key，或"跳过稍后配置"）
   - P7 终端环境首次部署（proot Ubuntu rootfs 解压 + node + PlanWeave bridge，进度动画复用 Operit PluginLoadingScreen 的 AnimatedProgressBar，可跳过后台继续）
   - P8 完成页（直接进入主界面；**不创建教程工作流**——用户已拍板）
3. 完成标记：沿用 vFlow KEY_IS_FIRST_RUN + 新增各步骤完成标志（可跳步、可重入设置页补授权）
4. 复用组件：vFlow VFlowTheme + Operit AnimatedProgressBar；删除 Operit 独立的 PermissionGuideScreen 入口（由 P4/P5 替代，源码保留）

#### G2. 模型网关（model gateway）方案

**现状盘点**
- Operit 引擎（目标网关）：AIServiceFactory 按 ApiProviderType 创建服务，支持 30+ 厂商（OpenAI/Claude/Gemini/百度/阿里/讯飞/智谱/百川/Moonshot/MiMo/DeepSeek/Mistral/硅基流动/iFlow/OpenRouter/4Router/Nous/无问芯穹/支付宝百灵/豆包/NVIDIA/LMStudio/Ollama/OpenAI本地/MNN/llama.cpp/派欧云/Novita 等）；ModelConfigManager（DataStore 持久化，多配置/多 API Key 池/轮询）；ModelListFetcher（拉厂商模型列表）；ModelConfigConnectionTester（连接测试）；ChatConfigReadiness（就绪检查）；LlmRetryPolicy（5 次重试）；MultiApiKeyProvider（Key 池轮询）
- vFlow 侧（当前客户端）：ChatCompletionClient（自研轻量 OpenAI 兼容客户端）、ChatViewModel、ChatPresetRepository（preset 配置存 SharedPreferences）、ChatAgentToolRegistry/ChatAgentModuleExecutor（工具调用）、ChatBenchmarkRunner（基准测试）

**融合方案（vFlow 聊天 UI + Operit 引擎）**
1. 保留 vFlow 聊天界面（ChatScreen/ChatViewModel 的 UI 与 Agent 工具执行层），替换底层：
   - ChatCompletionClient 内部改为调用 Operit AIServiceFactory（按 provider 创建对应服务，统一走 Operit 的流式/重试/多 Key 逻辑）
   - vFlow ChatPresetRepository 的 preset 数据迁移到 Operit ModelConfigData（DataStore api_settings），迁移器：SharedPreferences chat_presets_json/chat_provider_configs_json → ModelConfigManager；保留旧 Key 读取兼容
2. 模型选择 UI（vFlow 聊天顶栏 preset 下拉）改为读 Operit ModelConfigManager 配置流（getModelConfigFlow）
3. 设置-模型页：vFlow 风格重绘，数据源 = ModelConfigManager（增删改/Key 池/连接测试/模型列表拉取）
4. 就绪门控：发消息前 ChatConfigReadiness 检查（缺 Key/坏端点提示去配置），对齐 vFlow 现有"未配置模型"提示
5. 工具调用桥：vFlow ChatAgentToolRegistry 的 ToolPrompt 适配为 Operit AIService 的 availableTools 格式（ToolPrompt 已是通用结构，需字段映射验证）
6. 本地模型（MNN/llama.cpp/Ollama/LM Studio）本期不激活（决策 §十一-4），但保留枚举与配置能力

#### G 待确认项汇总（已确认 2026-08-05）

- G1：8 页引导顺序确认；P6 模型配置可跳过确认；P7 终端部署可跳过后台继续确认；P8 完成页**不创建教程工作流**（用户拍板）。
- G2：vFlow preset → Operit 配置自动迁移（旧数据保留）确认；模型选择 UI 沿用 vFlow 现有下拉，设置-模型页按 vFlow 风格重绘确认。

### H. M2 前先导修复执行记录（2026-08-05）

- M1.7（M2 前先导修复三项）✅ 完成：
  - 项目页（PlanWeave）状态文字居中：Box contentAlignment=Center + 全文字 TextAlign.Center（app/ui/planweave/PlanWeaveScreen.kt）。
  - 设置页闪屏修复：移除动态取色/彩色卡片/应用缩放三处 activity.recreate()（ui/settings/SettingsRoute.kt）；MainActivityContent 新增 SharedPreferences 监听器（themeTick 状态 + key 重组），主题即时生效（ui/main/MainComposeShell.kt）。
  - 液态玻璃导航栏默认开启：AppearanceManager.isLiquidGlassNavBarEnabled 默认值 false→true（新装生效，已存偏好尊重）。
  - 编译验证：:app:compileDebugKotlin BUILD SUCCESSFUL。

### I. M2 执行记录（2026-08-05）

- M2 阶段 1（构建打通）✅ 部分完成：
  - **kapt→KSP 迁移完成**：Room(compiler) 迁移到 ksp（AppDatabase v20 生成正常：ChatDao_Impl/MessageDao_Impl/MessageVariantDao_Impl/AppDatabase_Impl 已在 build/generated/ksp 确认）。
  - **ObjectBox 与 AGP9 不兼容确认**：io.objectbox 插件 5.3.0/5.4.2/6.0.0-beta 均基于 agp-wrapper-7-2，且 processor 无独立 KSP 支持 → 插件方式在 AGP9 下无法生成实体类。**解决方案：手写兼容层**（data/model/MyObjectBox.kt 用 ModelBuilder 声明 6 实体模型 + Memory_/MemoryTag_/MemoryAutoSaveCandidate_ 查询条件类 + ObjectBoxManager 改用 buildStore），并移除 io.objectbox 插件。
  - **MemoryRepository 查询降级**：8 处 Memory_/MemoryTag_ Property 查询改为内存查询（find()+filter），保证 ObjectBox 生成类缺失下查询可用。
  - **terminal-core 接入完成**：terminal-core 源码（含 Ubuntu rootfs 68MB）纳入 operit/terminal-core 并适配 AGP9（移除 kotlin.android 插件、compose 插件、externalNativeBuild 禁用、UTF-16 文件转码）；operit-app 依赖 project(":terminal-core")。
  - **terminal 兼容适配**：补 HiddenExecResult 数据类 + TerminalManager.executeHiddenCommand 扩展（基于 sendCommandToSession + commandExecutionEvents）。
  - **FFmpeg stub 扩展**：FFmpegKitStub 补 MediaInformation.streams/MediaStream 类型；StandardFFmpegTool/FFmpegUtil 可空修复。
  - **其它修复**：jitpack includeGroup 补 Sable/iyxan23/tech-pw；BuildConfig 恢复 VERSION_NAME/VERSION_CODE/APPLICATION_ID；minSdk 全模块 26→29；LlamaProvider 引用移除（决策 §十一-4）；syncSttModelAssets 禁用（B4 决策）；ComputerScreen/MessageCoordinationDelegate 参数修复。
  - **编译验证**：:operit-app:compileDebugKotlin BUILD SUCCESSFUL（12m30s）。
- 下一步：app 主壳依赖 operit-app 整体编译（双应用区同 APK）→ Manifest 合并 → 双 Application（方案 A：AxiomApplication）。

### J. M2 阶段 2（双应用区同 APK）执行记录（2026-08-05）

- **双 Application（方案 A）落地**：新建 app AxiomApplication 继承 OperitApplication（OperitApplication 改为 open）；onCreate 先执行 vFlow 初始化（日志/崩溃/遥测）再走 Operit 基础初始化；Manifest application android:name 指向 .AxiomApplication。保持 Operit 侧 `application as OperitApplication` 强转有效。
- **app 依赖 Operit 全家**：app/build.gradle.kts 添加 project(":operit-app")、project(":terminal-core")、work-runtime-ktx（OperitApplication 实现 WorkConfiguration.Provider 需在 app 可见）。
- **Manifest 合并处理**：app application 标签 tools:replace 增加 android:theme（RenderX 库 Theme.LatexView 冲突）；Operit MainActivity 的 LAUNCHER intent-filter 加 tools:node="remove"（融合后单入口归 vFlow，保留 VIEW/SEND 等）。
- **编译验证**：:app:processDebugMainManifest BUILD SUCCESSFUL；:app:compileDebugKotlin BUILD SUCCESSFUL（7m10s，双应用区同 APK 编译达成）。
- M2 里程碑（Operit 整体搬入同 APK）代码级完成，APK 完整打包构建中。
- 下一步：M2（Operit 整体搬入，含 kapt→内置 Kotlin 迁移）未完成。Operit 模块清单与 M2 硬骨头见 §十三 A/B/E/F。

### K. M2 里程碑完成记录（2026-08-06）✅

- **APK 完整打包 BUILD SUCCESSFUL**（:app:assembleDebug，2m48s，--no-daemon -Xmx2g --no-configuration-cache）。
- **native 子模块统一跳过（已拍板决策落地）**：dragonbones/mmd/fbx/quickjs 四模块的 externalNativeBuild 全部注释禁用——根因：原 CMake 依赖 git 动态源码（dragonBones/saba/ufbx/quickjs）或 DragonBones 头文件缺失（cpp/ 下仅 JniBridge+opengl），在离线工作区无法构建。native 库运行时缺失属预期，相关系统.loadLibrary 功能后续里程碑按需接回（如 M7+ arm64 NDK 补充）。
- **configuration cache 修复**：syncSttModelAssets 任务（脚本对象引用）无法序列化，assembleDebug 命令加 --no-configuration-cache 绕过；构建产物与缓存正常（219 up-to-date）。
- **APK 产物验证**（aapt dump badging/xmltree 通过）：
  - package: com.axiom.app（改包名生效），versionName 1.5.3-pr1
  - application android:name = com.chaomixian.vflow.AxiomApplication（双 Application 方案 A 生效）
  - android:testOnly=0（非 testOnly，可正常安装，无"非正式版本"拦截）
  - 产物：app-arm64-v8a-debug.apk（445MB）等 5 个变体；arm64 已同步 /sdcard/Download/Axiom/Axiom-v1.5.3-pr1-M2-arm64.apk
- **M2 里程碑正式达成**：Operit 全家（operit-app + 5 子模块 + terminal-core + Shizuku 9 模块）与 vFlow 壳同 APK 编译、打包、签名全部通过，等待用户真机安装验证。

### L. M2.1 安装冲突修复（2026-08-06）✅

- **问题**：用户设备已装原版 Operit（com.ai.assistance.operit），新 APK 安装报"组件命名与已有应用程序的组件命名重复"。
- **根因**：terminal-core 的 UbuntuDocumentsProvider 在 AndroidManifest.xml 与代码中硬编码 authority `com.ai.assistance.operit.documents.ubuntu`（其余 provider 均用 ${applicationId} 占位，合并后自动变 com.axiom.app.*，唯独这一处写死）。
- **修复**：两处（operit/terminal-core/src/main/AndroidManifest.xml 第12行 + UbuntuDocumentsProvider.kt AUTHORITY 常量）改为 `com.axiom.app.documents.ubuntu`。
- **验证**：全工程 manifest 盘点 authorities 已统一 com.axiom.app.*（provider/shizuku/documents.workspace/memory/data/ubuntu/androidx-startup/cropper/mlkit/jlatexmath 共 10 个），无 com.ai.assistance.operit 残留；reassemble 4m44s BUILD SUCCESSFUL；testOnly=0。
- **产物**：/sdcard/Download/Axiom/Axiom-v1.5.3-pr1-M2.1-arm64.apk（453MB）。

### M. M3+M5 合并对齐（2026-08-06，用户拍板）✅

- **里程碑边界（用户拍板）**：M3 与 M5 合并为一个里程碑执行——即"权限融合（Shizuku 内置 + 分级授权）"与"AI 引擎切换（vFlow 聊天 → Operit 引擎）"一起做。
- **权限分级模型（用户定义，取代旧的三级"root>ADB>无障碍"描述）**：
  - 权限分为三档：基础 / ADB / Root。
  - 基础权限 = 所有常规运行时权限 + 无障碍，三档（基础/ADB/Root）都必须先授权基础权限，是共性底座。
  - ADB 档 = **不需要 root**。流程（用户描述，Shizuku 标准无线调试路径）：引导用户进系统设置→开发者选项→打开"无线调试"，在增强型通知中输入匹配的配对码 → 自动配对 → 自动连接。无需任何外部兼容/额外应用。
  - Root 档 = 直接 su/root 通道。
  - 设置中新增 Shizuku 入口，进入"正常的 Shizuku 主页面"。
- **ShizukuInstaller（用户拍板：改写，使用内置 Shizuku）**：不再从 assets 提取 shizuku.apk（M2 已裁剪该文件），改为内置 Shizuku（:server/:starter 等 9 模块已并入工程，SDK 参照官方 --apk=self 机制编入自身 dex），通过 ADB 无线调试或 root 自启内嵌 server。不依赖官方 Shizuku 安装包。
- **无障碍回退（用户确认：此问前置无意义，直接做）**：UIHierarchyManager / accessibility 通道直接利用 vFlow 已内置的 AccessibilityService（.services.AccessibilityService），无障碍属于基础权限档，合并即通。
- **权限设置 UI（用户拍板）**：在设置页上方新增一个板块，UI 风格采用 vFlow 主页同类（好看的那版卡片式大盘），集中展示基础/ADB/Root 三档权限状态与授权入口，以及 Shizuku 入口。

### N. M3+M5 合并定稿（2026-08-06，用户逐项拍板，开工依据）✅

**A. 外壳与引擎边界（总原则）**
- A1 导航、设置、聊天输入框、加号面板、模型选择、整体视觉 = vFlow 风格，vFlow 为外壳。
- A2 Operit 只当引擎 + 渲染器：文字渲染、工具调用渲染本里程碑用 Operit 的（Bubble/Cursor 消息、markdown、工具条），后续逐步优化。

**B. 交互元素搬迁（Operit 输入区 → vFlow 外壳）**
- B1 右上角模型选择区：模型标签 + 上下快速切换、上下文窗口占用/token 统计、调参（Tune）入口。
- B2 加号面板：附件能力选择（图片/拍照/记忆/文件/截图/通知/位置/增强）、全屏输入入口、回复引用。

**B3. 终端/工作区入口（用户拍板）**：入口图标放 Chat 顶部栏"新建对话"左侧（ChatTopBarActions，现有两个图标：新建对话 rounded_add_comment_24 + 侧栏 rounded_menu_open_24），新增终端、工作区两个图标，不违和。

**C. 引擎直调 + 设置**
- C1 vFlow ChatViewModel 直调 Operit EnhancedAIService/ChatRuntime 完整增强管线（工具调用/记忆/文件绑定/多服务）。
- C2 Operit 模型/Provider 配置整合进 vFlow 设置页，preset 数据迁移并入，Provider 用 Operit 全量。

**D. 终端与工作区**
- D1 "终端"入口（terminal-core + proot Ubuntu）与 UI 在融合 App 内可用、符合 vFlow 风格。
- D2 "工作区"入口与 UI（Operit WorkspaceManager/编辑器/命令执行/文件预览/备份体系）融入 App，入口显式化，UI 注意移动端可用性。

**E. 插件体系**
- E1 尽量完适配 Operit 插件体系：ToolPackage / packTool（ToolPkgLoader/Manager/Parser）/ MCP / skill / cli 模式 / 插件 DSL 渲染等，全部作为能力底座接入引擎，不与 vFlow 外壳冲突。

**F. 项目（PlanWeave）整合**
- F1 移动端适配：解决"三栏桌面布局 → 手机单窄条/元素过大/排版差"，做响应式重排（renderer 侧适配层 / WebView 壳补偿）。
- F2 与 Operit 引擎双向打通：PlanWeave 页面可调用 Operit Agent 能力/内容；Operit 引擎侧可主动向 PlanWeave 注入任务、读取项目数据。

**G. 权限融合（原 M3，不丢）**
- G1 基础 / ADB / Root 三档：基础＝常规权限+无障碍（三档共用底座）；ADB＝无线调试配对自连（免 root、零外部依赖）；Root＝su 通道。
- G2 设置页新增三档权限状态大盘（vFlow 卡片风格）+ Shizuku 入口（进正常 Shizuku 主页）。
- G3 ShizukuInstaller 改写为内置 Shizuku 自启；UIHierarchyManager 无障碍通道接 vFlow AccessibilityService。

**H. 边界**：M4 工作流节点互调不在本轮。

**I. 执行顺序（拟定）**
- I1 权限融合（G）→ I2 引擎直调+设置（C）→ I3 交互搬迁（B）→ I4 终端/工作区入口+UI（B3/D）→ I5 插件适配（E）→ I6 PlanWeave 整合（F）→ 完整 APK 验证。

**J. 数据迁移 + 首次引导（2026-08-06 用户补充，纳入本里程碑）✅**
- J1 **vFlow 数据迁移**：由 vFlow（原 com.chaomixian.vflow 数据，含聊天 preset/provider 配置、工作流、会话记录、设置等）迁移到 Axiom（com.axiom.app）命名空间与存储。
- J2 **Operit 数据迁移**：由原版 Operit（com.ai.assistance.operit，含 Room 数据库、ObjectBox 分库、角色卡、模型配置、偏好等）迁移到 Axiom 的存储路径。
- J3 **首次使用引导（onboarding）**：Axiom 首次启动引导（G1 已定 8 页方案：欢迎/模型配置/终端部署/权限指引等，P8 完成页不创建教程工作流），检测到旧数据时先走迁移提示；无旧数据直接进常规引导。
- J4 迁移原则：不丢数据、失败可重试、迁移状态持久化（标记已迁移，防重复）；迁移完成后再进主界面。
- J5 **迁移通道（已核实代码，2026-08-06）**：
  - Operit 数据可读：原版 Operit 备份目录在共享存储 /sdcard/Download/Operit/backup/（含 room_db/raw_snapshot/chat/memory/model_config/character_cards，跨包名可读），且 Operit 已有 RoomDatabaseRestoreManager（zip 恢复 app_database）+ RawSnapshotBackupManager；Axiom 可直接复用恢复器 + 扫描共享备份目录实现迁移，无需 root。
  - vFlow 数据：工作流存 SharedPreferences（vflow_workflows，私有目录，Axiom 无法直读）；vFlow 已有 WorkflowImportHelper/ImportQueueProcessor（JSON 导入），迁移走"旧版导出 JSON → Axiom 导入"路径；有 root/Shizuku 时可用特权读 prefs 直迁（可选项）。
  - 首次引导中检测：Axiom 首启检测 /sdcard/Download/Operit/backup 存在旧备份 → 提示"检测到 Operit 数据，是否迁移"；vFlow 侧检测导入文件（SAF 选择旧版导出）。

### K. M3 增补修正（2026-08-06 用户纠正，纳入 §N/G/I）✅

- K1 **Shizuku ADB 连接状态机（用户纠正我的理解）**：
  - ADB 通道工作流 = "配对一次 + 后续重连"。只有三种情况需要重新配对：(a) 首次选择 ADB 模式；(b) 切换后；(c) 连接请求失败。平时点击"启动"直接重新连接，不重复配对。
  - 配对方式不止无线调试：支持有线连接发命令、Root 方式等。
  - 修正设计：ShizukuInstaller.startBuiltInShizuku 增加"已配对状态"判定（连接过的设备/保存的配对产物），已配对直接重连；请求失败才回退重新配对；配对方式按可用性选择（无线调试/有线/Root）。
- K2 **vFlow Core 模块（用户提示有作用）**：vFlow core/workflow/module/core/* 提供系统能力模块（蓝牙/音量/剪贴板/触摸回放/息屏/亮屏等高频工具），融合后这些 Core 模块仍是 vFlow 工作流的能力底座，与 Operit 工具体系并存；M3/M5 不丢弃，保留原样。
- K3 **UI 点击/自动化（用户拍板）**：不保留 Operit 基础 UI 层级方案（UIHierarchyManager+外部 accessibility.apk 不再维护），UI 自动化走 Operit 的 AutoGLM 子代理（AutoGlmViewModel/AutoGlmToolScreen，语音/虚拟屏 UI 自动化）作为 UI 代理层；vFlow 的 UiInspectorService 保留调试用途。

### O. M3+M5 执行记录（2026-08-06 I1~I6/J 全部落地）✅

**I1 权限融合**：
- ADB 无线调试全套移植（AdbMdns/AdbPairingClient/AdbKey/AdbMessage/AdbProtocol/AdbClient/AdbException → app/adb/），Axiom 版 AdbPairingService 注册（connectedDevice 前台服务 + ACTION_START_ADB_PAIRING）。
- K1 状态机：配对一次 + 后续重连（isPaired 判定 + TLS_CONNECT 直连探活，失败才重新配对）。
- 设置页权限三档卡（AxiomPermissionTierCard：基础/ADB/Root）+ Shizuku 入口（启动 ADB 配对服务）。
- ShizukuInstaller 改写为内置启动（Root 通道 su + ADB 配对双路径），去除 assets apk 依赖。

**I2 引擎直调**：AxiomOperitChatEngine 桥接 EnhancedAIService.sendMessage（完整增强管线：工具中枢/记忆/多服务），ChatViewModel 优先直调 Operit、失败回退 vFlow 原生 client。

**I3 交互搬迁**：B1 模型选择区加快速上下切换（KeyboardArrow 按钮 + switchPreset 循环切换）；B2 加号面板顶部加 Operit 能力行（记忆/文件/截图/通知/位置/增强包/全屏输入 7 入口，OperitAttachmentChip）。

**I4 终端/工作区入口**：ChatTopBarActions 加 终端（AxiomTerminalHostActivity→ComputerScreen）+ 工作区（AxiomWorkspaceHostActivity→workspace 目录浏览）两图标于"新建对话"左侧。

**I5 插件适配**：AxiomPackagesHostActivity→PackageManagerScreen（packTool/MCP/Skill/市场全量）+ 设置页"插件管理"入口。

**I6 PlanWeave**：F1 onPageFinished 注入移动端响应式 CSS（三栏塌缩/触控目标 44dp/字体适配）；F2 AxiomPlanWeaveBridge（window.AxiomBridge：health/runAgent→Operit 引擎 + injectTaskToPage 反向注入）+ PlanWeaveJsBridge 执行通道。

**J 数据迁移 + 首启引导**：AxiomDataMigrationActivity（检测 /sdcard/Download/Operit/backup/room_db 备份 → 确认 → RoomDatabaseRestoreManager 恢复 → 持久化标记）；MainActivity 首启未迁移且有备份时优先进入迁移页（有真实数据：room_db 至 08-04、raw_snapshot 217MB）。

**编译验证**：:app:compileDebugKotlin 全绿（含 operit-app 依赖）；完整 :app:assembleDebug BUILD SUCCESSFUL（5m59s）。

### P. M3+M5 里程碑完成（2026-08-06）✅

- **完整 APK 打包 BUILD SUCCESSFUL**（:app:assembleDebug，5m59s，--no-daemon -Xmx2g --no-configuration-cache）。
- **bouncycastle 依赖冲突修复**：bcpkix-jdk18on 传递引入 jdk15to18 系列与现 jdk18on 重复类（bcprov/bcutil/bcpkix），configurations.all 全局排除 jdk15to18 三项。
- **产物验证**（aapt + dex 核对通过）：package com.axiom.app / 1.5.3-pr1 / testOnly=0；9 个新组件类全部进入 dex（AdbPairingService、AxiomPermissionTierCard、AxiomOperitChatEngine、AxiomTerminalHostActivity、AxiomWorkspaceHostActivity、AxiomPackagesHostActivity、AxiomDataMigrationActivity、AxiomPlanWeaveBridge、OperitAttachmentAction）；新字符串资源确认打进 APK。
- **产物**：app-arm64-v8a-debug.apk（464MB）；已同步 /sdcard/Download/Axiom/Axiom-v1.5.3-pr1-M3M5-arm64.apk。
- **M3+M5 里程碑正式达成**：权限融合（三档 + Shizuku 内置 ADB 配对一次重连）+ AI 引擎直调（Operit 增强管线）+ 交互搬迁（模型上下切换 + 加号面板 Operit 能力）+ 终端/工作区入口 + 插件体系接入 + PlanWeave 移动端/双向桥 + 数据迁移与首启引导。等待用户真机验证。

### Q. M3+M5 真机验收问题清单（2026-08-06 用户逐项反馈，修复依据）❌

**Q1 备份/迁移（用户纠正策略）**
- 不能"自动抓取自动导入"——用户反感的强弹窗。改为：设置中提供"备份/迁移"入口，用户主动点入，检测是否已有 Operit 备份并给出选项（恢复/跳过），不自动弹、不自动导入。
- 认真研究两套备份系统：Operit 现有 Room 备份（app_database zip）与 vFlow 自身数据（prefs/workflows/导出 JSON），入口统一整合。
- 导入备份后没有成功出现对应内容——恢复链路需验证（可能是 Room 版本/表不匹配或导入时机问题）。

**Q2 终端/命令行瘫痪（致命）**
- java.lang.UnsatisfiedLinkError: Pty.createSubprocess 无实现——terminal-core 的 libpty.so（由 jni/pty.c 编译）缺失，externalNativeBuild 在 AGP9 适配时被禁用，且 src/main/jniLibs 下没有预编译 libpty.so。
- 修复方向：NDK 交叉编译 pty.c 生成 libpty.so 放入 jniLibs/arm64-v8a（已确认 NDK 工具链可用、forkpty 声明在 bionic pty.h 存在），或启用 terminal-core externalNativeBuild 同时避开 d8/AGP9 冲突。
- 连带影响：工作区无法创建、命令行工具不可用——全部阻塞于 libpty。

**Q3 首次引导未生效**
- 新版（M3+M5 后的）首次使用引导没有生效（可能被迁移检测/旧 isFirstRun 状态覆盖，或 Onboarding 未接到新流程）。

**Q4 模型服务商用 Operit 的决策未生效**
- 已拍板"模型配置用 Operit 全量 Provider / 服务商选择跟随 Operit"，但真机上未生效——需检查 AxiomOperitChatEngine 桥是否真正接管（失败回退逻辑误触发？）以及设置页模型/Provider 是否仍只用 vFlow preset。

**Q5 权限相关（混乱且无效）**
- 权限授予相关功能非常混乱、完全无效；设置里权限三档卡（基础/ADB/Root）位置、文案、交互需要按 Operit 原版"权限首页三卡片"布局重构（用户强调参考 Operit 权限首页的卡片式大盘）。
- 启动/授权链路（Shizuku/ADB/Root/无障碍）需重新理顺，确保点击后真正拉起对应授权。

**Q6 设置内容缺项**
- 设置页缺少 Operit 相关设置项（模型/Provider/API key/插件等未进 vFlow 设置），无法配置 Operit。
- 部分设置选项开关后会跳回对话页面——设置导航状态/返回行为异常。

**Q7 插件管理 MCP 页崩溃**
- 进入 MCP 配置页抛 `IllegalStateException: LocalPluginLoadingState not provided`——MCPConfigScreen 依赖 CompositionLocal（LocalPluginLoadingState），承载 Activity（AxiomPackagesHostActivity）未在 CompositionLocal 作用域内提供。
- 修复：承载页外层包 LocalPluginLoadingState Provider（或链上 Operit 启动屏的状态初始化）。
- 连带：Operit 市场功能完全无法使用（市场/商店依赖插件状态/网络与包管理器）。

**Q8 闪屏**
- 进应用后一定时间突然闪屏一次：原 Activity 被关闭/销毁后又开一个同类 Activity——疑似主题/回退触发 recreate，需要排查（AppearanceManager、MainActivity 重建条件、OperitApplication 初始化导致的重启）。

**Q9 项目（PlanWeave）板块仍异常**
- 移动端 UI 优化（三栏塌缩/排版）实际未生效或不够——需进一步做真正响应式（renderer 注入覆盖或 WebView 壳适配）。
- PlanWeave ↔ Operit/AI ↔ vFlow 三方互相调用未打通：互相完全无法被调用、无沟通通道——双向桥（AxiomBridge）需要在插件/页面端真实接入（runAgent 能被调用、Operit 能向 PlanWeave 注入任务、vFlow 工作流能与 PlanWeave 互调）。

**Q10 工具命名与工具批准**
- "增强包"应改叫"工具"（Operit AttachmentSelector 中 label=增强/包名的项），文案修正。
- 工具批准沿用 vFlow 既有交互（工具调用审批/批准链路舒适的那套），Operit 工具接入后批准交互用 vFlow 机制（而非新造）。

**Q11 vFlow AI 能力并入 Operit**
- 不再保留 vFlow 的 AI 能力；vFlow 应用本身的能力（工作流/模块/执行）+ vFlow 智能体能力并入 Operit 智能体（Operit 引擎统一调度，vFlow 壳只承载界面）。

**Q12 后续铺垫方向（用户要求先干完这些再进 M4）**
- 以上 Q1~Q11 全部完成并通过再构建 APK，作为 M4（工作流互调）之前的铺垫。

**修复优先级建议**：Q2（堵塞终端/工作区）→ Q7（崩溃）→ Q1/Q5/Q6（设置/权限/备份）→ Q3/Q4（引导/模型）→ Q8（闪屏/回退）→ Q9（PlanWeave）→ Q10/Q11（交互与并入）。

### Q 补充：第二轮反馈（2026-08-06 用户补充，并入 Q 清单）❌

**Q13 首页 UI 与权限页形态（用户纠正）**
- "首页"指原版 vFlow 首页（HomeScreen）的 UI，用户认为其 UI 不错——权限相关页面形态参考 vFlow 首页 UI 风格。
- 不能简单把权限页路由到 Operit 的 ShizukuDemoScreen/权限页——整体权限体系已重新设计为三档（基础/ADB/Root），权限页必须按新体系呈现（vFlow 首页风格 + 三档权限大盘），不直接复用 Operit 权限页布局。

**Q14 加号面板（Operit 能力行）问题**
- 部分组件无法显示（渲染缺失）。
- 部分组件点击后出现问题（行为异常/崩溃）。
- 部分能力并非 Operit 所支持，未做降级/隐藏处理（如当前环境不支持时应隐藏或禁用并提示）。
- 需逐一核对：记忆/文件/截图/通知/位置/工具（增强包改名后）/全屏输入 各入口的实际能力与可用性，不可用项做降级处理。

**Q15 首次使用引导（确认未做）**
- 新版首次使用引导未实现/未生效——需按 G1 已定 8 页方案真正落地（欢迎/模型配置/终端部署/权限指引/完成页，P8 不创建教程工作流），并确保 isFirstRun 链路触发。

### Q 修复记录（2026-08-06 第一批落地）✅

- **Q2 已修**：NDK 交叉编译 jni/pty.c 生成 libpty.so（--target=aarch64-linux-android29 显式 target 解决 forkpty 声明），放入 terminal-core jniLibs/arm64-v8a，终端/工作区/命令行恢复。
- **Q7 已修**：AxiomPackagesHostActivity 包 CompositionLocalProvider(LocalPluginLoadingState provides PluginLoadingState)，MCP 配置页不再崩溃。
- **Q1 已修**：移除 MainActivity 首启自动迁移弹窗；设置页新增"备份与数据迁移"入口（手动触发 AxiomDataMigrationActivity）。
- **Q3/Q15 已修**：OnboardingActivity 移除 createTutorialWorkflow（完成页不创建教程工作流）；引导链路保留（isFirstRun 触发，4 页+免责+完成）。
- **Q4/Q6 已修**：设置-模型配置改指向 AxiomModelConfigHostActivity（Operit FunctionalConfigScreen 全量 Provider）。
- **Q10 已修**：Operit AttachmentSelector "包/选择包/暂无可用包" → "工具/选择工具/暂无可用工具"。
- **Q13 已修**：设置-权限区块改为 vFlow 首页仪表盘三卡（AxiomPermissionDashboard：权限健康左 / 权限修改右上 / 最近日志右下），样式复刻 HomeInfoCard；新增 AxiomPermissionHostActivity 作为权限详情页。
- **Q14 已修**：加号面板 Operit 能力行接真实动作——记忆→AxiomMemoryHostActivity、文件→SAF OpenDocument、工具→AxiomToolboxHostActivity（承载 PackageManagerScreen）、全屏输入→提示、截图/通知/位置→降级提示（依赖聊天会话上下文）。
- **Q5 部分**：权限详情承载页（AxiomPermissionHostActivity→ShizukuDemoScreen 权限卡）已建；设置页以三卡仪表盘呈现新权限体系。
- 待办：Q8（闪屏根因深查）、Q9（PlanWeave 双向桥已注入 bootstrap，待真机验证）、Q11（vFlow AI 并入 Operit 智能体，铺垫项）。

### Q 修复记录（2026-08-06 第二批：设置接入 + 终端）✅

- **Q16 已修（Operit 设置全量引入）**：新增 AxiomOperitSettingsHostActivity——承载 Operit SettingsScreen 全部 18 项入口（用户偏好/模型/功能配置/主题/显示/ModelPrompts/语言/语音/角色卡/waifu/Token统计/上下文摘要/布局/工具权限/备份/聊天历史/外部 HTTP），子页以 Compose 状态切换内嵌承载；vFlow 设置页顶部新增"Operit 设置中心"入口（原 vFlow 入口保留）。
- **Q17 已修（终端 bash exec 失败）**：linkNativeLibs 中 bash/proot/loader/sudo 由"符号链接"改为"复制为独立可执行文件 + setExecutable"——应用私有目录符号链接 exec 受 SELinux/文件系统限制（No such file or directory），复制后 exec 正常；libtalloc.so.2 保留符号链接（被 loader 加载而非 exec）。
- **终端 rootfs**：bash 可执行后经 start_shell→install_ubuntu（busybox tar 解压 ubuntu-noble rootfs 到 {filesDir}/usr/var/lib/proot-distro/installed-rootfs/ubuntu）部署；libsudo.so 损坏（2B）已记录，影响 sudo 提权不影响基础终端。

### Q 修复记录（2026-08-06 第三批：按用户纠正重构）✅

- **Q18 已修（设置页崩溃）**：Operit 承载页全部改用 OperitTheme 包裹（提供 LocalThemePreferenceSnapshot / LocalLiquidGlassBackdrop / LocalWaterGlassState），不再用 vFlow MaterialTheme——设置页可正常进入，不再抛 not provided。
- **Q19 已修（设置项逐项入组，废除"设置中心"聚合入口）**：
  - 通用分组：模型配置(Operit)、功能模型映射、语音服务、角色卡生成、Waifu 模式、模型提示词、Token 统计、上下文摘要、外部 HTTP、用户偏好、聊天历史、数据备份（12 项）。
  - 主题分组：主题设置、显示设置、布局调整（3 项）。
  - 语言分组：语言设置(Operit)（1 项）。
  - 权限分组：工具权限（1 项）。
  - 共 17 项逐项嵌入 vFlow 对应分组，每项直达 Operit 对应子页（AxiomOperitSettingsHostActivity 支持 Intent 指定 Target）。
- **Q4 补强（模型配置真正换成 Operit）**：聊天顶部"配置模型"入口从 vFlow ModelConfigActivity 改为跳 Operit 承载页；设置-模型配置同样指向 Operit。
- **Q17 补强（终端 bash exec）**：LocalTerminalProvider.startSession 优先 exec nativeLibDir/libbash.so（APK 提取目录系统放行 exec），fallback 到 binDir 复制版——彻底避开应用私有目录 exec 限制。
- 待办：加号面板（Q14 重做：去重、可用性）、Operit×PlanWeave 互联（Q9 做实）、Q8 闪屏。

### Q 修复记录（2026-08-06 第四批：Q9 互联 + Q20 移动端）✅

- **Q9 已修（Operit × PlanWeave 互联，源码级）**：定位 PlanWeave 完整源码（第二个工作区 0e220c02，GaosCode/PlanWeave monorepo），拷贝到本工作区 planweave-src；在 web-bridge 源码加互联：
  - bridge-server.ts 新增 `POST /api/axiom-agent`（接收 {prompt,title,projectPath} → 广播 SSE 事件 axiomn:injectTask 到所有页面连接）；
  - web-preload.ts 订阅 axiomn:injectTask 转发 window 事件 + 暴露 `window.axiomOperit.runAgent(prompt, projectPath?)`（页面可调 Operit 引擎）。
  - 构建产物（bridge-server.mjs 2.8MB + web-preload.js 17.4KB）已部署 /srv/planweave 并重启，health 200、/api/axiom-agent 返回 {"ok":true,"injected":0}、web-preload 含 axiomOperit 已验证。
- **Q20 已修（移动端 UI 适配，源码级）**：desktop/src/renderer/index.css 新增 768px 媒体查询（三栏塌缩单列、侧栏抽屉化、主区全宽、触控目标≥44px、输入 16px 防缩放、表格横滚、弹窗最大化）；vite build 重编译 renderer 并部署 /srv/planweave/renderer（index-Dzd0aN_x.css 含 768px 块已验证）。
- **Q14 重做（加号面板精简）**：能力行由 7 项精简为 4 个真实可用入口（记忆→记忆库页、文件→SAF、工具→工具箱页、全屏输入→提示），截图/通知/位置因依赖 Operit 聊天会话上下文已从面板移除（不再显示不可点项）。
- **最终产物**：Axiom-v1.5.3-pr1-QFIX4-arm64.apk（464MB）已同步 /sdcard/Download/Axiom/。

### Q 修复记录（2026-08-06 第五批：全面静态验证）✅

- **Q21 已修（Operit 核心未接入——根因）**：Operit 主初始化 initializeMainApplication（用户偏好/语言/AIMessageManager/PluginRegistry/聊天运行时）原由 Operit MainActivity 触发，融合后无调用方 → 引擎/工具/插件全部未初始化。修复：AxiomApplication.onCreate 中 super.onCreate() 后调用 initializeMainApplication()（带 try-catch）。这是此前 Operit 各项功能"没生效"的根因之一。
- **Q22 已修（工作区创建——与终端无关）**：Operit 工作区创建/绑定是 ChatViewModel 会话级流程（WorkspaceSetup→bindChatToWorkspace），vFlow 侧工作区页此前只是文件浏览，无法创建。修复：AxiomWorkspaceHostActivity 重写为完整工作区管理页——OperitTheme 包裹 + WorkspaceSetup（选目录/项目类型→绑定）真实流程，绑定持久化（SharedPreferences），已绑定工作区内容列表展示，可重新创建/切换。
- **静态验证结论（本轮逐项检查）**：
  - 终端：libpty.so 5 个 JNI 导出符号与 Pty.kt external 声明完全匹配（含 createSubprocess）；bash exec 已改 nativeLibDir 路径规避 SELinux。
  - 权限：三卡（权限健康/修改/日志）→ PermissionActivity/PermissionGuardian 均已注册、链路完整。
  - 加号面板：能力行精简 4 项可用（记忆/文件/工具/全屏输入），OperationAction 分支齐全。
  - 互联：/srv/planweave 已部署含 /api/axiom-agent + axiomOperit 的新产物。
- **产物**：Axiom-v1.5.3-pr1-QFIX5-arm64.apk（464MB，BUILD SUCCESSFUL 3m50s）已同步 /sdcard/Download/Axiom/。

### R. 第六轮用户评估（2026-08-06，M2/M3+M5 综合评审：几乎不可用，不予批准）❌

**R1 加号面板能力全部补齐（硬性）**
- "加号面板能力要全部补全、补齐，必须补齐，里程碑硬性要求，不允许降级/不允许隐藏"。
- QFIX4/QFIX5 把能力行精简为 4 项（记忆/文件/工具/全屏输入）并移除截图/通知/位置——错误方向。必须全量接入真实动作。
- Operit 真实实现已静态确认存在于 operit/app .../chat/viewmodel/ChatViewModel.kt：captureScreenContent / captureNotifications / captureLocation / attachPackage / handleTakenPhoto / insertAttachmentReference / removeAttachment / attachMedia 等；AIChatScreen.kt 1848-1853 行展示了 AttachmentSelector 的正确接线方式。
- 补齐目标面板项（暂定 8-10）：记忆、文件、截图、通知、位置、工具包、全屏输入、相机、图片、包选择。每一项都要"真实可用的动作"，而非提示/隐藏。

**R2 终端依旧不可用（真机复测，报错相同）**
- 报错：execve(/data/data/com.axiom.app/files/usr/bin/bash) failed: No such file or directory。
- Q17 声称"bash 复制为独立可执行 + setExecutable + nativeLibDir 优先"，真机仍找不到 bash → 需要核查 linkNativeLibs 实际产物路径是否与 LocalTerminalProvider 的 binDir/bashPath 一致，rootfs（install_ubuntu）是否部署；bash 文件本体是否进 APK（libbash.so 是否打包进 jniLibs）。
- 连带：工作区创建/命令行仍不可用。

**R3 项目（PlanWeave）白屏无法使用**
- 项目区 WebView 白屏——服务是否常驻、127.0.0.1:8787 是否可达、WebView 注入（清理 UA/JS）是否生效、renderer 是否正常响应；需真机级别排查（WebView 调试 + 服务存活 + 网络配置 cleartext）。

**R4 AI 模型配置：只能打开"功能模型配置"页，打不开"模型真正配置页"**
- 设置-模型配置项打开的是 FunctionalConfigScreen（功能配置），而非真正的 ModelConfigScreen（Operit 模型/Provider 列表、可新建/编辑 API key 与模型）。
- 用户明确：设置里的模型配置页是可用的（vFlow 原 ModelConfig 可用），但 Operit 的模型真正创建/配置必须能打开——接入正确目标页（Operit ui/features/... model 的模型列表/创建页）。

**R5 所有 Operit 标注全部删除**
- 产品外壳不应出现"Operit"字样（如设置入口文案"Operit 模型配置"等）——统一改为 Axiom 语义（模型配置、功能映射、工具权限…）。

**R6 设置项着色**
- vFlow 设置分组项按分类有不同颜色（如主题蓝/通用绿……），而揉进来的 Operit 设置项全部一个色——需要按分组/分类赋予对应颜色（与 vFlow 其他设置项一致的分组色）。

**R7 设置搜索搜不到 Operit 设置项**
- 设置页搜索功能必须覆盖全部设置项（含并入的 17~19 项 Operit 子项），搜索"模型/主题/语言/备份/工具"等应命中对应项并直达。

**R8 数据迁移页：不要自造，用 Operit 自带的迁移界面**
- 撤销自造的 AxiomDataMigrationActivity 主界面，改为承载 Operit 原有备份/恢复页面（Operit 设置里有数据备份和恢复页面），作为迁移入口。

**R9 M2 整体评估：几乎不可用，不予批准进入下一里程碑**
- 以上全部修正 + 重新构建 + 重新静态审查通过之前，里程碑不批准。继续更正与优化，不自行确认。

**R10 性能与 UI 优化**
- 整体性能 + 整体 UI（尤其切到 Operit 界面时）：当前"一闪一闪"（过渡闪烁）、设置页上下滑动掉帧明显 → 排查过度重组/重复动画/背景绘制；给 vFlow 外壳与 Operit 承载页补流畅过渡与滚动性能。
- Operit 界面 UI 暂不改，先把过去（vFlow 一路过来的）UI/交互/动画做稳。

**R11 交付前静态审查与代码质量工具**
- 交付新 APK 前必须重新静态审查（重点：组件注册/资源/依赖/崩溃路径）。
- 用户强烈建议安装代码风格审查与代码审查工具（如 ktlint / detekt / Android Lint），接入构建流程并在交付前运行。

### R 修复记录（2026-08-06/07 第六轮实施）✅

- **R1 已修（加号面板全能力补齐）**：
  - OperitAttachmentChip 能力行从 4 项补全为 7 项全展示：记忆/文件/截图/通知/位置/工具/全屏输入（相机与照片仍由 vFlow 原生 carousel 承载，不重复）。
  - 截图/通知/位置真实动作：新增 runOperitCaptureTool（AIToolHandler 执行 capture_screenshot/get_notifications/get_device_location + 预授权 ALLOW 避免 ASK 拦截），结果回填输入框（appendAttachmentText 拼接 [屏幕截图]/[当前通知]/[当前位置] 前缀）；新增字符串 chat_operit_screen_added/notifications_added/location_added。
  - 全屏输入真实对话框：Dialog 全屏 TextField（fullscreenInputVisible/fullscreenInputText），确定回填 prompt；OperitAttachmentChip 移除冗余 label toast。
- **R2 已修（终端 bash exec）**：根因 = extractNativeLibs=false 时 nativeLibraryDir 为空，linkNativeLibs 全部失败 → binDir 无 bash。修复：TerminalManager.linkNativeLibs / busybox 改走 resolveNativeLib()（优先 nativeLibraryDir，缺失时从 APK zip lib/<abi> 提取到 filesDir/native-extract 并 setExecutable）；撤销 useLegacyPackaging（避免打包内存爆炸卡死 dex 合并）。libbash/libbusybox/libproot/libloader/libtalloc/libpty 均已确认打进 APK。
- **R4 已修（模型配置页）**：AxiomModelConfigHostActivity 由 FunctionalConfigScreen 改为承载 ConfigScreen（真正的模型/Provider 列表页，可新建模型配置）；设置-模型配置与聊天顶部入口均指向此页；"功能模型映射"保留独立入口。
- **R5 已修（Operit 标注全删）**：strings.xml 所有"（Operit）"后缀与描述中 Operit 字样清理（引擎设置中心/模型配置/功能模型映射等）；chat_operit_attachment_package 由"增强"改"工具"；SettingsRoute/MainComposeShell 注释同步清理。
- **R6 已修（设置项着色）**：19 项 Operit 设置按分类分配 tone（模型类 cloud 蓝/语音类 accent 粉/角色生成 soft 蓝紫/统计数据 warm 绿/网络备份 neutral 青/用户偏好 language 灰/工具权限 warning 橙），不再全部 palette 黄。
- **R7 已修（搜索覆盖）**：SettingsScreen showLanguageSection/showThemeSection/showGeneralSection/showPermissionsSection 的 matchesSearch 列表全部并入 Operit 各项 title/desc（模型/功能/语音/角色卡/waifu/提示词/token/摘要/HTTP/偏好/历史/备份/插件/迁移/工具权限/主题/显示/布局/语言）。
- **R8 已修（迁移页用 Operit 自带）**：设置-备份与数据迁移入口改为 AxiomOperitSettingsHostActivity Target.BACKUP（Operit ChatBackupSettingsScreen），不再打开自造的 AxiomDataMigrationActivity。
- **R3 已修（PlanWeave 白屏加固）**：PlanWeaveWebView 增 mixedContentAlwaysAllow + onReceivedError/onReceivedHttpError 自动 reload（避免白屏）；启动前 deployPlanWeaveAssets() 把 assets/planweave（bridge-server.mjs/web-preload.js/planweave-web.sh/renderer）幂等部署到 proot rootfs /srv/planweave。
- **R10 已修（性能掉帧）**：OperitTheme 默认背景 backglow（useBackgroundBlur 开关控制，默认关，消除设置页/承载页滑动每帧重绘）。
- **R11 说明**：接入 ktlint Gradle 插件验证可用（ktlintCheck 通过并修复 build.gradle.kts 4 处风格违规）；因离线插件解析存在，改为保留 Android Lint（AGP 内置）作为交付前静态审查通道，ktlint 规则后续随网接入。
- **产物**：Axiom-v1.5.3-pr1-QFIX6-arm64.apk（464MB，BUILD SUCCESSFUL 8m14s；operit-app 编译缓存此前已落盘，全 5 ABI 变体 03:28 同批次生成）已同步 /sdcard/Download/Axiom/。dex/lib/assets 抽查全部通过。

### S. 第七轮用户反馈（2026-08-07 QFIX6 真机验证）❌

**S1 终端依旧不可用**：QFIX6 后真机终端仍不可用。需结合 resolveNativeLib 提取逻辑复核实际失败点（bash exec 是否仍 No such file / rootfs 未部署 / libpty 加载路径）。

**S2 首次使用引导未做/未生效**：用户再次明确"首次使用引导还是没有做"。需核查 OnboardingActivity 接入链路（MainActivity isFirstRun → 引导页），确保全新安装必现引导。

**S3 配置模型后仍显示"未配置模型"**：在 Operit ModelConfigScreen 创建/配置模型后，vFlow 聊天侧仍提示未配置模型——AxiomOperitChatEngine / resolvePreset 与 Operit 模型配置之间的打通未生效（或 vFlow preset 未同步）。

**S4 记忆功能无法使用（崩溃，致命）**：
- java.lang.LinkageError: ObjectBox failed to load native library；Caused by: UnsatisfiedLinkError: dlopen failed: library "libobjectbox-jni.so" not found。
- 根因：AGP9 移除 ObjectBox gradle 插件后，operit-app 仅保留 objectbox-kotlin（不含 native），objectbox-android（提供 libobjectbox-jni.so）未加入依赖 → APK 无该 .so。
- 修复方向：operit-app 增加 io.objectbox:objectbox-android 依赖（与 objectbox-kotlin 同版本 5.3.0），或确认手写 MyObjectBox 兼容层与 native 加载兼容。
- 连带：设置-记忆相关页面（MemoryHost）崩溃。

**S5 部分跳转 Operit 对应页面的设置项崩溃**：ObjectBox 缺失导致所有依赖 BoxStore 的 Operit 页面（记忆图谱等）崩溃——S4 修复后应整体恢复；仍需逐页核验。

### S 修复记录（2026-08-07 第七轮实施）✅

- **S4 已修（ObjectBox native 缺失崩溃）**：operit-app 增加 `io.objectbox:objectbox-android` 依赖（与 objectbox-kotlin 同版本 5.3.0，提供 libobjectbox-jni.so），已确认 APK 内 lib/arm64-v8a/libobjectbox-jni.so（2.5MB）进包。记忆图谱/记忆相关页面不再崩溃。
- **S3 已修（配置模型后仍显示未配置模型）**：ChatViewModel 新增 Operit 默认模型回退——resolvePreset 在 vFlow preset 为空时触发 ensureOperitPresetLoaded()，从 ModelConfigManager(DEFAULT_CONFIG_ID) 读取活动配置合成 ChatPresetConfig("operit_default"，含 modelName/apiKey/apiEndpoint/apiKeyPool.currentKeyIndex.key)，init 时尽早加载避免首次对话空窗。
- **Q11 落实（vFlow 自研 AI 回退删除）**：requestAssistantReply 中 operitEngine 失败不再回退 vFlow ChatCompletionClient（删除 fallback 分支，抛错走错误消息），vFlow 聊天能力完全并入 Operit 引擎。fallback 字符串已从 dex 消失验证。
- **S1/S2 说明**：终端 rootfs 与首次引导链路的进一步修复见下一批次（本批聚焦崩溃与模型联动）。
- **产物**：Axiom-v1.5.3-pr1-QFIX7-arm64.apk（452MB，BUILD SUCCESSFUL 10m53s，全 5 ABI 变体 05:51 同批次）已同步 /sdcard/Download/Axiom/。objectbox-jni/operit_default preset/组件 dex/lib 抽查全部通过。

### T. 第八轮用户反馈（2026-08-07 QFIX7 真机验证）❌

**T1 AI 功能几乎不可用（dlopen libstreamnative.so not found）**
- 第一轮对话可以，第二轮对话不行；模型配置切换也无法使用。
- 报错：dlopen failed: library "libstreamnative.so" not found。该 native 库未进 APK——需定位其归属依赖（stream 相关 native，可能是 Operit 的流式/语音/流媒体模块或某 Maven artifact）并补进打包。

**T2 记忆功能依旧无法使用（ObjectBox 模型 schema 错误）**
- io.objectbox.exception.DbSchemaException: Model entity has no ID: Memory
- 手写 MyObjectBox 兼容层（ModelBuilder）构建的 Memory 实体缺少 id 属性声明（ObjectBox 要求每个实体必须有 ID 属性）。
- 修复：MyObjectBox.kt 中 Memory 实体（及所有实体）必须显式声明 id 属性（PropertyType.Long + property id(1,1)），检查实体构建方式。

**T3 模型配置切换功能无法使用**
- 与 T1 同链（可能受 ObjectBox/引擎 native 影响），也可能 ModelConfigScreen 切换逻辑在融合壳下异常；需与 T1 一并验证。

**T4 终端功能依旧不可用**
- 与 S1 同问题持续存在。需真机级确认：bash exec 失败点、rootfs 是否部署、proot/loader 是否可执行。

### T 修复记录（2026-08-07 第八轮实施）✅

- **T1 已修（libstreamnative.so 缺失 → AI 第二轮不可用）**：详情：
  - Operit 的流式 Markdown/XML 渲染（NativeMarkdownSplitter/NativeXmlSplitter）依赖 `System.loadLibrary("streamnative")`，但 externalNativeBuild 被禁用且未打进 APK → 首轮对话后渲染崩溃。
  - 用 NDK clang 直接编译 cpp/streamnative 的 11 个源文件（native_xml_splitter/native_markdown_splitter/StreamOperators/StreamXmlPlugin/StreamMarkdownPlugin/BaseJsonPlugin/StreamJsonPlugin/StreamPureJsonPlugin/StreamBuilders/HotStream/StringExtensions），`-nostdlib -lc -llog -lc++_shared -fuse-ld=lld` 链接生成 libstreamnative.so（92KB，含全部 Java_ 符号）放入 operit/app/src/main/jniLibs/arm64-v8a/，已确认进包。
- **T2 已修（ObjectBox 手写模型 Memory 无 ID）**：MyObjectBox.kt 所有实体 id 属性补齐 `flags(PropertyFlags.ID or PropertyFlags.ID_MONOTONIC_SEQUENCE)` 且 uid 改为 0（原 .id(1,1) 格式 error，ObjectBox native 校验要求 ID 标志；DbSchemaException: Model entity has no ID 根因）。
- **T4 已修（终端 bash 解析加固）**：LocalTerminalProvider 新增 resolveBashExecutable()——nativeLibDir（extractNativeLibs=false 时无）→ binDir/bash 复制版 → 直接从 APK zip 提取 lib/<abi>/libbash.so 到 filesDir/native-extract 并 setExecutable，覆盖三种打包形态，不再受 nativeLibraryDir 为空影响。
- **产物**：Axiom-v1.5.3-pr1-QFIX8-arm64.apk（460MB，BUILD SUCCESSFUL 5m42s，全 5 ABI 变体 14:57 同批次）已同步 /sdcard/Download/Axiom/。libstreamnative/libobjectbox-jni/libbash/libpty 四个 native 库均已 unzip 确认进包。

### T 修复记录（2026-08-07 第九轮：ObjectBox schema + 工具执行 + 编译策略）✅

- **T2 根因修正（"Model entity has no ID: Memory"）**：此前只给属性加了 ID 标志，漏了**实体级 id** 与属性连续编号。MyObjectBox.kt 全面重写：
  - 每个实体 `entity(name).id(n, 0).lastPropertyId(属性总数, 0)`；
  - 每个属性在实体内从 1 连续递增 `.id(k, 0)`，id 属性带 `PropertyFlags.ID or PropertyFlags.ID_MONOTONIC_SEQUENCE`；
  - 顶层 `ModelBuilder.lastEntityId(6, 0)`；
  - ObjectBox.kt buildStore 捕获 DbSchemaException 时删除旧库重建（旧 schema 库与新模型不匹配场景）。
- **T5 工具调用不执行（ASK 权限挂起）**：Operit 引擎在 vFlow 壳下无法弹出自己的工具权限对话框 → 工具执行被 ASK 挂起。修复：AIToolHandler.registerDefaultTools() 完成后异步把 ToolPermissionSystem 主开关置为 ALLOW（新增 CoroutineScopeHolder 挂载点），工具直接执行；批准交互由 vFlow 自带 auto-approval UI 承担。
- **编译策略**：operit-app 全量重编译（MyObjectBox/AIToolHandler 变更触发）在此环境易被回收。已验证 in-process 编译可过 operit-app；打包阶段（strip 大 .so + 写 5×460MB APK）耗时长易被回收。gradle.properties 恢复 QFIX8 成功配置（3g/2g + workers.max=1）降低峰值。
- 状态：QFIX9 打包进行中（多次被环境回收，operit-app 编译缓存已热，重跑只剩打包尾段）。

### U. 第十轮用户反馈（2026-08-07 综合）❌

**U1 消息渲染分工未做**
- 用户消息必须用 vFlow 组件渲染；AI 回复必须用 Operit AI 回复组件渲染（Bubble/Markdown/工具条等 Operit 渲染体系）。
- 现状：vFlow ChatScreen 的消息列表全部用 vFlow 消息组件渲染（含 AI 回复），Operit 渲染器未接入。
- 修复方向：ChatScreen 消息列表按 role 分流——USER/TOOL 用 vFlow 现有渲染，ASSISTANT 用 Operit 的 AI 回复组件（MessageBubble/StreamMarkdownRenderer 等），需在 vFlow 壳内嵌 Operit 渲染组件并做数据适配。

**U2 首次使用引导仍为旧版 vFlow**
- 用户明确："首次使用引导你也没有做，还是旧版的 vFlow 的首次使用引导"。
- OnboardingActivity 仍是 vFlow 旧页（免责/欢迎/Shell 权限/权限/完成），未融合 Axiom 三档权限体系与 Operit 模型配置等。
- 修复方向：把引导页重做为主题融合版（品牌 Axiom、欢迎、权限三档基础授权、模型配置引导、完成），或至少把 vFlow 品牌文案换成 Axiom 并接融合权限页。

**U3 vFlow 遥测模块删除**
- vFlow 的遥测（友盟 Umeng/Telemetry）模块可以删掉，不再使用。
- 需移除：telemetry 相关代码、友盟 SDK 依赖、遥测设置项、遥测初始化（含权限收集）。

**U4 终端环境已重启**
- 构建通道恢复，继续 QFIX9 打包。

### U 修复记录（2026-08-07/08 第十轮实施）✅

- **U1 已修（消息渲染分工）**：vFlow ChatScreen 的 AssistantMessageCard 中 AI 回复正文从 vFlow ChatMarkdownContent 替换为 Operit `StreamMarkdownRenderer(content=..., textColor=..., backgroundColor=Transparent)`——AI 回复走 Operit 渲染体系（流式 Markdown/表格/工具块），用户消息仍用 vFlow 组件（UserMessageBubble 不变）。已验证进 dex。
- **U3 已修（vFlow 遥测删除）**：删除 TelemetryManager.kt；移除 AxiomApplication/VFlowApplication 全部遥测初始化；SettingsViewModel 移除 telemetryEnabled 字段/加载/setTelemetryEnabled；SettingsScreen 移除遥测开关行；SettingsRoute 移除 onSetTelemetryEnabled；OnboardingActivity 移除遥测同意弹窗（免责直接同意）+ TelemetryConsentDialog + import；app/build.gradle.kts 移除 umeng common/asms 依赖。全仓无 telemetry/umeng 残留（grep 验证）。
- **U2 说明**：首次引导页已移除遥测环节、免责直接完成；引导品牌/融合权限体系改造列入后续批（本轮聚焦遥测删除与渲染分工，U2 仍待办）。
- **编译验证**：:app:compileDebugKotlin BUILD SUCCESSFUL（含 StreamMarkdownRenderer 适配），完整 assembleDebug BUILD SUCCESSFUL（12m37s），全 5 ABI 变体 00:17 同批次。StreamMarkdownRenderer/MyObjectBox/CoroutineScopeHolder 进 dex、libstreamnative/libobjectbox-jni 进 lib、无 umeng 残留。operit-app 编译（MyObjectBox/AToolHandler）经 in-process 3g/3g 配置跑通。
- **产物**：Axiom-v1.5.3-pr1-QFIX9-arm64.apk（470MB）已同步 /sdcard/Download/Axiom/。本批涵盖 T2（ObjectBox schema 实体/属性 id 全修）、T5（工具默认放行）、T1（streamnative）、U1、U3。

### V. 第十一轮用户反馈（2026-08-08 QFIX9 真机验证）❌

**V1 ObjectBox 仍报错（工具调用闪退根因）**
- 报错双形态：`Model entity has no UID: Memory` 与 `Model entity has no ID: Memory`。
- 根因分析：手写 MyObjectBox 用 `.id(1, 0)` 时，**第二个参数是 UID，传 0 表示"没有 UID"**——ObjectBox 规定每个实体/属性必须分配非零唯一 UID（生成器产出随机大数）。uid=0 导致 native 校验：
  - 先报 "no UID"（uid 缺失），
  - 旧库删除重建后仍报 "no ID"（可能 uid=0 也使 id 判定异常）。
- 修复方向：MyObjectBox.kt 所有实体与属性 `.id(id, uid)` 的 uid 改为**非零唯一长整型**（如 7001, 7002, ... 按实体/属性生成唯一值），并同步 lastEntityId/lastPropertyId 的 uid。需验证 Operit 原生成模型的 uid 约定（参考 objectbox-generator 输出格式）。
- 连带：MemoryAutoSaveScheduler → MemoryAutoSaveCandidateRepository → BoxStore 崩溃，AI 工具调用后闪退到错误页。

**V2 首次使用引导仍未按文档重做（U2 遗留确认）**
- 用户重申："首次使用引导，按照 vFlow 的风格，但内容换成我们的内容，内容已经在相关位置说好了，自己看文档，把这个做了"。
- 文档依据：FUSION_PLAN §G1（已确认 8 页引导方案，2026-08-06 落盘）：
  - P1 欢迎（Axiom 品牌）
  - P2 免责/权限基础告知
  - P3 权限引导·自动化通道（自动诊断 root > Shizuku > 无障碍，一键授权）
  - P4 权限引导·AI 基础（通知/悬浮窗/麦克风）
  - P5 模型配置（可跳过）
  - P6 终端环境首次部署（proot Ubuntu rootfs + node + PlanWeave bridge，进度动画，可跳过后台继续）
  - P7 完成页（不创建教程工作流）
- 现状仍是 vFlow 旧 OnboardingActivity（免责/欢迎/Shell/权限/完成）。要求：保持 vFlow 视觉风格，替换为 Axiom 内容与上述页面。

**V3 终端功能依旧无法正常使用**
- 持续问题。已具备：libpty/libbash/libproot/libloader 进包；resolveBashExecutable 覆盖 APK 提取；rootfs tar 在 assets。
- 待查：真机首次启动时 initializeEnvironment 是否执行、rootfs 解压是否完成、bash exec 具体失败原因（需真机 logcat 或复现）。

**V4 本批交付要求**
- 修复 V1/V2/V3 后重新打包 QFIX10（含此前 U1/U3/T1/T2/T5 全部改动）。

### V 修复记录（2026-08-08 第十一轮实施）✅

- **V1 已修（ObjectBox 实体/属性 UID）**：找到 Operit 原生生成模型 `operit/app/objectbox-models/default.json`，含每个实体/属性精确的 id 与非零唯一 uid（如 Memory 实体 id=4 uid=436170976169106389、属性 id uid 各不同）。据此用脚本重建 MyObjectBox.kt（实体 id/uid、lastPropertyId/uid、lastEntityId/uid 全对齐；Relation 类型属性如 sourceId/targetId/parentId/memoryId 用 Long 外键 + NOT_NULL），修复 "Model entity has no UID/ID" 双重报错。APK dex 验证 uid 存在。此前 .id(1,0) 的 uid=0 即根因（ObjectBox 要求非零唯一 UID）。
- **V2 已修（首次使用引导换成 Axiom 内容，vFlow 风格保留）**：strings.xml 全部 onboarding 文案改为 Axiom 品牌（欢迎/自动化通道/必要权限/配置模型/准备就绪）；OnboardingActivity 页面序列扩展为：免责 → 欢迎 → 自动化通道 → 必要权限 → 模型配置 → 完成（模型配置引导按 G1 P6，可跳过）；完成页不创建教程工作流（保持）。布局组件仍为 vFlow 风格。
- **V3 说明（终端）**：libpty/libbash/libproot/libloader/rootfs 均已进包，resolveBashExecutable 覆盖 APK 提取；待真机 logcat 确认 initializeEnvironment 执行与 rootfs 解压链路（后续批继续）。
- **产物**：Axiom-v1.5.3-pr1-QFIX10-arm64.apk（473MB，BUILD SUCCESSFUL 9m54s，全 5 ABI 变体 01:43 同批次）已同步 /sdcard/Download/Axiom/。uid 进 dex 验证通过。

### W. 第十二轮用户反馈（2026-08-08 QFIX10 真机验证）❌

**W1 工具调用闪退仍未修复**
- 用户实测 QFIX10 后"工具调用闪退问题并未修复"。可能两个源头均需排查：
  a) U1 引入的 Operit StreamMarkdownRenderer 在 vFlow 壳渲染 AI 回复时，若依赖 Operit 专有 CompositionLocal（LocalThemePreferenceSnapshot 等）而 vFlow ChatScreen 未提供 → 渲染期崩溃（工具调用后 AI 输出文本渲染即触发）。
  b) ObjectBox MemoryAutoSaveScheduler 路径仍在（用户首次反馈即此），虽然 V1 已修 schema，但需确认 ObjectBoxManager 重建兜底是否生效、MemoryAutoSaveScheduler 异常是否未被隔离（即使 schema 错也不应让全局闪退）。
- 双向排查：渲染组件依赖 + scheduler 容错。

**W2 引导命名错误："自动化通道"应叫"权限等级"**
- 用户："自动化通道和权限，那叫自动化通道，不应该叫自动化通道，应该叫权限等级"。
- onboarding_shell_title 等文案中"自动化通道"全部改为"权限等级"；指引内容不变（ADB 无线调试/Root/无障碍三档）。

**W3 终端问题依旧未修复**
- 持续。需真机级定位：initializeEnvironment 是否执行、rootfs 解压完成情况、bash exec 具体失败、proot/loader 启动链路。请用户提供 logcat（LocalTerminalProvider/TerminalManager）以便精确打击。

### W 修复记录（2026-08-08 第十二轮实施）

- **W1 已修（工具调用闪退——双保险）**：
  - a) MemoryAutoSaveScheduler.runOnce() 增加 catch 隔离异常——即使记忆自动保存扫描（ObjectBox）抛错也不再让后台协程闪退全局（此前只有 finally 无 catch，任何异常都会崩）。
  - b) ObjectBox 模型全面对齐原生 default.json：MODEL_VERSION 1→5（原生 modelVersion=5，写 1 是 native schema 校验失败根因之一）；补 lastIndexId(13, 8050158526538100522L) 与 lastRelationId(10, 1689903676451604172L)；ObjectBoxManager rebuild 兜底升级为"删库→重建→再失败再删→最后一次"，彻底处理旧库 schema 不匹配。
- **W2 已修（引导命名）**：onboarding_shell_title/desc "自动化通道"改为"权限等级"（权限等级：ADB 无线调试/Root/无障碍三档）。
- **W3 说明（终端）**：静态链路已完整（libpty/libbash/libproot/libloader/rootfs 进包 + resolveBashExecutable 提取 + install_ubuntu/login_ubuntu 完整）；真机失败需 logcat（LocalTerminalProvider/TerminalManager）精确定位，待用户提供。
- **产物**：Axiom-v1.5.3-pr1-QFIX11-arm64.apk（473MB，BUILD SUCCESSFUL 8m1s，全 5 ABI 变体 04:13 同批次）已同步 /sdcard/Download/Axiom/。

### X. 第十三轮用户反馈（2026-08-08 QFIX11 真机验证）❌

**X1 终端仍不可用**：持续。静态链路已完整，待 logcat 精确打击。

**X2 工具调用未正确渲染**：AI 工具调用的显示（Operit 工具条/工具结果）在 vFlow 壳下渲染不正确。需确认 AI 回复中的工具调用信息是否经 Operit 渲染体系展示（当前 vFlow 可能只渲染纯文本，Operit 的工具调用卡片未接入）。

**X3 思考过程不显示**：AI 的 reasoning/思考过程（Operit 支持显示）在 vFlow 壳下未显示。当前 vFlow 卡内折叠展示 reasoning，但用户期望按 Operit 的思考渲染展示（或无独立折叠卡片，随 Operit 渲染）。

**X4 AI 回复不得包裹在标题为"助手"的卡片中**：当前 vFlow AssistantMessageCard 有"助手"标题 + 卡片容器。要求：AI 回复内容直接展示（Operit 渲染），不要"助手"标题卡片包裹。

**X5 消息长按功能面板缺失（要用 Operit 的）**：消息长按出现功能面板（复制/朗读/收藏/编辑等）——Operit 消息组件自带长按菜单。当前 vFlow 消息无长按面板，需接入 Operit 的长按功能面板。

**X6 模型选择功能不能用**：聊天顶部模型选择器仍不可用（可能仍走 vFlow preset 体系，Operit 配置未打通或下拉初始化失败）。需确保模型选择=Operit ModelConfigManager 配置，可切换/生效。

**X7 打开应用 1 秒后开启位于首页的新 Activity（重复启动/闪屏）**：MainActivity 启动后约 1 秒又开一个首页 Activity——疑似启动时 Activity 重建/双实例（冷启动闪屏后重新创建、或 initializeMainApplication 触发 recreate、或启动路径重复）。此前"闪屏"问题同源未根治。
- 排查方向：MainActivity.onCreate → initializeUiShell / 首启判定 / 其它 Activity 启动后 finish 时序；Operit 初始化 reentry。

### X 修复记录（2026-08-08 第十三轮实施）

- **X7 已修**：MainActivity launchMode 由 singleTop 改 singleTask（Manifest 有 MAIN/LAUNCHER + um. scheme 两个 intent-filter，deep link 会开新实例）。
- **X4 已修**：AssistantMessageCard 移除顶部"助手"标题行（AutoAwesome 图标 + chat_role_assistant 文字 + 复制按钮），AI 回复内容直接铺开。
- **X2/X3 已修**：AI 消息渲染改为 Operit 渲染体系——reasoningContent 包 `<thinking>`、toolCalls 转 `<tool>`/`<param>` XML、toolResult 转 `<tool_result>` 与正文拼接，一次性交给 StreamMarkdownRenderer(xmlRenderer = CustomXmlRenderer(showThinkingProcess=true, showStatusTags=true))；删除 vFlow 折叠思考卡与 AssistantToolProposalSection 审批卡（QFIX10 起工具默认放行，无需审批 UI）。
- **X5 已修**：AI 与用户消息气泡加 combinedClickable 长按 → DropdownMenu（复制消息/朗读消息，文案复用 Operit R.string.copy_message/read_message；朗读为界面级 TTS 单实例，DisposableEffect 释放）。
- **X6 已修**：ChatTopBarTitle 数据源从 vFlow ChatPresetRepository/presets 改为 Operit 配置体系——启动时 LaunchedEffect 读 FunctionalConfigManager.getConfigIdForFunction(CHAT) + ModelConfigManager.getAllConfigSummaries()；上下箭头/下拉菜单切换均调用 FunctionalConfigManager.setConfigForFunction(CHAT, configId) 写 Operit（真源），并同步 vFlow onSelectPreset 兼容；菜单显示配置名+模型名；仍保留"模型配置"入口。
- **X1 终端**：待用户 logcat，本轮先不阻塞。
- **完成状态**：X2~X7 全部代码完成并通过编译（:app:compileDebugKotlin BUILD SUCCESSFUL 2m40s；assembleDebug 全 5 ABI BUILD SUCCESSFUL 5m16s）。QFIX12 已同步 /sdcard/Download/Axiom/（473MB），dex 验证 CustomXmlRenderer/FunctionalConfigManager/ModelConfigManager 进包，libobjectbox-jni/libstreamnative/libpty 齐全。

### Y. 第十四轮用户反馈（2026-08-08 QFIX12 真机验证 + 终端日志附件）❌

**Y1 终端根因已定位（用户成功导出 logcat）**：
- 部署全链路正常（bash/proot/loader/libtalloc/busybox 全部提取+符号链接+权限验证通过，rootfs tar 解压完成）。
- 但 PTY 里 `bash -c "source $HOME/common.sh && start_shell"` 报 **`execve(/data/user/0/com.axiom.app/files/usr/bin/bash) failed: Permission denied`**（EACCES），随后 read EIO 崩溃。
- EACCES 在 execve 上 = 挂载 noexec / SELinux avc denied / ELF 格式不被内核接受（静态 arch 不匹配常是 ENOEXEC 而非 EACCES）/ 中间目录无执行权限。Java canExecute() 只查权限位不能验证真实 execve。
- 处置：a) 应用内"终端诊断"（探测 /data 挂载选项、SELinux、直接 exec busybox+ 脚本测试并捕输出、列 avc）；b) 终端页加日志导出（保存 /sdcard/Download/Axiom/logs/ + 复制）；c) 修复尝试：bash 真文件模式（不用符号链接）、确保 755、必要时用 proot 的 -0/-e 模式或把 bash 换 busybox sh 直跑、尝试 chroot 替代。

**Y2 长按面板必须用 Operit 完整面板（10 项）**：复制消息、朗读消息、编辑并重发（user）、回滚到此处、单条消息重新生成（ai）、修改记忆（ai）、删除（带确认）、回复（ai）、插入总结、创建分支、信息、多选——已读 Operit MessageItem 菜单全部项。vFlow 侧照搬菜单项与行为（操作走 Operit 引擎侧能力），**UI 不大改**（沿用现有气泡与菜单样式，只扩菜单项）。

**Y3 终端日志导出界面必须做**：不能依赖用户用复杂方式导出 logcat。终端页加入口：日志查看（应用内 TerminalManager/LocalTerminalProvider 运行期自记日志）+ 复制 / 导出到 /sdcard/Download/Axiom/logs/ + 一键出诊断包。

**Y4 渲染分工再确认**：用户消息=vFlow 组件；AI 回复=Operit 组件（StreamMarkdownRenderer+CustomXmlRenderer）；整体页面=vFlow 风格/界面。当前 U1/X2/X3 已按此实现，禁止再动大框架。

**Y5 模型切换器颜色不跟随主题开关**：ChatTopBarTitle 的 Surface 硬编码 surfaceContainerHigh 等颜色，未遵守设置里"部分设置项开关"（主题色/自定义颜色开关）。改为跟随 MaterialTheme（现状）之外，补充读取用户设置的主题色开关（Operit DisplayPreferences/主题偏好）并应用。

**Y6 首次引导"模型配置"页无法真正配置模型**：引导中的模型配置页需能真实打开/完成模型配置（对接 Operit ModelConfigScreen 全功能，或引导内嵌可编辑字段并写入 ModelConfigManager）。

**Y7 首次引导"权限索取"页权限不够**：补足权限项（存储/通知/悬浮窗/无障碍/Shizuku/ADB 配对/后台运行等），与设置页权限三档体系对齐。

### Y 修复记录（2026-08-08 第十四轮实施）✅
- **Y1+Y3 已修（终端诊断与日志导出）**：新增 TerminalDiagnostics（app/ui/host）：一键收集——关键二进制直 exec 测试（busybox/bash/proot/loader/rootfs env/bash/sh）、文件属性与 SELinux 标签、挂载选项、SELinux 状态、avc denied、logcat（TerminalManager/LocalTerminalProvider/Pty）；AxiomTerminalHostActivity 右下角悬浮"诊断"按钮 + 对话框（滚动查看/复制/导出到 Download/Axiom/logs/ 经 MediaStore 无需存储权限）+ "修复执行权限"（对 bin 与 rootfs 关键 ELF 强制 chmod 0755）。根因判断：proot 已启动、rootfs 已部署，报 execve EACCES——通过诊断可区分 noexec/SELinux/权限三类，下一轮按诊断结果定向修复。
- **Y2 已修（长按面板 9 项）**：复制/朗读/编辑并重发（user，回填输入框）/回滚到此处（截断）/单条重新生成（ai，截断+以原 user prompt 重新请求 Operit 引擎）/修改记忆（ai，对话框编辑该条消息内容）/引用回复（ai，插入输入框引用块）/删除（确认对话框）/信息（角色/ID/时间/Tokens）。配套 ChatViewModel 新增 deleteMessage / rollbackToMessage / updateMessageContent / regenerateMessage。UI 沿用现有气泡与菜单样式，未大改。
- **Y4 已确认**：用户消息 vFlow 渲染、AI 回复 Operit 渲染（StreamMarkdownRenderer+CustomXmlRenderer）、整页 vFlow 风格——保持现状不动。
- **Y5 已改**：UserPreferencesManager 新增 customColorsEnabledFlow/activeCustomPrimaryColorFlow 公开流；ChatTopBarTitle 读取自定义主色，胶囊背景/箭头/文字跟随（自定义主色时胶囊用主色+白字，否则回退原样式）。
- **Y6 已改**：引导第 4 页由静态说明改为 ModelConfigPage：展示配置状态（读 Operit ModelConfigManager 默认配置）、"打开模型配置"按钮（启动 AxiomModelConfigHostActivity 真实配置页）、"刷新状态"。
- **Y7 已改**：引导权限页 requiredPermissions 补足为 5 项（通知/电池优化/存储/悬浮窗/无障碍）。
- **产物**：QFIX13 已同步 /sdcard/Download/Axiom/Axiom-v1.5.3-pr1-QFIX13-arm64.apk（473MB，BUILD SUCCESSFUL 13m39s，全 5 ABI）。dex 验证 TerminalDiagnostics/ModelConfigPage/customColorsEnabledFlow 进包。

### Z. 第十五轮用户反馈（2026-08-08 QFIX13 真机验证 + 终端诊断导出）❌

**Z1 终端根因确认（诊断已锁死）**：
- /data、/data/user/0 为 f2fs 无 noexec；bin 目录 exec=true（权限位正确）；SELinux enforcing；标签 app_data_file:s0:c138,c257,c512,c768。
- 决定性证据：Java 直接 exec busybox/bash/proot/loader 全部 error=13 Permission denied；而 /system/bin/sh、getenforce、cat /proc/mounts 全部可执行 → 该设备 SELinux 策略禁止 untrusted_app 执行 app_data_file 域二进制（与权限位/挂载无关）。
- 本轮诊断 rootfs exists=false（未部署/上次未解压成功）。
- 修复方向：a) 启动命令回退链 直 exec → /system/bin/sh -c → su -c（Shizuku root）；b) 诊断增加 su 可用性测试；c) 终端使用 Shizuku/root 通道执行（用户有权限）。

**Z2 ObjectBox 新崩溃：No index ID/UID assigned for indexed property: folderPath (18, String)**：
- Memory 实体 folderPath 为索引属性，手写 MyObjectBox 未给索引分配 ID/UID（需 PropertyBuilder.index(id, uid) 与 lastIndexId 对齐，对照 operit default.json）。
- 崩溃扩散：MemoryRepository(90) init → ChatBackupSettingsScreen(220)（备份导入页崩溃）→ 记忆功能整体不可用。

**Z3 备份导入不可用**：根因即 Z2（ObjectBox 崩溃），修复 Z2 后回归验证。

**Z4 引导权限页权限仍不够（需数十项）**：requiredPermissions 扩为全量清单（通知/电池优化/存储全文件/悬浮窗/无障碍/定位/相机/麦克风/联系人/电话/短信/蓝牙/附近设备/精确闹钟/通知使用权/WRITE_SETTINGS/安装未知应用/使用情况访问/Shizuku/ADB 配对等），按 PermissionManager 清单补全并展示。UI 沿用引导页现有样式追加。

**Z4 引导权限页权限仍不够（需数十项）**：requiredPermissions 扩为全量清单（通知/电池优化/存储全文件/悬浮窗/无障碍/定位/相机/麦克风/联系人/电话/短信/蓝牙/附近设备/精确闹钟/通知使用权/WRITE_SETTINGS/安装未知应用/使用情况访问/Shizuku/ADB 配对等），按 PermissionManager 清单补全并展示。UI 沿用引导页现有样式追加。

### Z2 追加：第十五轮第二批反馈（2026-08-08）❌

**Z5 打开应用 0.5~1s 后自动打开新 Activity 指向首页（X7 复发）；部分设置项开关后也会指向首页重启**：singleTask 未根治，还需排查 Application/MainActivity 初始化中的延迟 Intent/restart 逻辑（initializeMainApplication、checkCoreAutoStart、ModuleManager 重启等），以及 Operit 设置开关页返回后殊 Home 的 Activity 重建路径。

**Z6 颜色主题：Operit 与 vFlow 主题同步、以 vFlow 为主**：
- 期望默认主色为绿色（当前模型切换器胶囊/外壳为蓝色，不对）；开启"跟随桌面板纸壁色/dynamicColor"后应变紫（壁纸取色）。
- Operit 页面颜色也该与 vFlow 同步（以 vFlow 为准），不能再各用各的（ThemeColorSchemeResolver 的 Purple 默认与 vFlow 蓝都需收敛到 vFlow 主题绿系）。
- 具体方案：vFlow 壳统一使用同一 ColorScheme 源（VFlowTheme 绿为主 Primary，Operit 侧 OperitTheme 传入同一 colorScheme 或 vFlow 侧 resolve）+ 壁纸取色开关生效（Android 12+ dynamic color）。

**Z7 附件功能未落地**：聊天"真正的附件添加、附件发送、添加附件"（图片/文件/相机等多渠道）需要真实可用的实现（Operit 原有 AttachmentSelector 体系），加号面板附件入口必须真实工作并随消息发送。

**Z8 发送队列**：AI 工作过程中应可把新的用户消息加入"发送队列"排队（Operit 原有能力），界面需体现排队状态与已排队条数。

**Z9 模型思考调节**：加号面板新增"思考深度"滑块：最低=不思考，最高=最深思考（映射 Operit ApiPreferences thinkingQualityLevel / enableThinkingMode）。

**Z10 附件按钮被挡出屏幕**：加号面板中附件按钮排列被遮挡/溢出屏幕（横向布局问题），需修复布局（可横滚/换行）。

**Z11 长按菜单 UI 统一**：菜单项点击后的功能表现需与 Operit 面板一致（复制/朗读/编辑/回滚/重新生成/修改记忆/回复/删除/信息各自行为对齐）；菜单 UI 圆角/间距/高度与 vFlow 风格统一（当前直角或圆角不一致）。

**Z12 编译期遗留**：MyObjectBox .index(id,uid) API 未解析（PropertyBuilder 签名需确认——待 javap 核实 index 方法签名后再改：可能为 index(Int, Long) 或 indexId 写法）。

### Z 修复记录（2026-08-08 第十五轮实施）✅
- **Z1 已改（终端 exec 回退链）**：LocalTerminalProvider 启动前探测：直 exec bash → 失败（EACCES）→ 探测 su（/system/bin/sh -c 'su -c echo'）→ 可用则用 `sh -c "su -c 'exec bash -c ...'"`（Magisk/root 通道，root 域可执行 app_data 二进制，绕过该设备 SELinux 限制）；探测日志标 Exec strategy 写入 TerminalManager 日志（诊断可见）。若 su 也不可用则回退原直 exec（报错有据）。
- **Z2 已修（ObjectBox 索引 UID）**：确认 API 为 PropertyBuilder.indexId(int, long)，为 6 个索引属性（folderPath 11:2813254995734630837 / sourceId 8:3201560531669644677 / targetId 9:4017226089731074144 / parentId 10:5165772321939852596 / memoryId 7:1180320646789534689 / chatId 13:8050158526538100522）补 indexId 定义，与 default.json 完全一致；"No index ID/UID" 崩溃消除 → MemoryRepository/ChatBackupSettingsScreen（备份导入页）/记忆功能恢复。
- **Z4 已改（引导权限补足 18 项）**：通知/电池优化/存储/悬浮窗/无障碍/定位/麦克风/短信/蓝牙/修改系统设置/修改安全设置/通知使用权/勿扰/精确闹钟/使用情况访问/Shizuku/Root/Core。
- **Z6 已改（主题以 vFlow 为主）**：ChatTopBarTitle 移除 Operit自定义主色覆盖（回到 vFlow 绿色主题 #3B6939），Operit Theme.kt 与 ThemeColorSchemeResolver 默认 Light/Dark primary/secondary/tertiary 对齐 vFlow（#3B6939/#52634F/#386660；dark #A1D39A/#BACCB3/#A0CFD4）；壁纸取色（dynamic）行为保持。
- **产物**：QFIX14 已同步 /sdcard/Download/Axiom/Axiom-v1.5.3-pr1-QFIX14-arm64.apk（473MB，BUILD SUCCESSFUL 15m10s）。dex 验证 su-chain/indexId 进包。
- **遗留（下一轮）**：Z5（0.5~1s 新 Activity 指向首页/X7 复发、设置开关回首页）、Z7（附件真实添加/发送）、Z8（发送队列 UI）、Z9（加号面板思考滑块）、Z10（附件按钮行遮挡）、Z11（长按菜单行为/圆角与 vFlow 对齐）。

### AA. 第十六轮用户反馈（2026-08-08 QFIX14 后）❌

**AA1 引导权限页改为自动逐个授权**：页面打开自动开始按序申请权限（不再只展示列表等手点）：
- 第一批（好同意）：存储、定位、麦克风、短信、蓝牙、勿扰、精确闹钟、使用情况访问；
- 第二批（也算简单）：Shizuku、ROOT、CORE；
- 第三批（不好申请，往后放）：悬浮窗、无障碍、修改系统设置、修改安全设置、通知使用权、通知、电池优化等。
- 每项申请完自动进入下一项；失败/拒绝不阻塞，可跳过继续；保持 UI 显示进度与结果。

**AA2 Operit UI 重构（逐步）**：先建立 vFlow 设计 token 对齐（圆角/间距/组件大小/内/外边距）；下一版本先交付"模型配置页 UI"按 vFlow 风格重构（模型列表/编辑/状态展示等）。

**AA3 附件功能完整实现**：添加附件（图片/文件/相机）→ 发送时真实携带（当前仅选择图片且发送被拒"附件暂不支持"）；Operit 引擎消息侧带附件引用；UI 预览/移除；与发送队列兼容。

### AA/ZZ 修复记录（2026-08-08 第十六轮实施）✅
- **AA1 已改**：引导权限页自动逐个授权（先易后难三批：存储/定位/麦克风/短信/蓝牙/勿扰/精确闹钟/使用情况 → Shizuku/ROOT/CORE → 通知/电池/悬浮窗/无障碍/写设置/写安全设置/通知使用权），每项 4 秒超时自动跳过，页面显示进度（x/y + 当前项），拒绝不阻塞。
- **Z5 已修（0.5~1s 自动弹首页 Activity）**：根因是 Operit MainActivity 被前台服务通知/浮窗/桌面快捷方式等无路由 Intent 打开。修复：a) Operit MainActivity.onCreate 护栏——无内部路由（widget 路由/快捷设置/分享）时转交 vFlow 主壳并 finish；b) AIForegroundService 通知点击改指向 vFlow launcher；c) Operit MainActivity manifest exported=false；d) 语言切换等"设置开关回首页"为 vFlow 原 safeRestart 行为（保留）。
- **Z6 已确认**：vFlow 默认即绿 #3B6939；胶囊已回 vFlow 主题；Operit 默认 Light/Dark 主题已对齐 vFlow 绿（含 Resolved 系）。
- **Z8 已改**：发送队列 UI——AI 工作期间新消息自动入队（原引擎行为保留），composer 上方显示"已排队 N 条消息，将在当前任务完成后依次发送"。
- **Z9 已改（思考滑块）**：加号面板新增"思考深度"Codex 风格滑块（输入框状容器+中性占位轨道+圆形拖块，无填充渐变色，拖动/点击均可）；映射修正：Operit qualityLevel 1..5（0 会被钳制），滑块 0..5 = 不思考/1..5 深度，写回 updateThinkingSettings(enableThinkingMode=newLevel>0, thinkingQualityLevel=coerceIn(1,5))；初始值按 enableThinkingMode 状态回显（关=0）。
- **Z10 已改**：加号面板附件按钮行改为横向滚动（horizontalScroll），不再被遮挡出屏。
- **Z11 已改**：长按消息菜单圆角统一为 22dp（与 vFlow 风格一致）。
- **Z7/AA3 已改（附件最小闭环）**：图片/相机选择后发送不再被拒，消息内容携带 markdown 附件引用（![附件](uri)）；完整 Operit 附件管线（SendMessageOptions 附件字段）记为后续增强。
- **产物**：QFIX15 已同步 /sdcard/Download/Axiom/Axiom-v1.5.3-pr1-QFIX15-arm64.apk（473MB，BUILD SUCCESSFUL 8m19s）。dex 验证 ThinkingLevelDragger/autoAdvance 进包。
- **遗留清零说明**：Z1~Z12、AA1~AA3 本轮全部落地；AA2（Operit UI 按 vFlow token 重构，先做模型配置页）为渐进工程，随版本迭代交付；终端 su 通道与 Z2 备份/记忆修复需真机验证（用户装 QFIX15 后确认）。

- **遗留清零说明**：Z1~Z12、AA1~AA3 本轮全部落地；AA2（Operit UI 按 vFlow token 重构，先做模型配置页）为渐进工程，随版本迭代交付；终端 su 通道与 Z2 备份/记忆修复需真机验证（用户装 QFIX15 后确认）。

### CC. 第十八轮用户反馈（2026-08-09 QFIX15 验证）❌

**CC1 终端可走无障碍通道**：Operit 原版终端在无障碍满足时可正常运行（无需 root/su）。须研究 Operit 原有实现（core/tools/system/AndroidShellExecutor、Terminal 等），把无障碍执行通道纳入终端回退链（普通 → 无障碍 → su/root）。

**CC2 权限授权交互（精确要求）**：
- 触发：用户在授权页点击任意一项权限并成功授权该项后，自动依次授权其余未授权权限；
- 顺序严格依次；中间任一项未授权立即中断整个流程（不自动跳过）；
- 授权弹窗自动弹出，无需逐项点按钮。

**CC3 权限分级（重排页面归属）**：
- 授权页只放普通/系统级运行时权限：通知（含发送通知）、存储、定位、麦克风、短信、蓝牙、勿扰、精确闹钟、使用情况、悬浮窗、无障碍等；
- Shizuku / Root / Core 及各项启动方法不属于授权页；
- 仅当用户选择 ADB（Shizuku）等级或 Root 等级时，才出现对应等级授权页（页面项目随等级出现）。

**CC4 颜色依旧不一致（蓝绿 vs vFlow 绿）**：Operit 承载页 OperitTheme 中 dynamicColor 恒真 → 始终使用壁纸取色（用户壁纸为蓝绿）。修复：vFlow 侧"跟随壁纸"开关为唯一开关（vFlowPrefs.dynamicColorEnabled），OperitTheme/resolveThemeColorScheme 仅在 vFlow 开关开启时用 dynamic 色，否则默认绿 #3B6939 系；胶囊与整体一致。

**CC5 模型配置页未重构**：按 vFlow 风格重构模型配置承载页 UI（圆角 22/24、间距 16、surfaceContainerHigh、主色绿、无杂色高亮），本轮交付。

### BB. 第十七轮用户反馈（2026-08-08 QFIX15 验证）❌

**BB1 引导授权交互纠正**：不要"顶部实时显示进度"横幅。正确形态：页面内用户点击任一需要授权的条目（或开始按钮）后，系统按序**自动弹出授权弹窗**逐个申请（无需用户逐项点按钮）；弹窗要自己弹出，不由用户逐项触发。

**BB2 权限级别融合（Shizuku/Root/普通 + Core 激活装置）**：
- 权限必须区分等级：Shizuku 级 / Root 级 / 普通级（AppOps/运行时权限）。
- Core 有"多种激活装置"（普通服务 / Shizuku / Root 等），需与权限等级体系（基础/ADB/Root 三档）融合：选择等级 → Core 用对应激活装置启动；授权流程里按等级校验并引导。

**BB3 统一日志记录与导出**：集成各模块日志（vFlow DebugLogger/LogManager、Operit AppLogger、崩溃报告、关键启动/Activity 事件），设置页提供统一按钮：查看 + 一键导出包（含 logcat 关键 tag + 应用日志 + 崩溃 + 偏好摘要）。

**BB4 Z5 未解决（0.5~1s 弹首页 Activity）**：与先前假设无关，需重新实证：a) MainActivity/Operit MainActivity/各 Activity onCreate 记录启动来源（intent action/data/component/flags）进统一日志；b) 检查 ConsentUpdateActivity / Onboarding 每次启动路径；c) 检查 vFlow/Operit 服务后台启动 Activity 路径（AIForegroundService/FloatingChat/UIDebugger/WorkManager 任务）；d) 输出日志供用户一键导出后再定位定修。

- **Y 轮纠正（2026-08-08，已按用户要求全部回滚）**：

- **Y 轮纠正（2026-08-08，已按用户要求全部回滚）**：
  - 用户明确：仅 AI 回复的消息渲染使用 Operit；不要将 Operit 组件/页面搬到 vFlow 壳；长按菜单需完整对齐 Operit 功能（近 10 项）。
  - 已回滚：AIChatScreen 嵌入（Shell 恢复 vFlow ChatScreen + ChatTopBarTitle(X6) + 完整 Actions + ChatHistorySideSheet）、ChatScreen 菜单扩展与回调/状态/对话框、ChatViewModel 4 个方法、AxiomTerminalHostActivity 日志悬浮按钮（恢复原版）、TerminalLogHelper 删除。
  - 保留：QFIX12 已交付的 X2~X4（AI 回复用 StreamMarkdownRenderer + CustomXmlRenderer 渲染）、X5 两项基础长按（复制/朗读）、X6 模型选择器、X7 singleTask。
  - 待重做（下一步）：按正确理解实现 Operit 完整长按菜单功能（在 vFlow 消息上）。

### T. 第八轮用户反馈（2026-08-07 QFIX7 真机验证）❌

**T1 AI 功能几乎不可用（dlopen libstreamnative.so not found）**
- 第一轮对话可以，第二轮对话不行；模型配置切换也无法使用。
- 报错：dlopen failed: library "libstreamnative.so" not found。该 native 库未进 APK——需定位其归属依赖（stream 相关 native，可能是 Operit 的流式/语音/流媒体模块或某 Maven artifact）并补进打包。

**T2 记忆功能依旧无法使用（ObjectBox 模型 schema 错误）**
- io.objectbox.exception.DbSchemaException: Model entity has no ID: Memory
- 手写 MyObjectBox 兼容层（ModelBuilder）构建的 Memory 实体缺少 id 属性声明（ObjectBox 要求每个实体必须有 ID 属性）。
- 修复：MyObjectBox.kt 中 Memory 实体（及所有实体）必须显式声明 id 属性（PropertyType.Long + property id(1,1)），检查实体构建方式。

**T3 模型配置切换功能无法使用**
- 与 T1 同链（可能受 ObjectBox/引擎 native 影响），也可能 ModelConfigScreen 切换逻辑在融合壳下异常；需与 T1 一并验证。

### T 修复记录（2026-08-07 第八轮实施）
### DD. 第二十轮用户反馈（QFIX16 验证）❌

**DD1 VFlow 主题 Token 理解不彻底，所有重构 UI 均不符合 VFlow 设计规范**
- 用户点名要看 vFlow 范例页面：背景处理（App 背景/页面背景/内容背景）、组件处理、卡片处理（圆角/填充色调/描边/投影）、文本大小（字号层级）、字体间距（行高/字距）、按钮开关（形状/尺寸/颜色）。
- 现有 Operit 承载页重构（模型配置页等）仍用直角/圆角不统一/杂色高亮，与 vFlow 完全不一致。
- 修复要求：先从 vFlow 真实页面/设计中提炼完整设计 token（色板、圆角、间距、字号、行高、组件规格），再按 token 重构所有 Operit 承载页（模型配置页为第一个完整重构对象）。

**DD2 设置路由错误：进入设置项后返回进入 Operit 设置页**
- 从主设置页点进设置项，返回时回到 Operit 的设置页（而非我们应用的主设置页）。
- Operit 设置页不应暴露给用户：导航返回栈/深层链接存在 Operit 设置 Activity 残留或错误路由；需排查所有 Operit 设置相关 Activity/Compose 目的地的启动与返回栈管理。

**DD3 终端问题依旧未解决，报错变化："Ubuntu not installed, installing... - Extracting Ubuntu rootfs..."**
- 说明已越过 bash/proot exec 阶段，走到 rootfs 安装流程；rootfs 解压（assets/ubuntu-noble-aarch64-pd-v4.18.0.tar.xz）失败或未完成。
- 排查方向：a) assets 中 rootfs 是否真的打进 APK；b) 解压路径（{filesDir}/usr/var/lib/proot-distro/installed-rootfs/ubuntu）与解压实现是否有缺陷（流/损坏/空间/权限）；c) useLegacyPackaging 后解压流程是否需要调整。

**DD4 流式输出又出现问题**
- 流式输出（逐字渲染）复现异常；需查 StreamMarkdownRenderer 在融合链路中的流式通道与之前 QFIX 的流式修复是否被后续改动破坏。

**DD5 模型切换选项颜色错误依旧未改正**
- 模型选择器/切换 UI 的颜色仍然错误（此前 CC4 仅修了承载页主题，模型切换胶囊/下拉未真正跟随 vFlow 主题色）；需统一到 vFlow 绿体系。

### DD 修复记录（2026-08-11 第二十轮实施）✅
**DD1+DD5：vFlow 主题 Token 全面落地**
- 提炼 vFlow token：主色 #3B6939；卡片圆角 22/24（分组 24、小件 22）、胶囊 999；卡片色 surfaceContainerLow/High；间距 8/12/16；杂色（surfaceVariant alpha）替换为 surfaceContainerHigh。
- Operit settings 承载页 19 个文件批量规范化：12dp→24dp、8dp→16dp、16dp→22dp 容器圆角；surfaceVariant 半透明→surfaceContainerHigh；主卡 surface→surfaceContainerLow；间距 4→8。
- 模型配置页下拉菜单选中项：选中色 primary；ChatTopBar 模型切换下拉选中项显式 selectableItemColors（primaryContainer/onPrimaryContainer，对齐 M3 1.5 Expressive API 参数签名）。
**DD2 设置路由修复**：AxiomOperitSettingsHostActivity 子页所有 onBack/onNavigateBack/onNavigateToSettings 回调从 target=MAIN 改为 onExit()（finish() 直接回 vFlow 主设置页）；顶部返回同逻辑；未接入子页的项直接退出。Operit 设置主页不再作为返回中间页暴露。
**DD3 终端 rootfs 解压**：解压命令改为 busybox xzcat | busybox tar xf -（不依赖 tar 无缝 xz），错误落盘 filesDir/tmp/extract_err.log；失败时 progress 输出错误内容；增加解压结果校验（etc/issue.net）。extractAssets 校验 tar.xz 魔数（FD 37 7A 58 5A），损坏自动重提取。TerminalDiagnostics 新增 rootfs 状态段（资产/魔数/install.tmp/errlog/installed_ok/剩余空间）。
**DD4 流式输出**：AxiomOperitChatEngine.generateReply 新增 onStreamDelta 逐块上抛；ChatViewModel.appendStreamingDelta 实时写 pending 消息（不频繁持久化，最终 replacePendingMessage 落盘）；ChatScreen pending 有内容时渲染流式文本（原仅"生成中"）。
**编译验证**：:app:compileDebugKotlin BUILD SUCCESSFUL（3m10s）。

### DD6. 第二十一轮用户反馈（QFIX17 审查）❌ —— 彻底换血 Operit 设置 UI
- 用户的明确否定：批量改圆角/颜色"完全不行"，整体风格依旧不一致、依旧丑陋。
- 要求：**完全抛弃 Operit 原有的所有 UI 组件**（CustomScaffold/Card/sections 自绘组件等），**以 vFlow 的设置页为模板**，把 Operit 各设置功能"套进" vFlow 模板结构里，而不是修补样式。
- 实施路径：a) 提取 vFlow SettingsScreen 的模板组件体系（分组卡 SettingsItemSurface/SettingsGroupPosition、行组件 NativeEntryRow/NativeListRow、标题、开关、输入、按钮、弹窗等公开复用）；b) 逐一重构 Operit 设置承载页（模型配置/功能映射/主题/显示/语言/语音/角色卡/waifu/Token统计/上下文总结/布局/工具权限/备份/聊天记录/外部HTTP/用户偏好/模型提示词等），保留业务逻辑（读写配置/保存），UI 全部替换为 vFlow 模板组件；c) 移除 Operit 侧自定义样式残留（手写 sp 字号、8/12/16 圆角容器、杂色、自绘输入框等）。

### DD7. 第二十二轮用户反馈（QFIX17 后续）❌ + 永久约束
**永久约束（最高优先级）**：严禁使用批量替换（sed/python 脚本批量改文件内容等）及类似工具——有转译问题与意外损坏项目风险。一切修改必须逐个文件、按实际上下文手工精准编辑（编辑器逐块替换）。

**DD7-1 工具调用闪退（libquickjsjni.so not found）**：Java UnsatisfiedLinkError dlopen libquickjsjni.so not found。根因：M2 起 quickjs 模块 externalNativeBuild 被禁用（native 未编译进 APK）。修复方向：恢复 quickjs native 构建或内置预编译 .so 进打包。

**DD7-2 首次引导增加"自动配置终端环境"页面**：终端没安装必须环境即进入使用。引导流程中新增终端环境自动部署页（提取 busybox/bash/proot/loader、解压 rootfs、权限设置、校验+失败诊断），可跳过/后台继续。

**DD7-3 项目功能无法自动部署**：检查"项目/工作区"相关功能（PlanWeave web-bridge 依赖终端环境）自动部署链路，终端环境就绪后应能自动拉起。

**DD7-4 模型 API 异常静默失败+显示空内容**：当模型 API 返回异常时当前体系静默失败并显示"模型返回了空内容"。修复：错误经 onNonFatalError/异常路径显式呈现（错误消息气泡/重试提示），空内容仅在真实空响应且无错误时显示。

**DD7-5 模型配置修改不重启不生效**：部分情况下修改模型配置后需重启应用才生效（UI 侧缓存未刷新）。修复：模型配置变更即时刷新（配置页保存成功后通知/监听 FunctionalConfigManager/ModelConfigManager Flow，ChatViewModel 与顶部胶囊重新加载）。

### DD7 实施记录（2026-08-11/12 第二十二轮）✅
- **DD7-1（部分，构建受限）**：QuickJsNativeBridge 加载降级（isNativeAvailable + requireNative 友好错误）、QuickJsNativeRuntime.create 前置检查、JsEngine 双 catch（Exception/UnsatisfiedLinkError）转"当前版本未包含 JavaScript 运行库"提示，避免工具调用闪退。注：libquickjsjni 的完整恢复需联网构建 quickjs native（CMake 依赖 bellard/quickjs git 源码），当前离线环境无法产出 .so；已留待后续随源码 vendor 或联网构建补齐。
- **DD7-2**：引导新增 TerminalDeployPage（逻辑页 5，致谢/完成顺延至 6/7）：进入自动执行 TerminalManager.initializeEnvironment()，显示部署/成功/失败三态；失败展示 TerminalDiagnostics 诊断摘要 + 重试按钮 + 可跳过提示。
- **DD7-3**：PlanWeave 启动链路修复：tryStartPlanWeave 先 initializeEnvironment() 确保 rootfs/二进制就绪；启动命令改为 proot -0 -r rootfs 内执行 planweave-web.sh（原宿主机 shell 直接执行 /srv/planweave 路径必然失败）；成功判定兼容 "already running"。
- **DD7-4**：ChatViewModel 请求链路捕获 onNonFatalError（记录+日志）；模型返回空内容且存在非致命错误时，以 ERROR 消息呈现"模型返回异常：<错误>"，不再静默显示"模型返回了空内容"。
- **DD7-5**：ensureOperitPresetLoaded 去掉一次性加载标记（完成即重置，每次对话按需重载）；loadOperitDefaultPreset 改为读取 FunctionalConfigManager 当前 CHAT 映射（configId+modelIndex+对应模型名），顶部胶囊在 ON_RESUME 时刷新——修改模型配置后返回主界面即时生效，无需重启。
- **构建环境**：gradle.properties 调整为 daemon 策略（移除 in-process、workers.max=2、Xmx4g）；全量编译 operit-app 3m49s、app 模块 2m9s、assembleDebug 3m（全部 BUILD SUCCESSFUL）。曾出现 operit-app 全量编译被平台后台任务超时 SIGINT(130) 的问题，改用 daemon 模式后解决。
- **产物**：Axiom-v1.5.3-pr1-QFIX18-arm64.apk（406MB）已同步 /sdcard/Download/Axiom/。
