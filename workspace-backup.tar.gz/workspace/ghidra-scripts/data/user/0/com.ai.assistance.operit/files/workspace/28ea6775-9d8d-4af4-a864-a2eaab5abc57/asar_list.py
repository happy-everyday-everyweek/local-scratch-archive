import sys, struct, json
p = sys.argv[1]
with open(p, 'rb') as f:
    first = f.read(4)
    hs = struct.unpack('<I', f.read(4))[0]
    hdr = f.read(hs)
print('first', struct.unpack('<I', first)[0], 'header_pickle_len', hs)
print('hdr[:16]', hdr[:16].hex())
js = struct.unpack('<I', hdr[4:8])[0]
print('json_len', js)
j = json.loads(hdr[8:8 + js].decode('utf-8', 'replace'))
base = (8 + hs + 3) // 4 * 4
print('base', base)
files = []


def walk(node, prefix=''):
    for name, v in node.get('files', {}).items():
        path = prefix + '/' + name
        if 'files' in v:
            walk(v, path)
        else:
            files.append((v.get('size', 0), path, v.get('offset')))


walk(j)
files.sort(reverse=True)
print('TOTAL_FILES', len(files))
print('--- TOP 30 ---')
for s, pa, o in files[:30]:
    print(s, pa)
