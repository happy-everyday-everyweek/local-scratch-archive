import sys, struct, json, os

asar = sys.argv[1]
mode = sys.argv[2]

with open(asar, 'rb') as f:
    f.read(4)
    hs = struct.unpack('<I', f.read(4))[0]
    hdr = f.read(hs)
js_len = struct.unpack('<I', hdr[4:8])[0]
root = json.loads(hdr[8:8 + js_len].decode('utf-8', 'replace'))
base = (8 + hs + 3) // 4 * 4
idx = {}


def walk(node, prefix=''):
    for name, v in node.get('files', {}).items():
        p = prefix + '/' + name
        if 'files' in v:
            walk(v, p)
        else:
            idx[p] = (int(v.get('offset', 0)), int(v.get('size', 0)))


walk(root)
src = open(asar, 'rb')

if mode == 'cat':
    target = sys.argv[3]
    off, size = idx[target]
    src.seek(base + off)
    sys.stdout.buffer.write(src.read(size))
elif mode == 'save':
    target, out = sys.argv[3], sys.argv[4]
    off, size = idx[target]
    src.seek(base + off)
    os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
    with open(out, 'wb') as g:
        g.write(src.read(size))
    print('saved', target, size, '->', out)
elif mode == 'grep':
    kw = sys.argv[3].lower()
    n = 0
    for p, (off, size) in idx.items():
        if size == 0 or size > 3_000_000:
            continue
        src.seek(base + off)
        b = src.read(size)
        if kw.encode() in b.lower():
            print(size, p)
            n += 1
    print('matches', n)
elif mode == 'ls':
    for p, (off, size) in sorted(idx.items()):
        print(size, p)
