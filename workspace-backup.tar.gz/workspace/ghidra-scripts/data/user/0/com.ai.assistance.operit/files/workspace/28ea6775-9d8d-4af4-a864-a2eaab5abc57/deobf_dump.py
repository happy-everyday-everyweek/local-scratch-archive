import re, sys, base64, os

path = sys.argv[1]
outdir = sys.argv[2]
os.makedirs(outdir, exist_ok=True)
data = open(path, 'r', encoding='utf-8', errors='replace').read()
calls = re.findall(r'_\$d\("([A-Za-z0-9+/=]{4,400})"\)', data)


def dec(s, k='wnWOOEYHZLPw'):
    try:
        b = bytearray(base64.b64decode(s + '=' * (-len(s) % 4)))
    except Exception:
        return None
    for i in range(len(b)):
        b[i] ^= ord(k[i % len(k)])
    try:
        return b.decode('utf-8')
    except Exception:
        return None


seen = {}
for c in calls:
    v = dec(c)
    if v is not None:
        seen[v] = seen.get(v, 0) + 1
vals = sorted(seen)

with open(os.path.join(outdir, 'strings_all.txt'), 'w', encoding='utf-8') as f:
    for v in vals:
        f.write(v.replace('\n', '\\n') + '\n')
print('dumped', len(vals))

urls = sorted(set(re.findall(r'https?://[^\s"\'`\\)\]\\]+', ' '.join(vals))))
with open(os.path.join(outdir, 'urls.txt'), 'w', encoding='utf-8') as f:
    f.write('\n'.join(urls))
print('urls', len(urls))

longv = [v for v in vals if len(v) >= 200]
with open(os.path.join(outdir, 'long_text.txt'), 'w', encoding='utf-8') as f:
    for v in longv:
        f.write(v.replace('\n', '\\n') + '\n')
print('long_text', len(longv))

qod = [v for v in vals if 'qoder' in v.lower()]
with open(os.path.join(outdir, 'qoder_specific.txt'), 'w', encoding='utf-8') as f:
    f.write('\n'.join(qod))
print('qoder_specific', len(qod))
