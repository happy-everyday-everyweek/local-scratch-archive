import re, sys, base64, json

path = sys.argv[1]
limit = int(sys.argv[2]) if len(sys.argv) > 2 else 120
data = open(path, 'r', encoding='utf-8', errors='replace').read()
print('file chars', len(data))

keys = set(re.findall(r'_\$d\s*=\s*\([^)]*=\s*"([^"]{4,32})"\)', data))
print('xor keys found', keys)

calls = re.findall(r'_\$d\("([A-Za-z0-9+/=]{4,200})"\)', data)
print('decryptable call sites', len(calls))
print('unique payloads', len(set(calls)))


def dec(s, k='wnWOOEYHZLPw'):
    try:
        b = bytearray(base64.b64decode(s + '=' * (-len(s) % 4)))
    except Exception:
        return None
    for i in range(len(b)):
        b[i] ^= ord(k[i % len(k)])
    try:
        return b.decode('utf-8')
    except Exception:
        return None


out = {}
for c in calls:
    v = dec(c)
    if v:
        out[v] = out.get(v, 0) + 1
print('unique decrypted strings', len(out))
items = sorted(out.items(), key=lambda kv: -kv[1])
print('--- TOP 60 by frequency ---')
for v, n in items[:60]:
    print(n, repr(v[:120]))
