// ============================================================
// Edge Function: upload-apk-direct
// 对应 spec Task 8 SubTask 8.3
//
// 功能：通过用户 GitHub PAT 直接上传 APK 到 GitHub Release（正版/自然分类）。
// 1. 接收 device_token（header）与 body（apk_base64, app_name, package_name,
//    version, description, category, icon_base64, filename）
// 2. 使用 service_role key（从 Deno.env 获取，绝不硬编码）
// 3. 通过 device_token 查找 profile_id
// 4. 从 vault 读取该 profile 的 GitHub PAT（调用 get_github_pat RPC）
// 5. 从 user_settings 读取 github_username 和 github_repo_for_upload
// 6. 使用用户 PAT 调用 GitHub API：
//    a. 创建 Release（POST /repos/{owner}/{repo}/releases）
//    b. 上传 APK 资产（POST /uploads/{owner}/{repo}/releases/{id}/assets）
//    c. 上传图标（可选，作为 Release 资产 icon.png）
// 7. 在 apps 表创建记录（status='pending_review'）
// 8. 在 app_apks 表创建记录
// 9. 返回 { app_id, release_id, status }
//
// 注意：
//   - 此 Edge Function 仅支持 genuine 和 natural 分类（开源分类使用 submit-app-by-repo）
//   - APK 文件较大，base64 编码后可能超过 Edge Function 请求体限制
//   - 生产环境应改用 Storage 中转：客户端先上传 APK 到 Supabase Storage，
//     Edge Function 从 Storage 下载再上传到 GitHub（本任务先用 base64 方式实现）
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码
//   - 用户 PAT 从 vault 读取，不在数据库中明文存储
//   - 客户端仅持有 Publishable key，无法直接读取 PAT
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 从环境变量读取 Supabase 配置（绝不硬编码）
const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

// CORS 响应头
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// APK MIME 类型
const APK_MIME_TYPE = "application/vnd.android.package-archive";

// 分类描述映射（自然分类统一用「对正版的 APK 进行的自然化」）
const CATEGORY_DESCRIPTION: Record<string, string> = {
  opensource: "开源",
  genuine: "正版",
  natural: "自然（对正版的 APK 进行的自然化）",
};

// 根据文件名推断 CPU 架构
function inferArch(filename: string): string | null {
  const lower = filename.toLowerCase();
  if (
    lower.includes("arm64-v8a") || lower.includes("aarch64") ||
    lower.includes("arm64")
  ) {
    return "arm64-v8a";
  }
  if (lower.includes("armeabi-v7a") || lower.includes("armv7")) {
    return "armeabi-v7a";
  }
  if (lower.includes("x86_64") || lower.includes("x64")) {
    return "x86_64";
  }
  if (lower.includes("x86")) {
    return "x86";
  }
  if (lower.includes("universal") || lower.includes("all")) {
    return "universal";
  }
  return null;
}

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  try {
    // 从 header 获取 device_token
    const deviceToken = req.headers.get("device_token");
    if (!deviceToken) {
      return new Response(
        JSON.stringify({
          error: "missing_device_token",
          message: "缺少 device_token",
        }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 解析请求 body
    const body = await req.json();
    const apkBase64: string | undefined = body?.apk_base64;
    const appName: string | undefined = body?.app_name;
    const packageName: string | undefined = body?.package_name;
    const version: string | undefined = body?.version;
    const description: string | undefined = body?.description;
    const category: string | undefined = body?.category;
    const iconBase64: string | undefined = body?.icon_base64;
    const filename: string | undefined = body?.filename;

    // 校验必填参数
    if (!apkBase64 || typeof apkBase64 !== "string") {
      return new Response(
        JSON.stringify({
          error: "invalid_input",
          message: "apk_base64 为必填项",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!appName || typeof appName !== "string" || appName.trim().length === 0) {
      return new Response(
        JSON.stringify({
          error: "invalid_input",
          message: "app_name 为必填项",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!version || typeof version !== "string" || version.trim().length === 0) {
      return new Response(
        JSON.stringify({
          error: "invalid_input",
          message: "version 为必填项",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!filename || typeof filename !== "string" || filename.trim().length === 0) {
      return new Response(
        JSON.stringify({
          error: "invalid_input",
          message: "filename 为必填项",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    // 仅支持 genuine 和 natural 分类（开源分类使用 submit-app-by-repo）
    if (!category || !["genuine", "natural"].includes(category)) {
      return new Response(
        JSON.stringify({
          error: "invalid_input",
          message: "category 无效，仅支持 genuine 或 natural",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 使用 service_role key 创建 Supabase 客户端，绕过 RLS
    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    // 通过 device_token 查找 profile_id
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("id")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (profileError) {
      console.error("Failed to query profile:", profileError);
      return new Response(
        JSON.stringify({
          error: "profile_query_failed",
          message: "查询用户失败",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!profile) {
      return new Response(
        JSON.stringify({
          error: "profile_not_found",
          message: "用户不存在",
        }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    const ownerId = profile.id;

    // 从 vault 读取该 profile 的 GitHub PAT（调用 get_github_pat RPC）
    const { data: githubPat, error: patError } = await supabase.rpc(
      "get_github_pat",
      { p_profile_id: ownerId },
    );

    if (patError) {
      console.error("Failed to read GitHub PAT from vault:", patError);
      return new Response(
        JSON.stringify({
          error: "pat_read_failed",
          message: "读取 GitHub 密钥失败",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!githubPat) {
      return new Response(
        JSON.stringify({
          error: "pat_not_configured",
          message: "请先在设置中配置 GitHub 密钥",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 从 user_settings 读取 github_username 和 github_repo_for_upload
    const { data: settings, error: settingsError } = await supabase
      .from("user_settings")
      .select("github_username, github_repo_for_upload")
      .eq("id", ownerId)
      .maybeSingle();

    if (settingsError) {
      console.error("Failed to query user_settings:", settingsError);
      return new Response(
        JSON.stringify({
          error: "settings_query_failed",
          message: "读取用户设置失败",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    const githubUsername = settings?.github_username;
    const githubRepo = settings?.github_repo_for_upload;

    if (!githubUsername || typeof githubUsername !== "string" ||
      githubUsername.trim().length === 0) {
      return new Response(
        JSON.stringify({
          error: "settings_incomplete",
          message: "请先在设置中配置 GitHub 用户名",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!githubRepo || typeof githubRepo !== "string" ||
      githubRepo.trim().length === 0) {
      return new Response(
        JSON.stringify({
          error: "settings_incomplete",
          message: "请先在设置中配置 GitHub 仓库名",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    const repoOwner = githubUsername.trim();
    const repoName = githubRepo.trim();

    // 解码 base64 APK 二进制数据
    let apkBytes: Uint8Array;
    try {
      const binaryString = atob(apkBase64);
      apkBytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        apkBytes[i] = binaryString.charCodeAt(i);
      }
    } catch (e) {
      console.error("Failed to decode APK base64:", e);
      return new Response(
        JSON.stringify({
          error: "invalid_apk_base64",
          message: "APK base64 解码失败",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    const apkSize = apkBytes.length;

    // 使用用户 PAT 调用 GitHub API
    const ghHeaders: Record<string, string> = {
      "User-Agent": "AppMarket-Blog/1.0",
      "Accept": "application/vnd.github+json",
      "Authorization": `token ${githubPat}`,
    };

    // 1. 创建 Release
    const categoryDescription = CATEGORY_DESCRIPTION[category] ?? category;
    const releaseBody =
      `自动生成的 Release 说明\n\n应用名: ${appName}\n版本: ${version}\n描述: ${description ?? ""}\n分类: ${categoryDescription}`;

    const tagName = `v${version}`;
    const createReleaseUrl =
      `https://api.github.com/repos/${repoOwner}/${repoName}/releases`;

    let releaseId: number;
    let releaseHtmlUrl: string;
    try {
      const releaseResponse = await fetch(createReleaseUrl, {
        method: "POST",
        headers: {
          ...ghHeaders,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          tag_name: tagName,
          name: `${appName} ${version}`,
          body: releaseBody,
        }),
      });

      if (!releaseResponse.ok) {
        const errText = await releaseResponse.text();
        console.error("GitHub create release failed:", releaseResponse.status, errText);
        return new Response(
          JSON.stringify({
            error: "github_create_release_failed",
            message: `创建 Release 失败（HTTP ${releaseResponse.status}）`,
          }),
          {
            status: 502,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }

      const releaseData = await releaseResponse.json();
      releaseId = releaseData.id;
      releaseHtmlUrl = releaseData.html_url ?? "";
    } catch (e) {
      console.error("GitHub create release network error:", e);
      return new Response(
        JSON.stringify({
          error: "github_api_network_error",
          message: "GitHub API 网络错误",
        }),
        {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 2. 上传 APK 资产
    const uploadApkUrl =
      `https://uploads.github.com/repos/${repoOwner}/${repoName}/releases/${releaseId}/assets?name=${encodeURIComponent(filename)}`;

    let apkAssetUrl: string;
    try {
      const uploadResponse = await fetch(uploadApkUrl, {
        method: "POST",
        headers: {
          ...ghHeaders,
          "Content-Type": APK_MIME_TYPE,
          "Content-Length": apkSize.toString(),
        },
        body: apkBytes,
      });

      if (!uploadResponse.ok) {
        const errText = await uploadResponse.text();
        console.error("GitHub upload APK failed:", uploadResponse.status, errText);
        return new Response(
          JSON.stringify({
            error: "github_upload_apk_failed",
            message: `上传 APK 失败（HTTP ${uploadResponse.status}）`,
          }),
          {
            status: 502,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }

      const assetData = await uploadResponse.json();
      apkAssetUrl = assetData.browser_download_url ?? "";
    } catch (e) {
      console.error("GitHub upload APK network error:", e);
      return new Response(
        JSON.stringify({
          error: "github_api_network_error",
          message: "GitHub API 网络错误",
        }),
        {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 3. 上传图标（可选，作为 Release 资产 icon.png）
    let iconUrl: string | null = null;
    if (iconBase64 && typeof iconBase64 === "string" && iconBase64.length > 0) {
      try {
        const iconBinaryString = atob(iconBase64);
        const iconBytes = new Uint8Array(iconBinaryString.length);
        for (let i = 0; i < iconBinaryString.length; i++) {
          iconBytes[i] = iconBinaryString.charCodeAt(i);
        }

        const uploadIconUrl =
          `https://uploads.github.com/repos/${repoOwner}/${repoName}/releases/${releaseId}/assets?name=icon.png`;

        const iconResponse = await fetch(uploadIconUrl, {
          method: "POST",
          headers: {
            ...ghHeaders,
            "Content-Type": "image/png",
            "Content-Length": iconBytes.length.toString(),
          },
          body: iconBytes,
        });

        if (iconResponse.ok) {
          const iconAssetData = await iconResponse.json();
          iconUrl = iconAssetData.browser_download_url ?? null;
        } else {
          // 图标上传失败不阻塞流程，仅记录日志
          const errText = await iconResponse.text();
          console.error("GitHub upload icon failed (non-blocking):", iconResponse.status, errText);
        }
      } catch (e) {
        // 图标上传失败不阻塞流程
        console.error("GitHub upload icon error (non-blocking):", e);
      }
    }

    // 7. 在 apps 表创建记录（status='pending_review'）
    const { data: app, error: appInsertError } = await supabase
      .from("apps")
      .insert({
        owner_id: ownerId,
        name: appName.trim(),
        package_name: packageName ?? null,
        github_repo: `https://github.com/${repoOwner}/${repoName}`,
        category: category,
        status: "pending_review",
        icon_url: iconUrl,
        description: description ?? null,
        latest_version: version,
      })
      .select("id, status")
      .single();

    if (appInsertError) {
      console.error("Failed to insert app:", appInsertError);
      return new Response(
        JSON.stringify({
          error: "insert_app_failed",
          message: "创建应用记录失败",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    const appId = app.id;

    // 8. 在 app_apks 表创建记录
    const { error: apkInsertError } = await supabase
      .from("app_apks")
      .insert({
        app_id: appId,
        release_id: releaseId,
        version: version,
        filename: filename,
        size: apkSize,
        arch: inferArch(filename),
        github_asset_url: apkAssetUrl,
        release_notes: releaseBody,
      });

    if (apkInsertError) {
      console.error("Failed to insert app_apks:", apkInsertError);
      // APK 记录插入失败，但应用记录已创建，返回部分成功
      return new Response(
        JSON.stringify({
          error: "insert_apk_failed",
          message: "保存 APK 信息失败",
          app_id: appId,
          release_id: releaseId,
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 9. 返回结果
    return new Response(
      JSON.stringify({
        app_id: appId,
        release_id: releaseId,
        status: "pending_review",
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({
        error: "internal_server_error",
        message: "内部服务器错误",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
