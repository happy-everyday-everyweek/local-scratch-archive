// ============================================================
// Edge Function: manual-review
// 对应 spec Task 10 SubTask 10.1 / 10.2 / 10.3
//
// 功能：管理员/站长对正版/自然分类应用执行人工审核。
//   1. 接收 POST 请求，header 含 device_token，body 含 { app_id, action, virus_safe_reason? }
//   2. 使用 service_role key（从 Deno.env 获取，绝不硬编码）
//   3. 通过 device_token 查找调用者，校验 role in ('admin', 'owner')
//   4. action 取值：
//      - 'approve'：status -> 'approved'
//      - 'virus_safe'：status -> 'virus_safe'，必须提供 virus_safe_reason
//      - 'reject'：status -> 'rejected'
//   5. 校验 app 当前 status='pending_review'（不能审核已审核的 app）
//   6. 更新 apps 表的 status 和 virus_safe_reason（若 action=virus_safe）
//   7. 若 action='virus_safe'：向上传该应用的用户（apps.owner_id）发送站内消息
//   8. 返回 { success: true, app_id, status }
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码。
//   - apps.status 与 virus_safe_reason 字段已撤销 anon/authenticated 的直接写权限（RLS），
//     必须经此 Edge Function 由服务端 service_role key 执行。
//   - 客户端仅持有 Publishable key，无法绕过此校验直接修改审核状态。
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 允许的审核动作
const ALLOWED_ACTIONS = new Set(["approve", "virus_safe", "reject"]);

// action 到目标 status 的映射
const ACTION_TO_STATUS: Record<string, string> = {
  approve: "approved",
  virus_safe: "virus_safe",
  reject: "rejected",
};

// CORS 响应头（Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量（绝不硬编码 service_role key）
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 从 header 读取 device_token（由客户端 AuthInterceptor 自动附加）
  const deviceToken = req.headers.get("device_token");
  if (!deviceToken || deviceToken.trim().length === 0) {
    return new Response(
      JSON.stringify({ error: "device_token is required" }),
      {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 解析请求 body，获取 app_id / action / virus_safe_reason
  let appId: string | undefined;
  let action: string | undefined;
  let virusSafeReason: string | undefined;
  try {
    const body = await req.json();
    appId = body?.app_id;
    action = body?.action;
    virusSafeReason = body?.virus_safe_reason;
  } catch {
    return new Response(
      JSON.stringify({ error: "Invalid request body" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 校验 app_id 参数
  if (
    !appId ||
    typeof appId !== "string" ||
    appId.trim().length === 0
  ) {
    return new Response(
      JSON.stringify({ error: "app_id is required" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 校验 action 参数
  if (
    !action ||
    typeof action !== "string" ||
    !ALLOWED_ACTIONS.has(action)
  ) {
    return new Response(
      JSON.stringify({ error: "action must be 'approve', 'virus_safe' or 'reject'" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 若 action='virus_safe'，必须提供 virus_safe_reason（非空字符串）
  if (action === "virus_safe") {
    if (
      !virusSafeReason ||
      typeof virusSafeReason !== "string" ||
      virusSafeReason.trim().length === 0
    ) {
      return new Response(
        JSON.stringify({ error: "virus_safe_reason is required for virus_safe action" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
  }

  // 使用 service_role key 创建客户端，绕过 RLS 直接操作 apps / messages
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  try {
    // 通过 device_token 查找调用者 profile，并校验其角色
    const { data: caller, error: callerError } = await supabase
      .from("profiles")
      .select("id, role")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (callerError) {
      console.error("Failed to query caller profile:", callerError);
      return new Response(
        JSON.stringify({ error: "Failed to query caller profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (!caller) {
      return new Response(
        JSON.stringify({ error: "Caller profile not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 仅站长/管理员可调用
    if (caller.role !== "owner" && caller.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Only owner or admin can review apps" }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 查询目标 app，校验其存在且当前 status='pending_review'
    const { data: app, error: appError } = await supabase
      .from("apps")
      .select("id, owner_id, name, status")
      .eq("id", appId)
      .maybeSingle();

    if (appError) {
      console.error("Failed to query app:", appError);
      return new Response(
        JSON.stringify({ error: "Failed to query app" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (!app) {
      return new Response(
        JSON.stringify({ error: "App not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 不能审核已审核的 app（必须处于 pending_review 状态）
    if (app.status !== "pending_review") {
      return new Response(
        JSON.stringify({
          error: `App is not in pending_review status (current: ${app.status})`,
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 计算目标 status
    const targetStatus = ACTION_TO_STATUS[action];

    // 更新 apps 表的 status（以及 virus_safe_reason，若 action=virus_safe）
    // service_role 绕过 RLS 与字段级 revoke
    const updatePayload: Record<string, string> = { status: targetStatus };
    if (action === "virus_safe") {
      updatePayload.virus_safe_reason = virusSafeReason!.trim();
    }

    const { error: updateError } = await supabase
      .from("apps")
      .update(updatePayload)
      .eq("id", appId);

    if (updateError) {
      console.error("Failed to update app status:", updateError);
      return new Response(
        JSON.stringify({ error: "Failed to update app status" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 若 action='virus_safe'：向上传该应用的用户发送站内消息
    if (action === "virus_safe") {
      const messageTitle = "应用审核结果：报毒但安全";
      const messageContent =
        `您的应用 ${app.name} 经审核被标记为「报毒但安全」。原因：${virusSafeReason!.trim()}。请您补充说明该应用触发报毒的原因，以便我们更好地向用户解释。`;

      const { error: msgError } = await supabase
        .from("messages")
        .insert({
          recipient_id: app.owner_id,
          title: messageTitle,
          content: messageContent,
          type: "review_virus_safe",
          related_app_id: appId,
        });

      if (msgError) {
        // 消息发送失败不回滚审核结果，仅记录错误
        console.error(
          `Failed to send review_virus_safe message for app ${appId}:`,
          msgError,
        );
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        app_id: appId,
        status: targetStatus,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
