// ============================================================
// Edge Function: generate-inherit-code
// 对应 spec Task 4 SubTask 4.1
//
// 功能：为当前设备账号生成一次性继承码，用于在新设备上继承账号。
//
// 流程：
//   1. 从请求 header 读取 device_token，通过 service_role 查找 source profile。
//   2. 将该 profile 旧的未使用继承码标记为 used（保证同时只有一个有效码）。
//   3. 生成 8 位随机继承码（大写字母+数字，去除易混淆字符 O/0/I/1）。
//   4. 写入 inherit_codes 表，有效期 10 分钟。
//   5. 返回 { code, expires_at }。
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码。
//   - 客户端仅持有 Publishable key，无法直接操作 inherit_codes（RLS 限制），
//     必须经此 Edge Function 由服务端执行。
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 继承码字符集：大写字母+数字，去除易混淆字符 O / 0 / I / 1
const CODE_CHARSET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const CODE_LENGTH = 8;
// 继承码有效期：10 分钟
const CODE_TTL_MS = 10 * 60 * 1000;

// CORS 响应头（Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// 生成 8 位随机继承码，使用 crypto.getRandomValues 保证密码学安全随机
function generateCode(): string {
  const bytes = new Uint8Array(CODE_LENGTH);
  crypto.getRandomValues(bytes);
  let code = "";
  for (let i = 0; i < CODE_LENGTH; i++) {
    code += CODE_CHARSET[bytes[i] % CODE_CHARSET.length];
  }
  return code;
}

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量（绝不硬编码 service_role key）
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 从 header 读取 device_token（由客户端 AuthInterceptor 自动附加）
  const deviceToken = req.headers.get("device_token");
  if (!deviceToken || deviceToken.trim().length === 0) {
    return new Response(
      JSON.stringify({ error: "device_token is required" }),
      {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 使用 service_role key 创建客户端，绕过 RLS 直接操作 inherit_codes
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  try {
    // 通过 device_token 查找当前 profile（source_profile_id）
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("id")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (profileError) {
      console.error("Failed to query profile:", profileError);
      return new Response(
        JSON.stringify({ error: "Failed to query profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (!profile) {
      return new Response(
        JSON.stringify({ error: "Profile not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    const sourceProfileId = profile.id;

    // 将该 profile 旧的未使用继承码标记为 used
    // 保证每个 profile 同时只有一个未使用的继承码
    const { error: invalidateError } = await supabase
      .from("inherit_codes")
      .update({ used: true })
      .eq("source_profile_id", sourceProfileId)
      .eq("used", false);

    if (invalidateError) {
      console.error("Failed to invalidate old codes:", invalidateError);
      return new Response(
        JSON.stringify({ error: "Failed to invalidate old codes" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 生成新继承码并写入，若唯一约束冲突（极小概率）则重试
    const expiresAt = new Date(Date.now() + CODE_TTL_MS).toISOString();
    let code = "";
    let inserted = false;
    for (let attempt = 0; attempt < 5; attempt++) {
      code = generateCode();
      const { error: insertError } = await supabase
        .from("inherit_codes")
        .insert({
          source_profile_id: sourceProfileId,
          code,
          expires_at: expiresAt,
          used: false,
        });
      if (!insertError) {
        inserted = true;
        break;
      }
      // 23505 = unique_violation，继承码重复，重试生成
      if (insertError.code !== "23505") {
        console.error("Failed to insert inherit code:", insertError);
        return new Response(
          JSON.stringify({ error: "Failed to generate inherit code" }),
          {
            status: 500,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }
    }

    if (!inserted) {
      return new Response(
        JSON.stringify({ error: "Failed to generate unique inherit code" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    return new Response(
      JSON.stringify({ code, expires_at: expiresAt }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
