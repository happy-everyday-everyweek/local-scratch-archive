// ============================================================
// Edge Function: get-feed
// 对应 spec Task 15（SubTask 15.1 ~ 15.4）
//
// 功能：应用市场信息流推荐接口，返回混排的 FeedCard 列表。
//   1. 接收 POST 请求，header 含 device_token，body 含 { page, page_size }
//   2. 使用 service_role key（从 Deno.env 获取，绝不硬编码）
//   3. 通过 device_token 查找 profile_id（可能不存在，匿名用户也允许浏览）
//   4. 按推荐算法生成混排卡片，每页约 10 张：
//      - 你可能需要：基于用户历史（浏览/下载）的 category/tag 召回，新用户返回热门
//      - 重磅更新：近 7 天更新且 latest_version 非空，按下载量取 Top
//      - 全新上线：近 7 天创建且已审核通过，按创建时间取 Top
//      - 单应用卡片：优质应用推荐
//      - 文章/推荐/主题卡片
//   5. 多应用卡片不连续，整体顺序随机混排
//   6. 返回 { cards: [...], has_more: boolean }
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码。
//   - 客户端仅持有 Publishable key，device_token 由 AuthInterceptor 附加。
//   - 匿名用户（无 device_token 或未匹配 profile）也允许浏览，
//     仅「你可能需要」回退为热门应用。
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Supabase 客户端类型别名
type SupabaseClient = ReturnType<typeof createClient>;

// 应用行（与客户端 App 模型字段一致，使用 snake_case）
interface AppRow {
  id: string;
  [key: string]: unknown;
}

// 多应用卡片
interface MultiAppCard {
  type: "multi_app";
  title: string;
  apps: AppRow[];
}

// 单应用卡片
interface SingleAppCard {
  type: "single_app";
  app: AppRow;
}

// 文章/推荐/主题卡片
interface ArticleCard {
  type: "theme" | "article" | "recommend";
  article: Record<string, unknown>;
  apps?: AppRow[];
}

type FeedCard = MultiAppCard | SingleAppCard | ArticleCard;

// CORS 响应头（Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// 推荐算法相关常量
const PAGE_SIZE_DEFAULT = 10; // 每页默认卡片数量
const HISTORY_DAYS = 30; // 用户历史回溯天数
const RECENT_DAYS = 7; // 「重磅更新」「全新上线」时间窗口
const MULTI_APP_MIN = 2; // 多应用卡片最少应用数，不足则不生成
const MULTI_APP_MAX = 4; // 多应用卡片最多应用数
const SINGLE_TARGET = 3; // 单应用卡片目标数量
const ARTICLE_TARGET = 2; // 文章卡片目标数量

// App 查询字段（与客户端 App 模型一致，使用 snake_case）
const APP_FIELDS =
  "id, owner_id, name, package_name, github_repo, category, status, review_level, virus_safe_reason, icon_url, description, latest_version, screenshots, tags, download_count, created_at, updated_at";

// Article 查询字段（与客户端 Article 模型一致）
const ARTICLE_FIELDS =
  "id, author_id, type, title, cover, content, app_ids, tags, created_at";

// 信息流可展示的应用状态
const FEED_STATUSES = ["approved", "virus_safe"];

// 多应用卡片标题（固定）
const TITLE_YOU_MAY_NEED = "你可能需要";
const TITLE_MAJOR_UPDATE = "重磅更新";
const TITLE_NEW_LAUNCH = "全新上线";

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量（绝不硬编码 service_role key）
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return jsonResponse({ error: "Server is not configured properly" }, 500);
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }

  // 解析请求 body { page, page_size }
  let page = 0;
  let pageSize = PAGE_SIZE_DEFAULT;
  try {
    const body = await req.json();
    if (typeof body?.page === "number" && body.page >= 0) {
      page = Math.floor(body.page);
    }
    if (typeof body?.page_size === "number" && body.page_size > 0) {
      pageSize = Math.floor(body.page_size);
    }
  } catch {
    return jsonResponse({ error: "Invalid request body" }, 400);
  }

  // 从 header 读取 device_token（可选，匿名用户也允许浏览）
  const deviceToken = req.headers.get("device_token");

  // 使用 service_role key 创建客户端，绕过 RLS 读取推荐所需数据
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  try {
    // 通过 device_token 查找 profile_id（可能不存在，匿名用户返回 null）
    const profileId = await resolveProfileId(supabase, deviceToken);

    // 已在本页多应用卡片中使用过的 app id，避免同一页内重复出现
    const usedAppIds = new Set<string>();

    // 1. 你可能需要（基于用户历史，新用户/匿名用户返回热门）
    const youMayNeedApps = await getYouMayNeedApps(
      supabase,
      profileId,
      usedAppIds,
      page,
    );
    youMayNeedApps.forEach((a) => usedAppIds.add(a.id));
    const youMayNeedCard = youMayNeedApps.length >= MULTI_APP_MIN
      ? makeMultiCard(TITLE_YOU_MAY_NEED, youMayNeedApps)
      : null;

    // 2. 重磅更新（近 7 天更新 + 下载量 Top）
    const majorUpdateApps = await getMajorUpdateApps(supabase, usedAppIds, page);
    majorUpdateApps.forEach((a) => usedAppIds.add(a.id));
    const majorUpdateCard = majorUpdateApps.length >= MULTI_APP_MIN
      ? makeMultiCard(TITLE_MAJOR_UPDATE, majorUpdateApps)
      : null;

    // 3. 全新上线（近 7 天首次审核通过）
    const newLaunchApps = await getNewLaunchApps(supabase, usedAppIds, page);
    newLaunchApps.forEach((a) => usedAppIds.add(a.id));
    const newLaunchCard = newLaunchApps.length >= MULTI_APP_MIN
      ? makeMultiCard(TITLE_NEW_LAUNCH, newLaunchApps)
      : null;

    // 4. 单应用卡片（优质应用推荐）
    const singleResult = await getSingleApps(
      supabase,
      usedAppIds,
      page,
      SINGLE_TARGET,
    );
    singleResult.apps.forEach((a) => usedAppIds.add(a.id));

    // 5. 文章/推荐/主题卡片
    const articleResult = await getArticleCards(supabase, page, ARTICLE_TARGET);

    // 组装多应用卡片与其他卡片
    const multiCards: MultiAppCard[] = [
      youMayNeedCard,
      majorUpdateCard,
      newLaunchCard,
    ].filter((c): c is MultiAppCard => c !== null);
    const otherCards: FeedCard[] = [
      ...singleResult.apps.map((app) => ({ type: "single_app", app }) as SingleAppCard),
      ...articleResult.cards,
    ];

    // 随机混排，但多应用卡片不连续
    const shuffledMulti = shuffleArray(multiCards);
    const shuffledOther = shuffleArray(otherCards);
    const mixedCards = interleaveCards(shuffledMulti, shuffledOther);

    // 单页返回不超过 page_size 张卡片
    const cards = mixedCards.length > pageSize
      ? mixedCards.slice(0, pageSize)
      : mixedCards;

    // 是否还有更多页：单应用或文章还有剩余即认为有更多
    const hasMore = singleResult.hasMore || articleResult.hasMore;

    return jsonResponse({ cards, has_more: hasMore }, 200);
  } catch (err) {
    console.error("get-feed unexpected error:", err);
    return jsonResponse({ error: "Internal server error" }, 500);
  }
});

// ============================================================
// 通用辅助函数
// ============================================================

/** 统一 JSON 响应 */
function jsonResponse(body: unknown, status: number): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

/** 通过 device_token 查找 profile_id，未匹配返回 null（匿名用户） */
async function resolveProfileId(
  supabase: SupabaseClient,
  deviceToken: string | null,
): Promise<string | null> {
  if (!deviceToken || deviceToken.trim().length === 0) return null;
  const { data, error } = await supabase
    .from("profiles")
    .select("id")
    .eq("device_token", deviceToken)
    .maybeSingle();
  if (error || !data) return null;
  return data.id as string;
}

/** 构造多应用卡片 */
function makeMultiCard(title: string, apps: AppRow[]): MultiAppCard {
  return { type: "multi_app", title, apps };
}

/** Fisher-Yates 洗牌 */
function shuffleArray<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * 将多应用卡片与其他卡片混排，保证多应用卡片不连续。
 * 策略：在其他卡片的间隙中插入多应用卡片，每个间隙最多一张，
 *       从而确保任意两张多应用卡片之间至少隔一张其他卡片。
 */
function interleaveCards(
  multiCards: MultiAppCard[],
  otherCards: FeedCard[],
): FeedCard[] {
  if (multiCards.length === 0) return otherCards;
  if (otherCards.length === 0) return [...multiCards];

  const result: FeedCard[] = [...otherCards];
  // 其他卡片构成的间隙数（含首尾）
  const gaps = result.length + 1;

  // 为每张多应用卡片选择一个间隙位置，尽量均匀分布
  const positions: number[] = [];
  if (multiCards.length <= gaps) {
    // 间隙充足：均匀选取不同间隙，保证不连续
    const step = gaps / multiCards.length;
    for (let i = 0; i < multiCards.length; i++) {
      positions.push(Math.floor(i * step));
    }
  } else {
    // 间隙不足：无法完全避免连续，尽量分散
    for (let i = 0; i < multiCards.length; i++) {
      positions.push(i % gaps);
    }
  }

  // 将每张多应用卡片与其位置配对，按位置降序插入（从后往前，避免索引偏移）
  const pairs = multiCards.map((card, i) => ({ card, pos: positions[i] }));
  pairs.sort((a, b) => b.pos - a.pos);
  for (const { card, pos } of pairs) {
    result.splice(pos, 0, card);
  }
  return result;
}

/** 构造「不在指定 id 集合内」的排除过滤值，返回 null 表示无需排除 */
function buildExcludeFilter(ids: Set<string>): string | null {
  if (ids.size === 0) return null;
  return `(${[...ids].join(",")})`;
}

/** 安全读取数字字段 */
function toNumber(value: unknown): number {
  return typeof value === "number" ? value : 0;
}

// ============================================================
// SubTask 15.2: 你可能需要
// ============================================================

/**
 * 「你可能需要」算法：
 * - 查询用户最近 30 天的 view_history 和 download_logs
 * - 提取浏览/下载过的应用的 category 和 tags
 * - 召回同 category 或同 tag 的已审核应用，排除已下载
 * - 按 download_count 降序取 Top 2~4
 * - 无历史（新用户/匿名用户）返回热门应用 Top 2~4
 */
async function getYouMayNeedApps(
  supabase: SupabaseClient,
  profileId: string | null,
  usedAppIds: Set<string>,
  page: number,
): Promise<AppRow[]> {
  const offset = page * MULTI_APP_MAX;

  // 匿名用户或无 profile：返回热门应用
  if (!profileId) {
    return await fetchPopularApps(supabase, usedAppIds, offset);
  }

  const since = new Date(
    Date.now() - HISTORY_DAYS * 24 * 60 * 60 * 1000,
  ).toISOString();

  // 查询最近 30 天浏览过的应用
  const { data: views } = await supabase
    .from("view_history")
    .select("app_id")
    .eq("profile_id", profileId)
    .gte("viewed_at", since);

  // 查询最近 30 天下载过的应用
  const { data: downloads } = await supabase
    .from("download_logs")
    .select("app_id")
    .eq("profile_id", profileId)
    .gte("started_at", since);

  const viewedIds = new Set(
    (views ?? []).map((r: any) => r.app_id as string),
  );
  const downloadedIds = new Set(
    (downloads ?? []).map((r: any) => r.app_id as string),
  );
  const historyIds = [...new Set([...viewedIds, ...downloadedIds])];

  // 无历史：返回热门应用
  if (historyIds.length === 0) {
    return await fetchPopularApps(supabase, usedAppIds, offset);
  }

  // 提取历史应用的 category 和 tags
  const { data: historyApps } = await supabase
    .from("apps")
    .select("category, tags")
    .in("id", historyIds);

  const categories = new Set<string>();
  const tags = new Set<string>();
  (historyApps ?? []).forEach((a: any) => {
    if (a.category) categories.add(a.category);
    if (Array.isArray(a.tags)) {
      a.tags.forEach((t: string) => tags.add(t));
    }
  });

  // 无可用特征：返回热门应用
  if (categories.size === 0 && tags.size === 0) {
    return await fetchPopularApps(supabase, usedAppIds, offset);
  }

  // 召回同 category 的应用
  let byCategory: AppRow[] = [];
  if (categories.size > 0) {
    const { data } = await supabase
      .from("apps")
      .select(APP_FIELDS)
      .in("status", FEED_STATUSES)
      .in("category", [...categories])
      .order("download_count", { ascending: false })
      .limit(60);
    byCategory = (data ?? []) as AppRow[];
  }

  // 召回同 tag 的应用（数组重叠 ov 操作符）
  let byTag: AppRow[] = [];
  if (tags.size > 0) {
    const { data } = await supabase
      .from("apps")
      .select(APP_FIELDS)
      .in("status", FEED_STATUSES)
      .filter("tags", "ov", `{${[...tags].join(",")}}`)
      .order("download_count", { ascending: false })
      .limit(60);
    byTag = (data ?? []) as AppRow[];
  }

  // 合并去重
  const seen = new Set<string>();
  const merged: AppRow[] = [];
  [...byCategory, ...byTag].forEach((a) => {
    if (!seen.has(a.id)) {
      seen.add(a.id);
      merged.push(a);
    }
  });

  // 排除已下载 + 本页已使用的应用
  const exclude = new Set<string>([...downloadedIds, ...usedAppIds]);
  const filtered = merged
    .filter((a) => !exclude.has(a.id))
    .sort(
      (a, b) => toNumber(b.download_count) - toNumber(a.download_count),
    );

  const result = filtered.slice(offset, offset + MULTI_APP_MAX);

  // 个性化结果不足：回退热门应用（保证有内容）
  if (result.length < MULTI_APP_MIN) {
    return await fetchPopularApps(supabase, usedAppIds, offset);
  }
  return result;
}

/** 查询热门应用（按 download_count 降序），排除已使用的 app */
async function fetchPopularApps(
  supabase: SupabaseClient,
  usedAppIds: Set<string>,
  offset: number,
): Promise<AppRow[]> {
  let query = supabase
    .from("apps")
    .select(APP_FIELDS)
    .in("status", FEED_STATUSES);

  const exclude = buildExcludeFilter(usedAppIds);
  if (exclude) query = query.not("id", "in", exclude);

  const { data, error } = await query
    .order("download_count", { ascending: false })
    .range(offset, offset + MULTI_APP_MAX - 1);

  if (error) {
    console.error("fetchPopularApps error:", error);
    return [];
  }
  return (data ?? []) as AppRow[];
}

// ============================================================
// SubTask 15.3: 重磅更新
// ============================================================

/**
 * 「重磅更新」算法：
 * - 查询近 7 天内 updated_at 有变化且 latest_version 非空的应用
 * - 按 download_count 降序取 Top 2~4
 * - 不足 2 个则返回空（由调用方跳过该卡片）
 */
async function getMajorUpdateApps(
  supabase: SupabaseClient,
  usedAppIds: Set<string>,
  page: number,
): Promise<AppRow[]> {
  const since = new Date(
    Date.now() - RECENT_DAYS * 24 * 60 * 60 * 1000,
  ).toISOString();
  const offset = page * MULTI_APP_MAX;

  let query = supabase
    .from("apps")
    .select(APP_FIELDS)
    .in("status", FEED_STATUSES)
    .gte("updated_at", since)
    .not("latest_version", "is", null)
    .neq("latest_version", "");

  const exclude = buildExcludeFilter(usedAppIds);
  if (exclude) query = query.not("id", "in", exclude);

  const { data, error } = await query
    .order("download_count", { ascending: false })
    .range(offset, offset + MULTI_APP_MAX - 1);

  if (error) {
    console.error("getMajorUpdateApps error:", error);
    return [];
  }
  return (data ?? []) as AppRow[];
}

// ============================================================
// SubTask 15.4: 全新上线
// ============================================================

/**
 * 「全新上线」算法：
 * - 查询近 7 天内 created_at 且 status 首次变为 approved 的应用
 * - 按 created_at 降序取 Top 2~4
 * - 不足 2 个则返回空（由调用方跳过该卡片）
 *
 * 说明：数据库无独立的状态变更时间戳，以 created_at 近 7 天且当前
 *       status 为 approved/virus_safe 近似「全新上线」。
 */
async function getNewLaunchApps(
  supabase: SupabaseClient,
  usedAppIds: Set<string>,
  page: number,
): Promise<AppRow[]> {
  const since = new Date(
    Date.now() - RECENT_DAYS * 24 * 60 * 60 * 1000,
  ).toISOString();
  const offset = page * MULTI_APP_MAX;

  let query = supabase
    .from("apps")
    .select(APP_FIELDS)
    .in("status", FEED_STATUSES)
    .gte("created_at", since);

  const exclude = buildExcludeFilter(usedAppIds);
  if (exclude) query = query.not("id", "in", exclude);

  const { data, error } = await query
    .order("created_at", { ascending: false })
    .range(offset, offset + MULTI_APP_MAX - 1);

  if (error) {
    console.error("getNewLaunchApps error:", error);
    return [];
  }
  return (data ?? []) as AppRow[];
}

// ============================================================
// 单应用卡片
// ============================================================

/**
 * 单应用卡片：优质应用推荐，按 download_count 降序取 Top N。
 * 多取一个用于判断 has_more。
 */
async function getSingleApps(
  supabase: SupabaseClient,
  usedAppIds: Set<string>,
  page: number,
  count: number,
): Promise<{ apps: AppRow[]; hasMore: boolean }> {
  const offset = page * count;

  let query = supabase
    .from("apps")
    .select(APP_FIELDS)
    .in("status", FEED_STATUSES);

  const exclude = buildExcludeFilter(usedAppIds);
  if (exclude) query = query.not("id", "in", exclude);

  const { data, error } = await query
    .order("download_count", { ascending: false })
    .range(offset, offset + count); // 多取 1 个判断 has_more

  if (error) {
    console.error("getSingleApps error:", error);
    return { apps: [], hasMore: false };
  }
  const rows = (data ?? []) as AppRow[];
  const hasMore = rows.length > count;
  return { apps: rows.slice(0, count), hasMore };
}

// ============================================================
// 文章/推荐/主题卡片
// ============================================================

/**
 * 文章卡片：查询 type 为 article/recommend/theme 的文章，按 created_at 降序。
 * recommend 类型额外加载关联应用。
 */
async function getArticleCards(
  supabase: SupabaseClient,
  page: number,
  count: number,
): Promise<{ cards: ArticleCard[]; hasMore: boolean }> {
  const offset = page * count;

  const { data, error } = await supabase
    .from("articles")
    .select(ARTICLE_FIELDS)
    .in("type", ["article", "recommend", "theme"])
    .order("created_at", { ascending: false })
    .range(offset, offset + count); // 多取 1 个判断 has_more

  if (error) {
    console.error("getArticleCards error:", error);
    return { cards: [], hasMore: false };
  }

  const rows = (data ?? []) as any[];
  const hasMore = rows.length > count;
  const target = rows.slice(0, count);

  const cards: ArticleCard[] = [];
  for (const article of target) {
    if (article.type === "recommend") {
      const appIds: string[] = Array.isArray(article.app_ids)
        ? article.app_ids
        : [];
      const apps = await fetchAppsByIds(supabase, appIds);
      cards.push({ type: "recommend", article, apps });
    } else if (article.type === "theme") {
      cards.push({ type: "theme", article });
    } else {
      cards.push({ type: "article", article });
    }
  }
  return { cards, hasMore };
}

/** 根据 id 列表查询可展示的应用 */
async function fetchAppsByIds(
  supabase: SupabaseClient,
  appIds: string[],
): Promise<AppRow[]> {
  if (appIds.length === 0) return [];
  const { data, error } = await supabase
    .from("apps")
    .select(APP_FIELDS)
    .in("id", appIds)
    .in("status", FEED_STATUSES);
  if (error) {
    console.error("fetchAppsByIds error:", error);
    return [];
  }
  return (data ?? []) as AppRow[];
}
