// Edge Function: create-or-get-profile
// 设备指纹账号体系入口：根据设备指纹创建或获取 profile。
//
// 安全说明：
// - 使用 service_role key 创建 Supabase 客户端，绕过 RLS 直接操作 profiles 表。
// - service_role key 从 Deno.env 获取，绝不硬编码。
// - 客户端仅持有 Publishable key，无法直接 insert profile（RLS 限制），
//   必须经此 Edge Function 由服务端执行。
// - 首个 profile 由数据库触发器 handle_new_profile 自动设置为 owner 角色。

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 从环境变量读取 Supabase 配置（绝不硬编码）
const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

// CORS 响应头（虽然 Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  try {
    // 解析请求 body
    const body = await req.json();
    const deviceFingerprint: string | undefined = body?.device_fingerprint;

    // 校验 device_fingerprint 参数
    if (!deviceFingerprint || typeof deviceFingerprint !== "string" ||
      deviceFingerprint.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: "device_fingerprint is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 使用 service_role key 创建 Supabase 客户端，绕过 RLS
    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });

    // 查询是否已存在该 device_fingerprint 的 profile
    const { data: existing, error: queryError } = await supabase
      .from("profiles")
      .select("id, device_token, role")
      .eq("device_fingerprint", deviceFingerprint)
      .maybeSingle();

    if (queryError) {
      console.error("Failed to query profile:", queryError);
      return new Response(
        JSON.stringify({ error: "Failed to query profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 若存在，返回已有 profile 的信息
    if (existing) {
      return new Response(
        JSON.stringify({
          profile_id: existing.id,
          device_token: existing.device_token,
          role: existing.role,
        }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 若不存在，insert 新 profile
    // role 由数据库触发器 handle_new_profile 自动设置（首个为 owner，其余为 user）
    // device_token 由数据库默认值 gen_random_uuid() 自动生成
    const { data: inserted, error: insertError } = await supabase
      .from("profiles")
      .insert({
        device_fingerprint: deviceFingerprint,
      })
      .select("id, device_token, role")
      .single();

    if (insertError) {
      console.error("Failed to insert profile:", insertError);
      return new Response(
        JSON.stringify({ error: "Failed to create profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 返回新创建 profile 的信息
    return new Response(
      JSON.stringify({
        profile_id: inserted.id,
        device_token: inserted.device_token,
        role: inserted.role,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
