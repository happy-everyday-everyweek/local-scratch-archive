// ============================================================
// Edge Function: submit-app-by-repo
// 对应 spec Task 6 SubTask 6.2
//
// 功能：通过 GitHub 仓库地址上传应用。
// 1. 接收 device_token（header）与 { github_repo, category, name, description }（body）
// 2. 通过 device_token 查找 profile_id 作为 owner_id
// 3. 校验 github_repo URL 格式（必须是 https://github.com/owner/repo）
// 4. 在 apps 表 insert 记录（status='pending_fetch'）
// 5. 调用 GitHub API 获取最新 Release
// 6. 筛选 APK 资产（.apk 后缀或 android mime type）
// 7. 若找到 APK：insert app_apks、更新 apps、insert fetch_logs
// 8. 若未找到 APK：返回错误、insert fetch_logs 失败记录、保留 app 记录
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码
//   - 客户端仅持有 Publishable key，无法直接 insert apps（RLS 限制 status 字段）
//   - GITHUB_TOKEN 可选，从 Deno.env 获取，用于提高 GitHub API 速率限制
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 从环境变量读取 Supabase 配置（绝不硬编码）
const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
// GitHub Token 可选，用于提高 API 速率限制（可能不存在）
const githubToken = Deno.env.get("GITHUB_TOKEN");

// CORS 响应头（虽然 Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// GitHub 仓库 URL 校验正则：https://github.com/owner/repo
const GITHUB_REPO_REGEX = /^https:\/\/github\.com\/([^/]+)\/([^/]+)\/?$/;

// APK MIME 类型
const APK_MIME_TYPE = "application/vnd.android.package-archive";

// 根据文件名推断 CPU 架构
function inferArch(filename: string): string | null {
  const lower = filename.toLowerCase();
  if (
    lower.includes("arm64-v8a") || lower.includes("aarch64") ||
    lower.includes("arm64")
  ) {
    return "arm64-v8a";
  }
  if (lower.includes("armeabi-v7a") || lower.includes("armv7")) {
    return "armeabi-v7a";
  }
  if (lower.includes("x86_64") || lower.includes("x64")) {
    return "x86_64";
  }
  if (lower.includes("x86")) {
    return "x86";
  }
  if (lower.includes("universal") || lower.includes("all")) {
    return "universal";
  }
  return null;
}

// 判断资产是否为 APK：content_type 为 android mime 或文件名以 .apk 结尾
function isApkAsset(asset: {
  content_type?: string;
  name?: string;
}): boolean {
  if (asset.content_type === APK_MIME_TYPE) {
    return true;
  }
  return !!asset.name && asset.name.toLowerCase().endsWith(".apk");
}

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  try {
    // 从 header 获取 device_token
    const deviceToken = req.headers.get("device_token");
    if (!deviceToken) {
      return new Response(
        JSON.stringify({
          error: "missing_device_token",
          message: "缺少 device_token",
        }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 解析请求 body
    const body = await req.json();
    const githubRepo: string | undefined = body?.github_repo;
    const category: string | undefined = body?.category;
    const name: string | undefined = body?.name;
    const description: string | undefined = body?.description;
    // 包名（可选，开源分类选择本地应用时传入，作为 apps 表额外信息）
    const packageName: string | undefined = body?.package_name;

    // 校验必填参数
    if (!githubRepo || typeof githubRepo !== "string") {
      return new Response(
        JSON.stringify({
          error: "invalid_input",
          message: "github_repo 为必填项",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!category || !["opensource", "genuine", "natural"].includes(category)) {
      return new Response(
        JSON.stringify({
          error: "invalid_input",
          message: "category 无效",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!name || typeof name !== "string" || name.trim().length === 0) {
      return new Response(
        JSON.stringify({
          error: "invalid_input",
          message: "name 为必填项",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 校验 github_repo URL 格式
    const match = githubRepo.trim().match(GITHUB_REPO_REGEX);
    if (!match) {
      return new Response(
        JSON.stringify({
          error: "invalid_repo_url",
          message: "GitHub 仓库地址格式无效，应为 https://github.com/owner/repo",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    const repoOwner = match[1];
    // 去除可能的 .git 后缀
    const repoName = match[2].replace(/\.git$/, "");

    // 使用 service_role key 创建 Supabase 客户端，绕过 RLS
    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    // 通过 device_token 查找 profile_id 作为 owner_id
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("id")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (profileError) {
      console.error("Failed to query profile:", profileError);
      return new Response(
        JSON.stringify({
          error: "profile_query_failed",
          message: "查询用户失败",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!profile) {
      return new Response(
        JSON.stringify({
          error: "profile_not_found",
          message: "用户不存在",
        }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    const ownerId = profile.id;

    // 在 apps 表 insert 记录（status='pending_fetch'）
    const { data: app, error: appInsertError } = await supabase
      .from("apps")
      .insert({
        owner_id: ownerId,
        name: name.trim(),
        package_name: packageName ?? null,
        github_repo: githubRepo.trim(),
        category: category,
        description: description ?? null,
        status: "pending_fetch",
      })
      .select("id, status")
      .single();

    if (appInsertError) {
      console.error("Failed to insert app:", appInsertError);
      return new Response(
        JSON.stringify({
          error: "insert_app_failed",
          message: "创建应用记录失败",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    const appId = app.id;

    // 调用 GitHub API 获取最新 Release
    // GitHub API 需要 User-Agent header
    const ghHeaders: Record<string, string> = {
      "User-Agent": "AppMarket-Blog/1.0",
      "Accept": "application/vnd.github+json",
    };
    if (githubToken) {
      ghHeaders["Authorization"] = `token ${githubToken}`;
    }

    const ghApiUrl =
      `https://api.github.com/repos/${repoOwner}/${repoName}/releases/latest`;
    let releaseData: { id?: number; tag_name?: string; body?: string; assets?: Array<{ id: number; name: string; content_type: string; size: number; browser_download_url: string }> } | null = null;
    let ghError: string | null = null;

    try {
      const ghResponse = await fetch(ghApiUrl, { headers: ghHeaders });
      if (ghResponse.status === 404) {
        // 仓库没有 Release
        ghError = "no_release";
      } else if (!ghResponse.ok) {
        ghError = `github_api_error_${ghResponse.status}`;
        const errText = await ghResponse.text();
        console.error("GitHub API error:", ghResponse.status, errText);
      } else {
        releaseData = await ghResponse.json();
      }
    } catch (e) {
      ghError = "github_api_network_error";
      console.error("GitHub API fetch failed:", e);
    }

    // 筛选 APK 资产
    let apkAssets: Array<{
      id: number;
      name: string;
      content_type: string;
      size: number;
      browser_download_url: string;
    }> = [];
    if (releaseData && Array.isArray(releaseData.assets)) {
      apkAssets = releaseData.assets.filter(isApkAsset);
    }

    // 若未找到 APK
    if (apkAssets.length === 0) {
      // 在 fetch_logs 表 insert 失败记录
      await supabase.from("fetch_logs").insert({
        app_id: appId,
        release_id: releaseData?.id ?? null,
        status: "failed",
        apk_count: 0,
        error_message: ghError ?? "no_apk_in_release",
      });

      // 返回错误，不删除 app 记录（保留待后续抓取）
      return new Response(
        JSON.stringify({
          error: "no_apk_found",
          message: "无法发布，请先在 GitHub 创建包含 APK 的 Release",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 找到 APK，为每个 APK 在 app_apks 表 insert 记录
    const releaseId = releaseData!.id ?? null;
    const version = releaseData!.tag_name ?? "";
    const releaseNotes = releaseData!.body ?? null;

    const apkInserts = apkAssets.map((asset) => ({
      app_id: appId,
      release_id: releaseId,
      version: version,
      filename: asset.name ?? "",
      size: asset.size ?? 0,
      arch: inferArch(asset.name ?? ""),
      github_asset_url: asset.browser_download_url ?? "",
      release_notes: releaseNotes,
    }));

    const { error: apkInsertError } = await supabase
      .from("app_apks")
      .insert(apkInserts);

    if (apkInsertError) {
      console.error("Failed to insert app_apks:", apkInsertError);
      // APK 插入失败，记录日志
      await supabase.from("fetch_logs").insert({
        app_id: appId,
        release_id: releaseId,
        status: "failed",
        apk_count: 0,
        error_message: `insert_apk_failed: ${apkInsertError.message}`,
      });
      return new Response(
        JSON.stringify({
          error: "insert_apk_failed",
          message: "保存 APK 信息失败",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 更新 apps 表的 latest_version 和 status
    // 对于开源分类，status 设为 'pending_review'（待自动审核）
    // 对于正版/自然，status 也设为 'pending_review'（待人工审核）
    const { error: appUpdateError } = await supabase
      .from("apps")
      .update({
        latest_version: version,
        status: "pending_review",
      })
      .eq("id", appId);

    if (appUpdateError) {
      console.error("Failed to update app:", appUpdateError);
    }

    // 在 fetch_logs 表 insert 成功记录
    await supabase.from("fetch_logs").insert({
      app_id: appId,
      release_id: releaseId,
      status: "success",
      apk_count: apkAssets.length,
      error_message: null,
    });

    // 若为开源分类，异步触发自动审核（不阻塞当前请求）
    // 正版/自然分类需人工审核，不触发自动审核
    if (category === "opensource") {
      const reviewUrl = `${supabaseUrl}/functions/v1/auto-review-opensource`;
      // 使用 service_role key 鉴权调用，fire-and-forget 不阻塞响应
      void fetch(reviewUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${supabaseServiceRoleKey}`,
          "apikey": supabaseServiceRoleKey,
        },
        body: JSON.stringify({ app_id: appId }),
      }).catch((e) => {
        // 触发失败不影响提交结果，app 仍保持 pending_review 可后续重审
        console.error("Failed to trigger auto-review-opensource:", e);
      });
    }

    // 返回结果
    return new Response(
      JSON.stringify({
        app_id: appId,
        status: "pending_review",
        apk_count: apkAssets.length,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({
        error: "internal_server_error",
        message: "内部服务器错误",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
