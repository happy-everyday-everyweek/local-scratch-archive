// ============================================================
// Edge Function: check-mirror-health
// 对应 spec Task 11 SubTask 11.3
//
// 功能：遍历所有 enabled 的 mirror_sites，对每个镜像站拼接出一个
// 测试 URL（基于已知的 GitHub Release 资源），发起 HEAD 请求（超时 5 秒），
// 记录响应状态码与延迟，并更新 mirror_sites.last_health_check 字段。
//
// 安全说明：
//   - service_role key 与 Supabase URL 均从 Deno.env 获取，不硬编码。
//   - 本函数仅服务端调用，客户端不可直接访问 service_role key。
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 健康检查使用的测试 GitHub Release 资源 URL（真实存在的 Release 资产，
// 用于验证镜像站能否正常代理 GitHub Release 下载）。
// 可通过环境变量 MIRROR_HEALTH_TEST_URL 覆盖。
const DEFAULT_TEST_GITHUB_URL =
  "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-linux-x86_64";

// HEAD 请求超时时间（毫秒）
const REQUEST_TIMEOUT_MS = 5000;

// 单条镜像站健康检查结果
interface MirrorHealthResult {
  id: string;
  name: string;
  site_type: string;
  test_url: string;
  status: number; // HTTP 状态码，0 表示请求失败（超时或网络错误）
  latency_ms: number; // 延迟（毫秒），-1 表示未能完成请求
  healthy: boolean; // 是否健康（status 为 200）
  error: string | null; // 错误信息
}

// 根据镜像站类型与模板拼接测试 URL
// prefix 型：将 {github_url} 替换为完整的 GitHub URL
// replace 型：将 {path} 替换为 GitHub URL 的路径部分
function buildTestUrl(
  urlTemplate: string,
  siteType: string,
  githubUrl: string,
): string {
  if (siteType === "prefix") {
    return urlTemplate.replace("{github_url}", githubUrl);
  }
  // replace 型：提取 githubUrl 中域名之后的路径
  const parsed = new URL(githubUrl);
  return urlTemplate.replace("{path}", parsed.pathname);
}

// 对单个 URL 发起 HEAD 请求，带超时控制
// 返回状态码、延迟与可能的错误信息
async function headRequest(
  url: string,
  timeoutMs: number,
): Promise<{ status: number; latencyMs: number; error: string | null }> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  const start = performance.now();
  try {
    const resp = await fetch(url, {
      method: "HEAD",
      signal: controller.signal,
      redirect: "follow",
    });
    const latencyMs = Math.round(performance.now() - start);
    return { status: resp.status, latencyMs, error: null };
  } catch (e) {
    const latencyMs = Math.round(performance.now() - start);
    const msg = e instanceof Error ? e.message : String(e);
    // AbortError 表示超时
    if (e instanceof DOMException && e.name === "AbortError") {
      return { status: 0, latencyMs, error: "timeout" };
    }
    return { status: 0, latencyMs, error: msg };
  } finally {
    clearTimeout(timeoutId);
  }
}

Deno.serve(async (req: Request) => {
  // 仅允许 POST 触发（可由 pg_cron 或管理员手动调用）
  if (req.method !== "POST" && req.method !== "GET") {
    return new Response(JSON.stringify({ error: "method not allowed" }), {
      status: 405,
      headers: { "content-type": "application/json" },
    });
  }

  // 从环境变量读取 Supabase 连接信息（不硬编码）
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({
        error: "missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY env",
      }),
      { status: 500, headers: { "content-type": "application/json" } },
    );
  }

  const testGithubUrl = Deno.env.get("MIRROR_HEALTH_TEST_URL") ??
    DEFAULT_TEST_GITHUB_URL;

  // 使用 service_role key 创建客户端，绕过 RLS 直接读写 mirror_sites
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: { persistSession: false },
  });

  // 查询所有 enabled 的镜像站
  const { data: mirrors, error: queryError } = await supabase
    .from("mirror_sites")
    .select("id, name, url_template, site_type, is_official")
    .eq("enabled", true);

  if (queryError) {
    return new Response(
      JSON.stringify({ error: "query mirror_sites failed", detail: queryError.message }),
      { status: 500, headers: { "content-type": "application/json" } },
    );
  }

  if (!mirrors || mirrors.length === 0) {
    return new Response(
      JSON.stringify({ summary: { total: 0, healthy: 0, unhealthy: 0 }, results: [] }),
      { status: 200, headers: { "content-type": "application/json" } },
    );
  }

  // 并发对所有镜像站发起 HEAD 请求
  const checkTasks = mirrors.map(async (mirror): Promise<MirrorHealthResult> => {
    const testUrl = buildTestUrl(
      mirror.url_template,
      mirror.site_type,
      testGithubUrl,
    );
    const { status, latencyMs, error } = await headRequest(
      testUrl,
      REQUEST_TIMEOUT_MS,
    );
    return {
      id: mirror.id,
      name: mirror.name,
      site_type: mirror.site_type,
      test_url: testUrl,
      status,
      latency_ms: latencyMs,
      healthy: status === 200,
      error,
    };
  });

  const results = await Promise.all(checkTasks);

  // 更新每个已检查镜像站的 last_health_check 时间戳
  // 注意：无论健康与否都更新时间戳，表示「已检查」；
  // 不自动禁用非 200 或超时的镜像站（部分镜像站不支持 HEAD 但支持 GET）
  const now = new Date().toISOString();
  const updatePromises = results.map((r) =>
    supabase
      .from("mirror_sites")
      .update({ last_health_check: now })
      .eq("id", r.id)
  );
  await Promise.all(updatePromises);

  // 汇总健康状态
  const healthy = results.filter((r) => r.healthy).length;
  const unhealthy = results.length - healthy;
  const summary = {
    total: results.length,
    healthy,
    unhealthy,
    checked_at: now,
    test_github_url: testGithubUrl,
    timeout_ms: REQUEST_TIMEOUT_MS,
  };

  return new Response(
    JSON.stringify({ summary, results }, null, 2),
    { status: 200, headers: { "content-type": "application/json" } },
  );
});
