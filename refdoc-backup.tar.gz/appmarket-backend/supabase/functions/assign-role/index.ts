// ============================================================
// Edge Function: assign-role
// 对应 spec Task 5 SubTask 5.1
//
// 功能：站长（owner）修改其他用户的角色，将 user 提升为 admin 或将 admin
// 撤销为 user。owner 转移需另外的逻辑，本函数不允许直接设置 owner。
//
// 流程：
//   1. 从请求 header 读取 device_token，通过 service_role 查找调用者 profile。
//   2. 校验调用者 role='owner'（仅站长可调用）。
//   3. 从 body 读取 target_profile_id 与 new_role。
//   4. 校验 new_role 只能是 'user' 或 'admin'。
//   5. 不允许修改自己的角色（target_profile_id != caller_profile_id）。
//   6. 不允许修改 owner 的角色（目标 profile.role != 'owner'）。
//   7. 更新目标 profile 的 role 字段。
//   8. 返回 { success, target_profile_id, new_role }。
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码。
//   - profiles.role 字段已撤销 anon/authenticated 的直接写权限（RLS），
//     必须经此 Edge Function 由服务端 service_role key 执行。
//   - 客户端仅持有 Publishable key，无法绕过此校验直接修改角色。
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 允许的角色值（不能直接设为 owner，owner 转移需另外的逻辑）
const ALLOWED_NEW_ROLES = new Set(["user", "admin"]);

// CORS 响应头（Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量（绝不硬编码 service_role key）
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 从 header 读取 device_token（由客户端 AuthInterceptor 自动附加）
  const deviceToken = req.headers.get("device_token");
  if (!deviceToken || deviceToken.trim().length === 0) {
    return new Response(
      JSON.stringify({ error: "device_token is required" }),
      {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 解析请求 body，获取 target_profile_id 与 new_role
  let targetProfileId: string | undefined;
  let newRole: string | undefined;
  try {
    const body = await req.json();
    targetProfileId = body?.target_profile_id;
    newRole = body?.new_role;
  } catch {
    return new Response(
      JSON.stringify({ error: "Invalid request body" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 校验 target_profile_id 参数
  if (
    !targetProfileId ||
    typeof targetProfileId !== "string" ||
    targetProfileId.trim().length === 0
  ) {
    return new Response(
      JSON.stringify({ error: "target_profile_id is required" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 校验 new_role 参数（只能为 user 或 admin，不能直接设为 owner）
  if (
    !newRole ||
    typeof newRole !== "string" ||
    !ALLOWED_NEW_ROLES.has(newRole)
  ) {
    return new Response(
      JSON.stringify({ error: "new_role must be 'user' or 'admin'" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 使用 service_role key 创建客户端，绕过 RLS 直接操作 profiles
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  try {
    // 通过 device_token 查找调用者 profile，并校验其 role='owner'
    const { data: caller, error: callerError } = await supabase
      .from("profiles")
      .select("id, role")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (callerError) {
      console.error("Failed to query caller profile:", callerError);
      return new Response(
        JSON.stringify({ error: "Failed to query caller profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (!caller) {
      return new Response(
        JSON.stringify({ error: "Caller profile not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 仅站长可调用
    if (caller.role !== "owner") {
      return new Response(
        JSON.stringify({ error: "Only owner can assign roles" }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 不允许修改自己的角色
    if (caller.id === targetProfileId) {
      return new Response(
        JSON.stringify({ error: "Cannot modify your own role" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 查找目标 profile，校验其存在且非 owner
    const { data: target, error: targetError } = await supabase
      .from("profiles")
      .select("id, role")
      .eq("id", targetProfileId)
      .maybeSingle();

    if (targetError) {
      console.error("Failed to query target profile:", targetError);
      return new Response(
        JSON.stringify({ error: "Failed to query target profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (!target) {
      return new Response(
        JSON.stringify({ error: "Target profile not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 不允许修改 owner 的角色
    if (target.role === "owner") {
      return new Response(
        JSON.stringify({ error: "Cannot modify owner role" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 更新目标 profile 的 role 字段（service_role 绕过 RLS 与字段级 revoke）
    const { error: updateError } = await supabase
      .from("profiles")
      .update({ role: newRole })
      .eq("id", targetProfileId);

    if (updateError) {
      console.error("Failed to update target profile role:", updateError);
      return new Response(
        JSON.stringify({ error: "Failed to update role" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        target_profile_id: targetProfileId,
        new_role: newRole,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
