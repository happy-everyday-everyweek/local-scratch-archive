// ============================================================
// Edge Function: daily-fetch-releases
// 对应 spec Task 7 SubTask 7.1
//
// 功能：每日定时抓取 GitHub Release，更新应用 APK 信息。
// 1. 查询所有 status in ('pending_fetch', 'approved') 的 apps
// 2. 对每个 app，调用 GitHub API 获取最新 Release
// 3. 筛选 APK 资产，检测新版本
// 4. 若有新版本：删除旧 app_apks 记录，插入新记录，更新 apps.latest_version
// 5. 记录 fetch_logs 日志（无论成功/失败/无更新）
// 6. 处理 GitHub API 速率限制（403 或 X-RateLimit-Remaining < 5 时停止）
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码
//   - GITHUB_TOKEN 可选，从 Deno.env 获取，用于提高 GitHub API 速率限制
//   - 数据库密码不出现在代码中
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 从环境变量读取 Supabase 配置（绝不硬编码）
const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
// GitHub Token 可选，用于提高 API 速率限制（可能不存在）
const githubToken = Deno.env.get("GITHUB_TOKEN");

// CORS 响应头（虽然 cron 调用不受 CORS 限制，保留以便浏览器手动触发调试）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

// GitHub 仓库 URL 校验正则：https://github.com/owner/repo
const GITHUB_REPO_REGEX = /^https:\/\/github\.com\/([^/]+)\/([^/]+)\/?$/;

// APK MIME 类型
const APK_MIME_TYPE = "application/vnd.android.package-archive";

// 速率限制阈值：剩余次数低于此值时停止抓取
const RATE_LIMIT_THRESHOLD = 5;

// 根据文件名推断 CPU 架构
function inferArch(filename: string): string | null {
  const lower = filename.toLowerCase();
  if (
    lower.includes("arm64-v8a") || lower.includes("aarch64") ||
    lower.includes("arm64")
  ) {
    return "arm64-v8a";
  }
  if (lower.includes("armeabi-v7a") || lower.includes("armv7")) {
    return "armeabi-v7a";
  }
  if (lower.includes("x86_64") || lower.includes("x64")) {
    return "x86_64";
  }
  if (lower.includes("x86")) {
    return "x86";
  }
  if (lower.includes("universal") || lower.includes("all")) {
    return "universal";
  }
  return null;
}

// 判断资产是否为 APK：content_type 为 android mime 或文件名以 .apk 结尾
function isApkAsset(asset: {
  content_type?: string;
  name?: string;
}): boolean {
  if (asset.content_type === APK_MIME_TYPE) {
    return true;
  }
  return !!asset.name && asset.name.toLowerCase().endsWith(".apk");
}

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 接受 POST（cron 触发）和 GET（手动测试）
  if (req.method !== "POST" && req.method !== "GET") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 使用 service_role key 创建 Supabase 客户端，绕过 RLS
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  // 查询所有待抓取（pending_fetch）和已发布（approved）的 apps
  const { data: apps, error: appsError } = await supabase
    .from("apps")
    .select("id, name, github_repo, status, latest_version")
    .in("status", ["pending_fetch", "approved"]);

  if (appsError) {
    console.error("Failed to query apps:", appsError);
    return new Response(
      JSON.stringify({
        error: "query_apps_failed",
        message: appsError.message,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 汇总结果
  const summary = {
    total: apps.length,
    success: 0,
    no_update: 0,
    no_release: 0,
    rate_limited: 0,
    errors: [] as Array<{ app_id: string; name: string; error: string }>,
  };

  // 是否因速率限制而停止后续抓取
  let rateLimited = false;

  // GitHub API 请求头（必须包含 User-Agent）
  const ghHeaders: Record<string, string> = {
    "User-Agent": "AppMarket-Blog/1.0",
    "Accept": "application/vnd.github+json",
  };
  if (githubToken) {
    ghHeaders["Authorization"] = `token ${githubToken}`;
  }

  // 遍历每个 app 进行抓取
  for (const app of apps) {
    // 若已触发速率限制，停止后续抓取
    if (rateLimited) break;

    try {
      // 校验 github_repo 是否存在
      if (!app.github_repo) {
        await supabase.from("fetch_logs").insert({
          app_id: app.id,
          release_id: null,
          status: "failed",
          apk_count: 0,
          error_message: "github_repo is null",
        });
        summary.errors.push({
          app_id: app.id,
          name: app.name,
          error: "github_repo is null",
        });
        continue;
      }

      // 从 github_repo 解析出 owner/repo
      const match = app.github_repo.trim().match(GITHUB_REPO_REGEX);
      if (!match) {
        await supabase.from("fetch_logs").insert({
          app_id: app.id,
          release_id: null,
          status: "failed",
          apk_count: 0,
          error_message: "invalid_repo_url",
        });
        summary.errors.push({
          app_id: app.id,
          name: app.name,
          error: "invalid_repo_url",
        });
        continue;
      }
      const repoOwner = match[1];
      // 去除可能的 .git 后缀
      const repoName = match[2].replace(/\.git$/, "");

      // 调用 GitHub API 获取最新 Release
      const ghApiUrl =
        `https://api.github.com/repos/${repoOwner}/${repoName}/releases/latest`;
      const ghResponse = await fetch(ghApiUrl, { headers: ghHeaders });

      // 处理 403（速率限制）：记录日志并停止后续抓取
      if (ghResponse.status === 403) {
        await supabase.from("fetch_logs").insert({
          app_id: app.id,
          release_id: null,
          status: "rate_limited",
          apk_count: 0,
          error_message: "github_api_403_rate_limited",
        });
        summary.rate_limited += 1;
        rateLimited = true;
        break;
      }

      // 检查 X-RateLimit-Remaining header，若低于阈值则标记停止（处理完当前 app 后停止）
      const rateLimitRemaining = parseInt(
        ghResponse.headers.get("X-RateLimit-Remaining") ?? "1000",
        10,
      );
      if (rateLimitRemaining < RATE_LIMIT_THRESHOLD) {
        rateLimited = true;
      }

      // 处理 404（无 Release）：记录日志，跳过
      if (ghResponse.status === 404) {
        await supabase.from("fetch_logs").insert({
          app_id: app.id,
          release_id: null,
          status: "no_release",
          apk_count: 0,
          error_message: null,
        });
        summary.no_release += 1;
        continue;
      }

      // 处理其他非 200 响应
      if (!ghResponse.ok) {
        const errText = await ghResponse.text();
        console.error(
          `GitHub API error for app ${app.id}:`,
          ghResponse.status,
          errText,
        );
        await supabase.from("fetch_logs").insert({
          app_id: app.id,
          release_id: null,
          status: "failed",
          apk_count: 0,
          error_message: `github_api_error_${ghResponse.status}`,
        });
        summary.errors.push({
          app_id: app.id,
          name: app.name,
          error: `github_api_error_${ghResponse.status}`,
        });
        continue;
      }

      // 解析 Release 数据
      const releaseData = await ghResponse.json();
      const releaseId = releaseData.id ?? null;
      const version = releaseData.tag_name ?? "";
      const releaseNotes = releaseData.body ?? null;

      // 筛选 APK 资产（content_type 为 android mime 或 filename 以 .apk 结尾）
      const apkAssets: Array<{
        id: number;
        name: string;
        content_type: string;
        size: number;
        browser_download_url: string;
      }> = Array.isArray(releaseData.assets)
        ? releaseData.assets.filter(isApkAsset)
        : [];

      // 检测新版本：release.id 不在 app_apks 表中 或 version != app.latest_version
      const { data: existingApks } = await supabase
        .from("app_apks")
        .select("id")
        .eq("app_id", app.id)
        .eq("release_id", releaseId)
        .limit(1);

      const isNewVersion =
        !existingApks || existingApks.length === 0 ||
        version !== app.latest_version;

      // 无新版本：记录日志
      if (!isNewVersion) {
        await supabase.from("fetch_logs").insert({
          app_id: app.id,
          release_id: releaseId,
          status: "no_update",
          apk_count: apkAssets.length,
          error_message: null,
        });
        summary.no_update += 1;
        continue;
      }

      // 发现新版本但无 APK 资产：记录失败日志
      if (apkAssets.length === 0) {
        await supabase.from("fetch_logs").insert({
          app_id: app.id,
          release_id: releaseId,
          status: "failed",
          apk_count: 0,
          error_message: "no_apk_in_release",
        });
        summary.errors.push({
          app_id: app.id,
          name: app.name,
          error: "no_apk_in_release",
        });
        continue;
      }

      // 删除该 app 旧的 app_apks 记录（避免重复）
      const { error: deleteError } = await supabase
        .from("app_apks")
        .delete()
        .eq("app_id", app.id);

      if (deleteError) {
        console.error("Failed to delete old app_apks:", deleteError);
        await supabase.from("fetch_logs").insert({
          app_id: app.id,
          release_id: releaseId,
          status: "failed",
          apk_count: 0,
          error_message: `delete_old_apks_failed: ${deleteError.message}`,
        });
        summary.errors.push({
          app_id: app.id,
          name: app.name,
          error: "delete_old_apks_failed",
        });
        continue;
      }

      // 为每个 APK insert app_apks 记录
      const apkInserts = apkAssets.map((asset) => ({
        app_id: app.id,
        release_id: releaseId,
        version: version,
        filename: asset.name ?? "",
        size: asset.size ?? 0,
        arch: inferArch(asset.name ?? ""),
        github_asset_url: asset.browser_download_url ?? "",
        release_notes: releaseNotes,
      }));

      const { error: apkInsertError } = await supabase
        .from("app_apks")
        .insert(apkInserts);

      if (apkInsertError) {
        console.error("Failed to insert app_apks:", apkInsertError);
        await supabase.from("fetch_logs").insert({
          app_id: app.id,
          release_id: releaseId,
          status: "failed",
          apk_count: 0,
          error_message: `insert_apk_failed: ${apkInsertError.message}`,
        });
        summary.errors.push({
          app_id: app.id,
          name: app.name,
          error: "insert_apk_failed",
        });
        continue;
      }

      // 更新 apps.latest_version
      // 若 app 之前是 pending_fetch，更新 status 为 pending_review
      const updateData: { latest_version: string; status?: string } = {
        latest_version: version,
      };
      if (app.status === "pending_fetch") {
        updateData.status = "pending_review";
      }

      const { error: appUpdateError } = await supabase
        .from("apps")
        .update(updateData)
        .eq("id", app.id);

      if (appUpdateError) {
        console.error("Failed to update app:", appUpdateError);
      }

      // 记录成功日志
      await supabase.from("fetch_logs").insert({
        app_id: app.id,
        release_id: releaseId,
        status: "success",
        apk_count: apkAssets.length,
        error_message: null,
      });
      summary.success += 1;
    } catch (err) {
      // 单个 app 失败不影响其他 app，记录错误日志后继续
      console.error(`Error processing app ${app.id}:`, err);
      await supabase.from("fetch_logs").insert({
        app_id: app.id,
        release_id: null,
        status: "failed",
        apk_count: 0,
        error_message: `unexpected_error: ${
          err instanceof Error ? err.message : String(err)
        }`,
      });
      summary.errors.push({
        app_id: app.id,
        name: app.name,
        error: "unexpected_error",
      });
    }
  }

  // 返回汇总
  return new Response(
    JSON.stringify(summary),
    {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    },
  );
});
