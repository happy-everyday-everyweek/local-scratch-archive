// ============================================================
// Edge Function: save-github-pat
// 对应 spec Task 8 SubTask 8.1
//
// 功能：将用户的 GitHub PAT 安全存入 Supabase Vault。
// 1. 接收 device_token（header）与 { pat }（body）
// 2. 使用 service_role key（从 Deno.env 获取，绝不硬编码）
// 3. 通过 device_token 查找 profile_id
// 4. 调用数据库函数 save_github_pat(p_profile_id, p_pat) 封装 vault 操作
//    - 若已有旧 secret，先删除
//    - 创建新 secret 并更新 profiles.github_pat_secret_id
// 5. 返回 { success: true }，PAT 不在响应中返回
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码
//   - 客户端仅持有 Publishable key，无法直接调用 vault
//   - PAT 明文仅存于 Vault，客户端不持久化明文
//   - 响应中不返回 PAT，仅返回 success 标志
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 从环境变量读取 Supabase 配置（绝不硬编码）
const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

// CORS 响应头（虽然 Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  try {
    // 从 header 获取 device_token
    const deviceToken = req.headers.get("device_token");
    if (!deviceToken) {
      return new Response(
        JSON.stringify({
          error: "missing_device_token",
          message: "缺少 device_token",
        }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 解析请求 body
    const body = await req.json();
    const pat: string | undefined = body?.pat;

    // 校验 PAT 非空
    if (!pat || typeof pat !== "string" || pat.trim().length === 0) {
      return new Response(
        JSON.stringify({
          error: "invalid_input",
          message: "pat 为必填项",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 使用 service_role key 创建 Supabase 客户端，绕过 RLS
    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    // 通过 device_token 查找 profile_id
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("id")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (profileError) {
      console.error("Failed to query profile:", profileError);
      return new Response(
        JSON.stringify({
          error: "profile_query_failed",
          message: "查询用户失败",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }
    if (!profile) {
      return new Response(
        JSON.stringify({
          error: "profile_not_found",
          message: "用户不存在",
        }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 调用数据库函数 save_github_pat 封装 vault 操作
    // 该函数为 security definer，会先删除旧 secret 再创建新 secret
    const { error: rpcError } = await supabase.rpc("save_github_pat", {
      p_profile_id: profile.id,
      p_pat: pat.trim(),
    });

    if (rpcError) {
      console.error("Failed to save GitHub PAT:", rpcError);
      return new Response(
        JSON.stringify({
          error: "save_pat_failed",
          message: "保存 GitHub 密钥失败",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 返回成功，PAT 不在响应中返回
    return new Response(
      JSON.stringify({ success: true }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({
        error: "internal_server_error",
        message: "内部服务器错误",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
