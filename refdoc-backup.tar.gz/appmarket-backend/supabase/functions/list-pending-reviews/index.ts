// ============================================================
// Edge Function: list-pending-reviews
// 对应 spec Task 10 SubTask 10.4
//
// 功能：查询待人工审核的应用列表，供管理员/站长在审核界面查看。
//   1. 接收 POST 请求，header 含 device_token
//   2. 使用 service_role key（从 Deno.env 获取，绝不硬编码）
//   3. 通过 device_token 查找调用者，校验 role in ('admin', 'owner')
//   4. 查询 status='pending_review' 的 apps，关联 profiles 获取上传者信息
//   5. 返回 apps 列表（id, name, category, latest_version, github_repo,
//      owner_fingerprint, created_at）
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码。
//   - RLS 限制普通用户只能读 status in ('approved','virus_safe') 或自己 owner_id 的 app，
//     必须经此 Edge Function 由服务端 service_role key 执行才能获取所有 pending_review 的 app。
//   - 不返回 device_token 等敏感字段，仅返回上传者的设备指纹（脱敏由客户端处理）。
//   - 客户端仅持有 Publishable key，无法绕过此校验直接读取待审核应用列表。
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// CORS 响应头（Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量（绝不硬编码 service_role key）
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 从 header 读取 device_token（由客户端 AuthInterceptor 自动附加）
  const deviceToken = req.headers.get("device_token");
  if (!deviceToken || deviceToken.trim().length === 0) {
    return new Response(
      JSON.stringify({ error: "device_token is required" }),
      {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 解析请求 body（可选，预留分页参数扩展）
  try {
    const text = await req.text();
    if (text && text.trim().length > 0) {
      JSON.parse(text);
    }
  } catch {
    return new Response(
      JSON.stringify({ error: "Invalid request body" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 使用 service_role key 创建客户端，绕过 RLS 直接读取所有 pending_review 的 app
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  try {
    // 通过 device_token 查找调用者 profile，并校验其角色
    const { data: caller, error: callerError } = await supabase
      .from("profiles")
      .select("id, role")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (callerError) {
      console.error("Failed to query caller profile:", callerError);
      return new Response(
        JSON.stringify({ error: "Failed to query caller profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (!caller) {
      return new Response(
        JSON.stringify({ error: "Caller profile not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 仅站长/管理员可调用
    if (caller.role !== "owner" && caller.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Only owner or admin can list pending reviews" }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 查询所有 status='pending_review' 的 app，关联 profiles 获取上传者信息
    // 不返回 device_token 等敏感字段，仅返回上传者的设备指纹
    const { data: apps, error: listError } = await supabase
      .from("apps")
      .select(
        "id, name, category, latest_version, github_repo, created_at, owner_id, profiles:owner_id(device_fingerprint)",
      )
      .eq("status", "pending_review")
      .order("created_at", { ascending: true });

    if (listError) {
      console.error("Failed to list pending_review apps:", listError);
      return new Response(
        JSON.stringify({ error: "Failed to list pending reviews" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 整理返回数据：将嵌套的 profiles 信息扁平化为 owner_fingerprint
    const result = (apps ?? []).map((row: any) => ({
      id: row.id,
      name: row.name,
      category: row.category,
      latest_version: row.latest_version ?? null,
      github_repo: row.github_repo ?? null,
      owner_fingerprint: row.profiles?.device_fingerprint ?? null,
      created_at: row.created_at,
    }));

    return new Response(
      JSON.stringify({
        apps: result,
        total: result.length,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
