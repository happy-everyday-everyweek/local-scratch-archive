// ============================================================
// Edge Function: publish-content
// 对应 spec Task 17 SubTask 17.1
//
// 功能：站长/管理员发布博客内容（文章 / 推荐 / 主题）。
//   1. 接收 POST 请求，header 含 device_token，body 含
//      { type, title, cover, content, app_ids, tags }
//   2. 使用 service_role key（从 Deno.env 获取，绝不硬编码）
//   3. 通过 device_token 查找调用者，校验 role in ('admin', 'owner')
//   4. 校验 type in ('article', 'recommend', 'theme')
//   5. 校验 title 非空
//   6. recommend 和 theme 类型要求 app_ids 非空（至少关联一个应用）
//      article 类型 app_ids 强制为空数组
//   7. 在 articles 表 insert 记录（author_id 为调用者 profile_id）
//   8. 返回 { success: true, article_id }
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码。
//   - articles 表已撤销 anon/authenticated 的直接写权限（RLS 未创建
//     insert/update/delete 策略，默认拒绝），必须经此 Edge Function
//     由服务端 service_role key 执行。
//   - 客户端仅持有 Publishable key，无法绕过此校验直接写入 articles。
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 允许的文章类型
const ALLOWED_TYPES = new Set(["article", "recommend", "theme"]);

// 需要关联应用（app_ids 非空）的类型
const TYPES_REQUIRING_APPS = new Set(["recommend", "theme"]);

// CORS 响应头（Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量（绝不硬编码 service_role key）
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 从 header 读取 device_token（由客户端 AuthInterceptor 自动附加）
  const deviceToken = req.headers.get("device_token");
  if (!deviceToken || deviceToken.trim().length === 0) {
    return new Response(
      JSON.stringify({ error: "device_token is required" }),
      {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 解析请求 body
  let type: string | undefined;
  let title: string | undefined;
  let cover: string | undefined;
  let content: string | undefined;
  let appIds: unknown;
  let tags: unknown;
  try {
    const body = await req.json();
    type = body?.type;
    title = body?.title;
    cover = body?.cover;
    content = body?.content;
    appIds = body?.app_ids;
    tags = body?.tags;
  } catch {
    return new Response(
      JSON.stringify({ error: "Invalid request body" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 校验 type 参数
  if (!type || typeof type !== "string" || !ALLOWED_TYPES.has(type)) {
    return new Response(
      JSON.stringify({ error: "type must be 'article', 'recommend' or 'theme'" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 校验 title 非空
  if (!title || typeof title !== "string" || title.trim().length === 0) {
    return new Response(
      JSON.stringify({ error: "title is required" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 规整 cover：非字符串视为 null
  const coverValue =
    typeof cover === "string" && cover.trim().length > 0 ? cover.trim() : null;

  // 规整 content：数据库 content 字段为 NOT NULL，缺省时使用空字符串
  const contentValue = typeof content === "string" ? content : "";

  // 规整 app_ids：必须是字符串数组
  const appIdsArray = Array.isArray(appIds)
    ? appIds.filter((id) => typeof id === "string" && id.trim().length > 0)
    : [];

  // recommend / theme 类型要求至少关联一个应用
  if (TYPES_REQUIRING_APPS.has(type) && appIdsArray.length === 0) {
    return new Response(
      JSON.stringify({
        error: "app_ids must contain at least one app for recommend/theme type",
      }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // article 类型强制 app_ids 为空数组（文章不关联应用）
  const finalAppIds = type === "article" ? [] : appIdsArray;

  // 规整 tags：必须是字符串数组
  const tagsArray = Array.isArray(tags)
    ? tags.filter((t) => typeof t === "string" && t.trim().length > 0)
    : [];

  // 使用 service_role key 创建客户端，绕过 RLS 直接写入 articles
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  try {
    // 通过 device_token 查找调用者 profile，并校验其角色
    const { data: caller, error: callerError } = await supabase
      .from("profiles")
      .select("id, role")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (callerError) {
      console.error("Failed to query caller profile:", callerError);
      return new Response(
        JSON.stringify({ error: "Failed to query caller profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (!caller) {
      return new Response(
        JSON.stringify({ error: "Caller profile not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 仅站长/管理员可发布内容
    if (caller.role !== "owner" && caller.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Only owner or admin can publish content" }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 在 articles 表 insert 记录，author_id 为调用者 profile_id
    const insertPayload = {
      author_id: caller.id,
      type,
      title: title.trim(),
      cover: coverValue,
      content: contentValue,
      app_ids: finalAppIds,
      tags: tagsArray,
    };

    const { data: inserted, error: insertError } = await supabase
      .from("articles")
      .insert(insertPayload)
      .select("id")
      .single();

    if (insertError) {
      console.error("Failed to insert article:", insertError);
      return new Response(
        JSON.stringify({ error: "Failed to publish content" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        article_id: inserted.id,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
