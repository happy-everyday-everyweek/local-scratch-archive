// ============================================================
// Edge Function: auto-review-opensource
// 对应 spec Task 9 SubTask 9.1 / 9.2 / 9.3
//
// 功能：对开源分类应用执行自动审核。
//   1. 接收 POST 请求，body 可包含 { app_id }（不传则遍历所有待审核的开源 app）
//   2. 使用 service_role key（从 Deno.env 获取，绝不硬编码）
//   3. 可选使用 GITHUB_TOKEN 环境变量提高 GitHub API 速率限制
//   4. 对每个 app：
//      a. 从 github_repo 解析 owner/repo
//      b. 调用 GitHub API https://api.github.com/repos/{owner}/{repo}
//         （包含 User-Agent header，若有 GITHUB_TOKEN 则附加 Authorization）
//      c. 获取 stargazers_count（Star 数）与 size（仓库大小，单位 KB）
//      d. 获取该 app 最新 APK 的 size（从 app_apks 表取最大的一条，单位字节）
//      e. 三级判定逻辑：
//         - 仓库大小（KB 转 bytes）< APK 大小 × 0.5：review_level='failed'，status='rejected'
//         - 否则 Star < 10000：review_level='passed'，status='approved'
//         - 否则（Star >= 10000）：review_level='premium'，status='approved'
//      f. 更新 apps 表的 review_level 与 status
//      g. 若审核未通过（failed）：向 owner_id 发送站内消息
//   5. GitHub API 失败时记录错误，不更新审核状态（保持 pending_review）
//   6. 返回 { reviewed, passed, premium, failed, errors }
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码
//   - 客户端仅持有 Publishable key，无法直接修改 status/review_level（RLS 限制）
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 从环境变量读取 Supabase 配置（绝不硬编码）
const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
// GitHub Token 可选，用于提高 API 速率限制（可能不存在）
const githubToken = Deno.env.get("GITHUB_TOKEN");

// CORS 响应头（虽然 Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// GitHub 仓库 URL 校验正则：https://github.com/owner/repo
const GITHUB_REPO_REGEX = /^https:\/\/github\.com\/([^/]+)\/([^/]+)\/?$/;

// Star 数优质分界
const PREMIUM_STAR_THRESHOLD = 10000;
// 仓库大小与 APK 大小的判定比例（仓库大小 < APK × 0.5 视为未通过）
const REPO_SIZE_RATIO = 0.5;

// 审核结果类型
type ReviewOutcome = "passed" | "premium" | "failed" | "error";

// 单个 app 的审核结果
interface AppReviewResult {
  appId: string;
  outcome: ReviewOutcome;
}

// 从 github_repo 解析 owner 与 repo
function parseGithubRepo(
  githubRepo: string,
): { owner: string; repo: string } | null {
  const match = githubRepo.trim().match(GITHUB_REPO_REGEX);
  if (!match) {
    return null;
  }
  const owner = match[1];
  // 去除可能的 .git 后缀
  const repo = match[2].replace(/\.git$/, "");
  return { owner, repo };
}

// 调用 GitHub API 获取仓库信息（Star 数与仓库大小）
async function fetchGithubRepoInfo(
  owner: string,
  repo: string,
): Promise<{ stargazersCount: number; sizeKb: number } | null> {
  // GitHub API 需要 User-Agent header
  const ghHeaders: Record<string, string> = {
    "User-Agent": "AppMarket-Blog/1.0",
    "Accept": "application/vnd.github+json",
  };
  if (githubToken) {
    ghHeaders["Authorization"] = `token ${githubToken}`;
  }

  const ghApiUrl = `https://api.github.com/repos/${owner}/${repo}`;
  try {
    const ghResponse = await fetch(ghApiUrl, { headers: ghHeaders });
    if (!ghResponse.ok) {
      const errText = await ghResponse.text();
      console.error(
        "GitHub API error:",
        ghResponse.status,
        errText,
      );
      return null;
    }
    const data = await ghResponse.json();
    return {
      stargazersCount: data?.stargazers_count ?? 0,
      sizeKb: data?.size ?? 0,
    };
  } catch (e) {
    console.error("GitHub API fetch failed:", e);
    return null;
  }
}

// 审核单个 app，返回审核结果
async function reviewApp(
  supabase: ReturnType<typeof createClient>,
  app: { id: string; owner_id: string; name: string; github_repo: string | null },
): Promise<AppReviewResult> {
  const appId = app.id;

  // 校验 github_repo 存在且格式正确
  if (!app.github_repo) {
    console.error(`App ${appId} has no github_repo, skip`);
    return { appId, outcome: "error" };
  }
  const parsed = parseGithubRepo(app.github_repo);
  if (!parsed) {
    console.error(
      `App ${appId} has invalid github_repo: ${app.github_repo}, skip`,
    );
    return { appId, outcome: "error" };
  }

  // 调用 GitHub API 获取仓库信息
  // 失败时记录错误，不更新审核状态（保持 pending_review）
  const repoInfo = await fetchGithubRepoInfo(parsed.owner, parsed.repo);
  if (!repoInfo) {
    return { appId, outcome: "error" };
  }

  // 获取该 app 最新 APK 的 size（从 app_apks 表取最大的一条，单位字节）
  const { data: apkRow, error: apkError } = await supabase
    .from("app_apks")
    .select("size")
    .eq("app_id", appId)
    .order("size", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (apkError) {
    console.error(`Failed to query app_apks for app ${appId}:`, apkError);
    return { appId, outcome: "error" };
  }
  if (!apkRow) {
    // 没有 APK 记录，无法进行大小比对，保持 pending_review
    console.error(`App ${appId} has no APK record, skip`);
    return { appId, outcome: "error" };
  }

  const apkSizeBytes: number = apkRow.size ?? 0;
  // 仓库大小由 KB 转为 bytes
  const repoSizeBytes = repoInfo.sizeKb * 1024;

  // 三级判定逻辑
  let reviewLevel: "failed" | "passed" | "premium";
  let status: "rejected" | "approved";

  if (repoSizeBytes < apkSizeBytes * REPO_SIZE_RATIO) {
    // 仓库大小不合理（远小于 APK 大小），未通过
    reviewLevel = "failed";
    status = "rejected";
  } else if (repoInfo.stargazersCount < PREMIUM_STAR_THRESHOLD) {
    // Star < 10000，通过
    reviewLevel = "passed";
    status = "approved";
  } else {
    // Star >= 10000，优质
    reviewLevel = "premium";
    status = "approved";
  }

  // 更新 apps 表的 review_level 与 status
  const { error: updateError } = await supabase
    .from("apps")
    .update({
      review_level: reviewLevel,
      status: status,
    })
    .eq("id", appId);

  if (updateError) {
    console.error(`Failed to update app ${appId}:`, updateError);
    return { appId, outcome: "error" };
  }

  // 若审核未通过（failed）：向 owner_id 发送站内消息
  if (reviewLevel === "failed") {
    const messageContent =
      `您的应用 ${app.name} 未通过开源审核，原因：仓库大小不合理（远小于 APK 大小）。请确保仓库包含完整源码。`;
    const { error: msgError } = await supabase
      .from("messages")
      .insert({
        recipient_id: app.owner_id,
        title: "应用审核未通过",
        content: messageContent,
        type: "review_failed",
        related_app_id: appId,
      });

    if (msgError) {
      // 消息发送失败不回滚审核结果，仅记录错误
      console.error(
        `Failed to send review_failed message for app ${appId}:`,
        msgError,
      );
    }
  }

  return { appId, outcome: reviewLevel };
}

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 解析请求 body（可为空，body 也可不包含 app_id）
  let body: { app_id?: string } = {};
  try {
    const text = await req.text();
    if (text && text.trim().length > 0) {
      body = JSON.parse(text);
    }
  } catch (e) {
    return new Response(
      JSON.stringify({ error: "Invalid request body" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  const appId = body?.app_id;

  // 使用 service_role key 创建 Supabase 客户端，绕过 RLS
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  try {
    // 确定待审核的 app 列表
    let appsToReview: Array<{
      id: string;
      owner_id: string;
      name: string;
      github_repo: string | null;
    }> = [];

    if (appId) {
      // 审核单个 app（仅限开源分类且待审核）
      const { data: app, error: appError } = await supabase
        .from("apps")
        .select("id, owner_id, name, github_repo, category, status")
        .eq("id", appId)
        .maybeSingle();

      if (appError) {
        console.error("Failed to query app:", appError);
        return new Response(
          JSON.stringify({
            error: "Failed to query app",
            detail: appError.message,
          }),
          {
            status: 500,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }
      if (!app) {
        return new Response(
          JSON.stringify({ error: "App not found" }),
          {
            status: 404,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }
      // 仅开源分类且待审核状态才进行自动审核
      if (app.category !== "opensource" || app.status !== "pending_review") {
        return new Response(
          JSON.stringify({
            reviewed: 0,
            passed: 0,
            premium: 0,
            failed: 0,
            errors: 0,
            message: "App is not opensource or not in pending_review status",
          }),
          {
            status: 200,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }
      appsToReview = [app];
    } else {
      // 查询所有 category='opensource' AND status='pending_review' 的 app
      const { data: apps, error: appsError } = await supabase
        .from("apps")
        .select("id, owner_id, name, github_repo")
        .eq("category", "opensource")
        .eq("status", "pending_review");

      if (appsError) {
        console.error("Failed to query pending_review apps:", appsError);
        return new Response(
          JSON.stringify({
            error: "Failed to query pending_review apps",
            detail: appsError.message,
          }),
          {
            status: 500,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }
      appsToReview = apps ?? [];
    }

    // 逐一审核
    const results: AppReviewResult[] = [];
    for (const app of appsToReview) {
      const result = await reviewApp(supabase, app);
      results.push(result);
    }

    // 统计结果
    const passed = results.filter((r) => r.outcome === "passed").length;
    const premium = results.filter((r) => r.outcome === "premium").length;
    const failed = results.filter((r) => r.outcome === "failed").length;
    const errors = results.filter((r) => r.outcome === "error").length;
    const reviewed = results.length;

    return new Response(
      JSON.stringify({
        reviewed,
        passed,
        premium,
        failed,
        errors,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
