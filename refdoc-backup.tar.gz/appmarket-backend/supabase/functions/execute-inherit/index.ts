// ============================================================
// Edge Function: execute-inherit
// 对应 spec Task 4 SubTask 4.2
//
// 功能：在新设备上执行账号继承，将原账号所有数据转移到新设备账号。
//
// 流程：
//   1. 从请求 header 读取新设备的 device_token，查找 target profile。
//   2. 从 body 读取继承码 code。
//   3. 调用 RPC execute_inherit(code, target_profile_id) 在单个事务内完成：
//      - 校验继承码（存在 / 未使用 / 未过期 / 非自继承）
//      - 转移 apps / articles / download_logs / messages /
//        user_settings / view_history / github_pat_secret_id
//      - 标记继承码为已使用
//      - 删除 source profile（级联清理残留）
//   4. 返回 { success, message }。
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码。
//   - 事务由 Postgres RPC 函数保证原子性，避免数据不一致。
//   - 客户端仅持有 Publishable key，无法直接操作转移逻辑。
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// CORS 响应头
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量（绝不硬编码 service_role key）
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 从 header 读取新设备的 device_token（由客户端 AuthInterceptor 自动附加）
  const deviceToken = req.headers.get("device_token");
  if (!deviceToken || deviceToken.trim().length === 0) {
    return new Response(
      JSON.stringify({ error: "device_token is required" }),
      {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 解析请求 body，获取继承码
  let code: string | undefined;
  try {
    const body = await req.json();
    code = body?.code;
  } catch {
    return new Response(
      JSON.stringify({ error: "Invalid request body" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  if (!code || typeof code !== "string" || code.trim().length === 0) {
    return new Response(
      JSON.stringify({ error: "code is required" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 使用 service_role key 创建客户端，绕过 RLS
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  try {
    // 通过 device_token 查找新设备的 profile（target_profile_id）
    const { data: targetProfile, error: targetError } = await supabase
      .from("profiles")
      .select("id")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (targetError) {
      console.error("Failed to query target profile:", targetError);
      return new Response(
        JSON.stringify({ error: "Failed to query target profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (!targetProfile) {
      return new Response(
        JSON.stringify({ error: "Target profile not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    const targetProfileId = targetProfile.id;

    // 调用 RPC execute_inherit，在单个事务内完成所有转移
    // 事务内会校验继承码有效性、转移数据、标记已使用、删除 source profile
    const { data: rpcResult, error: rpcError } = await supabase
      .rpc("execute_inherit", {
        p_code: code.trim(),
        p_target_profile_id: targetProfileId,
      });

    if (rpcError) {
      console.error("RPC execute_inherit failed:", rpcError);
      return new Response(
        JSON.stringify({
          error: "Inherit failed",
          detail: rpcError.message,
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // RPC 返回 jsonb: { success, error? / message? }
    const result = rpcResult as {
      success?: boolean;
      error?: string;
      message?: string;
    };

    if (!result || result.success !== true) {
      const errMsg = result?.error ?? "继承失败";
      return new Response(
        JSON.stringify({ error: errMsg }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    return new Response(
      JSON.stringify({ success: true, message: "继承成功" }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
