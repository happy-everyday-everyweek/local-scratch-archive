// ============================================================
// Edge Function: list-profiles
// 对应 spec Task 5 SubTask 5.2
//
// 功能：返回所有 profiles 列表，供站长/管理员在管理界面查看。
//
// 流程：
//   1. 从请求 header 读取 device_token，通过 service_role 查找调用者 profile。
//   2. 校验调用者 role in ('owner', 'admin')（仅站长/管理员可调用）。
//   3. 解析 body 中的分页参数 offset / limit（默认 0 / 20，limit 上限 100）。
//   4. 查询所有 profiles，仅返回 id / device_fingerprint / role / created_at，
//      不返回 device_token 等敏感字段。
//   5. 返回 { profiles, total, offset, limit }。
//
// 安全说明：
//   - service_role key 从 Deno.env 获取，绝不硬编码。
//   - RLS 限制普通用户只能读自己的 profile，必须经此 Edge Function
//     由服务端 service_role key 执行才能获取所有用户列表。
//   - 不返回 device_token 等敏感字段，避免泄露会话凭证。
//   - 客户端仅持有 Publishable key，无法绕过此校验直接读取所有 profile。
// ============================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 默认分页参数与上限
const DEFAULT_OFFSET = 0;
const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;

// CORS 响应头（Android 客户端不受 CORS 限制，保留以便调试与浏览器调用）
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, device_token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 校验环境变量（绝不硬编码 service_role key）
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return new Response(
      JSON.stringify({ error: "Server is not configured properly" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 仅接受 POST 请求
  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 从 header 读取 device_token（由客户端 AuthInterceptor 自动附加）
  const deviceToken = req.headers.get("device_token");
  if (!deviceToken || deviceToken.trim().length === 0) {
    return new Response(
      JSON.stringify({ error: "device_token is required" }),
      {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }

  // 解析请求 body，获取分页参数（可选）
  let offset = DEFAULT_OFFSET;
  let limit = DEFAULT_LIMIT;
  try {
    const body = await req.json();
    if (typeof body?.offset === "number" && Number.isFinite(body.offset) && body.offset >= 0) {
      offset = Math.floor(body.offset);
    }
    if (typeof body?.limit === "number" && Number.isFinite(body.limit) && body.limit > 0) {
      limit = Math.floor(body.limit);
    }
  } catch {
    // body 为空或非 JSON 时使用默认分页参数
  }
  // 限制 limit 上限，防止一次拉取过多数据
  limit = Math.min(limit, MAX_LIMIT);

  // 使用 service_role key 创建客户端，绕过 RLS 直接读取所有 profiles
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  try {
    // 通过 device_token 查找调用者 profile，并校验其角色
    const { data: caller, error: callerError } = await supabase
      .from("profiles")
      .select("id, role")
      .eq("device_token", deviceToken)
      .maybeSingle();

    if (callerError) {
      console.error("Failed to query caller profile:", callerError);
      return new Response(
        JSON.stringify({ error: "Failed to query caller profile" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (!caller) {
      return new Response(
        JSON.stringify({ error: "Caller profile not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 仅站长/管理员可调用
    if (caller.role !== "owner" && caller.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Only owner or admin can list profiles" }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 查询所有 profiles，仅返回非敏感字段
    // 不返回 device_token / github_pat_secret_id 等敏感字段
    const { data: profiles, error: listError } = await supabase
      .from("profiles")
      .select("id, device_fingerprint, role, created_at")
      .order("created_at", { ascending: true })
      .range(offset, offset + limit - 1);

    if (listError) {
      console.error("Failed to list profiles:", listError);
      return new Response(
        JSON.stringify({ error: "Failed to list profiles" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // 查询总数（用于客户端判断是否还有更多数据）
    const { count, error: countError } = await supabase
      .from("profiles")
      .select("id", { count: "exact", head: true });

    if (countError) {
      console.error("Failed to count profiles:", countError);
      return new Response(
        JSON.stringify({ error: "Failed to count profiles" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    return new Response(
      JSON.stringify({
        profiles: profiles ?? [],
        total: count ?? 0,
        offset,
        limit,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
