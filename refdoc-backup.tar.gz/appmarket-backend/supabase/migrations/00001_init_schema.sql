-- ============================================================
-- 初始化 migration：应用市场 + 博客 Android 应用后端
-- 创建所有数据库表、触发器、RLS 策略
-- 本文件对应 spec Task 2，包含 SubTask 2.1 ~ 2.7
-- ============================================================

-- pgcrypto 扩展（提供 gen_random_uuid）
create extension if not exists pgcrypto;

-- ============================================================
-- SubTask 2.1: profiles 表
-- ============================================================
create table public.profiles (
  id uuid primary key default gen_random_uuid(),
  device_fingerprint text not null unique,
  role text not null default 'user' check (role in ('user', 'admin', 'owner')),  -- 角色：user=普通用户 / admin=管理员 / owner=站长
  device_token text not null default gen_random_uuid(),
  github_pat_secret_id uuid,  -- 指向 vault.decrypted_secrets 的 id（GitHub PAT 加密存储引用）
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 触发器函数：首个创建的 profile 自动成为 owner（站长）
-- 在 insert 前检查是否是第一条记录，如果是则 role='owner'
create or replace function public.handle_new_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if (select count(*) from public.profiles) = 0 then
    new.role := 'owner';
  end if;
  return new;
end;
$$;

create trigger trg_profiles_before_insert
before insert on public.profiles
for each row execute function public.handle_new_profile();

-- 辅助函数：通过请求头中的 device_token 获取当前请求的 profile id
-- 设备指纹账号体系（非 Supabase Auth），通过 request header 中的 device_token 匹配用户
-- security definer 以绕过 RLS 避免递归
create or replace function public.get_current_profile_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select p.id
  from public.profiles p
  where p.device_token = nullif(current_setting('request.header.device_token', true), '')::text
  limit 1;
$$;

-- ============================================================
-- SubTask 2.2: apps 表
-- ============================================================
create table public.apps (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  package_name text,
  github_repo text,  -- GitHub 仓库地址，如 https://github.com/user/repo
  -- 分类：opensource=开源 / genuine=正版 / natural=对正版的 APK 进行的自然化
  category text not null check (category in ('opensource', 'genuine', 'natural')),
  -- 状态：pending_fetch=待抓取 / pending_review=待审核 / approved=已通过 / virus_safe=报毒但安全 / rejected=已拒绝
  status text not null default 'pending_fetch' check (status in ('pending_fetch', 'pending_review', 'approved', 'virus_safe', 'rejected')),
  -- 审核等级（仅开源分类）：failed=未通过 / passed=通过 / premium=优质
  review_level text check (review_level in ('failed', 'passed', 'premium')),
  virus_safe_reason text,  -- 报毒但安全的原因解释
  icon_url text,
  description text,
  latest_version text,
  screenshots text[],  -- 截图 URL 数组
  tags text[],  -- 标签数组
  download_count integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- SubTask 2.3: app_apks 表
-- ============================================================
create table public.app_apks (
  id uuid primary key default gen_random_uuid(),
  app_id uuid not null references public.apps(id) on delete cascade,
  release_id bigint,  -- GitHub Release ID
  version text not null,
  filename text not null,
  size bigint not null,  -- 字节
  arch text,  -- 推断的架构：arm64-v8a / armeabi-v7a / x86 / x86_64 / universal
  github_asset_url text not null,  -- GitHub 原始 asset URL
  release_notes text,
  created_at timestamptz not null default now()
);
create index idx_app_apks_app_id on public.app_apks(app_id);

-- ============================================================
-- SubTask 2.4: mirror_sites 表 + 预置数据
-- ============================================================
create table public.mirror_sites (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  url_template text not null,  -- URL 模板，前缀代理型使用 {github_url} 占位符，域名替换型使用 {path} 占位符
  -- 类型：prefix=前缀代理型（在 GitHub URL 前加镜像域名）/ replace=域名替换型（替换 github.com）
  site_type text not null check (site_type in ('prefix', 'replace')),
  enabled boolean not null default true,
  priority integer not null default 0,
  last_health_check timestamptz,
  is_official boolean not null default false  -- 是否为 GitHub 原始链接
);

-- 预置镜像站数据
-- 注意：以下 URL 模板中的域名为占位符，实际域名需要在 Task 11 中逐一验证后更新
-- 前缀代理型 url_template 格式：https://域名/{github_url}
-- 域名替换型 url_template 格式：https://github.com{path}
insert into public.mirror_sites (name, url_template, site_type, is_official, priority) values
  -- GitHub 原始链接（域名替换型，官方源，优先级最高）
  ('GitHub', 'https://github.com{path}', 'replace', true, 100),
  -- 前缀代理型镜像站
  ('Tbedu', 'https://tbedu.mirror/{github_url}', 'prefix', false, 0),
  ('Mrhjx', 'https://mrhjx.mirror/{github_url}', 'prefix', false, 0),
  ('Cxkpro', 'https://cxkpro.mirror/{github_url}', 'prefix', false, 0),
  ('Xxooo', 'https://xxooo.mirror/{github_url}', 'prefix', false, 0),
  ('Nxnow', 'https://nxnow.mirror/{github_url}', 'prefix', false, 0),
  ('Chjina', 'https://chjina.mirror/{github_url}', 'prefix', false, 0),
  ('FastGitCc', 'https://fastgit.cc/{github_url}', 'prefix', false, 0),
  ('Zwy', 'https://zwy.mirror/{github_url}', 'prefix', false, 0),
  ('GeekerTao', 'https://geekertao.mirror/{github_url}', 'prefix', false, 0),
  ('LIkk', 'https://likk.mirror/{github_url}', 'prefix', false, 0),
  ('CrashMc', 'https://crashmc.mirror/{github_url}', 'prefix', false, 0),
  ('JasonZeng', 'https://jasonzeng.mirror/{github_url}', 'prefix', false, 0),
  ('Yylx', 'https://yylx.mirror/{github_url}', 'prefix', false, 0),
  ('Ednovas', 'https://ednovas.mirror/{github_url}', 'prefix', false, 0),
  ('BokiMoe', 'https://bokimoe.mirror/{github_url}', 'prefix', false, 0),
  ('Monlor', 'https://monlor.mirror/{github_url}', 'prefix', false, 0),
  ('GhProxyNetHyphe', 'https://ghproxy.nethyphe.com/{github_url}', 'prefix', false, 0),
  ('GhProxyNet', 'https://ghproxy.net/{github_url}', 'prefix', false, 0),
  ('Limoruirui', 'https://limoruirui.mirror/{github_url}', 'prefix', false, 0),
  ('Firewall', 'https://firewall.mirror/{github_url}', 'prefix', false, 0),
  ('Gh-Pro', 'https://gh-pro.mirror/{github_url}', 'prefix', false, 0);

-- ============================================================
-- SubTask 2.5: articles 表
-- ============================================================
create table public.articles (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  -- 类型：article=文章 / recommend=推荐 / theme=主题
  type text not null check (type in ('article', 'recommend', 'theme')),
  title text not null,
  cover text,  -- 封面图 URL
  content text not null,  -- 正文（Markdown）
  app_ids uuid[] default '{}',  -- 关联的应用 id 数组（推荐和主题用）
  tags text[] default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_articles_type on public.articles(type);

-- ============================================================
-- SubTask 2.6: 其他表
-- ============================================================

-- download_logs: 下载日志
create table public.download_logs (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  app_id uuid not null references public.apps(id) on delete cascade,
  apk_id uuid not null references public.app_apks(id) on delete cascade,
  mirror_site_id uuid references public.mirror_sites(id) on delete set null,
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  status text not null default 'pending',  -- 状态：pending=待下载 / downloading=下载中 / completed=已完成 / failed=失败
  bytes_downloaded bigint not null default 0,
  total_bytes bigint,
  error_message text
);

-- messages: 站内消息
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  content text not null,
  type text not null,  -- 消息类型：system=系统 / review=审核 / download=下载 / general=通用
  related_app_id uuid references public.apps(id) on delete set null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

-- user_settings: 用户设置
-- 注意：id 即 profile_id，与 profiles 一对一；GitHub PAT 不存这里，存 vault
create table public.user_settings (
  id uuid primary key references public.profiles(id) on delete cascade,
  preferred_mirror_site_id uuid references public.mirror_sites(id) on delete set null,
  github_username text,
  github_repo_for_upload text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- inherit_codes: 继承码（用于账号迁移/继承）
create table public.inherit_codes (
  id uuid primary key default gen_random_uuid(),
  source_profile_id uuid not null references public.profiles(id) on delete cascade,
  code text not null unique,
  expires_at timestamptz not null,
  used boolean not null default false,
  created_at timestamptz not null default now()
);

-- fetch_logs: 抓取日志
create table public.fetch_logs (
  id uuid primary key default gen_random_uuid(),
  app_id uuid not null references public.apps(id) on delete cascade,
  release_id bigint,
  status text not null,  -- 状态：success=成功 / failed=失败 / partial=部分成功
  apk_count integer not null default 0,
  error_message text,
  created_at timestamptz not null default now()
);

-- view_history: 浏览历史（用于推荐算法）
create table public.view_history (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  app_id uuid not null references public.apps(id) on delete cascade,
  viewed_at timestamptz not null default now()
);

-- app_tags: 应用标签（用于推荐算法召回，与 apps.tags 数组互补，便于查询）
create table public.app_tags (
  id uuid primary key default gen_random_uuid(),
  app_id uuid not null references public.apps(id) on delete cascade,
  tag text not null,
  created_at timestamptz not null default now()
);
create index idx_app_tags_app_id on public.app_tags(app_id);
create index idx_app_tags_tag on public.app_tags(tag);

-- ============================================================
-- updated_at 自动更新触发器（用于 apps、profiles、articles、user_settings 表）
-- ============================================================
create or replace function public.update_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger trg_profiles_updated_at
before update on public.profiles
for each row execute function public.update_updated_at();

create trigger trg_apps_updated_at
before update on public.apps
for each row execute function public.update_updated_at();

create trigger trg_articles_updated_at
before update on public.articles
for each row execute function public.update_updated_at();

create trigger trg_user_settings_updated_at
before update on public.user_settings
for each row execute function public.update_updated_at();

-- ============================================================
-- 授权 anon 和 authenticated 角色基本访问权限
-- RLS 在授权基础上进一步过滤行级访问
-- ============================================================
grant select, insert, update on public.profiles to anon, authenticated;
grant select, insert, update on public.apps to anon, authenticated;
grant select on public.app_apks to anon, authenticated;
grant select on public.mirror_sites to anon, authenticated;
grant select on public.articles to anon, authenticated;
grant select, insert, update, delete on public.download_logs to anon, authenticated;
grant select, update on public.messages to anon, authenticated;
grant select, insert, update, delete on public.user_settings to anon, authenticated;
grant select, insert, update, delete on public.view_history to anon, authenticated;
grant select on public.app_tags to anon, authenticated;
-- inherit_codes、fetch_logs 不授权给 anon/authenticated（仅 service_role 可访问）

-- ============================================================
-- SubTask 2.7: RLS 策略
-- ============================================================

-- profiles: 用户只能读自己的 profile（通过 device_token 匹配）；
-- 不能直接 insert/update role 字段（角色变更必须经 Edge Function）
alter table public.profiles enable row level security;

create policy "profiles_select_own"
on public.profiles for select
using (id = public.get_current_profile_id());

-- 新设备（无 device_token 匹配时）可创建 profile，已存在 profile 的设备不可重复创建
create policy "profiles_insert_new_device"
on public.profiles for insert
with check (public.get_current_profile_id() is null);

create policy "profiles_update_own"
on public.profiles for update
using (id = public.get_current_profile_id())
with check (id = public.get_current_profile_id());

-- 撤销 role 字段的直接写入权限（角色变更必须经 Edge Function，service_role 绕过此限制）
revoke update (role) on public.profiles from anon, authenticated;

-- apps: 所有人可读已审核通过的应用（status in ('approved','virus_safe')）；
-- 用户只能写自己 owner_id 的应用（且不能写 status/review_level/virus_safe_reason 字段，这些必须经 Edge Function）
alter table public.apps enable row level security;

create policy "apps_select_visible"
on public.apps for select
using (
  status in ('approved', 'virus_safe')
  or owner_id = public.get_current_profile_id()
);

create policy "apps_insert_own"
on public.apps for insert
with check (owner_id = public.get_current_profile_id());

create policy "apps_update_own"
on public.apps for update
using (owner_id = public.get_current_profile_id())
with check (owner_id = public.get_current_profile_id());

-- 撤销敏感字段的直接写入权限（必须经 Edge Function，service_role 绕过此限制）
revoke insert (status, review_level, virus_safe_reason) on public.apps from anon, authenticated;
revoke update (status, review_level, virus_safe_reason) on public.apps from anon, authenticated;

-- app_apks: 所有人可读；不能直接 insert/update（必须经 Edge Function 抓取）
alter table public.app_apks enable row level security;

create policy "app_apks_select_all"
on public.app_apks for select
using (true);
-- 不创建 insert/update 策略，默认拒绝直接写入

-- mirror_sites: 所有人可读；不能写（仅管理员经 Edge Function）
alter table public.mirror_sites enable row level security;

create policy "mirror_sites_select_all"
on public.mirror_sites for select
using (true);
-- 不创建 insert/update/delete 策略，默认拒绝直接写入

-- articles: 所有人可读；不能直接 insert/update（必须经 Edge Function，仅站长/管理员）
alter table public.articles enable row level security;

create policy "articles_select_all"
on public.articles for select
using (true);
-- 不创建 insert/update/delete 策略，默认拒绝直接写入

-- download_logs: 用户只能读写自己 profile_id 的记录
alter table public.download_logs enable row level security;

create policy "download_logs_select_own"
on public.download_logs for select
using (profile_id = public.get_current_profile_id());

create policy "download_logs_insert_own"
on public.download_logs for insert
with check (profile_id = public.get_current_profile_id());

create policy "download_logs_update_own"
on public.download_logs for update
using (profile_id = public.get_current_profile_id())
with check (profile_id = public.get_current_profile_id());

create policy "download_logs_delete_own"
on public.download_logs for delete
using (profile_id = public.get_current_profile_id());

-- messages: 用户只能读自己 recipient_id 的消息，只能更新 read 字段
alter table public.messages enable row level security;

create policy "messages_select_own"
on public.messages for select
using (recipient_id = public.get_current_profile_id());

create policy "messages_update_read_own"
on public.messages for update
using (recipient_id = public.get_current_profile_id())
with check (recipient_id = public.get_current_profile_id());
-- 不创建 insert/delete 策略，消息由系统/Edge Function 创建

-- 撤销非 read 字段的更新权限（用户只能更新 read 字段）
revoke update (recipient_id, title, content, type, related_app_id) on public.messages from anon, authenticated;

-- user_settings: 用户只能读写自己 profile_id 的设置
alter table public.user_settings enable row level security;

create policy "user_settings_select_own"
on public.user_settings for select
using (id = public.get_current_profile_id());

create policy "user_settings_insert_own"
on public.user_settings for insert
with check (id = public.get_current_profile_id());

create policy "user_settings_update_own"
on public.user_settings for update
using (id = public.get_current_profile_id())
with check (id = public.get_current_profile_id());

create policy "user_settings_delete_own"
on public.user_settings for delete
using (id = public.get_current_profile_id());

-- inherit_codes: 不能直接读写（必须经 Edge Function）
alter table public.inherit_codes enable row level security;
-- 不创建任何策略，默认拒绝所有 anon/authenticated 访问

-- fetch_logs: 不能直接读写（仅服务端）
alter table public.fetch_logs enable row level security;
-- 不创建任何策略，默认拒绝所有 anon/authenticated 访问

-- view_history: 用户只能读写自己 profile_id 的记录
alter table public.view_history enable row level security;

create policy "view_history_select_own"
on public.view_history for select
using (profile_id = public.get_current_profile_id());

create policy "view_history_insert_own"
on public.view_history for insert
with check (profile_id = public.get_current_profile_id());

create policy "view_history_update_own"
on public.view_history for update
using (profile_id = public.get_current_profile_id())
with check (profile_id = public.get_current_profile_id());

create policy "view_history_delete_own"
on public.view_history for delete
using (profile_id = public.get_current_profile_id());

-- app_tags: 所有人可读；不能直接写（经 Edge Function）
alter table public.app_tags enable row level security;

create policy "app_tags_select_all"
on public.app_tags for select
using (true);
-- 不创建 insert/update/delete 策略，默认拒绝直接写入
