-- ============================================================
-- SubTask 4.2: 账号继承原子转移函数 execute_inherit
-- ============================================================
-- Edge Function execute-inherit 通过 RPC 调用此函数，在单个事务内完成：
--   1. 校验继承码（存在 / 未使用 / 未过期 / 非自继承）
--   2. 转移所有关联数据（apps / articles / download_logs / messages /
--      user_settings / view_history / github_pat_secret_id）
--   3. 标记继承码为已使用
--   4. 删除 source profile（on delete cascade 清理 inherit_codes 等残留）
--
-- 使用 select ... for update 锁定继承码行，防止并发重复使用同一继承码。
--
-- 安全说明：
--   - security definer 绕过 RLS，仅由 Edge Function（持有 service_role key）调用。
--   - Edge Function 负责 device_token -> target_profile_id 的鉴权，
--     此函数仅做数据转移，不直接读取请求头。
-- ============================================================

create or replace function public.execute_inherit(
  p_code text,
  p_target_profile_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_code_id uuid;
  v_source_profile_id uuid;
  v_used boolean;
  v_expires_at timestamptz;
  v_source_github_pat uuid;
begin
  -- 锁定继承码行，防止并发重复使用
  select id, source_profile_id, used, expires_at
    into v_code_id, v_source_profile_id, v_used, v_expires_at
    from public.inherit_codes
    where code = p_code
    for update;

  if v_code_id is null then
    return jsonb_build_object('success', false, 'error', '继承码不存在');
  end if;

  if v_used then
    return jsonb_build_object('success', false, 'error', '继承码已被使用');
  end if;

  if v_expires_at <= now() then
    return jsonb_build_object('success', false, 'error', '继承码已过期');
  end if;

  -- 不能继承到自己
  if v_source_profile_id = p_target_profile_id then
    return jsonb_build_object('success', false, 'error', '不能继承到自己的账号');
  end if;

  -- 转移 apps
  update public.apps
    set owner_id = p_target_profile_id
    where owner_id = v_source_profile_id;

  -- 转移 articles
  update public.articles
    set author_id = p_target_profile_id
    where author_id = v_source_profile_id;

  -- 转移 download_logs
  update public.download_logs
    set profile_id = p_target_profile_id
    where profile_id = v_source_profile_id;

  -- 转移 messages
  update public.messages
    set recipient_id = p_target_profile_id
    where recipient_id = v_source_profile_id;

  -- 转移 user_settings：先删除 target 已有设置，再将 source 的设置 id 改为 target
  delete from public.user_settings where id = p_target_profile_id;
  update public.user_settings
    set id = p_target_profile_id
    where id = v_source_profile_id;

  -- 转移 view_history
  update public.view_history
    set profile_id = p_target_profile_id
    where profile_id = v_source_profile_id;

  -- 转移 github_pat_secret_id（先取出 source 的引用，再写入 target）
  select github_pat_secret_id into v_source_github_pat
    from public.profiles
    where id = v_source_profile_id;

  update public.profiles
    set github_pat_secret_id = v_source_github_pat
    where id = p_target_profile_id;

  -- 标记继承码为已使用
  update public.inherit_codes
    set used = true
    where id = v_code_id;

  -- 删除 source profile（on delete cascade 清理 inherit_codes 等残留）
  delete from public.profiles where id = v_source_profile_id;

  return jsonb_build_object('success', true, 'message', '继承成功');
end;
$$;
