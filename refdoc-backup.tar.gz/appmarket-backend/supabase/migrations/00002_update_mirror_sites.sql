-- ============================================================
-- migration 00002：更新 mirror_sites 表中各镜像站的真实 URL 模板
-- 对应 spec Task 11 SubTask 11.2
--
-- 说明：
--   1. 镜像站域名来源于社区维护的 GitHub 加速镜像列表（MoreTools.app 收录的
--      115 个节点、github.akams.cn 节点列表、mirror-cn 项目及多个公开测速文章）。
--   2. 所有可验证的镜像站均采用「前缀代理型」URL 模式：
--      https://镜像域名/{github_url}
--      其中 {github_url} 为完整的 GitHub 原始下载链接，例如
--      https://github.com/user/repo/releases/download/v1.0/app.apk
--   3. GitHub 官方源（is_official=true）保持不变，仍为域名替换型
--      https://github.com{path}
--   4. 无法在公开镜像列表中验证真实域名或已失效的镜像站，
--      将 enabled 设为 false 并在行内注释中说明原因。
-- ============================================================

-- GitHub 官方源：保持不变（域名替换型，优先级最高）
-- 已在 00001 中正确配置，此处无需更新

-- ------------------------------------------------------------
-- 以下为前缀代理型镜像站，逐一更新 url_template 为真实域名
-- ------------------------------------------------------------

-- Tbedu：域名 github.tbedu.top，见于 github.akams.cn 节点列表与 mirror-cn 项目
update public.mirror_sites
  set url_template = 'https://github.tbedu.top/{github_url}'
  where name = 'Tbedu';

-- Mrhjx：域名 gitproxy.mrhjx.cn，见于 MoreTools 与 github.akams.cn 测绘节点列表
update public.mirror_sites
  set url_template = 'https://gitproxy.mrhjx.cn/{github_url}'
  where name = 'Mrhjx';

-- Cxkpro：域名 ghproxy.cxkpro.top，见于 MoreTools 与 github.akams.cn 测绘节点列表
update public.mirror_sites
  set url_template = 'https://ghproxy.cxkpro.top/{github_url}'
  where name = 'Cxkpro';

-- Xxooo：域名 gh.xxooo.cf，见于 MoreTools 与公开测速文章节点列表
update public.mirror_sites
  set url_template = 'https://gh.xxooo.cf/{github_url}'
  where name = 'Xxooo';

-- Nxnow：域名 gh.nxnow.top，见于 MoreTools 与公开测速文章节点列表
update public.mirror_sites
  set url_template = 'https://gh.nxnow.top/{github_url}'
  where name = 'Nxnow';

-- Chjina：域名 gh.chjina.com，见于 MoreTools 与 github.akams.cn 测绘节点列表
update public.mirror_sites
  set url_template = 'https://gh.chjina.com/{github_url}'
  where name = 'Chjina';

-- FastGitCc：域名 fastgit.cc，见于 MoreTools、github.akams.cn 及公开测速文章
update public.mirror_sites
  set url_template = 'https://fastgit.cc/{github_url}'
  where name = 'FastGitCc';

-- GeekerTao：域名 ghfile.geekertao.top，见于 MoreTools、github.akams.cn 及 mirror-cn 项目
update public.mirror_sites
  set url_template = 'https://ghfile.geekertao.top/{github_url}'
  where name = 'GeekerTao';

-- JasonZeng：域名 gh.jasonzeng.dev，见于 MoreTools、github.akams.cn 及 mirror-cn 项目
update public.mirror_sites
  set url_template = 'https://gh.jasonzeng.dev/{github_url}'
  where name = 'JasonZeng';

-- Yylx：域名 git.yylx.win，见于 MoreTools、github.akams.cn 及 mirror-cn 项目
update public.mirror_sites
  set url_template = 'https://git.yylx.win/{github_url}'
  where name = 'Yylx';

-- Ednovas：域名 github.ednovas.xyz，见于 MoreTools 与 github.akams.cn 测绘节点列表
update public.mirror_sites
  set url_template = 'https://github.ednovas.xyz/{github_url}'
  where name = 'Ednovas';

-- BokiMoe：域名 github.boki.moe，见于 mirror-cn 项目（由 blog.boki.moe 提供）
update public.mirror_sites
  set url_template = 'https://github.boki.moe/{github_url}'
  where name = 'BokiMoe';

-- Monlor：域名 gh.monlor.com，见于 MoreTools、github.akams.cn 及 mirror-cn 项目
update public.mirror_sites
  set url_template = 'https://gh.monlor.com/{github_url}'
  where name = 'Monlor';

-- GhProxyNet：域名 ghproxy.net，见于多个公开镜像列表，长期稳定
update public.mirror_sites
  set url_template = 'https://ghproxy.net/{github_url}'
  where name = 'GhProxyNet';

-- Limoruirui：域名 github.limoruirui.com，见于 MoreTools 与公开测速文章节点列表
update public.mirror_sites
  set url_template = 'https://github.limoruirui.com/{github_url}'
  where name = 'Limoruirui';

-- Firewall：域名 firewall.lxstd.org，见于公开测速文章节点列表
update public.mirror_sites
  set url_template = 'https://firewall.lxstd.org/{github_url}'
  where name = 'Firewall';

-- Gh-Pro：推断对应 gh-proxy.com（主流前缀代理镜像，"Gh-Pro" 为 gh-proxy 缩写）
-- gh-proxy.com 见于 MoreTools、github.akams.cn 及多个公开测速文章，长期高可用
update public.mirror_sites
  set url_template = 'https://gh-proxy.com/{github_url}'
  where name = 'Gh-Pro';

-- ------------------------------------------------------------
-- 以下镜像站无法在公开镜像列表中验证真实域名或已失效，
-- 将 enabled 设为 false 并保留占位 url_template，待后续验证
-- ------------------------------------------------------------

-- Zwy：未能在公开镜像列表（MoreTools 115 节点、github.akams.cn、mirror-cn）中
-- 找到对应的真实域名，可能为已下线的个人镜像，暂时禁用
update public.mirror_sites
  set url_template = 'https://zwy.mirror/{github_url}',
      enabled = false
  where name = 'Zwy';

-- LIkk：未能在公开镜像列表中找到对应的真实域名，
-- 可能项目名与域名不一致或已下线，暂时禁用
update public.mirror_sites
  set url_template = 'https://likk.mirror/{github_url}',
      enabled = false
  where name = 'LIkk';

-- CrashMc：未能在公开镜像列表中找到对应的真实域名，
-- 可能项目名与域名不一致或已下线，暂时禁用
update public.mirror_sites
  set url_template = 'https://crashmc.mirror/{github_url}',
      enabled = false
  where name = 'CrashMc';

-- GhProxyNetHyphe：原占位域名为 ghproxy.nethyphe.com，未能在当前公开镜像列表
-- （MoreTools、github.akams.cn、mirror-cn）中验证其仍在运行，可能已失效，暂时禁用
update public.mirror_sites
  set url_template = 'https://ghproxy.nethyphe.com/{github_url}',
      enabled = false
  where name = 'GhProxyNetHyphe';

-- ============================================================
-- 验证：更新后镜像站总数应为 22（1 官方 + 21 镜像），
-- 其中 enabled=true 的数量为 1（官方）+ 17（已验证镜像）= 18，
-- enabled=false 的数量为 4（Zwy、LIkk、CrashMc、GhProxyNetHyphe）
-- ============================================================
