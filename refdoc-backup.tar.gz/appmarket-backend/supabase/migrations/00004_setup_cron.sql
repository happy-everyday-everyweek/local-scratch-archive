-- ============================================================
-- migration 00004: 配置 pg_cron 每日触发 daily-fetch-releases Edge Function
-- 对应 spec Task 7 SubTask 7.2
--
-- 功能：
--   1. 启用 pg_cron 和 pg_net 扩展
--   2. 在 Supabase Vault 中存储 project_url 和 publishable_key（占位符，部署时替换）
--   3. 创建 cron job：每天北京时间 03:00（UTC 19:00）触发 daily-fetch-releases
--
-- 注意：
--   - 占位符值需要在部署时通过 Vault UI 或 SQL 更新为实际值
--   - cron 表达式 '0 19 * * *' = UTC 19:00 = 北京时间 03:00
--   - publishable_key 用于调用 Edge Function 的 Authorization header
--     （Edge Function 内部使用 service_role key 从 Deno.env 获取，绕过 RLS）
--   - 数据库密码不出现在本文件中
-- ============================================================

-- 启用 pg_cron 扩展（用于定时任务调度）
create extension if not exists pg_cron with schema extensions;

-- 允许 postgres 用户使用 cron schema
grant usage on schema cron to postgres;

-- 启用 pg_net 扩展（用于从数据库发起 HTTP 请求调用 Edge Function）
create extension if not exists pg_net with schema extensions;

-- ============================================================
-- 在 Supabase Vault 中存储 project_url 和 publishable_key
-- 使用占位符值，实际值在部署时通过 Vault UI 或 SQL 更新
-- ============================================================

-- 删除已存在的同名 secret（保证 migration 幂等）
delete from vault.secrets where name = 'project_url';
delete from vault.secrets where name = 'publishable_key';

-- 创建 secret：project_url（占位符，部署时替换为实际 Supabase 项目 URL）
select vault.create_secret(
  'https://ibqeewjbdtcvgedsqflh.supabase.co',
  'project_url',
  'Supabase 项目 URL，用于 cron 调用 Edge Function'
);

-- 创建 secret：publishable_key（占位符，部署时替换为实际 publishable key）
select vault.create_secret(
  'sb_publishable_21y8mRrxJWW8LTFMWWMKYw_GbDyQtuS',
  'publishable_key',
  'Publishable key，用于 cron 调用 Edge Function 的 Authorization header'
);

-- ============================================================
-- 创建 cron job：每天北京时间 03:00 触发 daily-fetch-releases
-- cron 表达式 '0 19 * * *' = UTC 19:00 = 北京时间 03:00
-- job 名称：'daily-fetch-releases'
-- ============================================================

-- 先取消已存在的同名 job（保证 migration 幂等）
do $$
begin
  perform cron.unschedule('daily-fetch-releases');
exception
  when others then
    null;  -- job 不存在时忽略错误
end $$;

-- 创建 cron job，使用 net.http_post 调用 Edge Function
-- Authorization header 使用 publishable_key
-- timeout_milliseconds 设为 300000（5 分钟），与 Edge Function 最大执行时间匹配
select cron.schedule(
  'daily-fetch-releases',
  '0 19 * * *',
  $$
  select net.http_post(
    url := (
      select decrypted_secret
      from vault.decrypted_secrets
      where name = 'project_url'
    ) || '/functions/v1/daily-fetch-releases',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || (
        select decrypted_secret
        from vault.decrypted_secrets
        where name = 'publishable_key'
      ),
      'Content-Type', 'application/json'
    ),
    body := '{}'::jsonb,
    timeout_milliseconds := 300000
  );
  $$
);
