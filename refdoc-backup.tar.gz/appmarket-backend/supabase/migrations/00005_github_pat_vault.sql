-- ============================================================
-- Migration 00005: GitHub PAT Vault 集成
-- 对应 spec Task 8 SubTask 8.1
--
-- 创建数据库函数封装 vault 操作：
-- - save_github_pat(p_profile_id, p_pat): 将 PAT 存入 vault，更新 profiles.github_pat_secret_id
-- - get_github_pat(p_profile_id): 从 vault 读取 PAT（仅 service_role 可调用）
--
-- 安全说明：
--   - 两个函数均为 security definer，绕过 RLS 直接操作 vault
--   - get_github_pat 函数内校验调用者角色，仅 service_role 可调用
--   - PAT 明文仅存在于 vault.decrypted_secrets 视图中（仅 postgres/service_role 可见）
--   - Edge Function 通过 service_role key 调用 RPC，客户端仅持有 Publishable key
-- ============================================================

-- 确保 vault 扩展已启用（Supabase 默认启用，此处幂等声明）
create extension if not exists supabase_vault;

-- ============================================================
-- save_github_pat: 保存/更新用户的 GitHub PAT 到 Vault
--
-- 流程：
--   1. 校验 profile 存在
--   2. 若已有旧 secret，先从 vault 删除
--   3. 调用 vault.create_secret 创建新 secret
--   4. 更新 profiles.github_pat_secret_id
--   5. 返回新 secret id
-- ============================================================
create or replace function public.save_github_pat(p_profile_id uuid, p_pat text)
returns uuid
language plpgsql
security definer
set search_path = public, vault
as $$
declare
  v_old_secret_id uuid;
  v_new_secret_id uuid;
begin
  -- 校验 profile 存在
  if not exists (select 1 from public.profiles where id = p_profile_id) then
    raise exception 'profile_not_found';
  end if;

  -- 获取旧 secret id
  select github_pat_secret_id into v_old_secret_id
  from public.profiles
  where id = p_profile_id;

  -- 若有旧 secret，先从 vault 删除
  if v_old_secret_id is not null then
    delete from vault.secrets where id = v_old_secret_id;
  end if;

  -- 创建新 secret（名称以 profile_id 为后缀，便于识别）
  v_new_secret_id := vault.create_secret(
    p_pat,
    'github_pat_' || p_profile_id::text
  );

  -- 更新 profiles.github_pat_secret_id
  update public.profiles
  set github_pat_secret_id = v_new_secret_id
  where id = p_profile_id;

  return v_new_secret_id;
end;
$$;

-- ============================================================
-- get_github_pat: 从 Vault 读取用户的 GitHub PAT
--
-- 仅 service_role 可调用（函数内校验 current_setting('role')）
-- 返回 PAT 明文，供 Edge Function 调用 GitHub API 使用
-- ============================================================
create or replace function public.get_github_pat(p_profile_id uuid)
returns text
language plpgsql
security definer
set search_path = public, vault
as $$
declare
  v_secret_id uuid;
  v_pat text;
begin
  -- 仅 service_role 可调用，anon/authenticated 调用时抛出异常
  if current_setting('role', true) is distinct from 'service_role' then
    raise exception 'permission_denied: only service_role can call get_github_pat';
  end if;

  -- 获取 secret id
  select github_pat_secret_id into v_secret_id
  from public.profiles
  where id = p_profile_id;

  -- 未配置 PAT 时返回 null
  if v_secret_id is null then
    return null;
  end if;

  -- 从 vault 读取解密后的 secret
  select secret into v_pat
  from vault.decrypted_secrets
  where id = v_secret_id;

  return v_pat;
end;
$$;

-- 撤销 anon/authenticated 对这两个函数的执行权限（仅 service_role/postgres 可执行）
revoke execute on function public.save_github_pat(uuid, text) from anon, authenticated;
revoke execute on function public.get_github_pat(uuid) from anon, authenticated;
