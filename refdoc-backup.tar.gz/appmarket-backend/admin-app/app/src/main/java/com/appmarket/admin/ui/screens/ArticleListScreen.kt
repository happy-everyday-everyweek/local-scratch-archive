package com.appmarket.admin.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.appmarket.admin.data.ArticleItem
import com.appmarket.admin.viewmodel.ArticleListViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArticleListScreen(navigate: (String) -> Unit) {
    val vm: ArticleListViewModel = viewModel()
    val articles by vm.articles.collectAsState()
    val loading by vm.loading.collectAsState()
    val refreshing by vm.refreshing.collectAsState()
    val fromCache by vm.fromCache.collectAsState()
    val error by vm.error.collectAsState()

    LaunchedEffect(Unit) { vm.loadArticles() }

    var showNewDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf<ArticleItem?>(null) }

    showDeleteDialog?.let { article ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("删除文章") },
            text = { Text("确定删除 ${article.title}?") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteArticle(article.id)
                    showDeleteDialog = null
                }) { Text("删除") }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = null }) { Text("取消") } }
        )
    }

    if (showNewDialog) {
        NewArticleDialog(
            onDismiss = { showNewDialog = false },
            onPublish = { type, title, content, appIds, tags ->
                vm.publishArticle(type, title, content, appIds, tags)
                showNewDialog = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("博客管理") },
                actions = {
                    IconButton(onClick = { vm.loadArticles(forceRefresh = true) }, enabled = !refreshing) {
                        if (refreshing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = "刷新")
                        }
                    }
                    IconButton(onClick = { showNewDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "新建")
                    }
                }
            )
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    if (fromCache) {
                        AssistChip(
                            onClick = { vm.loadArticles(forceRefresh = true) },
                            leadingIcon = { Icon(Icons.Default.CloudOff, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("离线缓存（点击刷新）") }
                        )
                    }
                }
                item {
                    if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error)
                }
                items(articles, key = { it.id }) { article ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { navigate("articles/${article.id}") }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(article.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AssistChip(onClick = {}, label = { Text(article.type) })
                                    if (article.tags.isNotEmpty()) {
                                        AssistChip(onClick = {}, label = { Text(article.tags.take(2).joinToString(",")) })
                                    }
                                }
                            }
                            IconButton(onClick = { showDeleteDialog = article }) {
                                Icon(Icons.Default.Delete, contentDescription = "删除")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NewArticleDialog(
    onDismiss: () -> Unit,
    onPublish: (String, String, String, List<String>, List<String>) -> Unit
) {
    var type by remember { mutableStateOf("article") }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var appIdsText by remember { mutableStateOf("") }
    var tagsText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("新建文章") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("article", "recommend", "theme").forEach { t ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) })
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("标题") })
                OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("内容(Markdown)") }, modifier = Modifier.height(120.dp))
                if (type != "article") {
                    OutlinedTextField(value = appIdsText, onValueChange = { appIdsText = it }, label = { Text("关联应用ID(逗号分隔)") })
                }
                OutlinedTextField(value = tagsText, onValueChange = { tagsText = it }, label = { Text("标签(逗号分隔)") })
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val appIdList = appIdsText.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    val tagList = tagsText.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    onPublish(type, title, content, appIdList, tagList)
                },
                enabled = title.isNotBlank()
            ) { Text("发布") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}
