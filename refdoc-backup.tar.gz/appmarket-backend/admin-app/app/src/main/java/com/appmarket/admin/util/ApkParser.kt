package com.appmarket.admin.util

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.Uri
import java.io.File

data class ApkMeta(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val versionCode: Long,
    val icon: Drawable?,
    val minSdkVersion: Int
)

object ApkParser {
    fun parseApk(context: Context, uri: Uri): ApkMeta? {
        return try {
            val pm = context.packageManager

            // content URI 需要先复制到临时文件，getPackageArchiveInfo 需要文件路径
            val filePath = when (uri.scheme) {
                "content" -> {
                    val tempFile = File.createTempFile("temp_apk", ".apk", context.cacheDir)
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        tempFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: return null
                    tempFile.absolutePath
                }
                "file" -> uri.path ?: return null
                else -> uri.path ?: return null
            }

            val info = pm.getPackageArchiveInfo(filePath, PackageManager.GET_META_DATA)
                ?: return null

            info.applicationInfo?.sourceDir = filePath
            info.applicationInfo?.publicSourceDir = filePath

            val appName = info.applicationInfo?.loadLabel(pm)?.toString() ?: info.packageName ?: ""
            val icon = try { info.applicationInfo?.loadIcon(pm) } catch (_: Exception) { null }

            ApkMeta(
                packageName = info.packageName ?: "",
                appName = appName,
                versionName = info.versionName ?: "",
                versionCode = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else (info.versionCode ?: 0).toLong(),
                icon = icon,
                minSdkVersion = info.applicationInfo?.minSdkVersion ?: 21
            )
        } catch (e: Exception) {
            null
        }
    }

    fun drawableToByteArray(drawable: Drawable, size: Int = 192): ByteArray {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        drawable.setBounds(0, 0, size, size)
        drawable.draw(canvas)
        val stream = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        bitmap.recycle()
        return stream.toByteArray()
    }
}
