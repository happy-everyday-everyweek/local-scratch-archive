package com.appmarket.admin.data

data class AppItem(
    val id: String,
    val name: String,
    val packageName: String?,
    val githubRepo: String?,
    val category: String,
    val status: String,
    val reviewLevel: String?,
    val virusSafeReason: String?,
    val iconUrl: String?,
    val description: String?,
    val latestVersion: String?,
    val screenshots: List<String>?,
    val tags: List<String>?,
    val downloadCount: Int,
    val ownerId: String,
    val createdAt: String?,
    val updatedAt: String?
)

data class ArticleItem(
    val id: String,
    val authorId: String,
    val type: String,
    val title: String,
    val cover: String?,
    val content: String,
    val appIds: List<String>,
    val tags: List<String>,
    val createdAt: String?
)

data class ProfileItem(
    val id: String,
    val deviceFingerprint: String,
    val role: String,
    val deviceToken: String,
    val createdAt: String?
)

data class MirrorSiteItem(
    val id: String,
    val name: String,
    val urlTemplate: String,
    val siteType: String,
    val enabled: Boolean,
    val priority: Int,
    val isOfficial: Boolean
)

data class ApkItem(
    val id: String,
    val appId: String,
    val version: String,
    val filename: String,
    val size: Long,
    val arch: String?,
    val githubAssetUrl: String,
    val releaseNotes: String?
)

data class MessageItem(
    val id: String,
    val recipientId: String,
    val title: String,
    val content: String,
    val type: String,
    val read: Boolean,
    val createdAt: String?
)

data class FetchLogItem(
    val id: String,
    val appId: String,
    val releaseId: Long?,
    val status: String,
    val apkCount: Int,
    val errorMessage: String?,
    val createdAt: String?
)

data class DownloadLogItem(
    val id: String,
    val profileId: String,
    val appId: String,
    val apkId: String,
    val status: String,
    val bytesDownloaded: Long,
    val totalBytes: Long?,
    val startedAt: String?
)
