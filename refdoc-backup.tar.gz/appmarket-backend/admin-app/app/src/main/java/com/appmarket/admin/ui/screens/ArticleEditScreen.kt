package com.appmarket.admin.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.appmarket.admin.data.AppCache
import com.appmarket.admin.data.AppItem
import com.appmarket.admin.data.SupabaseClient
import com.appmarket.admin.data.toAppItem
import com.appmarket.admin.data.toArticleItem
import com.appmarket.admin.ui.components.MarkdownEditor
import com.appmarket.admin.ui.components.MultiSelectAppDropdown
import com.appmarket.admin.ui.components.SectionHeader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*

// ============================================================
// 博客编辑页面
// 美化 UI + Markdown 编辑器 + 全中文
// ============================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArticleEditScreen(articleId: String, onBack: () -> Unit) {
    val db = remember { SupabaseClient() }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    var title by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("article") }
    var content by remember { mutableStateOf("") }
    var cover by remember { mutableStateOf("") }
    var selectedAppIds by remember { mutableStateOf<List<String>>(emptyList()) }
    var tagsText by remember { mutableStateOf("") }

    // 关联应用列表（用于下拉多选）
    var allApps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var appsLoading by remember { mutableStateOf(false) }

    // 拉取文章详情
    LaunchedEffect(articleId) {
        // 先读缓存秒显
        val cached = AppCache.getDetail("articles", articleId)
        if (cached != null) {
            try {
                val item = cached.jsonObject.toArticleItem()
                title = item.title
                type = item.type
                content = item.content
                cover = item.cover ?: ""
                selectedAppIds = item.appIds
                tagsText = item.tags.joinToString(", ")
                loading = false
            } catch (_: Exception) {}
        }
        // 后台拉取最新
        withContext(Dispatchers.IO) {
            try {
                val result = db.select("articles", filter = "id=eq.$articleId")
                if (result.isNotEmpty()) {
                    val item = result[0].jsonObject.toArticleItem()
                    title = item.title
                    type = item.type
                    content = item.content
                    cover = item.cover ?: ""
                    selectedAppIds = item.appIds
                    tagsText = item.tags.joinToString(", ")
                    AppCache.putDetail("articles", articleId, result[0])
                }
            } catch (e: Exception) {
                if (cached == null) error = e.message
            }
            loading = false
        }
    }

    // 拉取应用列表（带缓存）
    LaunchedEffect(Unit) {
        // 先读缓存秒显
        val cached = AppCache.getJson("apps_list")
        if (cached != null) {
            try {
                val arr = cached.jsonArray
                allApps = arr.map { it.jsonObject.toAppItem() }
            } catch (_: Exception) {}
        }
        // 后台拉取最新
        appsLoading = true
        withContext(Dispatchers.IO) {
            try {
                val result = db.select("apps", order = "created_at.desc")
                allApps = result.map { it.jsonObject.toAppItem() }
                AppCache.putJson("apps_list", result)
                AppCache.putCount("apps_list", result.size)
            } catch (_: Exception) {
                // 拉取失败时保留缓存数据
            } finally {
                appsLoading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("编辑文章") },
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                        Spacer(Modifier.width(4.dp))
                        Text("返回")
                    }
                }
            )
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (error != null) {
                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Error, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onErrorContainer)
                            Spacer(Modifier.width(8.dp))
                            Text(error!!, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                // === 基本信息 ===
                SectionHeader("基本信息")

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("文章标题") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // 文章类型
                Text("文章类型", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("文章" to "article", "推荐" to "recommend", "主题" to "theme").forEach { (label, value) ->
                        FilterChip(
                            selected = type == value,
                            onClick = { type = value },
                            label = { Text(label) }
                        )
                    }
                }

                OutlinedTextField(
                    value = cover,
                    onValueChange = { cover = it },
                    label = { Text("封面图片 URL（可选）") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // === 正文（Markdown 编辑器） ===
                SectionHeader("正文内容")

                MarkdownEditor(
                    value = content,
                    onValueChange = { content = it },
                    label = "文章正文（支持 Markdown）",
                    minHeight = 250
                )

                // === 标签和关联 ===
                SectionHeader("标签与关联")

                OutlinedTextField(
                    value = tagsText,
                    onValueChange = { tagsText = it },
                    label = { Text("标签（逗号分隔）") },
                    placeholder = { Text("AI, 工具, 技术") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (type != "article") {
                    MultiSelectAppDropdown(
                        allApps = allApps,
                        selectedIds = selectedAppIds,
                        onSelectionChange = { selectedAppIds = it },
                        loading = appsLoading
                    )
                }

                Spacer(Modifier.height(8.dp))

                // === 保存按钮 ===
                Button(
                    onClick = {
                        saving = true
                        kotlinx.coroutines.MainScope().launch(Dispatchers.IO) {
                            try {
                                val appIdList = selectedAppIds
                                val tagList = tagsText.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                                val data = buildJsonObject {
                                    put("title", title)
                                    put("type", type)
                                    put("content", content)
                                    put("cover", if (cover.isBlank()) JsonNull else JsonPrimitive(cover))
                                    put("app_ids", JsonArray(appIdList.map { JsonPrimitive(it) }))
                                    put("tags", JsonArray(tagList.map { JsonPrimitive(it) }))
                                }
                                db.update("articles", articleId, data)
                                AppCache.removeDetail("articles", articleId)
                                AppCache.remove("articles_list")
                                error = null
                            } catch (e: Exception) { error = e.message }
                            saving = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    enabled = !saving
                ) {
                    if (saving) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(Modifier.width(8.dp))
                        Text("保存中...")
                    } else {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("保存")
                    }
                }
            }
        }
    }
}
