package com.appmarket.admin.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.admin.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*

class ArticleListViewModel : ViewModel() {
    private val db = SupabaseClient()

    private val cacheKey = "articles_list"

    private val _articles = MutableStateFlow<List<ArticleItem>>(emptyList())
    val articles: StateFlow<List<ArticleItem>> = _articles

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing

    private val _fromCache = MutableStateFlow(false)
    val fromCache: StateFlow<Boolean> = _fromCache

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun loadArticles(forceRefresh: Boolean = false) {
        // 先读缓存秒显
        if (!forceRefresh && _articles.value.isEmpty()) {
            val cached = AppCache.getJson(cacheKey)
            if (cached != null) {
                try {
                    val arr = cached.jsonArray
                    _articles.value = arr.map { it.jsonObject.toArticleItem() }
                    _fromCache.value = true
                } catch (_: Exception) {}
            }
        }

        val isFirstLoad = _articles.value.isEmpty()
        if (isFirstLoad) _loading.value = true else _refreshing.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = db.select("articles", order = "created_at.desc")
                _articles.value = result.map { it.jsonObject.toArticleItem() }
                AppCache.putJson(cacheKey, result)
                AppCache.putCount(cacheKey, result.size)
                _fromCache.value = false
                _error.value = null
            } catch (e: Exception) {
                if (_articles.value.isEmpty()) {
                    _error.value = e.message
                } else {
                    _error.value = "刷新失败（已显示缓存数据）: ${e.message}"
                }
            } finally {
                _loading.value = false
                _refreshing.value = false
            }
        }
    }

    fun deleteArticle(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                db.delete("articles", id)
                _articles.value = _articles.value.filter { it.id != id }
                AppCache.remove(cacheKey)
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    fun publishArticle(type: String, title: String, content: String, appIds: List<String>, tags: List<String>) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val data = buildJsonObject {
                    put("type", type)
                    put("title", title)
                    put("content", content)
                    put("app_ids", JsonArray(appIds.map { JsonPrimitive(it) }))
                    put("tags", JsonArray(tags.map { JsonPrimitive(it) }))
                    put("author_id", "3aa93f0b-96f1-44b8-bc8c-cdb032847282")
                }
                db.insert("articles", data)
                AppCache.remove(cacheKey)
                loadArticles(forceRefresh = true)
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }
}
