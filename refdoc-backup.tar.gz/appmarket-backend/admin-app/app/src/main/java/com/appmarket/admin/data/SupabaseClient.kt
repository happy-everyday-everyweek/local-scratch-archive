package com.appmarket.admin.data

import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class SupabaseClient {
    private val client = OkHttpClient.Builder()
        .retryOnConnectionFailure(true)
        .build()
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private fun headers(): Headers = Headers.Builder()
        .add("apikey", AdminConfig.SUPABASE_SERVICE_ROLE_KEY)
        .add("Authorization", "Bearer ${AdminConfig.SUPABASE_SERVICE_ROLE_KEY}")
        .add("Content-Type", "application/json")
        .add("Prefer", "return=representation")
        .build()

    private fun headersForQuery(): Headers = Headers.Builder()
        .add("apikey", AdminConfig.SUPABASE_SERVICE_ROLE_KEY)
        .add("Authorization", "Bearer ${AdminConfig.SUPABASE_SERVICE_ROLE_KEY}")
        .build()

    private fun parseError(body: String): String {
        return try {
            val elem = json.parseToJsonElement(body)
            if (elem is JsonObject) {
                val msg = elem["message"]?.jsonPrimitive?.content
                val hint = elem["hint"]?.jsonPrimitive?.content
                val code = elem["code"]?.jsonPrimitive?.content
                buildString {
                    code?.let { append("[$it] ") }
                    msg?.let { append(it) }
                    hint?.let { append(" ($it)") }
                }.ifEmpty { body }
            } else {
                body
            }
        } catch (e: Exception) {
            body
        }
    }

    suspend fun select(table: String, columns: String = "*", filter: String? = null, order: String? = null): JsonArray {
        val urlBuilder = StringBuilder("${AdminConfig.REST_BASE}/$table?select=$columns")
        filter?.let { urlBuilder.append("&$it") }
        order?.let { urlBuilder.append("&order=$it") }

        val request = Request.Builder()
            .url(urlBuilder.toString())
            .headers(headersForQuery())
            .get()
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: "[]"
        if (!response.isSuccessful) {
            throw Exception("HTTP ${response.code}: ${parseError(body)}")
        }
        val elem = json.parseToJsonElement(body)
        return when (elem) {
            is JsonArray -> elem
            is JsonObject -> throw Exception("Expected array but got object: ${parseError(body)}")
            else -> throw Exception("Unexpected response: $body")
        }
    }

    suspend fun insert(table: String, data: JsonObject): JsonObject {
        val request = Request.Builder()
            .url("${AdminConfig.REST_BASE}/$table")
            .headers(headers())
            .post(data.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: "{}"
        if (!response.isSuccessful) {
            throw Exception("HTTP ${response.code}: ${parseError(body)}")
        }
        val elem = json.parseToJsonElement(body)
        return when (elem) {
            is JsonArray -> if (elem.isNotEmpty()) elem[0].jsonObject else buildJsonObject {}
            is JsonObject -> elem
            else -> buildJsonObject {}
        }
    }

    suspend fun update(table: String, id: String, data: JsonObject): JsonObject {
        val request = Request.Builder()
            .url("${AdminConfig.REST_BASE}/$table?id=eq.$id")
            .headers(headers())
            .patch(data.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: "[]"
        if (!response.isSuccessful) {
            throw Exception("HTTP ${response.code}: ${parseError(body)}")
        }
        val elem = json.parseToJsonElement(body)
        return when (elem) {
            is JsonArray -> if (elem.isNotEmpty()) elem[0].jsonObject else buildJsonObject {}
            is JsonObject -> elem
            else -> buildJsonObject {}
        }
    }

    suspend fun delete(table: String, id: String): Boolean {
        val request = Request.Builder()
            .url("${AdminConfig.REST_BASE}/$table?id=eq.$id")
            .headers(headers())
            .delete()
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val body = response.body?.string() ?: ""
            throw Exception("HTTP ${response.code}: ${parseError(body)}")
        }
        return true
    }

    suspend fun rpc(fn: String, params: JsonObject): String {
        val request = Request.Builder()
            .url("${AdminConfig.REST_BASE}/rpc/$fn")
            .headers(headers())
            .post(params.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: ""
        if (!response.isSuccessful) {
            throw Exception("HTTP ${response.code}: ${parseError(body)}")
        }
        return body
    }

    suspend fun uploadToStorage(bucket: String, path: String, bytes: ByteArray, contentType: String): String? {
        val mediaType = contentType.toMediaType()
        val request = Request.Builder()
            .url("${AdminConfig.STORAGE_BASE}/object/$bucket/$path")
            .addHeader("apikey", AdminConfig.SUPABASE_SERVICE_ROLE_KEY)
            .addHeader("Authorization", "Bearer ${AdminConfig.SUPABASE_SERVICE_ROLE_KEY}")
            .addHeader("Content-Type", contentType)
            .addHeader("x-upsert", "true")
            .put(bytes.toRequestBody(mediaType))
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val body = response.body?.string() ?: ""
            throw Exception("Upload failed HTTP ${response.code}: ${parseError(body)}")
        }
        return "${AdminConfig.STORAGE_BASE}/object/public/$bucket/$path"
    }

    suspend fun getPublicUrl(bucket: String, path: String): String {
        return "${AdminConfig.STORAGE_BASE}/object/public/$bucket/$path"
    }
}
