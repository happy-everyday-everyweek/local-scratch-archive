package com.appmarket.admin.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.appmarket.admin.viewmodel.UploadViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadScreen() {
    val vm: UploadViewModel = viewModel()
    val state by vm.state.collectAsState()
    val context = LocalContext.current

    // 使用 OpenDocument 支持多 MIME 类型，兼容性更好
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { vm.pickApk(context, it) }
    }

    val categories = listOf("opensource", "genuine", "natural")
    val meta = state.apkMeta

    Scaffold(
        topBar = { TopAppBar(title = { Text("上传应用") }) }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {
                    launcher.launch(arrayOf(
                        "application/vnd.android.package-archive",
                        "application/octet-stream",
                        "*/*"
                    ))
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (meta != null) "已选择: ${meta.appName}" else "选择本地 APK")
            }

            if (meta != null) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("包名: ${meta.packageName}", style = MaterialTheme.typography.bodySmall)
                        Text("版本: ${meta.versionName}", style = MaterialTheme.typography.bodySmall)
                        Text("版本Code: ${meta.versionCode}", style = MaterialTheme.typography.bodySmall)
                        Text("MinSDK: ${meta.minSdkVersion}", style = MaterialTheme.typography.bodySmall)
                        if (meta.icon != null) {
                            Spacer(Modifier.height(4.dp))
                            Button(
                                onClick = { vm.uploadIcon() },
                                enabled = !state.iconUploaded,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (state.iconUploaded) "图标已上传" else "上传图标到 Storage")
                            }
                        }
                    }
                }
            }

            OutlinedTextField(value = state.name, onValueChange = { vm.updateName(it) }, label = { Text("应用名称") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = state.packageName, onValueChange = { vm.updatePackageName(it) }, label = { Text("包名") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = state.githubRepo, onValueChange = { vm.updateGithubRepo(it) }, label = { Text("GitHub 仓库地址") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = state.latestVersion, onValueChange = { vm.updateLatestVersion(it) }, label = { Text("最新版本") }, modifier = Modifier.fillMaxWidth())

            Text("分类", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.forEach { cat ->
                    FilterChip(selected = state.category == cat, onClick = { vm.updateCategory(cat) }, label = { Text(cat) })
                }
            }

            OutlinedTextField(value = state.description, onValueChange = { vm.updateDescription(it) }, label = { Text("描述(Markdown)") }, modifier = Modifier.fillMaxWidth().height(120.dp))

            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            if (state.success) {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Text("上传成功!", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text("继续上传") }
            }

            if (!state.success) {
                Button(
                    onClick = { vm.submit() },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    enabled = !state.uploading && state.name.isNotBlank() && state.packageName.isNotBlank()
                ) { Text(if (state.uploading) "上传中..." else "提交") }
            }
        }
    }
}
