package com.appmarket.admin.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ============================================================
// Markdown 编辑器（所见即所得）
//
// 设计原则：保留所有原字符（包括 **、#、> 等标记符号），只对
// 内容部分应用样式。这样 VisualTransformation 的 OffsetMapping
// 使用 Identity 即可保证光标位置与实际编辑位置一一对应。
// 同时格式化效果（加粗、标题大字号、引用灰字等）立即可见。
// ============================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarkdownEditor(
    value: String,
    onValueChange: (String) -> Unit,
    label: String = "内容",
    modifier: Modifier = Modifier,
    minHeight: Int = 200
) {
    val textFieldColors = TextFieldDefaults.outlinedTextFieldColors(
        focusedBorderColor = MaterialTheme.colorScheme.primary,
        unfocusedBorderColor = MaterialTheme.colorScheme.outline
    )

    Column(modifier = modifier.fillMaxWidth()) {
        // 工具栏
        MarkdownToolbar(
            onInsert = { prefix, suffix, placeholder ->
                onValueChange(insertMarkdownFormat(value, prefix, suffix, placeholder))
            },
            onInsertLine = { linePrefix ->
                onValueChange(insertLineFormat(value, linePrefix))
            }
        )

        // 编辑器（内联渲染 Markdown，保留所有字符以保证光标准确）
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth().heightIn(min = minHeight.dp),
            textStyle = MaterialTheme.typography.bodyMedium,
            visualTransformation = MarkdownVisualTransformation(),
            colors = textFieldColors
        )
    }
}

// ============================================================
// 工具栏
// ============================================================

@Composable
private fun MarkdownToolbar(
    onInsert: (prefix: String, suffix: String, placeholder: String) -> Unit,
    onInsertLine: (linePrefix: String) -> Unit
) {
    Surface(tonalElevation = 2.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolbarItem(Icons.Default.FormatBold, "加粗") { onInsert("**", "**", "粗体文本") }
            ToolbarItem(Icons.Default.FormatItalic, "斜体") { onInsert("*", "*", "斜体文本") }
            ToolbarItem(Icons.Default.FormatStrikethrough, "删除线") { onInsert("~~", "~~", "删除线文本") }
            ToolbarItem(Icons.Default.Code, "行内代码") { onInsert("`", "`", "代码") }
            DividerItem()
            ToolbarItem(Icons.Default.Title, "一级标题") { onInsertLine("# ") }
            ToolbarItem(Icons.Default.Subtitles, "二级标题") { onInsertLine("## ") }
            ToolbarItem(Icons.Default.Notes, "三级标题") { onInsertLine("### ") }
            DividerItem()
            ToolbarItem(Icons.Default.FormatListBulleted, "无序列表") { onInsertLine("- ") }
            ToolbarItem(Icons.Default.FormatListNumbered, "有序列表") { onInsertLine("1. ") }
            ToolbarItem(Icons.Default.FormatQuote, "引用") { onInsertLine("> ") }
            DividerItem()
            ToolbarItem(Icons.Default.Link, "链接") { onInsert("[", "](url)", "链接文本") }
            ToolbarItem(Icons.Default.Image, "图片") { onInsert("![", "](url)", "图片描述") }
            ToolbarItem(Icons.Default.Functions, "代码块") { onInsert("\n```\n", "\n```\n", "代码块") }
        }
    }
}

@Composable
private fun ToolbarItem(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) {
        Icon(icon, contentDescription = desc, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun DividerItem() {
    HorizontalDivider(modifier = Modifier.width(1.dp).height(24.dp))
}

// ============================================================
// 文本插入逻辑
// ============================================================

private fun insertMarkdownFormat(text: String, prefix: String, suffix: String, placeholder: String): String {
    return "$text$prefix$placeholder$suffix"
}

private fun insertLineFormat(text: String, linePrefix: String): String {
    val lastNewline = text.lastIndexOf('\n')
    val lineStart = if (lastNewline == -1) 0 else lastNewline + 1
    val before = text.substring(0, lineStart)
    val lineContent = text.substring(lineStart)
    return "$before$linePrefix$lineContent"
}

// ============================================================
// VisualTransformation：保留所有原字符，仅对内容部分应用样式
// 由于不改变文本长度，OffsetMapping.Identity 即可保证光标准确
// ============================================================

class MarkdownVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        return TransformedText(
            text = buildMarkdownAnnotatedString(text.text),
            offsetMapping = OffsetMapping.Identity
        )
    }
}

// 标记符号样式：弱化显示，让用户视觉聚焦在内容上
private val MarkerColor = Color(0xFF9E9E9E)
private val AccentColor = Color(0xFF6750A4)

private fun buildMarkdownAnnotatedString(text: String): AnnotatedString {
    return buildAnnotatedString {
        val lines = text.split("\n")
        for ((lineIndex, line) in lines.withIndex()) {
            if (lineIndex > 0) append("\n")
            renderLine(line)
        }
    }
}

private fun AnnotatedString.Builder.renderLine(line: String) {
    val trimmed = line.trimStart()
    val leadingSpaces = line.length - trimmed.length

    // 先追加行首空格
    if (leadingSpaces > 0) {
        append(line.substring(0, leadingSpaces))
    }

    when {
        // 标题 # ## ###
        trimmed.startsWith("### ") -> {
            withStyle(SpanStyle(color = MarkerColor)) { append("### ") }
            withStyle(SpanStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold)) {
                appendInline(trimmed.removePrefix("### "))
            }
        }
        trimmed.startsWith("## ") -> {
            withStyle(SpanStyle(color = MarkerColor)) { append("## ") }
            withStyle(SpanStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold)) {
                appendInline(trimmed.removePrefix("## "))
            }
        }
        trimmed.startsWith("# ") -> {
            withStyle(SpanStyle(color = MarkerColor)) { append("# ") }
            withStyle(SpanStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold)) {
                appendInline(trimmed.removePrefix("# "))
            }
        }
        // 引用
        trimmed.startsWith("> ") -> {
            withStyle(SpanStyle(color = MarkerColor)) { append("> ") }
            withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = AccentColor)) {
                appendInline(trimmed.removePrefix("> "))
            }
        }
        // 无序列表
        trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
            val marker = trimmed.substring(0, 2)
            withStyle(SpanStyle(color = MarkerColor, fontWeight = FontWeight.Bold)) { append(marker) }
            appendInline(trimmed.substring(2))
        }
        // 有序列表
        trimmed.matches(Regex("^\\d+\\.\\s.+")) || trimmed.matches(Regex("^\\d+\\.\\s$")) -> {
            val dotIndex = trimmed.indexOf(". ")
            if (dotIndex != -1) {
                val marker = trimmed.substring(0, dotIndex + 2)
                withStyle(SpanStyle(color = MarkerColor, fontWeight = FontWeight.Bold)) { append(marker) }
                appendInline(trimmed.substring(dotIndex + 2))
            } else {
                // 仅 "1." 没有空格内容
                withStyle(SpanStyle(color = MarkerColor)) { append(trimmed) }
            }
        }
        // 代码块开始/结束
        trimmed.startsWith("```") -> {
            withStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = AccentColor)) {
                append(line.substring(leadingSpaces))
            }
        }
        else -> {
            appendInline(trimmed)
        }
    }
}

// 行内渲染：保留所有标记字符，对内容部分应用样式
private fun AnnotatedString.Builder.appendInline(text: String) {
    var i = 0
    while (i < text.length) {
        when {
            // 粗体 **text**
            text.startsWith("**", i) -> {
                val end = text.indexOf("**", i + 2)
                if (end != -1) {
                    withStyle(SpanStyle(color = MarkerColor)) { append("**") }
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(text.substring(i + 2, end))
                    }
                    withStyle(SpanStyle(color = MarkerColor)) { append("**") }
                    i = end + 2
                } else { append(text[i]); i++ }
            }
            // 删除线 ~~text~~
            text.startsWith("~~", i) -> {
                val end = text.indexOf("~~", i + 2)
                if (end != -1) {
                    withStyle(SpanStyle(color = MarkerColor)) { append("~~") }
                    withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) {
                        append(text.substring(i + 2, end))
                    }
                    withStyle(SpanStyle(color = MarkerColor)) { append("~~") }
                    i = end + 2
                } else { append(text[i]); i++ }
            }
            // 行内代码 `text`
            text[i] == '`' -> {
                val end = text.indexOf('`', i + 1)
                if (end != -1) {
                    withStyle(SpanStyle(color = MarkerColor)) { append("`") }
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)) {
                        append(text.substring(i + 1, end))
                    }
                    withStyle(SpanStyle(color = MarkerColor)) { append("`") }
                    i = end + 1
                } else { append(text[i]); i++ }
            }
            // 斜体 *text*
            text[i] == '*' && !text.startsWith("**", i) -> {
                val end = text.indexOf('*', i + 1)
                if (end != -1 && end > i + 1) {
                    withStyle(SpanStyle(color = MarkerColor)) { append("*") }
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(text.substring(i + 1, end))
                    }
                    withStyle(SpanStyle(color = MarkerColor)) { append("*") }
                    i = end + 1
                } else { append(text[i]); i++ }
            }
            // 链接 [text](url)
            text[i] == '[' -> {
                val textEnd = text.indexOf(']', i + 1)
                if (textEnd != -1 && textEnd + 1 < text.length && text[textEnd + 1] == '(') {
                    val urlEnd = text.indexOf(')', textEnd + 2)
                    if (urlEnd != -1) {
                        withStyle(SpanStyle(color = MarkerColor)) { append("[") }
                        withStyle(SpanStyle(color = AccentColor, textDecoration = TextDecoration.Underline)) {
                            append(text.substring(i + 1, textEnd))
                        }
                        withStyle(SpanStyle(color = MarkerColor)) {
                            append("](")
                            append(text.substring(textEnd + 2, urlEnd))
                            append(")")
                        }
                        i = urlEnd + 1
                    } else { append(text[i]); i++ }
                } else { append(text[i]); i++ }
            }
            else -> { append(text[i]); i++ }
        }
    }
}

// ============================================================
// 纯渲染组件（只读预览用，同样保留标记字符）
// ============================================================

@Composable
fun MarkdownText(markdown: String, modifier: Modifier = Modifier) {
    val annotated = buildMarkdownAnnotatedString(markdown)
    Text(text = annotated, style = MaterialTheme.typography.bodyMedium, modifier = modifier)
}
