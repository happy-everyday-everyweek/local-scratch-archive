package com.appmarket.admin.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.admin.data.AppCache
import com.appmarket.admin.data.SupabaseClient
import com.appmarket.admin.data.string
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*

class DbBrowserViewModel : ViewModel() {
    private val db = SupabaseClient()

    private val _rows = MutableStateFlow<List<JsonObject>>(emptyList())
    val rows: StateFlow<List<JsonObject>> = _rows

    private val _columns = MutableStateFlow<List<String>>(emptyList())
    val columns: StateFlow<List<String>> = _columns

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing

    private val _fromCache = MutableStateFlow(false)
    val fromCache: StateFlow<Boolean> = _fromCache

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // 当前加载的表名，用于检测切换表
    private var currentTable: String? = null

    private fun cacheKey(table: String) = "db_${table}_list"

    fun loadTable(tableName: String, forceRefresh: Boolean = false) {
        val key = cacheKey(tableName)
        // 切换表时清空旧数据
        val tableChanged = currentTable != null && currentTable != tableName
        if (tableChanged) {
            _rows.value = emptyList()
            _columns.value = emptyList()
            _fromCache.value = false
        }
        currentTable = tableName

        // 先读缓存秒显
        if (!forceRefresh && _rows.value.isEmpty()) {
            val cached = AppCache.getJson(key)
            if (cached != null) {
                try {
                    val arr = cached.jsonArray
                    val rowsList = arr.map { it.jsonObject }
                    _rows.value = rowsList
                    _columns.value = if (rowsList.isNotEmpty()) rowsList[0].keys.toList() else emptyList()
                    _fromCache.value = true
                } catch (_: Exception) {}
            }
        }

        val isFirstLoad = _rows.value.isEmpty()
        if (isFirstLoad) _loading.value = true else _refreshing.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = db.select(tableName, order = null)
                val rowsList = result.map { it.jsonObject }
                _rows.value = rowsList
                _columns.value = if (rowsList.isNotEmpty()) rowsList[0].keys.toList() else emptyList()
                AppCache.putJson(key, result)
                AppCache.putCount(key, result.size)
                _fromCache.value = false
                _error.value = null
            } catch (e: Exception) {
                if (_rows.value.isEmpty()) {
                    _error.value = e.message
                } else {
                    _error.value = "刷新失败（已显示缓存数据）: ${e.message}"
                }
            } finally {
                _loading.value = false
                _refreshing.value = false
            }
        }
    }

    fun deleteRow(tableName: String, id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                db.delete(tableName, id)
                _rows.value = _rows.value.filter { it.string("id") != id }
                AppCache.remove(cacheKey(tableName))
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    fun updateRow(tableName: String, id: String, data: JsonObject) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                db.update(tableName, id, data)
                AppCache.remove(cacheKey(tableName))
                loadTable(tableName, forceRefresh = true)
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }
}
