package com.appmarket.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.appmarket.admin.data.AppCache
import com.appmarket.admin.ui.screens.*
import com.appmarket.admin.ui.theme.AdminTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 初始化本地缓存
        AppCache.init(this)
        enableEdgeToEdge()
        setContent {
            AdminTheme {
                MainNavigation()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainNavigation() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomItems = listOf(
        NavItem("apps", "应用"),
        NavItem("articles", "博客"),
        NavItem("upload", "上传"),
        NavItem("db", "数据库")
    )

    // 只有主页面显示底部导航栏，编辑页面隐藏
    val showBottomBar = currentRoute in listOf("apps", "articles", "upload", "db")

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            icon = { Text(item.label.first().toString()) },
                            label = { Text(item.label) },
                            selected = currentRoute == item.route,
                            onClick = {
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "apps",
            modifier = Modifier.fillMaxSize().padding(innerPadding)
        ) {
            composable("apps") { AppListScreen(navController::navigate) }
            composable("apps/{id}") { backStackEntry ->
                AppEditScreen(
                    appId = backStackEntry.arguments?.getString("id") ?: "",
                    onBack = { navController.popBackStack() }
                )
            }
            composable("articles") { ArticleListScreen(navController::navigate) }
            composable("articles/{id}") { backStackEntry ->
                ArticleEditScreen(
                    articleId = backStackEntry.arguments?.getString("id") ?: "",
                    onBack = { navController.popBackStack() }
                )
            }
            composable("upload") { AddAppScreen() }
            composable("db") { DbBrowserScreen(navController::navigate) }
            composable("db/{table}") { backStackEntry ->
                DbTableScreen(
                    tableName = backStackEntry.arguments?.getString("table") ?: "",
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}

data class NavItem(val route: String, val label: String)
