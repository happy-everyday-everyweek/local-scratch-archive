package com.appmarket.admin.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.admin.data.*
import com.appmarket.admin.util.ApkMeta
import com.appmarket.admin.util.ApkParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*

data class UploadState(
    val apkUri: Uri? = null,
    val apkMeta: ApkMeta? = null,
    val name: String = "",
    val packageName: String = "",
    val description: String = "",
    val category: String = "opensource",
    val githubRepo: String = "",
    val latestVersion: String = "",
    val iconUploaded: Boolean = false,
    val iconUrl: String? = null,
    val uploading: Boolean = false,
    val success: Boolean = false,
    val error: String? = null
)

class UploadViewModel : ViewModel() {
    private val db = SupabaseClient()
    private val ownerId = "3aa93f0b-96f1-44b8-bc8c-cdb032847282"

    private val _state = MutableStateFlow(UploadState())
    val state: StateFlow<UploadState> = _state

    fun pickApk(context: android.content.Context, uri: Uri) {
        val meta = ApkParser.parseApk(context, uri)
        _state.value = _state.value.copy(
            apkUri = uri,
            apkMeta = meta,
            name = meta?.appName ?: "",
            packageName = meta?.packageName ?: "",
            latestVersion = meta?.versionName ?: ""
        )
    }

    fun updateName(v: String) { _state.value = _state.value.copy(name = v) }
    fun updatePackageName(v: String) { _state.value = _state.value.copy(packageName = v) }
    fun updateDescription(v: String) { _state.value = _state.value.copy(description = v) }
    fun updateCategory(v: String) { _state.value = _state.value.copy(category = v) }
    fun updateGithubRepo(v: String) { _state.value = _state.value.copy(githubRepo = v) }
    fun updateLatestVersion(v: String) { _state.value = _state.value.copy(latestVersion = v) }

    fun uploadIcon() {
        val meta = _state.value.apkMeta ?: return
        val iconDrawable = meta.icon ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val bytes = ApkParser.drawableToByteArray(iconDrawable)
                val path = "${_state.value.packageName}/icon.png"
                val url = db.uploadToStorage(AdminConfig.BUCKET_ICONS, path, bytes, "image/png")
                _state.value = _state.value.copy(iconUploaded = true, iconUrl = url)
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = "图标上传失败: ${e.message}")
            }
        }
    }

    fun submit() {
        val s = _state.value
        if (s.name.isBlank()) { _state.value = s.copy(error = "名称不能为空"); return }
        if (s.packageName.isBlank()) { _state.value = s.copy(error = "包名不能为空"); return }

        _state.value = s.copy(uploading = true, error = null)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val data = buildJsonObject {
                    put("owner_id", ownerId)
                    put("name", s.name)
                    put("package_name", s.packageName)
                    put("github_repo", if (s.githubRepo.isBlank()) JsonNull else JsonPrimitive(s.githubRepo))
                    put("category", s.category)
                    put("status", "approved")
                    put("description", if (s.description.isBlank()) JsonNull else JsonPrimitive(s.description))
                    put("latest_version", if (s.latestVersion.isBlank()) JsonNull else JsonPrimitive(s.latestVersion))
                    if (s.iconUrl != null) put("icon_url", s.iconUrl)
                }
                db.insert("apps", data)
                _state.value = _state.value.copy(uploading = false, success = true)
            } catch (e: Exception) {
                _state.value = _state.value.copy(uploading = false, error = e.message)
            }
        }
    }

    fun reset() { _state.value = UploadState() }
}
