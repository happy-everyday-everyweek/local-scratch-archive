package com.appmarket.admin.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.appmarket.admin.data.string
import com.appmarket.admin.viewmodel.DbBrowserViewModel
import kotlinx.serialization.json.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DbTableScreen(tableName: String, onBack: () -> Unit) {
    val vm: DbBrowserViewModel = viewModel()
    val rows by vm.rows.collectAsState()
    val columns by vm.columns.collectAsState()
    val loading by vm.loading.collectAsState()
    val error by vm.error.collectAsState()

    LaunchedEffect(tableName) { vm.loadTable(tableName) }

    var deleteId by remember { mutableStateOf<String?>(null) }
    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null },
            title = { Text("删除记录") },
            text = { Text("确定删除 $id?") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteRow(tableName, id)
                    deleteId = null
                }) { Text("删除") }
            },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("取消") } }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tableName) },
                navigationIcon = { TextButton(onClick = onBack) { Text("返回") } },
                actions = {
                    TextButton(onClick = { vm.loadTable(tableName, forceRefresh = true) }) { Text("刷新") }
                }
            )
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error)
                Text("${rows.size} 行", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(8.dp))

                val scrollState = rememberScrollState()
                Column(modifier = Modifier.fillMaxSize().horizontalScroll(scrollState)) {
                    // Header
                    Row(modifier = Modifier.padding(4.dp)) {
                        columns.forEach { col ->
                            Text(col, modifier = Modifier.width(120.dp).padding(2.dp), style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text("操作", modifier = Modifier.width(60.dp).padding(2.dp), style = MaterialTheme.typography.labelSmall)
                    }
                    Divider()
                    // Rows
                    rows.forEach { row ->
                        Row(modifier = Modifier.padding(4.dp)) {
                            columns.forEach { col ->
                                val value = row[col]?.let { el ->
                                    if (el is JsonNull) "null" else el.jsonPrimitive.content
                                } ?: ""
                                Text(value, modifier = Modifier.width(120.dp).padding(2.dp), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            val rowId = row.string("id")
                            TextButton(onClick = { if (rowId != null) deleteId = rowId }, modifier = Modifier.width(60.dp)) {
                                Text("Del", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
