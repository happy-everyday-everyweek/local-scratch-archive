package com.appmarket.admin.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.admin.data.*
import com.appmarket.admin.util.ApkMeta
import com.appmarket.admin.util.ApkParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

// ============================================================
// 添加应用 ViewModel
//
// 核心理解：
// - apps 表：存储应用基本信息（名称、包名、图标、描述、GitHub 仓库地址等），手动填写
// - app_apks 表：存储各版本 APK 下载链接，后端 daily-fetch-releases 自动从 GitHub Release 抓取
// - 所有分类（开源/正版/自然）本质上都是一个 GitHub 仓库地址
// - 本地选择 APK 仅用于辅助解析包名/图标/版本等信息，不上传 APK 文件
// ============================================================

data class GitHubRepoInfo(
    val name: String = "",
    val description: String = "",
    val fullName: String = "",
    val stars: Int = 0,
    val language: String = "",
    val homepage: String = ""
)

data class AddAppState(
    // 公共字段（手动填写）
    val appName: String = "",
    val packageName: String = "",
    val description: String = "",
    val githubRepo: String = "",
    val latestVersion: String = "",
    val category: String = "opensource",
    val iconUrl: String = "",
    val tagsText: String = "",
    // GitHub 仓库抓取
    val repoUrl: String = "",
    val fetchingRepo: Boolean = false,
    val repoInfo: GitHubRepoInfo? = null,
    // 本地 APK 辅助解析
    val apkUri: Uri? = null,
    val apkMeta: ApkMeta? = null,
    val iconUploaded: Boolean = false,
    val uploadingIcon: Boolean = false,
    // 提交状态
    val submitting: Boolean = false,
    val success: Boolean = false,
    val createdAppId: String? = null,
    val error: String? = null
)

class AddAppViewModel : ViewModel() {
    private val db = SupabaseClient()
    private val httpClient = OkHttpClient.Builder().build()
    private val ownerId = "3aa93f0b-96f1-44b8-bc8c-cdb032847282"

    private val _state = MutableStateFlow(AddAppState())
    val state: StateFlow<AddAppState> = _state

    fun updateAppName(v: String) { _state.value = _state.value.copy(appName = v) }
    fun updatePackageName(v: String) { _state.value = _state.value.copy(packageName = v) }
    fun updateDescription(v: String) { _state.value = _state.value.copy(description = v) }
    fun updateGithubRepo(v: String) { _state.value = _state.value.copy(githubRepo = v) }
    fun updateLatestVersion(v: String) { _state.value = _state.value.copy(latestVersion = v) }
    fun updateCategory(v: String) { _state.value = _state.value.copy(category = v) }
    fun updateIconUrl(v: String) { _state.value = _state.value.copy(iconUrl = v) }
    fun updateTagsText(v: String) { _state.value = _state.value.copy(tagsText = v) }
    fun updateRepoUrl(v: String) { _state.value = _state.value.copy(repoUrl = v) }

    // === GitHub 仓库地址抓取（辅助预填基本信息） ===
    fun fetchRepoInfo() {
        val url = _state.value.repoUrl.trim()
        if (url.isBlank()) {
            _state.value = _state.value.copy(error = "请输入 GitHub 仓库地址")
            return
        }

        val match = Regex("^https://github\\.com/([^/]+)/([^/]+)/?$").find(url)
        if (match == null) {
            _state.value = _state.value.copy(error = "地址格式无效，应为 https://github.com/owner/repo")
            return
        }

        val owner = match.groupValues[1]
        val repo = match.groupValues[2].removeSuffix(".git")

        _state.value = _state.value.copy(fetchingRepo = true, error = null)

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url("https://api.github.com/repos/$owner/$repo")
                    .header("User-Agent", "AppMarket-Admin/1.0")
                    .header("Accept", "application/vnd.github+json")
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw Exception("GitHub API 返回 ${response.code}")
                    }
                    val body = response.body?.string() ?: throw Exception("空响应")
                    val json = JSONObject(body)
                    val info = GitHubRepoInfo(
                        name = json.optString("name", ""),
                        description = json.optString("description", ""),
                        fullName = json.optString("full_name", ""),
                        stars = json.optInt("stargazers_count", 0),
                        language = json.optString("language", ""),
                        homepage = json.optString("homepage", "")
                    )
                    // 预填基本信息
                    _state.value = _state.value.copy(
                        fetchingRepo = false,
                        repoInfo = info,
                        appName = if (_state.value.appName.isBlank()) info.name else _state.value.appName,
                        description = if (_state.value.description.isBlank()) info.description else _state.value.description,
                        githubRepo = url,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(fetchingRepo = false, error = "抓取失败: ${e.message}")
            }
        }
    }

    // === 本地 APK 辅助解析（仅用于解析包名/版本/图标，不上传 APK） ===
    fun pickApk(context: Context, uri: Uri) {
        val meta = ApkParser.parseApk(context, uri)
        if (meta == null) {
            _state.value = _state.value.copy(error = "无法解析 APK 文件")
            return
        }
        // 预填基本信息（不覆盖已有内容）
        _state.value = _state.value.copy(
            apkUri = uri,
            apkMeta = meta,
            appName = if (_state.value.appName.isBlank()) meta.appName else _state.value.appName,
            packageName = if (_state.value.packageName.isBlank()) meta.packageName else _state.value.packageName,
            latestVersion = if (_state.value.latestVersion.isBlank()) meta.versionName else _state.value.latestVersion,
            error = null
        )
    }

    // === 上传图标到 Storage（辅助功能） ===
    fun uploadIcon() {
        val meta = _state.value.apkMeta ?: return
        val iconDrawable = meta.icon ?: return
        _state.value = _state.value.copy(uploadingIcon = true)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val bytes = ApkParser.drawableToByteArray(iconDrawable)
                val path = "${_state.value.packageName.ifBlank { "unknown" }}/icon.png"
                val url = db.uploadToStorage(AdminConfig.BUCKET_ICONS, path, bytes, "image/png")
                if (url != null) {
                    _state.value = _state.value.copy(iconUploaded = true, iconUrl = url, uploadingIcon = false)
                } else {
                    _state.value = _state.value.copy(uploadingIcon = false, error = "图标上传返回空 URL")
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(uploadingIcon = false, error = "图标上传失败: ${e.message}")
            }
        }
    }

    // === 提交创建应用 ===
    // 创建 apps 表记录（基本信息），后端 daily-fetch-releases 会自动抓取各版本 APK 到 app_apks 表
    fun submit() {
        val s = _state.value
        if (s.appName.isBlank()) { _state.value = s.copy(error = "应用名称不能为空"); return }
        if (s.githubRepo.isBlank()) { _state.value = s.copy(error = "GitHub 仓库地址不能为空"); return }

        _state.value = s.copy(submitting = true, error = null)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val data = buildJsonObject {
                    put("owner_id", ownerId)
                    put("name", s.appName)
                    put("package_name", if (s.packageName.isBlank()) JsonNull else JsonPrimitive(s.packageName))
                    put("github_repo", s.githubRepo)
                    put("category", s.category)
                    put("status", "pending_fetch")
                    put("description", if (s.description.isBlank()) JsonNull else JsonPrimitive(s.description))
                    put("latest_version", if (s.latestVersion.isBlank()) JsonNull else JsonPrimitive(s.latestVersion))
                    put("icon_url", if (s.iconUrl.isBlank()) JsonNull else JsonPrimitive(s.iconUrl))
                    val tagList = s.tagsText.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    if (tagList.isNotEmpty()) {
                        put("tags", JsonArray(tagList.map { JsonPrimitive(it) }))
                    }
                }
                val result = db.insert("apps", data)
                val appId = result["id"]?.jsonPrimitive?.content

                // 创建成功后，触发后端抓取 Release（自动抓取各版本 APK 到 app_apks 表）
                if (appId != null) {
                    try { db.rpc("daily-fetch-releases", buildJsonObject { }) } catch (_: Exception) {}
                }

                _state.value = _state.value.copy(submitting = false, success = true, createdAppId = appId)
            } catch (e: Exception) {
                _state.value = _state.value.copy(submitting = false, error = e.message)
            }
        }
    }

    fun reset() { _state.value = AddAppState() }
}
