package com.appmarket.admin.data

import kotlinx.serialization.json.*

fun JsonObject.string(key: String): String? = get(key)?.let { if (it is JsonNull) null else it.jsonPrimitive.content }
fun JsonObject.int(key: String): Int = get(key)?.jsonPrimitive?.intOrNull ?: 0
fun JsonObject.long(key: String): Long = get(key)?.jsonPrimitive?.longOrNull ?: 0L
fun JsonObject.bool(key: String): Boolean = get(key)?.jsonPrimitive?.booleanOrNull ?: false
fun JsonObject.stringList(key: String): List<String>? = get(key)?.let { if (it is JsonNull) null else it.jsonArray.map { e -> e.jsonPrimitive.content } }

fun JsonObject.toAppItem() = AppItem(
    id = string("id") ?: "",
    name = string("name") ?: "",
    packageName = string("package_name"),
    githubRepo = string("github_repo"),
    category = string("category") ?: "opensource",
    status = string("status") ?: "pending_fetch",
    reviewLevel = string("review_level"),
    virusSafeReason = string("virus_safe_reason"),
    iconUrl = string("icon_url"),
    description = string("description"),
    latestVersion = string("latest_version"),
    screenshots = stringList("screenshots"),
    tags = stringList("tags"),
    downloadCount = int("download_count"),
    ownerId = string("owner_id") ?: "",
    createdAt = string("created_at"),
    updatedAt = string("updated_at")
)

fun JsonObject.toArticleItem() = ArticleItem(
    id = string("id") ?: "",
    authorId = string("author_id") ?: "",
    type = string("type") ?: "article",
    title = string("title") ?: "",
    cover = string("cover"),
    content = string("content") ?: "",
    appIds = stringList("app_ids") ?: emptyList(),
    tags = stringList("tags") ?: emptyList(),
    createdAt = string("created_at")
)

fun JsonObject.toProfileItem() = ProfileItem(
    id = string("id") ?: "",
    deviceFingerprint = string("device_fingerprint") ?: "",
    role = string("role") ?: "user",
    deviceToken = string("device_token") ?: "",
    createdAt = string("created_at")
)

fun JsonObject.toMirrorSiteItem() = MirrorSiteItem(
    id = string("id") ?: "",
    name = string("name") ?: "",
    urlTemplate = string("url_template") ?: "",
    siteType = string("site_type") ?: "prefix",
    enabled = bool("enabled"),
    priority = int("priority"),
    isOfficial = bool("is_official")
)

fun JsonObject.toApkItem() = ApkItem(
    id = string("id") ?: "",
    appId = string("app_id") ?: "",
    version = string("version") ?: "",
    filename = string("filename") ?: "",
    size = long("size"),
    arch = string("arch"),
    githubAssetUrl = string("github_asset_url") ?: "",
    releaseNotes = string("release_notes")
)

fun JsonObject.toMessageItem() = MessageItem(
    id = string("id") ?: "",
    recipientId = string("recipient_id") ?: "",
    title = string("title") ?: "",
    content = string("content") ?: "",
    type = string("type") ?: "",
    read = bool("read"),
    createdAt = string("created_at")
)

fun JsonObject.toFetchLogItem() = FetchLogItem(
    id = string("id") ?: "",
    appId = string("app_id") ?: "",
    releaseId = get("release_id")?.jsonPrimitive?.longOrNull,
    status = string("status") ?: "",
    apkCount = int("apk_count"),
    errorMessage = string("error_message"),
    createdAt = string("created_at")
)

fun JsonObject.toDownloadLogItem() = DownloadLogItem(
    id = string("id") ?: "",
    profileId = string("profile_id") ?: "",
    appId = string("app_id") ?: "",
    apkId = string("apk_id") ?: "",
    status = string("status") ?: "",
    bytesDownloaded = long("bytes_downloaded"),
    totalBytes = get("total_bytes")?.jsonPrimitive?.longOrNull,
    startedAt = string("started_at")
)
