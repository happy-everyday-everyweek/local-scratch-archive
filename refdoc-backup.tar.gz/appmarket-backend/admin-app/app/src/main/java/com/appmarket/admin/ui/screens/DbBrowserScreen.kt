package com.appmarket.admin.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private val TABLES = listOf(
    "profiles", "apps", "app_apks", "articles", "mirror_sites",
    "download_logs", "messages", "user_settings", "inherit_codes",
    "fetch_logs", "view_history", "app_tags"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DbBrowserScreen(navigate: (String) -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("数据库浏览") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(TABLES) { table ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { navigate("db/$table") }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(table, style = MaterialTheme.typography.titleMedium)
                        Text(">", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}
