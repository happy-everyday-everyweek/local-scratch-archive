package com.appmarket.admin.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonPrimitive

// ============================================================
// 本地缓存层
//
// 基于 SharedPreferences 持久化 JSON 数据，配合内存 LRU 缓存提升读取速度。
// 设计目标：
// 1. 列表/详情数据先从缓存恢复（首屏秒开），后台再拉取最新数据覆盖
// 2. 提供时间戳新鲜度判断，避免短时间内重复请求
// 3. 写入失败（如磁盘满）不影响主流程
// ============================================================

object AppCache {
    private const val PREFS_NAME = "appmarket_admin_cache"
    private const val KEY_PREFIX_DATA = "data_"
    private const val KEY_PREFIX_TIME = "time_"
    private const val KEY_PREFIX_COUNT = "count_"

    // 默认缓存有效期（毫秒）：5 分钟
    const val DEFAULT_FRESH_DURATION_MS = 5 * 60 * 1000L

    private lateinit var prefs: SharedPreferences
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    // 内存缓存：避免每次都反序列化
    private val memoryCache = mutableMapOf<String, String>()
    private val memoryTime = mutableMapOf<String, Long>()

    // 必须在 Application 或 Activity 启动时初始化
    fun init(context: Context) {
        if (this::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private fun ensureInit() {
        check(this::prefs.isInitialized) {
            "AppCache 未初始化，请先调用 AppCache.init(context)"
        }
    }

    // === 基础存取 ===

    /** 写入任意 JSON 字符串（任意字符串数据均可） */
    fun putString(key: String, data: String) {
        ensureInit()
        val fullKey = KEY_PREFIX_DATA + key
        try {
            prefs.edit()
                .putString(fullKey, data)
                .putLong(KEY_PREFIX_TIME + key, System.currentTimeMillis())
                .apply()
            memoryCache[fullKey] = data
            memoryTime[key] = System.currentTimeMillis()
        } catch (_: Exception) {
            // 写入失败不影响主流程
        }
    }

    /** 读取字符串数据 */
    fun getString(key: String): String? {
        ensureInit()
        val fullKey = KEY_PREFIX_DATA + key
        memoryCache[fullKey]?.let { return it }
        val data = prefs.getString(fullKey, null) ?: return null
        memoryCache[fullKey] = data
        return data
    }

    /** 读取数据并解析为 JsonElement */
    fun getJson(key: String): JsonElement? {
        val raw = getString(key) ?: return null
        return try {
            json.parseToJsonElement(raw)
        } catch (_: Exception) {
            null
        }
    }

    /** 写入 JsonElement */
    fun putJson(key: String, element: JsonElement) {
        putString(key, element.toString())
    }

    /** 缓存写入时间戳，0 表示无缓存 */
    fun getTimestamp(key: String): Long {
        ensureInit()
        memoryTime[key]?.let { return it }
        val t = prefs.getLong(KEY_PREFIX_TIME + key, 0L)
        memoryTime[key] = t
        return t
    }

    /** 缓存是否新鲜（在 freshDurationMs 内写入过） */
    fun isFresh(key: String, freshDurationMs: Long = DEFAULT_FRESH_DURATION_MS): Boolean {
        val ts = getTimestamp(key)
        if (ts == 0L) return false
        return System.currentTimeMillis() - ts < freshDurationMs
    }

    /** 缓存是否存在 */
    fun exists(key: String): Boolean = getString(key) != null

    /** 删除单条缓存 */
    fun remove(key: String) {
        ensureInit()
        val fullKey = KEY_PREFIX_DATA + key
        prefs.edit()
            .remove(fullKey)
            .remove(KEY_PREFIX_TIME + key)
            .remove(KEY_PREFIX_COUNT + key)
            .apply()
        memoryCache.remove(fullKey)
        memoryTime.remove(key)
    }

    /** 清空所有缓存 */
    fun clearAll() {
        ensureInit()
        prefs.edit().clear().apply()
        memoryCache.clear()
        memoryTime.clear()
    }

    // === 便捷方法：列表数据 ===

    /** 缓存列表项数量（用于显示 "缓存中 N 项" 提示） */
    fun putCount(key: String, count: Int) {
        ensureInit()
        try {
            prefs.edit().putInt(KEY_PREFIX_COUNT + key, count).apply()
        } catch (_: Exception) {}
    }

    fun getCount(key: String): Int {
        ensureInit()
        return prefs.getInt(KEY_PREFIX_COUNT + key, 0)
    }

    // === 便捷方法：单条详情缓存 ===

    /** 缓存单条详情（按 id 索引） */
    fun putDetail(table: String, id: String, element: JsonElement) {
        putJson("${table}_detail_$id", element)
    }

    fun getDetail(table: String, id: String): JsonElement? {
        return getJson("${table}_detail_$id")
    }

    fun isDetailFresh(table: String, id: String, freshDurationMs: Long = DEFAULT_FRESH_DURATION_MS): Boolean {
        return isFresh("${table}_detail_$id", freshDurationMs)
    }

    /** 失效单条详情缓存 */
    fun removeDetail(table: String, id: String) {
        remove("${table}_detail_$id")
    }
}
