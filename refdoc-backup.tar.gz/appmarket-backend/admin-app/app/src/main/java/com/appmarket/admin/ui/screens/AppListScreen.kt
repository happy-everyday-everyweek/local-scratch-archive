package com.appmarket.admin.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.appmarket.admin.data.AppItem
import com.appmarket.admin.viewmodel.AppListViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppListScreen(navigate: (String) -> Unit) {
    val vm: AppListViewModel = viewModel()
    val apps by vm.apps.collectAsState()
    val loading by vm.loading.collectAsState()
    val refreshing by vm.refreshing.collectAsState()
    val fromCache by vm.fromCache.collectAsState()
    val error by vm.error.collectAsState()

    LaunchedEffect(Unit) { vm.loadApps() }

    var showDeleteDialog by remember { mutableStateOf<AppItem?>(null) }

    showDeleteDialog?.let { app ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("删除应用") },
            text = { Text("确定删除 ${app.name}?") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteApp(app.id)
                    showDeleteDialog = null
                }) { Text("删除") }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = null }) { Text("取消") } }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("应用管理") },
                actions = {
                    IconButton(onClick = { vm.loadApps(forceRefresh = true) }, enabled = !refreshing) {
                        if (refreshing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = "刷新")
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    if (fromCache) {
                        AssistChip(
                            onClick = { vm.loadApps(forceRefresh = true) },
                            leadingIcon = { Icon(Icons.Default.CloudOff, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("离线缓存（点击刷新）") }
                        )
                    }
                }
                item {
                    if (error != null) {
                        Text(error!!, color = MaterialTheme.colorScheme.error)
                    }
                }
                items(apps, key = { it.id }) { app ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { navigate("apps/${app.id}") }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(app.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(app.packageName ?: "-", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AssistChip(
                                        onClick = {},
                                        label = { Text(app.category) }
                                    )
                                    AssistChip(
                                        onClick = {},
                                        label = { Text(app.status) }
                                    )
                                    app.latestVersion?.let {
                                        AssistChip(onClick = {}, label = { Text(it) })
                                    }
                                }
                            }
                            IconButton(onClick = { showDeleteDialog = app }) {
                                Icon(Icons.Default.Delete, contentDescription = "删除")
                            }
                        }
                    }
                }
            }
        }
    }
}
