package com.appmarket.admin.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.appmarket.admin.data.AppCache
import com.appmarket.admin.data.SupabaseClient
import com.appmarket.admin.data.toAppItem
import com.appmarket.admin.ui.components.MarkdownEditor
import com.appmarket.admin.ui.components.SectionHeader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*

// ============================================================
// 应用编辑页面
// 美化 UI + Markdown 编辑器 + 全中文
// ============================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppEditScreen(appId: String, onBack: () -> Unit) {
    val db = remember { SupabaseClient() }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    var name by remember { mutableStateOf("") }
    var packageName by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var githubRepo by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("opensource") }
    var status by remember { mutableStateOf("pending_fetch") }
    var latestVersion by remember { mutableStateOf("") }
    var iconUrl by remember { mutableStateOf("") }
    var tagsText by remember { mutableStateOf("") }
    var virusSafeReason by remember { mutableStateOf("") }

    LaunchedEffect(appId) {
        // 先读缓存秒显
        val cached = AppCache.getDetail("apps", appId)
        if (cached != null) {
            try {
                val item = cached.jsonObject.toAppItem()
                name = item.name
                packageName = item.packageName ?: ""
                description = item.description ?: ""
                githubRepo = item.githubRepo ?: ""
                category = item.category
                status = item.status
                latestVersion = item.latestVersion ?: ""
                iconUrl = item.iconUrl ?: ""
                tagsText = item.tags?.joinToString(", ") ?: ""
                virusSafeReason = item.virusSafeReason ?: ""
                loading = false
            } catch (_: Exception) {}
        }
        // 后台拉取最新
        withContext(Dispatchers.IO) {
            try {
                val result = db.select("apps", filter = "id=eq.$appId")
                if (result.isNotEmpty()) {
                    val item = result[0].jsonObject.toAppItem()
                    name = item.name
                    packageName = item.packageName ?: ""
                    description = item.description ?: ""
                    githubRepo = item.githubRepo ?: ""
                    category = item.category
                    status = item.status
                    latestVersion = item.latestVersion ?: ""
                    iconUrl = item.iconUrl ?: ""
                    tagsText = item.tags?.joinToString(", ") ?: ""
                    virusSafeReason = item.virusSafeReason ?: ""
                    AppCache.putDetail("apps", appId, result[0])
                }
            } catch (e: Exception) {
                // 网络失败时若有缓存数据不报错
                if (cached == null) error = e.message
            }
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("编辑应用") },
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                        Spacer(Modifier.width(4.dp))
                        Text("返回")
                    }
                }
            )
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (error != null) {
                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Error, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onErrorContainer)
                            Spacer(Modifier.width(8.dp))
                            Text(error!!, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                // === 基本信息 ===
                SectionHeader("基本信息")

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("应用名称") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = packageName,
                    onValueChange = { packageName = it },
                    label = { Text("包名") },
                    placeholder = { Text("com.example.app") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = githubRepo,
                    onValueChange = { githubRepo = it },
                    label = { Text("GitHub 仓库地址") },
                    placeholder = { Text("https://github.com/owner/repo") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = latestVersion,
                    onValueChange = { latestVersion = it },
                    label = { Text("最新版本") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = iconUrl,
                    onValueChange = { iconUrl = it },
                    label = { Text("图标 URL") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = tagsText,
                    onValueChange = { tagsText = it },
                    label = { Text("标签（逗号分隔）") },
                    placeholder = { Text("工具, 效率, AI") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // === 分类 ===
                Text("分类", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("开源" to "opensource", "正版" to "genuine", "自然" to "natural").forEach { (label, value) ->
                        FilterChip(
                            selected = category == value,
                            onClick = { category = value },
                            label = { Text(label) }
                        )
                    }
                }

                // === 状态 ===
                Text("审核状态", style = MaterialTheme.typography.labelLarge)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf(
                        "待抓取" to "pending_fetch",
                        "待审核" to "pending_review",
                        "已通过" to "approved",
                        "报毒但安全" to "virus_safe",
                        "已拒绝" to "rejected"
                    ).forEach { (label, value) ->
                        FilterChip(
                            selected = status == value,
                            onClick = { status = value },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                if (status == "virus_safe") {
                    OutlinedTextField(
                        value = virusSafeReason,
                        onValueChange = { virusSafeReason = it },
                        label = { Text("报毒但安全的原因说明") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // === 描述（Markdown 编辑器） ===
                SectionHeader("应用描述")
                MarkdownEditor(
                    value = description,
                    onValueChange = { description = it },
                    label = "应用描述（支持 Markdown）",
                    minHeight = 150
                )

                Spacer(Modifier.height(8.dp))

                // === 保存按钮 ===
                Button(
                    onClick = {
                        saving = true
                        kotlinx.coroutines.MainScope().launch(Dispatchers.IO) {
                            try {
                                val data = buildJsonObject {
                                    put("name", name)
                                    put("package_name", if (packageName.isBlank()) JsonNull else JsonPrimitive(packageName))
                                    put("github_repo", if (githubRepo.isBlank()) JsonNull else JsonPrimitive(githubRepo))
                                    put("category", category)
                                    put("status", status)
                                    put("latest_version", if (latestVersion.isBlank()) JsonNull else JsonPrimitive(latestVersion))
                                    put("icon_url", if (iconUrl.isBlank()) JsonNull else JsonPrimitive(iconUrl))
                                    put("description", if (description.isBlank()) JsonNull else JsonPrimitive(description))
                                    put("virus_safe_reason", if (virusSafeReason.isBlank()) JsonNull else JsonPrimitive(virusSafeReason))
                                    val tagList = tagsText.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                                    put("tags", JsonArray(tagList.map { JsonPrimitive(it) }))
                                }
                                db.update("apps", appId, data)
                                AppCache.removeDetail("apps", appId)
                                AppCache.remove("apps_list")
                                error = null
                            } catch (e: Exception) { error = e.message }
                            saving = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    enabled = !saving
                ) {
                    if (saving) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(Modifier.width(8.dp))
                        Text("保存中...")
                    } else {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("保存")
                    }
                }
            }
        }
    }
}
