package com.appmarket.admin.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.appmarket.admin.data.AppItem

// ============================================================
// 应用多选下拉框
//
// 用于在文章/推荐/主题中关联应用：
// - 顶部输入框（点击展开下拉面板）
// - 下拉面板含搜索框 + 列表 + 复选框
// - 已选项以 Chip 形式横向滚动展示在输入框下方
// ============================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MultiSelectAppDropdown(
    allApps: List<AppItem>,
    selectedIds: List<String>,
    onSelectionChange: (List<String>) -> Unit,
    label: String = "关联应用",
    modifier: Modifier = Modifier,
    loading: Boolean = false
) {
    var expanded by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    // 已选应用列表（保持选中顺序，过滤不存在的）
    val selectedApps = remember(allApps, selectedIds) {
        selectedIds.mapNotNull { id -> allApps.find { it.id == id } }
    }

    // 搜索过滤
    val filteredApps = remember(allApps, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) allApps
        else allApps.filter {
            it.name.lowercase().contains(q) ||
                (it.packageName?.lowercase()?.contains(q) == true) ||
                (it.githubRepo?.lowercase()?.contains(q) == true)
        }
    }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
        modifier = modifier.fillMaxWidth()
    ) {
        // 触发器：显示已选项数量
        OutlinedTextField(
            value = if (selectedApps.isEmpty()) {
                ""
            } else if (selectedApps.size == 1) {
                selectedApps[0].name
            } else {
                "已选 ${selectedApps.size} 个应用"
            },
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            placeholder = { Text("点击选择关联应用") },
            trailingIcon = {
                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                }
            },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            // 搜索框
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("搜索应用名称/包名/仓库") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )

            HorizontalDivider()

            // 列表
            if (filteredApps.isEmpty()) {
                Text(
                    if (loading) "加载中..." else "无匹配应用",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp)
                ) {
                    items(filteredApps, key = { it.id }) { app ->
                        val checked = app.id in selectedIds
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = checked,
                                        onCheckedChange = null,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            app.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        app.packageName?.let {
                                            Text(
                                                it,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            },
                            onClick = {
                                val newSelection = if (checked) {
                                    selectedIds.filter { it != app.id }
                                } else {
                                    selectedIds + app.id
                                }
                                onSelectionChange(newSelection)
                            }
                        )
                    }
                }
            }
        }
    }

    // 已选应用 Chip 区
    if (selectedApps.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            selectedApps.forEach { app ->
                InputChip(
                    selected = true,
                    onClick = {},
                    label = { Text(app.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    trailingIcon = {
                        IconButton(
                            onClick = { onSelectionChange(selectedIds.filter { it != app.id }) },
                            modifier = Modifier.size(18.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "移除", modifier = Modifier.size(14.dp))
                        }
                    }
                )
            }
        }
    }
}
