package com.appmarket.admin.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.admin.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*

class AppListViewModel : ViewModel() {
    private val db = SupabaseClient()

    // 缓存 key
    private val cacheKey = "apps_list"

    private val _apps = MutableStateFlow<List<AppItem>>(emptyList())
    val apps: StateFlow<List<AppItem>> = _apps

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    // 是否正在后台刷新（首屏已显示，仅拉取最新）
    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing

    // 是否当前数据来自缓存（用于 UI 提示）
    private val _fromCache = MutableStateFlow(false)
    val fromCache: StateFlow<Boolean> = _fromCache

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    /** 加载应用列表（forceRefresh = true 表示强制刷新，如下拉刷新） */
    fun loadApps(forceRefresh: Boolean = false) {
        // 先读缓存秒显（仅在非强制刷新且当前无数据时）
        if (!forceRefresh && _apps.value.isEmpty()) {
            val cached = AppCache.getJson(cacheKey)
            if (cached != null) {
                try {
                    val arr = cached.jsonArray
                    _apps.value = arr.map { it.jsonObject.toAppItem() }
                    _fromCache.value = true
                } catch (_: Exception) {}
            }
        }

        // 后台拉取最新
        val isFirstLoad = _apps.value.isEmpty()
        if (isFirstLoad) _loading.value = true else _refreshing.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = db.select("apps", order = "created_at.desc")
                _apps.value = result.map { it.jsonObject.toAppItem() }
                AppCache.putJson(cacheKey, result)
                AppCache.putCount(cacheKey, result.size)
                _fromCache.value = false
                _error.value = null
            } catch (e: Exception) {
                // 网络失败时若已有缓存数据则不报错（仅提示），否则报错
                if (_apps.value.isEmpty()) {
                    _error.value = e.message
                } else {
                    _error.value = "刷新失败（已显示缓存数据）: ${e.message}"
                }
            } finally {
                _loading.value = false
                _refreshing.value = false
            }
        }
    }

    fun deleteApp(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                db.delete("apps", id)
                _apps.value = _apps.value.filter { it.id != id }
                // 失效缓存（下次进入页面会重新拉取最新数据）
                AppCache.remove(cacheKey)
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    fun updateApp(id: String, data: JsonObject) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                db.update("apps", id, data)
                loadApps(forceRefresh = true)
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    fun updateStatus(id: String, status: String) {
        updateApp(id, buildJsonObject { put("status", status) })
    }
}
