package com.appmarket.admin.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.appmarket.admin.ui.components.MarkdownEditor
import com.appmarket.admin.ui.components.SectionHeader
import com.appmarket.admin.viewmodel.AddAppViewModel

// ============================================================
// 添加应用页面
//
// 核心理解：
// - apps 表：手动填写应用基本信息（名称、包名、图标、描述、GitHub 仓库地址）
// - app_apks 表：后端 daily-fetch-releases 自动从 GitHub Release 抓取各版本 APK
// - 所有分类（开源/正版/自然）本质上都是一个 GitHub 仓库地址
// - 提供两种辅助工具：GitHub 仓库地址抓取预填 / 本地 APK 解析预填
// ============================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAppScreen() {
    val vm: AddAppViewModel = viewModel()
    val state by vm.state.collectAsState()
    val context = LocalContext.current

    val apkLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { vm.pickApk(context, it) }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("添加应用") }) }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 说明卡片
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("应用信息说明", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text(
                        "基本信息（名称、包名、图标、描述、GitHub 仓库地址）需要手动填写。" +
                        "提交后，后端会自动从 GitHub Release 抓取各版本 APK 下载链接。",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "开源 / 正版 / 自然 三种分类本质上都是一个 GitHub 仓库地址。" +
                        "开源=开源项目；正版=官方发布；自然=对正版 APK 的再打包。",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            // === 辅助工具 ===
            SectionHeader("辅助工具（可选）")

            // 工具1：GitHub 仓库地址抓取
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("从 GitHub 仓库抓取信息", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text("输入 GitHub 仓库地址，自动预填应用名称和描述", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = state.repoUrl,
                        onValueChange = { vm.updateRepoUrl(it) },
                        label = { Text("GitHub 仓库地址") },
                        placeholder = { Text("https://github.com/owner/repo") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Button(
                        onClick = { vm.fetchRepoInfo() },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !state.fetchingRepo && state.repoUrl.isNotBlank()
                    ) {
                        if (state.fetchingRepo) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(Modifier.width(8.dp))
                            Text("抓取中...")
                        } else {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("抓取仓库信息")
                        }
                    }

                    state.repoInfo?.let { repo ->
                        Surface(tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(repo.fullName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                if (repo.description.isNotBlank()) {
                                    Text(repo.description, style = MaterialTheme.typography.bodySmall)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    InfoChip(Icons.Default.Star, "${repo.stars}")
                                    if (repo.language.isNotBlank()) {
                                        InfoChip(Icons.Default.Code, repo.language)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 工具2：本地 APK 解析
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("从本地 APK 解析信息", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text("选择本地 APK 文件，自动解析包名、版本、图标等信息", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Button(
                        onClick = {
                            apkLauncher.launch(arrayOf(
                                "application/vnd.android.package-archive",
                                "application/octet-stream",
                                "*/*"
                            ))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (state.apkMeta != null) "重新选择 APK" else "选择本地 APK")
                    }

                    state.apkMeta?.let { meta ->
                        Surface(tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                InfoRow("包名", meta.packageName)
                                InfoRow("版本", meta.versionName)
                                InfoRow("版本号", meta.versionCode.toString())
                                InfoRow("最低 SDK", meta.minSdkVersion.toString())

                                if (meta.icon != null) {
                                    Spacer(Modifier.height(4.dp))
                                    Button(
                                        onClick = { vm.uploadIcon() },
                                        enabled = !state.iconUploaded && !state.uploadingIcon,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        if (state.uploadingIcon) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                                            Spacer(Modifier.width(8.dp))
                                            Text("上传图标中...")
                                        } else if (state.iconUploaded) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Text("图标已上传")
                                        } else {
                                            Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Text("上传图标到 Storage")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            // === 应用基本信息（手动填写） ===
            SectionHeader("应用基本信息")

            OutlinedTextField(
                value = state.appName,
                onValueChange = { vm.updateAppName(it) },
                label = { Text("应用名称 *") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = state.packageName,
                onValueChange = { vm.updatePackageName(it) },
                label = { Text("包名") },
                placeholder = { Text("com.example.app") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = state.githubRepo,
                onValueChange = { vm.updateGithubRepo(it) },
                label = { Text("GitHub 仓库地址 *") },
                placeholder = { Text("https://github.com/owner/repo") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = state.iconUrl,
                onValueChange = { vm.updateIconUrl(it) },
                label = { Text("图标 URL") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = state.latestVersion,
                onValueChange = { vm.updateLatestVersion(it) },
                label = { Text("最新版本") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = state.tagsText,
                onValueChange = { vm.updateTagsText(it) },
                label = { Text("标签（逗号分隔）") },
                placeholder = { Text("工具, 效率, AI") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // 分类
            Text("分类", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("开源" to "opensource", "正版" to "genuine", "自然" to "natural").forEach { (label, value) ->
                    FilterChip(
                        selected = state.category == value,
                        onClick = { vm.updateCategory(value) },
                        label = { Text(label) }
                    )
                }
            }

            // 描述（Markdown 编辑器）
            SectionHeader("应用描述")
            MarkdownEditor(
                value = state.description,
                onValueChange = { vm.updateDescription(it) },
                label = "应用描述（支持 Markdown）",
                minHeight = 150
            )

            Spacer(Modifier.height(8.dp))

            // 成功提示
            AnimatedVisibility(visible = state.success) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("应用创建成功!", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        state.createdAppId?.let { Text("ID: $it", style = MaterialTheme.typography.bodySmall) }
                        Text("后端将自动从 GitHub Release 抓取各版本 APK", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }

            // 提交按钮
            if (!state.success) {
                Button(
                    onClick = { vm.submit() },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    enabled = !state.submitting && state.appName.isNotBlank() && state.githubRepo.isNotBlank()
                ) {
                    if (state.submitting) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(Modifier.width(8.dp))
                        Text("创建中...")
                    } else {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("创建应用")
                    }
                }
            } else {
                OutlinedButton(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                    Text("继续添加")
                }
            }
        }
    }
}

@Composable
private fun InfoChip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp))
        Text(text, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}
