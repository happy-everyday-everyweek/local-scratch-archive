// ============================================================
// 内置配置（个人管理工具，直接内嵌 key，绕过权限校验）
// ============================================================

object AdminConfig {
    // Supabase 项目 URL
    const val SUPABASE_URL = "https://ibqeewjbdtcvgedsqflh.supabase.co"

    // service_role key（管理员权限，绕过 RLS）
    // 注意：此 key 仅用于个人管理工具，切勿随正式 APP 分发
    const val SUPABASE_SERVICE_ROLE_KEY =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlicWVld2piZHRjdmdlZHNxZmxoIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MTQwMzY3MywiZXhwIjoyMDk2OTc5NjczfQ.MGzoBQJHHUYiP_-W20SdISEIhBTLXrDyAYcNBkqXwX8"

    // REST API 基础路径
    const val REST_BASE = "$SUPABASE_URL/rest/v1"

    // Storage 基础路径（图标、截图上传）
    const val STORAGE_BASE = "$SUPABASE_URL/storage/v1"

    // 图标存储桶名
    const val BUCKET_ICONS = "icons"

    // 截图存储桶名
    const val BUCKET_SCREENSHOTS = "screenshots"
}
