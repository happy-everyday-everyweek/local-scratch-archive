# 后端交接文档

> 本文档面向接手后端任务的智能体，完整描述 Supabase 后端的连接方式、密钥、数据库架构、Edge Functions、定时任务与运维操作。阅读本文档后应能独立完成后端所有开发与维护任务。

---

## 一、项目概览

### 1.1 项目定位

应用市场 + 博客 Android 应用的后端，基于 Supabase BaaS（PostgreSQL + Edge Functions + Storage + Vault + pg_cron）。

核心业务：
- **应用市场**：无需注册（设备指纹账号体系），支持上传/下载应用、GitHub Release 自动抓取 APK、镜像站下载加速、应用分类（开源 / 正版 / 自然）、审核流程
- **博客系统**：发布文章 / 推荐 / 主题，Markdown 正文，可关联应用
- **信息流**：Apple Today 风格的混排卡片推荐

### 1.2 项目标识

| 项 | 值 |
| --- | --- |
| Project Ref | `ibqeewjbdtcvgedsqflh` |
| Project Name | happy-everyday-everyweek's Project |
| Organization ID | `qrcxeyuqkekibzsdauag` |
| Supabase URL | `https://ibqeewjbdtcvgedsqflh.supabase.co` |
| Region | ap-northeast-1 (东京) |

### 1.3 服务版本

| 服务 | 版本 |
| --- | --- |
| Postgres | 17.6.1.127 |
| GoTrue (Auth) | v2.191.0 |
| PostgREST | v14.5 |
| Storage | v1.60.10 |
| Edge Runtime | Deno（policy: per_worker） |

### 1.4 代码位置

后端代码全部位于 `/workspace/supabase/`：
- `migrations/` — 数据库 migration（5 个文件）
- `functions/` — Edge Functions（15 个）
- `config.toml` — Supabase 本地配置
- `seed.sql` — 种子数据（当前为空占位）
- `.env.example` — 环境变量示例
- `.temp/` — Supabase CLI 元数据（项目绑定信息等）

---

## 二、密钥体系

### 2.1 密钥清单（真实可用值）

> **重要**：以下 service_role key 拥有完全数据库访问权限（绕过 RLS），切勿泄露或放入正式客户端 APP。当前内嵌于个人管理工具 `admin-app` 中，仅供站长本人使用。

#### service_role key（服务端，绕过 RLS）

```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlicWVld2piZHRjdmdlZHNxZmxoIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MTQwMzY3MywiZXhwIjoyMDk2OTc5NjczfQ.MGzoBQJHHUYiP_-W20SdISEIhBTLXrDyAYcNBkqXwX8
```

- 格式：Legacy JWT（`eyJ...` 三段式）
- iss: `supabase`
- ref: `ibqeewjbdtcvgedsqflh`
- role: `service_role`
- iat: 1781403673（2026-06-13）
- exp: 2096979673（2036-06-09，10 年有效期）
- **当前验证可用**（REST API 返回 200，可读写所有表）

#### Publishable key（客户端，anon 角色，受 RLS 约束）

```
sb_publishable_21y8mRrxJWW8LTFMWWMKYw_GbDyQtuS
```

- 格式：Supabase 新格式（`sb_publishable_...`）
- 客户端 APP 持有，可安全暴露
- **当前验证可用**（可读公开表如 mirror_sites）

#### 数据库密码

- **当前未知**（不在代码仓库中，仅存在于 Supabase 服务端环境变量与本地 `.env`）
- Pooler 连接串（需密码）：`postgresql://postgres.ibqeewjbdtcvgedsqflh@aws-1-ap-northeast-1.pooler.supabase.com:5432/postgres`
- 如需直连数据库，请通过 Supabase 控制台重置密码或查看 Database Settings

#### GitHub Token（GITHUB_TOKEN）

- **可选**，用于 Edge Function 调用 GitHub API 时提高速率限制（未认证 60 次/小时，认证后 5000 次/小时）
- 当前是否已配置未知（需通过 `supabase secrets list` 确认，需登录 CLI）
- 若未配置，`daily-fetch-releases` 等函数仍可工作，但大批量抓取会触发速率限制

### 2.2 密钥使用规则

| 角色 | 可持有的 key |
| --- | --- |
| 客户端 APP（android/） | 仅 Publishable key |
| 个人管理工具（admin-app/） | service_role key（内嵌，仅站长用） |
| Edge Function | service_role key（从 `Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")` 读取，绝不硬编码） |
| pg_cron 定时任务 | Publishable key（存于 Vault，用于调用 Edge Function 的 Authorization header） |

详见 `/workspace/SECURITY.md`。

---

## 三、连接方式

### 3.1 REST API（PostgREST）

**基础路径**：`https://ibqeewjbdtcvgedsqflh.supabase.co/rest/v1`

**请求头**：
```
apikey: <key>
Authorization: Bearer <key>
Content-Type: application/json
Prefer: return=representation   # 写操作返回数据
```

**示例**（用 service_role key 读 apps 表）：
```bash
curl "https://ibqeewjbdtcvgedsqflh.supabase.co/rest/v1/apps?select=id,name&limit=5" \
  -H "apikey: <SERVICE_ROLE_KEY>" \
  -H "Authorization: Bearer <SERVICE_ROLE_KEY>"
```

**过滤器语法**：`?id=eq.<uuid>`、`?status=in.(pending_fetch,approved)`、`order=created_at.desc`

### 3.2 Edge Functions

**基础路径**：`https://ibqeewjbdtcvgedsqflh.supabase.co/functions/v1/<function_name>`

**请求头**：
```
Authorization: Bearer <publishable_key 或 service_role_key>
apikey: <key>
Content-Type: application/json
device_token: <设备令牌>   # 多数 Edge Function 需要（设备指纹账号体系）
```

**verify_jwt 配置**：全局 `enabled = false`（见 `config.toml`），即 Edge Function 不验证 JWT，自行从 `device_token` header 鉴权。

### 3.3 Storage

**基础路径**：`https://ibqeewjbdtcvgedsqflh.supabase.co/storage/v1`

**Buckets**：
- `icons` — 应用图标
- `screenshots` — 应用截图

**上传**（需 service_role key）：
```
PUT /storage/v1/object/<bucket>/<path>
Header: x-upsert: true
返回公共 URL: /storage/v1/object/public/<bucket>/<path>
```

### 3.4 数据库直连（Pooler）

```
postgresql://postgres.ibqeewjbdtcvgedsqflh@aws-1-ap-northeast-1.pooler.supabase.com:5432/postgres
```
- 端口 5432，事务模式 pooler（pool_mode=transaction）
- 需数据库密码（见 2.1）

---

## 四、数据库架构

### 4.1 表清单

共 11 张表，定义在 `migrations/00001_init_schema.sql`：

| 表名 | 用途 | 关键字段 |
| --- | --- | --- |
| `profiles` | 设备指纹账号 | id, device_fingerprint(unique), role(user/admin/owner), device_token, github_pat_secret_id |
| `apps` | 应用基本信息（手动填写） | id, owner_id, name, package_name, github_repo, category, status, review_level, icon_url, latest_version |
| `app_apks` | APK 各版本下载链接（自动抓取） | id, app_id, release_id, version, filename, size, arch, github_asset_url, release_notes |
| `mirror_sites` | 镜像站配置 | id, name, url_template, site_type(prefix/replace), enabled, priority, is_official |
| `articles` | 博客内容 | id, author_id, type(article/recommend/theme), title, cover, content(Markdown), app_ids[], tags[] |
| `download_logs` | 下载日志 | profile_id, app_id, apk_id, mirror_site_id, status, bytes_downloaded, total_bytes |
| `messages` | 站内消息 | recipient_id, title, content, type(system/review/download/general), related_app_id, read |
| `user_settings` | 用户设置（与 profiles 一对一，id=profile_id） | id, preferred_mirror_site_id, github_username, github_repo_for_upload |
| `inherit_codes` | 账号继承码（一次性，10 分钟有效） | source_profile_id, code(unique), expires_at, used |
| `fetch_logs` | Release 抓取日志 | app_id, release_id, status(success/failed/no_update/no_release/rate_limited), apk_count, error_message |
| `view_history` | 浏览历史（推荐算法） | profile_id, app_id, viewed_at |
| `app_tags` | 应用标签（推荐召回用，与 apps.tags 互补） | app_id, tag |

### 4.2 核心表关系

```
profiles (1) ──< apps (owner_id) ──< app_apks (app_id)
         ──< articles (author_id)
         ──< download_logs (profile_id)
         ──< messages (recipient_id)
         ──< user_settings (1:1, id=profile_id)
         ──< view_history (profile_id)
         ──< inherit_codes (source_profile_id)
```

### 4.3 apps 表状态机（重要）

```
pending_fetch ──(daily-fetch-releases 抓到 APK)──> pending_review
pending_review ──(开源: auto-review-opensource)──> approved / rejected
pending_review ──(正版/自然: manual-review)──> approved / virus_safe / rejected
approved ──(daily-fetch-releases 检测新版本)──> approved (更新 latest_version)
```

- `status` 取值：`pending_fetch` / `pending_review` / `approved` / `virus_safe` / `rejected`
- `review_level`（仅开源）：`failed` / `passed` / `premium`
- `category` 取值：`opensource`（开源）/ `genuine`（正版）/ `natural`（自然=对正版 APK 的自然化）

### 4.4 两个核心表的设计要点（易混淆）

- **`apps` 表**：存储应用**基本信息**（名称、包名、图标、描述、GitHub 仓库地址等），由用户/管理员**手动填写**
- **`app_apks` 表**：存储各版本 APK 下载链接，由后端 `daily-fetch-releases` Edge Function **自动从 GitHub Release 抓取**
- **所有分类（开源/正版/自然）本质上都是一个 GitHub 仓库地址**，区别仅在审核流程不同

### 4.5 数据库函数（RPC）

定义在 migrations 中，可经 REST `/rest/v1/rpc/<fn_name>` 调用：

| 函数 | 定义位置 | 用途 | 权限 |
| --- | --- | --- | --- |
| `get_current_profile_id()` | 00001 | 通过 request header 的 device_token 获取当前 profile_id | security definer，所有角色可调用 |
| `handle_new_profile()` | 00001 | 触发器：首个 profile 自动设为 owner | before insert 触发器 |
| `update_updated_at()` | 00001 | 触发器：自动更新 updated_at | before update 触发器 |
| `execute_inherit(p_code, p_target_profile_id)` | 00003 | 账号继承原子转移（事务内转移所有数据） | security definer，仅 service_role |
| `save_github_pat(p_profile_id, p_pat)` | 00005 | 将 PAT 存入 Vault | security definer，仅 service_role |
| `get_github_pat(p_profile_id)` | 00005 | 从 Vault 读取 PAT 明文 | security definer，仅 service_role（函数内校验 role） |

### 4.6 RLS 策略要点

- **设备指纹账号体系**，不使用 Supabase Auth，通过 `device_token` header + `get_current_profile_id()` 识别用户
- `profiles`：用户只能读/改自己的；新设备可创建（首个自动 owner）
- `apps`：所有人可读 `status in ('approved','virus_safe')` 的；用户只能写自己 owner_id 的；`status/review_level/virus_safe_reason` 字段已 revoke 直接写权限（必须经 Edge Function）
- `app_apks` / `mirror_sites` / `articles` / `app_tags`：所有人可读，不可直接写（必须经 Edge Function）
- `download_logs` / `user_settings` / `view_history`：用户只能读写自己 profile_id 的
- `messages`：用户只能读自己 recipient_id 的，只能改 read 字段
- `inherit_codes` / `fetch_logs`：anon/authenticated 完全无权访问（仅 service_role）

---

## 五、Edge Functions 清单

共 15 个 Edge Function，全部位于 `/workspace/supabase/functions/<name>/index.ts`。

### 5.1 账号体系

| 函数名 | 方法 | 鉴权 | 功能 |
| --- | --- | --- | --- |
| `create-or-get-profile` | POST | 无需 device_token（body 传 device_fingerprint） | 创建或获取 profile，返回 profile_id/device_token/role |
| `generate-inherit-code` | POST | device_token | 生成 8 位一次性继承码（10 分钟有效） |
| `execute-inherit` | POST | device_token + body{code} | 执行账号继承，调用 RPC `execute_inherit` 转移所有数据 |
| `assign-role` | POST | device_token（仅 owner）+ body{target_profile_id, new_role} | 修改用户角色（user<->admin，不能设 owner） |
| `list-profiles` | POST | device_token（仅 owner/admin）+ body{offset, limit} | 列出所有 profiles（不返回 device_token） |

### 5.2 应用上传

| 函数名 | 方法 | 鉴权 | 功能 |
| --- | --- | --- | --- |
| `submit-app-by-repo` | POST | device_token + body{github_repo, category, name, description, package_name?} | 通过 GitHub 仓库地址上传应用（开源/正版/自然通用）。创建 apps 记录(pending_fetch)，立即抓取最新 Release 的 APK，更新 status 为 pending_review，开源分类自动触发 auto-review |
| `upload-apk-direct` | POST | device_token + body{apk_base64, app_name, package_name, version, description, category, icon_base64?, filename} | 通过用户 GitHub PAT 直接上传 APK 到 GitHub Release（仅 genuine/natural）。从 Vault 读 PAT，从 user_settings 读 github_username/repo，创建 Release 并上传资产 |
| `save-github-pat` | POST | device_token + body{pat} | 将 GitHub PAT 安全存入 Vault（调用 RPC save_github_pat） |

### 5.3 自动抓取

| 函数名 | 方法 | 鉴权 | 功能 |
| --- | --- | --- | --- |
| `daily-fetch-releases` | POST/GET | 无（cron 触发或手动） | 遍历 status in ('pending_fetch','approved') 的 apps，调用 GitHub API 抓最新 Release，筛选 APK 资产，检测新版本则删除旧 app_apks 记录插入新记录，更新 apps.latest_version，记录 fetch_logs。处理 403 速率限制（X-RateLimit-Remaining<5 时停止）。**核心函数** |

### 5.4 审核

| 函数名 | 方法 | 鉴权 | 功能 |
| --- | --- | --- | --- |
| `auto-review-opensource` | POST | service_role（body{app_id?}，不传则遍历所有 pending_review 的开源 app） | 开源自动审核：调 GitHub API 取 star 数与仓库大小。判定：仓库大小(bytes)<APK大小×0.5 → failed/rejected；star<10000 → passed/approved；star>=10000 → premium/approved。未通过则发站内消息 |
| `list-pending-reviews` | POST | device_token（仅 owner/admin） | 查询待人工审核应用列表（status=pending_review） |
| `manual-review` | POST | device_token（仅 owner/admin）+ body{app_id, action, virus_safe_reason?} | 人工审核：action=approve/virus_safe/reject。virus_safe 须提供原因并发站内消息 |

### 5.5 内容与推荐

| 函数名 | 方法 | 鉴权 | 功能 |
| --- | --- | --- | --- |
| `publish-content` | POST | device_token（仅 owner/admin）+ body{type, title, cover?, content, app_ids?, tags?} | 发布博客内容（article/recommend/theme）。recommend/theme 须关联 app_ids，article 强制 app_ids 为空 |
| `get-feed` | POST | device_token?（匿名也可）+ body{page, page_size} | 信息流推荐：混排卡片（你可能需要/重磅更新/全新上线/单应用/文章），多应用卡片不连续 |

### 5.6 镜像站

| 函数名 | 方法 | 鉴权 | 功能 |
| --- | --- | --- | --- |
| `check-mirror-health` | POST/GET | 无 | 遍历 enabled 的 mirror_sites，HEAD 请求测试 URL（默认 docker/compose Release，可经 MIRROR_HEALTH_TEST_URL 环境变量覆盖），5 秒超时，更新 last_health_check 字段 |

### 5.7 通用约定

- 所有函数从 `Deno.env.get("SUPABASE_URL")` 和 `Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")` 读取配置，**绝不硬编码**
- CORS 头允许 `*`，允许的 header 包含 `device_token`
- 错误响应统一格式：`{ "error": "<error_code>", "message": "<中文说明>" }`
- `GITHUB_TOKEN` 可选，存在时附加到 GitHub API 请求头提高速率限制

---

## 六、定时任务（pg_cron）

定义在 `migrations/00004_setup_cron.sql`：

| Job 名 | Cron 表达式 | 含义 | 调用 |
| --- | --- | --- | --- |
| `daily-fetch-releases` | `0 19 * * *` | UTC 19:00 = 北京时间 03:00 | `net.http_post` 调用 Edge Function，Authorization 用 Vault 中的 publishable_key，timeout 5 分钟 |

依赖扩展：
- `pg_cron`（定时调度）
- `pg_net`（从数据库发起 HTTP 请求）
- `supabase_vault`（存储 project_url 和 publishable_key 两个 secret）

Vault 中预置的 secrets：
- `project_url` = `https://ibqeewjbdtcvgedsqflh.supabase.co`
- `publishable_key` = `sb_publishable_21y8mRrxJWW8LTFMWWMKYw_GbDyQtuS`

**手动触发 daily-fetch-releases**：
```bash
curl -X POST "https://ibqeewjbdtcvgedsqflh.supabase.co/functions/v1/daily-fetch-releases" \
  -H "Authorization: Bearer <publishable_or_service_key>" \
  -H "apikey: <key>" \
  -H "Content-Type: application/json" \
  -d '{}'
```
返回示例：`{"total":5,"success":0,"no_update":5,"no_release":0,"rate_limited":0,"errors":[]}`

---

## 七、镜像站配置

定义在 `migrations/00001`（预置 22 条）+ `migrations/00002`（更新真实域名）。

- **官方源 GitHub**：`is_official=true`，域名替换型 `https://github.com{path}`，优先级 100
- **前缀代理型**：`https://镜像域名/{github_url}`，{github_url} 为完整 GitHub 下载链接
- 共 22 条，其中 17 条已验证真实域名（enabled=true），4 条禁用（Zwy/LIkk/CrashMc/GhProxyNetHyphe，未找到真实域名）
- 镜像站健康检查由 `check-mirror-health` Edge Function 负责

---

## 八、运维操作

### 8.1 Supabase CLI

```bash
# 登录（需要 access token，从 Supabase 控制台 Account Settings 获取）
npx supabase login

# 列出 Edge Function secrets
npx supabase secrets list --project-ref ibqeewjbdtcvgedsqflh

# 设置 secret（如 GITHUB_TOKEN）
npx supabase secrets set GITHUB_TOKEN=ghp_xxxxx --project-ref ibqeewjbdtcvgedsqflh

# 部署单个 Edge Function
npx supabase functions deploy daily-fetch-releases --project-ref ibqeewjbdtcvgedsqflh

# 查看函数日志
npx supabase functions logs daily-fetch-releases --project-ref ibqeewjbdtcvgedsqflh
```

### 8.2 数据库操作

经 REST API（service_role key）即可完成大部分操作。复杂查询或迁移走 SQL：

```bash
# 通过 psql 直连（需密码）
psql "postgresql://postgres.ibqeewjbdtcvgedsqflh@aws-1-ap-northeast-1.pooler.supabase.com:5432/postgres" -U postgres

# 或经 Supabase Studio SQL Editor
```

### 8.3 应用数据库 migration

migration 文件按序号执行，新增 migration 时：
1. 在 `migrations/` 新建 `00006_<name>.sql`
2. 通过 Supabase Studio SQL Editor 或 psql 执行
3. 本地开发用 `npx supabase db reset` 重置（会重跑所有 migration + seed.sql）

### 8.4 Storage 管理

在 Supabase Studio → Storage 创建/管理 buckets。当前需要：
- `icons`（public read）
- `screenshots`（public read）

---

## 九、已知问题与注意事项

### 9.1 service_role key 401 问题（已自行恢复）

历史记录：service_role key 曾通过 REST API 返回 401 "Invalid API key"，但 Edge Function 经环境变量使用正常。**当前已验证恢复正常**（2026-07-01 测试返回 200）。若再次出现，排查方向：
- 确认 key 未过期（exp 2036-06-09）
- 确认请求头同时包含 `apikey` 和 `Authorization: Bearer`
- 通过 Supabase Management API 获取最新 key 列表确认是否被轮换
- 新格式 key（`sb_secret_...`）曾出现在 Management API 返回中，若 legacy key 失效可尝试新格式

### 9.2 owner profile

- 数据库触发器 `handle_new_profile` 使**首个创建的 profile 自动成为 owner**
- admin-app 内嵌的 `owner_id = "3aa93f0b-96f1-44b8-bc8c-cdb032847282"`（在 `AddAppViewModel.kt` 和 `ArticleListViewModel.kt` 中硬编码），这是站长的 profile_id
- 若需修改 owner 或转移站长，需经专门逻辑（当前 `assign-role` 不允许直接设 owner）

### 9.3 app_apks 表为空

手动触发 `daily-fetch-releases` 曾返回 `no_update=5`，说明 5 个 app 都没新版本（可能 release_id 已存在且 version 未变，或 app 状态不在 pending_fetch/approved）。排查：
- 确认 app 的 status 为 `pending_fetch` 或 `approved`
- 确认 github_repo 格式正确（`https://github.com/owner/repo`）
- 查看 fetch_logs 表最新记录的 status 与 error_message

### 9.4 GitHub API 速率限制

- 未认证：60 次/小时
- 认证（GITHUB_TOKEN）：5000 次/小时
- `daily-fetch-releases` 在 X-RateLimit-Remaining<5 时停止后续抓取
- 若抓取异常，优先配置 GITHUB_TOKEN

### 9.5 Edge Function 请求体限制

`upload-apk-direct` 使用 base64 传 APK，大文件可能超 Edge Function 请求体限制。代码注释已标注：生产环境应改用 Storage 中转（客户端上传到 Storage，Edge Function 下载再传 GitHub）。

### 9.6 本地开发

- `config.toml` 中本地端口：API 54321 / DB 54322 / Studio 54323 / Storage 在 8000
- `verify_jwt = false`（设备指纹体系不用 Supabase Auth JWT）
- `auth.email.enable_signup = false`（不开放邮箱注册）
- Edge Runtime policy = `per_worker`

---

## 十、相关代码索引

### 后端
- 数据库 schema：`/workspace/supabase/migrations/00001_init_schema.sql`
- 镜像站更新：`/workspace/supabase/migrations/00002_update_mirror_sites.sql`
- 账号继承函数：`/workspace/supabase/migrations/00003_inherit_function.sql`
- pg_cron 配置：`/workspace/supabase/migrations/00004_setup_cron.sql`
- GitHub PAT Vault：`/workspace/supabase/migrations/00005_github_pat_vault.sql`
- Edge Functions：`/workspace/supabase/functions/<name>/index.ts`
- 配置：`/workspace/supabase/config.toml`
- 安全规范：`/workspace/SECURITY.md`

### 客户端（参考用）
- 客户端配置（Publishable key）：`/workspace/android/app/src/main/java/com/appmarket/blog/util/Config.kt`
- 管理工具配置（service_role key）：`/workspace/admin-app/app/src/main/java/com/appmarket/admin/data/AdminConfig.kt`

---

## 十一、快速验证清单

接手后建议依次执行以下验证，确认后端各组件正常：

```bash
# 1. REST API 可用性（service_role key）
curl -s -o /dev/null -w "%{http_code}\n" \
  "https://ibqeewjbdtcvgedsqflh.supabase.co/rest/v1/apps?select=id&limit=1" \
  -H "apikey: <SERVICE_ROLE_KEY>" -H "Authorization: Bearer <SERVICE_ROLE_KEY>"
# 期望: 200

# 2. Publishable key 可用性
curl -s -o /dev/null -w "%{http_code}\n" \
  "https://ibqeewjbdtcvgedsqflh.supabase.co/rest/v1/mirror_sites?select=name&limit=1" \
  -H "apikey: sb_publishable_21y8mRrxJWW8LTFMWWMKYw_GbDyQtuS" \
  -H "Authorization: Bearer sb_publishable_21y8mRrxJWW8LTFMWWMKYw_GbDyQtuS"
# 期望: 200

# 3. Edge Function 可用性（手动触发抓取）
curl -s -X POST "https://ibqeewjbdtcvgedsqflh.supabase.co/functions/v1/daily-fetch-releases" \
  -H "Authorization: Bearer <SERVICE_ROLE_KEY>" -H "apikey: <SERVICE_ROLE_KEY>" \
  -H "Content-Type: application/json" -d '{}'
# 期望: {"total":N,"success":N,...}

# 4. Storage 可用性（读公共图标）
curl -s -o /dev/null -w "%{http_code}\n" \
  "https://ibqeewjbdtcvgedsqflh.supabase.co/storage/v1/object/public/icons/test.png"
# 期望: 200 或 404（404 表示 bucket 可访问但文件不存在，属正常）

# 5. 检查 app_apks 表是否有数据
curl -s "https://ibqeewjbdtcvgedsqflh.supabase.co/rest/v1/app_apks?select=id&limit=1" \
  -H "apikey: <SERVICE_ROLE_KEY>" -H "Authorization: Bearer <SERVICE_ROLE_KEY>"
# 期望: [{"id":"..."}] 或 []
```

---

**文档生成时间**：2026-07-01
**后端代码位置**：`/workspace/supabase/`
**维护者**：原开发智能体 → 交接给后端专项智能体
