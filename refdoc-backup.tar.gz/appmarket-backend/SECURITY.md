# 安全规范

本项目涉及多种密钥与敏感数据，所有贡献者必须严格遵守以下规范。

## 一、密钥分级

| 密钥类型 | 存放位置 | 是否可入仓库 | 是否可入客户端 |
| --- | --- | --- | --- |
| 数据库密码 | Supabase 服务端环境变量、本地 `.env` | 否 | 否 |
| service_role key | Supabase 服务端环境变量、Edge Function secrets、本地 `.env` | 否 | 否 |
| GitHub PAT（服务端） | Supabase Vault（加密存储） | 否 | 否 |
| GitHub PAT（用户） | Supabase Vault（经 Edge Function 加密写入） | 否 | 否 |
| Publishable key（anon key） | 客户端代码 `Config.kt` | 是 | 是 |

## 二、客户端约束

1. 客户端（Android）**仅持有 Publishable key**（anon key），见
   `android/app/src/main/java/com/appmarket/blog/util/Config.kt`。
2. 客户端**绝不**出现以下内容：
   - 数据库密码
   - service_role key
   - 用户的 GitHub PAT 明文
3. 客户端初始化 Supabase SDK 时只使用 Publishable key，见
   `android/app/src/main/java/com/appmarket/blog/data/remote/SupabaseClient.kt`。
4. 所有敏感写操作（应用上传、审核状态变更、角色变更、账号继承、GitHub 密钥存储、
   Release 资产上传等）必须经 Edge Function，由服务端使用 service_role key 执行，
   RLS 对 anon/authenticated 角色禁止直接写这些表。

## 三、服务端约束

1. 数据库密码与 service_role key 仅存于：
   - Supabase 服务端环境变量
   - Edge Function secrets
   - 本地开发 `.env`（已被 `.gitignore` 忽略，不入仓库）
2. 用户的 GitHub PAT 经 Edge Function 写入 Supabase Vault（加密存储），
   客户端不持久化 PAT 明文。
3. Edge Function 中读取密钥使用 Deno 环境变量（`Deno.env.get(...)`），
   不硬编码。

## 四、本地开发

1. 复制 `supabase/.env.example` 为 `supabase/.env`，填入真实值。
2. `.env` 已被 `.gitignore` 忽略，**不要**强制提交。
3. 签名文件（`*.keystore`、`*.jks`）已被 `.gitignore` 忽略。

## 五、审计

在每次合并前与发布前，执行以下检查：

1. 全局搜索数据库密码，确认未出现在任何文件中。
2. 全局搜索 `service_role`，确认仅出现在文档与 `.env.example` 占位符中，
   不出现在客户端代码或真实 `.env` 之外的文件中。
3. 确认客户端代码中只有 Publishable key。
4. 确认无 GitHub PAT 明文硬编码。

## 六、泄露应急

若发现密钥泄露：

1. 立即在 Supabase 控制台轮换泄露的密钥。
2. 撤销已泄露的 GitHub PAT 并重新生成。
3. 使用 `git filter-repo` 或 BFG 清理历史记录中的泄露内容。
4. 通知所有贡献者重新拉取代码。
