# Add project specific ProGuard rules here.
# Keep Supabase 与 Kotlinx Serialization 相关类
-keepattributes Signature, Exceptions
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep class io.github.jan.supabase.** { *; }
