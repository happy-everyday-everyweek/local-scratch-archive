package com.appmarket.blog.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * 文章类型枚举，对应 articles 表的 type 字段。
 *
 * 序列化时使用 @SerialName 对应数据库中的字符串值。
 *
 * @property value 数据库中存储的类型字符串
 */
@Serializable
enum class ArticleType(val value: String) {
    /** 普通文章 */
    @SerialName("article") ARTICLE("article"),

    /** 推荐文章（关联应用） */
    @SerialName("recommend") RECOMMEND("recommend"),

    /** 主题合集（关联多个应用） */
    @SerialName("theme") THEME("theme"),
    ;

    companion object {
        /**
         * 从数据库字符串解析类型，未知值默认为 ARTICLE。
         */
        fun fromValue(value: String?): ArticleType =
            entries.find { it.value == value } ?: ARTICLE
    }
}

/**
 * 文章数据模型，对应数据库 articles 表。
 *
 * @property id 文章 UUID
 * @property authorId 作者 profile UUID
 * @property type 文章类型（article / recommend / theme）
 * @property title 标题
 * @property cover 封面图 URL
 * @property content 正文内容
 * @property appIds 关联应用 ID 数组（recommend / theme 类型使用）
 * @property tags 标签数组
 * @property createdAt 创建时间
 */
@Serializable
data class Article(
    @SerialName("id") val id: String,
    @SerialName("author_id") val authorId: String? = null,
    @SerialName("type") val type: ArticleType = ArticleType.ARTICLE,
    @SerialName("title") val title: String,
    @SerialName("cover") val cover: String? = null,
    @SerialName("content") val content: String? = null,
    @SerialName("app_ids") val appIds: List<String>? = null,
    @SerialName("tags") val tags: List<String>? = null,
    @SerialName("created_at") val createdAt: String? = null,
)
