package com.appmarket.blog

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.appmarket.blog.ui.navigation.AppMarketNavHost
import com.appmarket.blog.ui.theme.AppMarketBlogTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * 应用唯一 Activity，承载 Compose 导航。
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppMarketBlogTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppMarketNavHost()
                }
            }
        }
    }
}
