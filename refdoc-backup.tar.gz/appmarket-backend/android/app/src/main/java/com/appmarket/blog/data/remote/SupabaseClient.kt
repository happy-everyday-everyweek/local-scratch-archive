package com.appmarket.blog.data.remote

import com.appmarket.blog.util.Config
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.annotations.SupabaseInternal
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.functions.Functions
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.storage.Storage
import io.ktor.client.engine.android.Android

/**
 * Supabase 客户端单例。
 *
 * 安全约束：
 * - 仅使用 Publishable key（anon key）初始化，绝不使用 service_role key。
 * - 数据库密码不在此处出现，客户端不直连数据库。
 * - 所有敏感写操作（应用上传、审核、角色变更、账号继承、GitHub 密钥存储等）
 *   必须经 Edge Function 由服务端 service_role key 执行。
 *
 * 设备指纹账号体系：
 * - 通过 httpConfig 安装 AuthInterceptor.Plugin，为所有请求附加 device_token header。
 * - device_token 由 AuthInterceptor.deviceTokenProvider 动态提供，
 *   AppModule 在依赖注入时从 SecureStorage 读取并设置。
 * - 服务端 RLS 通过 request header 中的 device_token 匹配用户
 *   （见数据库 get_current_profile_id() 函数）。
 */
object SupabaseClient {

    /**
     * 全局共享的 Supabase 客户端实例。
     * 懒加载，首次访问时初始化。
     *
     * 注意：AuthInterceptor.deviceTokenProvider 必须在首次访问 client 前由
     * AppModule 设置，否则请求不会携带 device_token header。
     */
    @OptIn(SupabaseInternal::class)
    val client: SupabaseClient by lazy {
        createSupabaseClient(
            supabaseUrl = Config.SUPABASE_URL,
            supabaseKey = Config.SUPABASE_PUBLISHABLE_KEY,
        ) {
            // 使用 Ktor Android 引擎（Android 为工厂，需调用 create() 创建引擎实例）
            httpEngine = Android.create()

            // 安装所需模块
            install(Postgrest)
            install(Functions)
            install(Storage)
            install(Realtime)

            // 安装自定义 HTTP 插件：为所有请求附加 device_token header
            // Supabase Kotlin SDK v2.5.4 未提供全局 customHeaders 配置，
            // 通过 httpConfig 安装 Ktor 自定义插件实现
            httpConfig {
                install(AuthInterceptor.Plugin)
            }
        }
    }
}
