package com.appmarket.blog.data.repository

import com.appmarket.blog.data.local.SecureStorage
import com.appmarket.blog.data.remote.MirrorSite
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * 用户设置 Repository，负责镜像站列表查询与用户优先镜像站设置。
 *
 * 通过 Supabase Postgrest 查询 mirror_sites 与 user_settings 表。
 * device_token 由 AuthInterceptor 自动附加到请求 header，通过 RLS 鉴权。
 *
 * 安全说明：仅持有 Publishable key，user_settings 的写入受 RLS 限制，
 * 用户只能修改自己的 preferred_mirror_site_id 字段。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
class SettingsRepository(
    private val supabaseClient: SupabaseClient,
    private val secureStorage: SecureStorage,
) {

    /**
     * 查询所有启用的镜像站，按优先级升序排列。
     *
     * @return 启用的镜像站列表，查询失败返回空列表
     */
    suspend fun getMirrorSites(): List<MirrorSite> {
        return try {
            val result = supabaseClient.postgrest.from("mirror_sites").select {
                filter { eq("enabled", true) }
                order("priority", io.github.jan.supabase.postgrest.query.Order.ASCENDING)
            }
            result.decodeList<MirrorSite>()
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * 获取当前用户的优先镜像站 ID。
     *
     * 从 user_settings 表查询 preferred_mirror_site_id 字段。
     * 通过当前 profile_id 定位用户行。
     *
     * @return 优先镜像站 ID，未设置或查询失败返回 null
     */
    suspend fun getPreferredMirror(): String? {
        val profileId = secureStorage.getProfileId() ?: return null
        return try {
            val result = supabaseClient.postgrest.from("user_settings").select {
                filter { eq("profile_id", profileId) }
            }
            val settings = result.decodeList<PreferredMirrorDto>().firstOrNull()
            settings?.preferredMirrorSiteId
        } catch (_: Exception) {
            null
        }
    }

    /**
     * 设置当前用户的优先镜像站。
     *
     * 更新 user_settings 表的 preferred_mirror_site_id 字段。
     * 通过当前 profile_id 定位用户行，RLS 确保只能修改自己的设置。
     *
     * @param mirrorSiteId 镜像站 ID，传 null 表示清除优先设置
     * @return 是否更新成功
     */
    suspend fun setPreferredMirror(mirrorSiteId: String?): Boolean {
        val profileId = secureStorage.getProfileId() ?: return false
        return try {
            val updateBody: JsonObject = buildJsonObject {
                put("preferred_mirror_site_id", mirrorSiteId)
            }
            supabaseClient.postgrest.from("user_settings").update(updateBody) {
                filter { eq("profile_id", profileId) }
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}

/**
 * user_settings 表的客户端查询 DTO。
 */
@Serializable
private data class PreferredMirrorDto(
    @SerialName("preferred_mirror_site_id") val preferredMirrorSiteId: String? = null,
)
