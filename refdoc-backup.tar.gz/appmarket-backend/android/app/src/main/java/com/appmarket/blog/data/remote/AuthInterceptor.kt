package com.appmarket.blog.data.remote

import io.ktor.client.plugins.api.createClientPlugin

/**
 * 请求拦截器：为所有 Supabase 请求附加 device_token header。
 *
 * 设备指纹账号体系通过 request header 中的 device_token 匹配用户（见数据库
 * get_current_profile_id() 函数与 RLS 策略）。此 Ktor 插件确保每个请求都
 * 携带当前设备的 device_token，从而通过 RLS 行级安全策略。
 *
 * 实现说明：
 * - Supabase Kotlin SDK v2.5.4 未提供全局 customHeaders 配置，因此通过
 *   httpConfig 安装自定义 Ktor 插件实现全局 header 注入。
 * - deviceTokenProvider 由 AppModule 在依赖注入时设置，从 SecureStorage
 *   读取当前 device_token。使用 @Volatile 保证多线程可见性。
 * - onRequest 在每次请求发送前调用，动态读取最新 token，支持登录/登出后
 *   立即生效。
 */
object AuthInterceptor {

    /**
     * 当前设备 token 提供者，由 AppModule 在依赖注入时设置。
     * 返回 null 表示尚未登录（此时不附加 device_token header）。
     */
    @Volatile
    var deviceTokenProvider: (() -> String?)? = null

    /**
     * Ktor 自定义插件：为每个请求附加 device_token header。
     *
     * 在 SupabaseClient.kt 中通过 httpConfig { install(AuthInterceptor.Plugin) } 安装。
     */
    val Plugin = createClientPlugin("DeviceTokenAuth") {
        // 每次请求发送前动态读取最新 device_token，支持登录/登出后立即生效
        onRequest { request, _ ->
            val token = deviceTokenProvider?.invoke()
            if (!token.isNullOrEmpty()) {
                request.headers.append("device_token", token)
            }
        }
    }
}
