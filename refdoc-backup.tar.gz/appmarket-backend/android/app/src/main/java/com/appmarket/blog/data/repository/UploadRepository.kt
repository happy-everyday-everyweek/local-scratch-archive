package com.appmarket.blog.data.repository

import com.appmarket.blog.data.model.AppCategory
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.functions.functions
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 上传应用时未找到 APK 的异常。
 *
 * Edge Function 返回 no_apk_found 错误时抛出，表示 GitHub Release 中没有 APK 资产。
 * UI 层可据此显示「无法发布，请先在 GitHub 创建包含 APK 的 Release」提示。
 */
class NoApkFoundException(message: String) : Exception(message)

/**
 * 上传应用结果。
 *
 * @property appId 应用 ID
 * @property status 应用状态（pending_review 等）
 * @property apkCount 抓取到的 APK 数量
 */
data class SubmitResult(
    val appId: String,
    val status: String,
    val apkCount: Int,
)

/**
 * 上传应用 Repository，负责通过 GitHub 仓库地址提交应用。
 *
 * 调用 submit-app-by-repo Edge Function，由服务端使用 service_role key
 * 创建应用记录并抓取 GitHub Release。客户端仅持有 Publishable key，
 * 无法直接操作 apps 表的 status 字段（RLS 限制），必须经 Edge Function。
 *
 * device_token 由 AuthInterceptor 自动附加到请求 header，无需手动传递。
 */
@Singleton
class UploadRepository @Inject constructor(
    private val supabaseClient: SupabaseClient,
) {
    /**
     * JSON 解析器，忽略未知字段以兼容服务端字段扩展。
     */
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 通过 GitHub 仓库地址提交应用。
     *
     * @param githubRepo GitHub 仓库地址，如 https://github.com/user/repo
     * @param category 应用分类
     * @param name 应用名称
     * @param description 应用描述
     * @param packageName 包名（可选，开源分类选择本地应用时传入，作为 apps 表额外信息）
     * @return 成功返回 SubmitResult，失败返回异常
     *         （NoApkFoundException 表示未找到 APK，其他异常表示网络或服务端错误）
     */
    suspend fun submitByRepo(
        githubRepo: String,
        category: AppCategory,
        name: String,
        description: String,
        packageName: String? = null,
    ): Result<SubmitResult> {
        return try {
            // 调用 Edge Function，SDK 自动序列化 body 并附加 device_token header
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "submit-app-by-repo",
                body = SubmitAppRequest(
                    githubRepo = githubRepo,
                    category = category.value,
                    name = name,
                    description = description,
                    packageName = packageName,
                ),
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            // 检查 HTTP 状态码，非 2xx 视为错误
            if (response.status.value !in 200..299) {
                val errorResponse = try {
                    json.decodeFromString<SubmitAppErrorResponse>(bodyText)
                } catch (_: Exception) {
                    null
                }
                // no_apk_found 返回特定错误类型
                if (errorResponse?.error == "no_apk_found") {
                    return Result.failure(
                        NoApkFoundException(
                            errorResponse.message
                                ?: "无法发布，请先在 GitHub 创建包含 APK 的 Release"
                        )
                    )
                }
                return Result.failure(
                    Exception(errorResponse?.message ?: "提交失败")
                )
            }

            // 解析成功响应
            val result = json.decodeFromString<SubmitAppResponse>(bodyText)
            Result.success(
                SubmitResult(
                    appId = result.appId,
                    status = result.status,
                    apkCount = result.apkCount,
                )
            )
        } catch (e: NoApkFoundException) {
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/**
 * submit-app-by-repo Edge Function 的请求体。
 *
 * @property packageName 包名（可选，开源分类选择本地应用时传入）
 */
@Serializable
private data class SubmitAppRequest(
    @SerialName("github_repo") val githubRepo: String,
    @SerialName("category") val category: String,
    @SerialName("name") val name: String,
    @SerialName("description") val description: String,
    @SerialName("package_name") val packageName: String? = null,
)

/**
 * submit-app-by-repo Edge Function 的成功响应体。
 */
@Serializable
private data class SubmitAppResponse(
    @SerialName("app_id") val appId: String,
    @SerialName("status") val status: String,
    @SerialName("apk_count") val apkCount: Int,
)

/**
 * submit-app-by-repo Edge Function 的错误响应体。
 */
@Serializable
private data class SubmitAppErrorResponse(
    @SerialName("error") val error: String? = null,
    @SerialName("message") val message: String? = null,
)
