package com.appmarket.blog.ui.screens.download

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.appmarket.blog.data.download.DownloadState
import com.appmarket.blog.data.model.App
import com.appmarket.blog.ui.components.download.DownloadBottomSheet
import com.appmarket.blog.ui.components.download.DownloadLogPanel
import com.appmarket.blog.ui.components.download.DownloadTopSheet

/**
 * 下载弹窗容器，整合上弹窗与下弹窗。
 *
 * 布局：上弹窗（报毒但安全/简介）位于顶部，下弹窗（下载进度）位于底部，
 * 中间留白。点击弹窗外区域不关闭弹窗（下载中不可误关闭），
 * 仅通过明确的「取消」/「关闭」按钮操作。
 *
 * 下载完成后显示「安装」按钮（由 DownloadBottomSheet 内部处理），
 * 并在底部提供「关闭」按钮供用户退出。
 *
 * 通过 DownloadViewModel 观察下载状态与日志。
 *
 * @param app 应用数据
 * @param apkId APK ID
 * @param onDismiss 关闭弹窗回调
 * @param viewModel 下载 ViewModel（由 Hilt 提供）
 */
@Composable
fun DownloadDialog(
    app: App,
    apkId: String,
    onDismiss: () -> Unit,
    viewModel: DownloadViewModel = hiltViewModel(),
) {
    val downloadState by viewModel.downloadState.collectAsStateWithLifecycle()
    val logs by viewModel.logs.collectAsStateWithLifecycle()

    // 上弹窗是否已被用户确认/关闭
    var topSheetAcknowledged by rememberSaveable { mutableStateOf(false) }

    // 日志面板是否展开
    var logPanelExpanded by rememberSaveable { mutableStateOf(false) }

    // 判断当前是否处于可关闭状态（已完成或失败）
    val isClosable = downloadState is DownloadState.Completed ||
        downloadState is DownloadState.Failed

    Box(
        modifier = Modifier
            .fillMaxSize()
            // 半透明遮罩，吸收点击事件但不关闭弹窗
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {
                    // 吸收点击，不执行任何操作（下载中不可误关闭）
                },
            ),
    ) {
        // 上弹窗：位于顶部
        if (!topSheetAcknowledged) {
            DownloadTopSheet(
                app = app,
                onAcknowledge = { topSheetAcknowledged = true },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
            )
        }

        // 下弹窗 + 日志面板：位于底部
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // 可展开日志区
            if (logPanelExpanded) {
                DownloadLogPanel(logs = logs)
            }

            // 下弹窗：下载进度
            DownloadBottomSheet(
                apkId = apkId,
                downloadState = downloadState,
                onExpandLogs = { logPanelExpanded = !logPanelExpanded },
                onCancel = { viewModel.cancelDownload(apkId) },
            )

            // 关闭按钮（仅完成或失败状态显示）
            if (isClosable) {
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                    ),
                ) {
                    Text(
                        text = "关闭",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}
