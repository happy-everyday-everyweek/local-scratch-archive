package com.appmarket.blog.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * APK 数据模型，对应数据库 app_apks 表。
 *
 * @property id APK UUID
 * @property appId 所属应用 UUID
 * @property releaseId GitHub Release ID
 * @property version 版本号
 * @property filename 文件名
 * @property size 文件大小（字节）
 * @property arch 架构标识（如 arm64-v8a、universal，可为空）
 * @property githubAssetUrl GitHub Release 资产原始下载地址
 * @property releaseNotes 版本更新说明
 */
@Serializable
data class AppApk(
    @SerialName("id") val id: String,
    @SerialName("app_id") val appId: String,
    @SerialName("release_id") val releaseId: String? = null,
    @SerialName("version") val version: String? = null,
    @SerialName("filename") val filename: String? = null,
    @SerialName("size") val size: Long = 0L,
    @SerialName("arch") val arch: String? = null,
    @SerialName("github_asset_url") val githubAssetUrl: String? = null,
    @SerialName("release_notes") val releaseNotes: String? = null,
)

/**
 * 将字节数格式化为可读的文件大小字符串。
 *
 * 大于等于 1 MB 时以 MB 显示，否则以 KB 显示，均保留一位小数。
 */
fun Long.toFormattedSize(): String {
    val mb = this / (1024.0 * 1024.0)
    return if (mb >= 1.0) {
        "%.1f MB".format(mb)
    } else {
        val kb = this / 1024.0
        "%.1f KB".format(kb)
    }
}
