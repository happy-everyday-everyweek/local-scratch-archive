package com.appmarket.blog.util

/**
 * 客户端配置常量。
 *
 * 安全说明：
 * - 此文件仅持有 Publishable key（anon key），用于客户端 SDK 初始化。
 * - 数据库密码与 service_role key 绝不存放在客户端，仅存于 Supabase 服务端
 *   环境变量与 Edge Function secrets 中。
 * - Supabase URL 在项目创建后替换为真实地址。
 */
object Config {

    /**
     * Supabase 项目 URL。
     * 创建项目后替换 YOUR_PROJECT_REF 为真实项目引用 ID。
     */
    const val SUPABASE_URL: String = "https://ibqeewjbdtcvgedsqflh.supabase.co"

    /**
     * Supabase Publishable key（anon key）。
     * 客户端唯一持有的密钥，可安全暴露在客户端代码中。
     */
    const val SUPABASE_PUBLISHABLE_KEY: String =
        "sb_publishable_21y8mRrxJWW8LTFMWWMKYw_GbDyQtuS"

    /**
     * EncryptedSharedPreferences 文件名，用于安全存储 device_token 等敏感本地数据。
     */
    const val SECURE_PREFS_FILE_NAME: String = "app_market_secure_prefs"

    /**
     * device_token 在安全存储中的键名。
     */
    const val KEY_DEVICE_TOKEN: String = "device_token"

    /**
     * 设备指纹在安全存储中的键名。
     */
    const val KEY_DEVICE_FINGERPRINT: String = "device_fingerprint"
}
