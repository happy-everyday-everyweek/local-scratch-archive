package com.appmarket.blog.data.repository

import com.appmarket.blog.data.model.AppCategory
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.functions.functions
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 人工审核 Repository，负责查询待审核应用列表与执行审核操作。
 *
 * 安全说明：
 * - 仅持有 Publishable key，敏感操作由 Edge Function 使用 service_role key 执行。
 * - apps.status 与 virus_safe_reason 字段已撤销 anon/authenticated 的直接写权限（RLS），
 *   必须经 manual-review Edge Function 由服务端 service_role key 执行。
 * - RLS 限制普通用户只能读 status in ('approved','virus_safe') 或自己 owner_id 的 app，
 *   getPendingReviews 必须经 list-pending-reviews Edge Function 由服务端绕过 RLS 获取。
 * - device_token 由 AuthInterceptor 自动附加到请求 header，无需手动传递。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
@Singleton
class ReviewRepository @Inject constructor(
    private val supabaseClient: SupabaseClient,
) {
    /**
     * JSON 解析器，忽略未知字段以兼容服务端字段扩展。
     */
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 查询所有待审核（status='pending_review'）的应用列表。
     *
     * 调用 list-pending-reviews Edge Function，由服务端使用 service_role key
     * 绕过 RLS 读取所有 pending_review 的应用，并关联 profiles 获取上传者信息。
     *
     * @return 成功返回 PendingReviewPage（含应用列表），失败返回异常
     */
    suspend fun getPendingReviews(): Result<PendingReviewPage> {
        return try {
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "list-pending-reviews",
                body = buildJsonObject { },
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            // 非 2xx 视为错误，解析服务端返回的 error 字段
            if (response.status.value !in 200..299) {
                return Result.failure(ReviewException(parseError(bodyText)))
            }

            val result = json.decodeFromString<ListPendingReviewsResponse>(bodyText)
            val apps = result.apps.map { it.toModel() }
            Result.success(
                PendingReviewPage(
                    apps = apps,
                    total = result.total,
                ),
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 通过审核。调用 manual-review Edge Function，action='approve'。
     *
     * 服务端校验：
     * - 仅站长/管理员可调用
     * - app 当前 status 必须为 'pending_review'
     *
     * @param appId 应用 UUID
     * @return 成功返回 ReviewResult，失败返回异常
     */
    suspend fun approve(appId: String): Result<ReviewResult> {
        return invokeManualReview(appId, action = "approve", virusSafeReason = null)
    }

    /**
     * 标记为「报毒但安全」。调用 manual-review Edge Function，action='virus_safe'。
     *
     * 服务端校验：
     * - 仅站长/管理员可调用
     * - app 当前 status 必须为 'pending_review'
     * - 必须提供 virus_safe_reason（非空）
     * - 服务端会向上传者发送站内消息
     *
     * @param appId 应用 UUID
     * @param reason 报毒但安全的原因说明
     * @return 成功返回 ReviewResult，失败返回异常
     */
    suspend fun markVirusSafe(appId: String, reason: String): Result<ReviewResult> {
        val trimmed = reason.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(ReviewException("报毒但安全的原因不能为空"))
        }
        return invokeManualReview(appId, action = "virus_safe", virusSafeReason = trimmed)
    }

    /**
     * 拒绝审核。调用 manual-review Edge Function，action='reject'。
     *
     * 服务端校验：
     * - 仅站长/管理员可调用
     * - app 当前 status 必须为 'pending_review'
     *
     * @param appId 应用 UUID
     * @return 成功返回 ReviewResult，失败返回异常
     */
    suspend fun reject(appId: String): Result<ReviewResult> {
        return invokeManualReview(appId, action = "reject", virusSafeReason = null)
    }

    /**
     * 统一调用 manual-review Edge Function。
     *
     * @param appId 应用 UUID
     * @param action 审核动作（approve / virus_safe / reject）
     * @param virusSafeReason 报毒但安全的原因（仅 action=virus_safe 时非空）
     */
    private suspend fun invokeManualReview(
        appId: String,
        action: String,
        virusSafeReason: String?,
    ): Result<ReviewResult> {
        return try {
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "manual-review",
                body = buildJsonObject {
                    put("app_id", appId)
                    put("action", action)
                    if (virusSafeReason != null) {
                        put("virus_safe_reason", virusSafeReason)
                    }
                },
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            // 非 2xx 视为错误，解析服务端返回的 error 字段
            if (response.status.value !in 200..299) {
                return Result.failure(ReviewException(parseError(bodyText)))
            }

            val result = json.decodeFromString<ManualReviewResponse>(bodyText)
            Result.success(
                ReviewResult(
                    appId = result.appId,
                    status = result.status,
                ),
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 解析 Edge Function 错误响应 { error: "..." }，提取可读错误信息。
     */
    private fun parseError(body: String): String {
        return try {
            json.decodeFromString<ReviewErrorResponse>(body).error
        } catch (e: Exception) {
            "请求失败"
        }
    }
}

/**
 * 待审核应用列表分页数据。
 *
 * @property apps 当前页的应用列表
 * @property total 总数（与 apps.size 相同，预留分页扩展）
 */
data class PendingReviewPage(
    val apps: List<PendingReviewApp>,
    val total: Int,
)

/**
 * 待审核应用展示数据。
 *
 * 不包含 device_token 等敏感字段，仅用于审核界面展示。
 *
 * @property id 应用 UUID
 * @property name 应用名称
 * @property category 分类
 * @property latestVersion 最新版本号（可能为空）
 * @property githubRepo GitHub 仓库地址（可能为空）
 * @property ownerFingerprint 上传者的设备指纹（SHA-256 哈希值），UI 层需脱敏显示
 * @property createdAt 上传时间（ISO 8601 字符串）
 */
data class PendingReviewApp(
    val id: String,
    val name: String,
    val category: AppCategory,
    val latestVersion: String?,
    val githubRepo: String?,
    val ownerFingerprint: String?,
    val createdAt: String,
)

/**
 * 审核操作结果。
 *
 * @property appId 应用 UUID
 * @property status 审核后的新状态（approved / virus_safe / rejected）
 */
data class ReviewResult(
    val appId: String,
    val status: String,
)

/**
 * 审核操作失败异常，携带服务端返回的错误信息。
 */
class ReviewException(message: String) : Exception(message)

/**
 * list-pending-reviews Edge Function 的响应体。
 */
@Serializable
private data class ListPendingReviewsResponse(
    @SerialName("apps") val apps: List<PendingReviewAppDto> = emptyList(),
    @SerialName("total") val total: Int = 0,
)

/**
 * list-pending-reviews Edge Function 返回的单个 app DTO。
 *
 * 不包含 device_token 等敏感字段，仅返回上传者的设备指纹。
 */
@Serializable
private data class PendingReviewAppDto(
    @SerialName("id") val id: String,
    @SerialName("name") val name: String,
    @SerialName("category") val category: String,
    @SerialName("latest_version") val latestVersion: String? = null,
    @SerialName("github_repo") val githubRepo: String? = null,
    @SerialName("owner_fingerprint") val ownerFingerprint: String? = null,
    @SerialName("created_at") val createdAt: String,
) {
    /** 转换为领域模型 */
    fun toModel(): PendingReviewApp = PendingReviewApp(
        id = id,
        name = name,
        category = AppCategory.fromValue(category),
        latestVersion = latestVersion,
        githubRepo = githubRepo,
        ownerFingerprint = ownerFingerprint,
        createdAt = createdAt,
    )
}

/**
 * manual-review Edge Function 的成功响应体。
 */
@Serializable
private data class ManualReviewResponse(
    @SerialName("success") val success: Boolean = false,
    @SerialName("app_id") val appId: String,
    @SerialName("status") val status: String,
)

/**
 * Edge Function 错误响应体。
 *
 * 注意：使用唯一类名 ReviewErrorResponse，避免与其他 Repository 中的
 * ErrorResponse 等已有 DTO 类冲突导致 Redeclaration 错误。
 */
@Serializable
private data class ReviewErrorResponse(
    @SerialName("error") val error: String = "请求失败",
)
