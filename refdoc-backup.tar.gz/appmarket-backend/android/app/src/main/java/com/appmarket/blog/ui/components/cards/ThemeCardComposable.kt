package com.appmarket.blog.ui.components.cards

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.appmarket.blog.data.model.App

/**
 * 主题卡片。
 *
 * 主题封面 + 主题标题 + 主题内应用预览（横向滚动）。
 * 参考 Apple Today 的主题合集布局，封面图全宽展示，下方为应用图标列表。
 *
 * @param item 主题卡片数据
 * @param inverted 是否为反色模式（黑底白字）
 * @param onClick 卡片点击回调（跳转主题详情）
 * @param onAppClick 应用图标点击回调，参数为应用 ID
 * @param modifier 额外修饰符
 */
@Composable
fun ThemeCard(
    item: FeedItem.ThemeCard,
    inverted: Boolean = false,
    onClick: () -> Unit,
    onAppClick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val article = item.article
    val backgroundColor = if (inverted) {
        MaterialTheme.colorScheme.onBackground
    } else {
        MaterialTheme.colorScheme.surface
    }
    val contentColor = if (inverted) {
        MaterialTheme.colorScheme.background
    } else {
        MaterialTheme.colorScheme.onSurface
    }
    val secondaryColor = if (inverted) {
        MaterialTheme.colorScheme.background.copy(alpha = 0.7f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = backgroundColor,
        tonalElevation = 0.dp,
        shadowElevation = 2.dp,
    ) {
        Column {
            // 主题封面图
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
            ) {
                if (!article.cover.isNullOrBlank()) {
                    AsyncImage(
                        model = article.cover,
                        contentDescription = article.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )
                } else {
                    // 无封面时使用纯色背景
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                if (inverted) {
                                    MaterialTheme.colorScheme.background
                                } else {
                                    MaterialTheme.colorScheme.onBackground
                                },
                            ),
                    )
                }
                // 底部渐变遮罩，使标题在图片上可读
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.6f),
                                ),
                            ),
                        ),
                )
                // 标题叠加在封面底部
                Text(
                    text = article.title,
                    style = MaterialTheme.typography.headlineLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(20.dp),
                )
            }

            // 主题内应用预览（横向滚动）
            if (item.apps.isNotEmpty()) {
                LazyRow(
                    modifier = Modifier.padding(20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(item.apps) { app ->
                        ThemeAppPreview(
                            app = app,
                            inverted = inverted,
                            contentColor = contentColor,
                            secondaryColor = secondaryColor,
                            onClick = { onAppClick(app.id) },
                        )
                    }
                }
            }
        }
    }
}

/**
 * 主题卡片中的应用预览项。
 */
@Composable
private fun ThemeAppPreview(
    app: App,
    inverted: Boolean,
    contentColor: Color,
    secondaryColor: Color,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .width(72.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        AppIcon(
            iconUrl = app.iconUrl,
            appName = app.name,
            size = 56.dp,
            inverted = inverted,
        )
        Text(
            text = app.name,
            style = MaterialTheme.typography.labelSmall,
            color = contentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
