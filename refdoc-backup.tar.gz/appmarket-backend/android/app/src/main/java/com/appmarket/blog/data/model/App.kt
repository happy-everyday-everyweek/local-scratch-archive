package com.appmarket.blog.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * 应用分类枚举。
 *
 * 序列化时使用 @SerialName 对应数据库中的字符串值。
 *
 * @property value 数据库中存储的分类字符串
 */
@Serializable
enum class AppCategory(val value: String) {
    /** 开源 */
    @SerialName("opensource") OPENSOURCE("opensource"),

    /** 正版 */
    @SerialName("genuine") GENUINE("genuine"),

    /** 自然（对正版的 APK 进行的自然化） */
    @SerialName("natural") NATURAL("natural"),
    ;

    companion object {
        /**
         * 从字符串解析分类（兼容大小写），未知值默认为 OPENSOURCE。
         */
        fun fromString(value: String?): AppCategory =
            entries.find { it.value.equals(value, ignoreCase = true) } ?: OPENSOURCE

        /**
         * 从数据库字符串解析分类，未知值默认为 OPENSOURCE。
         */
        fun fromValue(value: String?): AppCategory =
            entries.find { it.value == value } ?: OPENSOURCE
    }
}

/**
 * 应用状态枚举。
 *
 * @property value 数据库中存储的状态字符串
 */
@Serializable
enum class AppStatus(val value: String) {
    /** 待抓取 */
    @SerialName("pending_fetch") PENDING_FETCH("pending_fetch"),

    /** 待审核 */
    @SerialName("pending_review") PENDING_REVIEW("pending_review"),

    /** 已通过 */
    @SerialName("approved") APPROVED("approved"),

    /** 报毒但安全 */
    @SerialName("virus_safe") VIRUS_SAFE("virus_safe"),

    /** 已拒绝 */
    @SerialName("rejected") REJECTED("rejected"),
    ;

    companion object {
        /**
         * 从数据库字符串解析状态，未知值默认为 PENDING_FETCH。
         */
        fun fromValue(value: String?): AppStatus =
            entries.find { it.value == value } ?: PENDING_FETCH
    }
}

/**
 * 应用数据模型，对应数据库 apps 表。
 *
 * @property id 应用 UUID
 * @property ownerId 所有者 profile UUID
 * @property name 应用名称
 * @property packageName 包名
 * @property githubRepo GitHub 仓库地址
 * @property category 分类
 * @property status 状态
 * @property reviewLevel 审核等级（仅开源分类）
 * @property virusSafeReason 报毒但安全的原因
 * @property iconUrl 图标 URL
 * @property description 应用描述
 * @property latestVersion 最新版本号
 * @property screenshots 截图 URL 数组
 * @property tags 标签数组
 * @property downloadCount 下载次数
 * @property createdAt 创建时间
 * @property updatedAt 更新时间
 */
@Serializable
data class App(
    @SerialName("id") val id: String,
    @SerialName("owner_id") val ownerId: String,
    @SerialName("name") val name: String,
    @SerialName("package_name") val packageName: String? = null,
    @SerialName("github_repo") val githubRepo: String? = null,
    @SerialName("category") val category: AppCategory,
    @SerialName("status") val status: AppStatus,
    @SerialName("review_level") val reviewLevel: String? = null,
    @SerialName("virus_safe_reason") val virusSafeReason: String? = null,
    @SerialName("icon_url") val iconUrl: String? = null,
    @SerialName("description") val description: String? = null,
    @SerialName("latest_version") val latestVersion: String? = null,
    @SerialName("screenshots") val screenshots: List<String>? = null,
    @SerialName("tags") val tags: List<String>? = null,
    @SerialName("download_count") val downloadCount: Int = 0,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)
