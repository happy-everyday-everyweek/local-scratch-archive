package com.appmarket.blog.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/**
 * APK 安装工具。
 *
 * 通过系统 Package Installer 触发 APK 安装，使用 FileProvider 安全共享文件 URI。
 * Android 7.0（API 24）及以上必须使用 FileProvider，禁止直接暴露 file:// URI。
 */
object ApkInstaller {

    /** APK 文件的 MIME 类型。 */
    private const val APK_MIME = "application/vnd.android.package-archive"

    /** 下载目录名（与 file_paths.xml 中配置的 cache-path 一致）。 */
    private const val DOWNLOAD_DIR = "downloads"

    /**
     * 触发系统 APK 安装界面。
     *
     * 创建 ACTION_VIEW Intent，设置 APK MIME 类型，
     * 授予目标应用读取 URI 的权限，并以新任务栈启动。
     *
     * @param context 上下文
     * @param fileUri APK 文件 URI（由 FileProvider 提供）
     */
    fun installApk(context: Context, fileUri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileUri, APK_MIME)
            // 授予安装器读取该 URI 的权限
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            // 以新任务栈启动，避免与当前应用任务栈混淆
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * 获取指定 APK ID 对应的已下载 APK 文件 URI（通过 FileProvider）。
     *
     * 在应用缓存目录的 downloads/ 子目录下查找匹配的 APK 文件。
     * 匹配规则：文件名等于 apkId、文件名（不含扩展名）等于 apkId，
     * 或目录下唯一的 .apk 文件。
     *
     * @param context 上下文
     * @param apkId APK ID
     * @return FileProvider 提供的文件 URI
     * @throws IllegalStateException 未找到 APK 文件时抛出
     */
    fun getApkFileUri(context: Context, apkId: String): Uri {
        val downloadDir = File(context.cacheDir, DOWNLOAD_DIR)
        val files = downloadDir.listFiles()?.toList() ?: emptyList()

        // 优先精确匹配 apkId，其次取目录下唯一的 apk 文件
        val target = files.firstOrNull { file ->
            file.name == apkId || file.nameWithoutExtension == apkId
        } ?: files.firstOrNull { file ->
            file.name.endsWith(".apk", ignoreCase = true)
        } ?: throw IllegalStateException("未找到 APK 文件")

        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            target,
        )
    }
}
