package com.appmarket.blog.data.repository

import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.functions.functions
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject

/**
 * 账号继承 Repository，负责生成继承码与执行账号继承。
 *
 * 安全说明：
 * - 仅持有 Publishable key，敏感操作由 Edge Function 使用 service_role key 执行。
 * - device_token 由 AuthInterceptor 自动附加到请求 header，无需手动传入。
 * - 继承成功后需调用方清除本地登录态并重新走 create-or-get-profile 流程。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
class InheritRepository(
    private val supabaseClient: SupabaseClient,
) {
    /**
     * JSON 解析器，忽略未知字段以兼容服务端字段扩展。
     */
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 生成继承码。调用 generate-inherit-code Edge Function。
     *
     * @return 成功返回 InheritCode（含 code 与 expires_at），失败返回异常
     */
    suspend fun generateCode(): Result<InheritCode> {
        return try {
            // device_token 由 AuthInterceptor 自动附加，body 为空 JSON 对象
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "generate-inherit-code",
                body = buildJsonObject { },
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            // 非 2xx 视为错误，解析服务端返回的 error 字段
            if (response.status.value !in 200..299) {
                return Result.failure(InheritException(parseError(bodyText)))
            }

            val result = json.decodeFromString<GenerateCodeResponse>(bodyText)
            Result.success(InheritCode(code = result.code, expiresAt = result.expiresAt))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 执行账号继承。调用 execute-inherit Edge Function。
     *
     * @param code 继承码
     * @return 成功返回 Unit，失败返回异常
     */
    suspend fun executeInherit(code: String): Result<Unit> {
        return try {
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "execute-inherit",
                body = ExecuteInheritRequest(code = code.trim()),
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            if (response.status.value !in 200..299) {
                return Result.failure(InheritException(parseError(bodyText)))
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 解析 Edge Function 错误响应 { error: "..." }，提取可读错误信息。
     */
    private fun parseError(body: String): String {
        return try {
            json.decodeFromString<InheritErrorResponse>(body).error
        } catch (e: Exception) {
            "请求失败"
        }
    }
}

/**
 * 继承码数据。
 *
 * @property code 8 位继承码
 * @property expiresAt 过期时间（ISO 8601 字符串）
 */
data class InheritCode(
    val code: String,
    val expiresAt: String,
)

/**
 * 继承操作失败异常，携带服务端返回的错误信息。
 */
class InheritException(message: String) : Exception(message)

/**
 * generate-inherit-code Edge Function 的成功响应体。
 */
@Serializable
private data class GenerateCodeResponse(
    @SerialName("code") val code: String,
    @SerialName("expires_at") val expiresAt: String,
)

/**
 * execute-inherit Edge Function 的请求体。
 */
@Serializable
private data class ExecuteInheritRequest(
    @SerialName("code") val code: String,
)

/**
 * Edge Function 错误响应体。
 */
@Serializable
private data class InheritErrorResponse(
    @SerialName("error") val error: String = "请求失败",
)
