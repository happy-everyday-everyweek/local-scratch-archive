package com.appmarket.blog.ui.screens.download

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.blog.data.download.DownloadLog
import com.appmarket.blog.data.download.DownloadManager
import com.appmarket.blog.data.download.DownloadState
import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.AppApk
import dagger.hilt.android.lifecycle.HiltViewModel
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 下载页面 ViewModel。
 *
 * 职责：
 * - 通过 apkId 查询 app_apks 与 apps 表，获取应用信息
 * - 委托 DownloadManager 启动/取消下载、观察下载状态与日志
 *
 * 通过 Hilt 注入 DownloadManager（单例）与 SupabaseClient。
 * 仅持有 Publishable key，通过 RLS 鉴权访问数据。
 */
@HiltViewModel
class DownloadViewModel @Inject constructor(
    private val downloadManager: DownloadManager,
    private val supabaseClient: SupabaseClient,
) : ViewModel() {

    /** 应用信息（基于 apkId 反查得到）。 */
    private val _app = MutableStateFlow<App?>(null)
    val app: StateFlow<App?> = _app.asStateFlow()

    /** 应用信息是否正在加载。 */
    private val _isLoadingApp = MutableStateFlow(true)
    val isLoadingApp: StateFlow<Boolean> = _isLoadingApp.asStateFlow()

    /** 当前下载状态流（按 apkId 切换）。 */
    private val _downloadState = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState: StateFlow<DownloadState> = _downloadState.asStateFlow()

    /** 当前下载日志（按下载状态变化刷新）。 */
    private val _logs = MutableStateFlow<List<DownloadLog>>(emptyList())
    val logs: StateFlow<List<DownloadLog>> = _logs.asStateFlow()

    /** 当前观察的 apkId，用于避免重复启动。 */
    private var currentApkId: String? = null

    /**
     * 加载应用信息并启动下载。
     *
     * 通过 apkId 查询 app_apks 获取 appId，再查询 apps 获取应用信息，
     * 随后启动下载并观察状态与日志。
     *
     * @param apkId APK ID
     */
    fun load(apkId: String) {
        if (apkId == currentApkId) return
        currentApkId = apkId

        viewModelScope.launch {
            _isLoadingApp.value = true
            fetchApp(apkId)
            _isLoadingApp.value = false

            // 启动下载
            startDownload(apkId)

            // 观察下载状态，状态变化时同步刷新日志
            downloadManager.observeDownload(apkId).collect { state ->
                _downloadState.value = state
                _logs.value = downloadManager.getDownloadLogs(apkId)
            }
        }
    }

    /**
     * 通过 apkId 反查应用信息。
     *
     * 先查询 app_apks 获取 appId，再查询 apps 获取完整应用信息。
     * 查询失败时 app 保持 null。
     */
    private suspend fun fetchApp(apkId: String) {
        try {
            val apkResult = supabaseClient.postgrest.from("app_apks").select {
                filter { eq("id", apkId) }
            }
            val apk = apkResult.decodeList<AppApk>().firstOrNull() ?: return

            val appResult = supabaseClient.postgrest.from("apps").select {
                filter { eq("id", apk.appId) }
            }
            _app.value = appResult.decodeList<App>().firstOrNull()
        } catch (_: Exception) {
            // 查询失败时保持 app 为 null
        }
    }

    /**
     * 启动下载。
     */
    fun startDownload(apkId: String) {
        downloadManager.startDownload(apkId)
    }

    /**
     * 取消下载。
     */
    fun cancelDownload(apkId: String) {
        downloadManager.cancelDownload(apkId)
    }
}
