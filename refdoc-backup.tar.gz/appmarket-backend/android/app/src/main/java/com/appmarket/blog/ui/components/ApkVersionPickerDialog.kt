package com.appmarket.blog.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.appmarket.blog.data.model.AppApk
import com.appmarket.blog.data.model.toFormattedSize

/**
 * 多 APK 版本选择弹窗。
 *
 * 当一个 Release 包含多个架构的 APK 时，弹出此对话框供用户选择。
 * 列出所有 APK 的文件名、大小（格式化为 MB）与架构（从 arch 字段或文件名推断）。
 *
 * 黑白主题，Material 3 风格。
 *
 * @param apks 可选的 APK 列表
 * @param onSelect 用户选择后的回调
 * @param onDismiss 关闭弹窗的回调
 */
@Composable
fun ApkVersionPickerDialog(
    apks: List<AppApk>,
    onSelect: (AppApk) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "选择版本",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp),
                    verticalArrangement = Arrangement.spacedBy(0.dp),
                ) {
                    items(apks) { apk ->
                        ApkItemRow(
                            apk = apk,
                            onClick = { onSelect(apk) },
                        )
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline,
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        },
    )
}

/**
 * 单个 APK 选项行。
 *
 * 显示文件名、架构与大小，点击后触发选择回调。
 */
@Composable
private fun ApkItemRow(
    apk: AppApk,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            imageVector = Icons.Outlined.Memory,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(24.dp),
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = apk.filename ?: apk.version ?: "未知文件",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = inferArch(apk),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = apk.size.toFormattedSize(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                apk.version?.let { version ->
                    Text(
                        text = version,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

/**
 * 推断 APK 架构。
 *
 * 优先使用 arch 字段，为空时从文件名推断。
 */
private fun inferArch(apk: AppApk): String {
    apk.arch?.takeIf { it.isNotBlank() }?.let { return it }
    val filename = apk.filename?.lowercase() ?: return "未知"
    return when {
        filename.contains("arm64-v8a") || filename.contains("arm64") -> "ARM64"
        filename.contains("armeabi-v7a") || filename.contains("armv7") -> "ARMv7"
        filename.contains("x86_64") || filename.contains("x64") -> "x86_64"
        filename.contains("x86") -> "x86"
        filename.contains("universal") || filename.contains("noarch") -> "通用"
        else -> "未知"
    }
}
