package com.appmarket.blog.ui.components.feed

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.AppCategory
import com.appmarket.blog.data.model.Article
import com.appmarket.blog.data.model.FeedCard

/**
 * 信息流卡片组件库。
 *
 * 包含五种卡片类型，采用 Apple Today 风格的黑白主题布局：
 * 大圆角（16dp）、适度阴影、简洁排版。
 * 所有卡片仅使用 MaterialTheme 中的黑白灰语义色，不引入彩色。
 */

/**
 * 应用图标组件。
 *
 * 有图标 URL 时加载网络图片，无 URL 时显示应用名首字母占位。
 * 黑白主题下占位符使用对比色。
 *
 * @param iconUrl 图标 URL，为 null 时显示文字占位
 * @param appName 应用名称，用于占位文字与无障碍描述
 * @param size 图标尺寸
 * @param modifier 额外修饰符
 */
@Composable
private fun FeedAppIcon(
    iconUrl: String?,
    appName: String,
    size: Dp,
    modifier: Modifier = Modifier,
) {
    val cornerRadius = size / 4
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (!iconUrl.isNullOrBlank()) {
            AsyncImage(
                model = iconUrl,
                contentDescription = appName,
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(cornerRadius)),
                contentScale = ContentScale.Crop,
            )
        } else {
            Text(
                text = appName.firstOrNull()?.uppercase() ?: "?",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * 分类标签。
 *
 * 以小圆角矩形展示应用分类，黑白配色。
 *
 * @param category 应用分类
 * @param modifier 额外修饰符
 */
@Composable
private fun CategoryTag(
    category: AppCategory,
    modifier: Modifier = Modifier,
) {
    val label = when (category) {
        AppCategory.OPENSOURCE -> "开源"
        AppCategory.GENUINE -> "正版"
        AppCategory.NATURAL -> "自然"
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.onBackground,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
        )
    }
}

/**
 * 将 ISO 时间字符串格式化为日期部分（yyyy-MM-dd）。
 *
 * @param isoString ISO 8601 时间字符串，为 null 或格式异常时返回空字符串
 */
private fun formatDate(isoString: String?): String {
    if (isoString.isNullOrBlank()) return ""
    return try {
        isoString.substringBefore("T")
    } catch (_: Exception) {
        ""
    }
}

// =========================================================================
// 1. 单应用卡片
// =========================================================================

/**
 * 单应用卡片。
 *
 * 大图卡片，展示应用图标（大）、名称、简介、分类标签。
 * 黑白主题，圆角 16dp，参考 Apple Today 的简洁布局。
 * 点击跳转应用详情。
 *
 * @param card 单应用卡片数据
 * @param onAppClick 应用点击回调，参数为应用 ID
 * @param modifier 额外修饰符
 */
@Composable
fun SingleAppCard(
    card: FeedCard.SingleApp,
    onAppClick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val app = card.app
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onAppClick(app.id) },
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shadowElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                FeedAppIcon(
                    iconUrl = app.iconUrl,
                    appName = app.name,
                    size = 72.dp,
                )
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = app.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = app.description ?: "暂无简介",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            CategoryTag(category = app.category)
        }
    }
}

// =========================================================================
// 2. 多应用卡片
// =========================================================================

/**
 * 多应用卡片。
 *
 * 标题（如「你可能需要」「重磅更新」「全新上线」）+ 下方 2~4 个应用列表。
 * 每个应用展示小图标、名称、简短描述。
 * 点击单个应用跳转详情，点击「查看更多」跳转分类列表。
 *
 * @param card 多应用卡片数据
 * @param onAppClick 应用点击回调，参数为应用 ID
 * @param onMoreClick 「查看更多」点击回调
 * @param modifier 额外修饰符
 */
@Composable
fun MultiAppCard(
    card: FeedCard.MultiApp,
    onAppClick: (String) -> Unit,
    onMoreClick: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shadowElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // 标题区域，字体大而醒目
            Text(
                text = card.title,
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )

            // 应用列表（纵向排列）
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                card.apps.forEach { app ->
                    MultiAppRow(
                        app = app,
                        onClick = { onAppClick(app.id) },
                    )
                }
            }

            // 「查看更多」按钮
            OutlinedButton(
                onClick = onMoreClick,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(text = "查看更多")
            }
        }
    }
}

/**
 * 多应用卡片中的单行应用。
 */
@Composable
private fun MultiAppRow(
    app: App,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        FeedAppIcon(
            iconUrl = app.iconUrl,
            appName = app.name,
            size = 48.dp,
        )
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = app.name,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = app.description ?: "暂无简介",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// =========================================================================
// 3. 主题卡片
// =========================================================================

/**
 * 主题卡片。
 *
 * 主题封面图 + 标题，展示主题包含的应用数量。
 * 点击跳转主题详情页。
 *
 * @param card 主题卡片数据
 * @param onClick 卡片点击回调（跳转主题详情）
 * @param modifier 额外修饰符
 */
@Composable
fun ThemeCard(
    card: FeedCard.Theme,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val article = card.article
    val appCount = article.appIds?.size ?: 0

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shadowElevation = 2.dp,
    ) {
        Column {
            // 主题封面图 + 标题叠加
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
            ) {
                if (!article.cover.isNullOrBlank()) {
                    AsyncImage(
                        model = article.cover,
                        contentDescription = article.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )
                } else {
                    // 无封面时使用纯色背景
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.onBackground),
                    )
                }
                // 底部渐变遮罩，使标题在图片上可读
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.6f),
                                ),
                            ),
                        ),
                )
                // 标题叠加在封面底部
                Text(
                    text = article.title,
                    style = MaterialTheme.typography.headlineLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(20.dp),
                )
            }

            // 应用数量
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = "主题合集",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = "$appCount 个应用",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

// =========================================================================
// 4. 文章卡片
// =========================================================================

/**
 * 文章卡片。
 *
 * 封面图、标题、摘要、作者、时间。
 * 点击跳转文章详情，不关联应用。
 *
 * @param card 文章卡片数据
 * @param onClick 卡片点击回调（跳转文章详情）
 * @param modifier 额外修饰符
 */
@Composable
fun ArticleCard(
    card: FeedCard.Article,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val article = card.article

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shadowElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // 封面图
            if (!article.cover.isNullOrBlank()) {
                AsyncImage(
                    model = article.cover,
                    contentDescription = article.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop,
                )
            }

            // 标题
            Text(
                text = article.title,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )

            // 摘要
            val summary = article.content?.take(120)
            if (!summary.isNullOrBlank()) {
                Text(
                    text = summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // 作者与时间
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = "作者",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                val date = formatDate(article.createdAt)
                if (date.isNotBlank()) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = date,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

// =========================================================================
// 5. 推荐卡片
// =========================================================================

/**
 * 推荐卡片。
 *
 * 类似文章卡片，但底部有快速跳转/安装组件。
 * 展示关联的应用图标和名称，「查看应用」和「快速安装」按钮。
 *
 * @param card 推荐卡片数据
 * @param onAppClick 「查看应用」点击回调，参数为应用 ID
 * @param onInstallClick 「快速安装」点击回调，参数为应用 ID
 * @param modifier 额外修饰符
 */
@Composable
fun RecommendCard(
    card: FeedCard.Recommend,
    onAppClick: (String) -> Unit,
    onInstallClick: (String) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val article = card.article
    val primaryApp = card.apps.firstOrNull()

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shadowElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // 封面图
            if (!article.cover.isNullOrBlank()) {
                AsyncImage(
                    model = article.cover,
                    contentDescription = article.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop,
                )
            }

            // 标题
            Text(
                text = article.title,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )

            // 摘要
            val summary = article.content?.take(120)
            if (!summary.isNullOrBlank()) {
                Text(
                    text = summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // 底部快速跳转/安装组件
            if (primaryApp != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        FeedAppIcon(
                            iconUrl = primaryApp.iconUrl,
                            appName = primaryApp.name,
                            size = 40.dp,
                        )
                        Text(
                            text = primaryApp.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedButton(onClick = { onAppClick(primaryApp.id) }) {
                            Text(text = "查看应用")
                        }
                        Button(onClick = { onInstallClick(primaryApp.id) }) {
                            Text(text = "快速安装")
                        }
                    }
                }
            }
        }
    }
}
