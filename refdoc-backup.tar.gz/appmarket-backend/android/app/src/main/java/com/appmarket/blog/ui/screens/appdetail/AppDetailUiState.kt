package com.appmarket.blog.ui.screens.appdetail

import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.AppApk
import com.appmarket.blog.data.model.Article

/**
 * 应用详情页 UI 状态。
 *
 * @property isLoading 是否正在加载应用详情
 * @property app 应用信息，加载完成前为 null
 * @property apks 应用对应的 APK 列表
 * @property articles 与该应用关联的博客文章列表
 * @property error 错误信息，非 null 表示当前存在错误
 */
data class AppDetailUiState(
    val isLoading: Boolean = false,
    val app: App? = null,
    val apks: List<AppApk> = emptyList(),
    val articles: List<Article> = emptyList(),
    val error: String? = null,
)
