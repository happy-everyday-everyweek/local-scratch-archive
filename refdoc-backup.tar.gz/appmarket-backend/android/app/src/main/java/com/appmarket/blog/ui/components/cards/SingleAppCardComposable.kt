package com.appmarket.blog.ui.components.cards

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.appmarket.blog.data.model.App

/**
 * 应用图标组件。
 *
 * 有图标 URL 时加载网络图片，无 URL 时显示应用名首字母占位。
 * 黑白主题下占位符使用对比色。
 *
 * @param iconUrl 图标 URL，为 null 时显示文字占位
 * @param appName 应用名称，用于占位文字与无障碍描述
 * @param size 图标尺寸
 * @param inverted 是否为反色（黑底白字）模式
 * @param modifier 额外修饰符
 */
@Composable
fun AppIcon(
    iconUrl: String?,
    appName: String,
    size: Dp,
    inverted: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val cornerRadius = size / 4
    val backgroundColor = if (inverted) {
        MaterialTheme.colorScheme.onBackground
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    val textColor = if (inverted) {
        MaterialTheme.colorScheme.background
    } else {
        MaterialTheme.colorScheme.onBackground
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(backgroundColor),
        contentAlignment = Alignment.Center,
    ) {
        if (!iconUrl.isNullOrBlank()) {
            AsyncImage(
                model = iconUrl,
                contentDescription = appName,
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(cornerRadius)),
                contentScale = ContentScale.Crop,
            )
        } else {
            Text(
                text = appName.firstOrNull()?.uppercase() ?: "?",
                style = MaterialTheme.typography.titleMedium,
                color = textColor,
            )
        }
    }
}

/**
 * 单应用卡片。
 *
 * 大图卡片，展示应用图标、名称、简介。
 * 黑白主题，圆角 16dp，参考 Apple Today 的简洁布局。
 *
 * @param item 单应用卡片数据
 * @param inverted 是否为反色模式（黑底白字）
 * @param onClick 点击回调
 * @param modifier 额外修饰符
 */
@Composable
fun SingleAppCard(
    item: FeedItem.SingleAppCard,
    inverted: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val app = item.app
    val backgroundColor = if (inverted) {
        MaterialTheme.colorScheme.onBackground
    } else {
        MaterialTheme.colorScheme.surface
    }
    val contentColor = if (inverted) {
        MaterialTheme.colorScheme.background
    } else {
        MaterialTheme.colorScheme.onSurface
    }
    val secondaryColor = if (inverted) {
        MaterialTheme.colorScheme.background.copy(alpha = 0.7f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = backgroundColor,
        tonalElevation = 0.dp,
        shadowElevation = 2.dp,
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            AppIcon(
                iconUrl = app.iconUrl,
                appName = app.name,
                size = 72.dp,
                inverted = inverted,
            )
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = app.name,
                    style = MaterialTheme.typography.titleLarge,
                    color = contentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = app.description ?: "暂无简介",
                    style = MaterialTheme.typography.bodyMedium,
                    color = secondaryColor,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
