package com.appmarket.blog.data.repository

import android.content.Context
import com.appmarket.blog.data.local.SecureStorage
import com.appmarket.blog.util.DeviceFingerprint
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.functions.functions
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 账号 Repository，负责设备指纹账号的创建与登录态管理。
 *
 * 设备指纹账号体系流程：
 * 1. 采集设备指纹（Android ID + 厂商 + 型号的 SHA-256 哈希）
 * 2. 调用 create-or-get-profile Edge Function，由服务端使用 service_role key
 *    创建或获取 profile，返回 device_token
 * 3. 将 device_token 安全存储到 EncryptedSharedPreferences
 * 4. 后续所有 Supabase 请求通过 AuthInterceptor 自动携带 device_token header，
 *    通过 RLS 策略鉴权
 */
@Singleton
class AuthRepository @Inject constructor(
    private val secureStorage: SecureStorage,
    private val supabaseClient: SupabaseClient,
) {
    /**
     * JSON 解析器，忽略未知字段以兼容服务端字段扩展。
     */
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 确保当前设备已创建 profile 并存储登录态。
     *
     * 采集设备指纹，调用 create-or-get-profile Edge Function，存储返回的
     * device_token、profile_id、role。若已登录则直接返回成功。
     *
     * @param context 上下文，用于采集设备指纹
     * @return 是否成功（已登录或创建成功返回 true，失败返回 false）
     */
    suspend fun ensureProfile(context: Context): Boolean {
        // 已登录则无需重复创建
        if (isLoggedIn()) {
            return true
        }

        val fingerprint = DeviceFingerprint.getDeviceFingerprint(context)

        return try {
            // 调用 Edge Function，SDK 自动序列化 body 并附加鉴权 header
            // 需手动指定 Content-Type 以便服务端 req.json() 解析
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "create-or-get-profile",
                body = CreateProfileRequest(deviceFingerprint = fingerprint),
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )
            // 手动反序列化响应体（SDK 的 invoke 返回 HttpResponse）
            val result = json.decodeFromString<CreateProfileResponse>(response.bodyAsText())
            secureStorage.saveAuth(
                deviceToken = result.deviceToken,
                profileId = result.profileId,
                role = result.role,
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * 返回当前用户角色字符串（user / admin / owner），未登录返回 null。
     */
    fun getRole(): String? = secureStorage.getRole()

    /**
     * 是否已登录（已有 device_token）。
     */
    fun isLoggedIn(): Boolean = !secureStorage.getDeviceToken().isNullOrEmpty()

    /**
     * 清除登录态（登出 / 账号迁移时调用）。
     */
    fun logout() {
        secureStorage.clearAuth()
    }
}

/**
 * create-or-get-profile Edge Function 的请求体。
 */
@Serializable
private data class CreateProfileRequest(
    @SerialName("device_fingerprint") val deviceFingerprint: String,
)

/**
 * create-or-get-profile Edge Function 的响应体。
 */
@Serializable
private data class CreateProfileResponse(
    @SerialName("profile_id") val profileId: String,
    @SerialName("device_token") val deviceToken: String,
    @SerialName("role") val role: String,
)
