package com.appmarket.blog.data.local

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.appmarket.blog.util.Config
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 安全存储，使用 EncryptedSharedPreferences 加密存储 device_token、profile_id、role。
 *
 * 安全说明：
 * - device_token 是访问 Supabase 的凭证，等同于会话 token，必须加密存储。
 * - EncryptedSharedPreferences 使用 AES-256-GCM 加密密钥，AES-256-SIV 加密值，
 *   即使设备被 root，密钥也存储在 Android Keystore 中，难以提取。
 * - 单例模式，通过 Hilt 注入。
 */
@Singleton
class SecureStorage @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    /**
     * MasterKey，基于 Android Keystore 的 AES-256-GCM 主密钥。
     */
    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    /**
     * 加密的 SharedPreferences 实例。
     * 懒加载，首次访问时创建。
     */
    private val sharedPreferences by lazy {
        EncryptedSharedPreferences.create(
            context,
            Config.SECURE_PREFS_FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    /**
     * 保存认证信息（device_token、profile_id、role）。
     * 在 ensureProfile 成功后调用。
     *
     * @param deviceToken 设备 token，用于后续请求的 RLS 鉴权
     * @param profileId profile 的 UUID
     * @param role 角色（user / admin / owner）
     */
    fun saveAuth(deviceToken: String, profileId: String, role: String) {
        sharedPreferences.edit().apply {
            putString(Config.KEY_DEVICE_TOKEN, deviceToken)
            putString(KEY_PROFILE_ID, profileId)
            putString(KEY_ROLE, role)
            apply()
        }
    }

    /**
     * 获取当前 device_token，未登录返回 null。
     */
    fun getDeviceToken(): String? =
        sharedPreferences.getString(Config.KEY_DEVICE_TOKEN, null)

    /**
     * 获取当前 profile_id，未登录返回 null。
     */
    fun getProfileId(): String? =
        sharedPreferences.getString(KEY_PROFILE_ID, null)

    /**
     * 获取当前角色（user / admin / owner），未登录返回 null。
     */
    fun getRole(): String? =
        sharedPreferences.getString(KEY_ROLE, null)

    /**
     * 清除认证信息（登出 / 账号迁移时调用）。
     */
    fun clearAuth() {
        sharedPreferences.edit().apply {
            remove(Config.KEY_DEVICE_TOKEN)
            remove(KEY_PROFILE_ID)
            remove(KEY_ROLE)
            apply()
        }
    }

    companion object {
        private const val KEY_PROFILE_ID = "profile_id"
        private const val KEY_ROLE = "role"
    }
}
