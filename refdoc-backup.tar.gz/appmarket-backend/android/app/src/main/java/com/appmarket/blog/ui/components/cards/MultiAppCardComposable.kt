package com.appmarket.blog.ui.components.cards

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.appmarket.blog.data.model.App

/**
 * 多应用卡片。
 *
 * 标题 + 2~4 个应用列表。标题字体大而醒目，参考 Apple Today 的标题风格。
 * 标题包括「你可能需要」「重磅更新」「全新上线」。
 *
 * @param item 多应用卡片数据
 * @param inverted 是否为反色模式（黑底白字）
 * @param onAppClick 应用点击回调，参数为应用 ID
 * @param modifier 额外修饰符
 */
@Composable
fun MultiAppCard(
    item: FeedItem.MultiAppCard,
    inverted: Boolean = false,
    onAppClick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val backgroundColor = if (inverted) {
        MaterialTheme.colorScheme.onBackground
    } else {
        MaterialTheme.colorScheme.surface
    }
    val contentColor = if (inverted) {
        MaterialTheme.colorScheme.background
    } else {
        MaterialTheme.colorScheme.onSurface
    }
    val secondaryColor = if (inverted) {
        MaterialTheme.colorScheme.background.copy(alpha = 0.7f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        color = backgroundColor,
        tonalElevation = 0.dp,
        shadowElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // 标题区域，字体大而醒目
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.headlineLarge,
                    color = contentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                item.subtitle?.let { subtitle ->
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = secondaryColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            // 应用列表
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item.apps.forEach { app ->
                    MultiAppRow(
                        app = app,
                        inverted = inverted,
                        contentColor = contentColor,
                        secondaryColor = secondaryColor,
                        onClick = { onAppClick(app.id) },
                    )
                }
            }
        }
    }
}

/**
 * 多应用卡片中的单行应用。
 */
@Composable
private fun MultiAppRow(
    app: App,
    inverted: Boolean,
    contentColor: androidx.compose.ui.graphics.Color,
    secondaryColor: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        AppIcon(
            iconUrl = app.iconUrl,
            appName = app.name,
            size = 48.dp,
            inverted = inverted,
        )
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = app.name,
                style = MaterialTheme.typography.titleMedium,
                color = contentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = app.description ?: "暂无简介",
                style = MaterialTheme.typography.bodyMedium,
                color = secondaryColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
