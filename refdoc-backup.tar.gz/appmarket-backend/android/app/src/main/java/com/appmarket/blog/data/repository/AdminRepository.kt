package com.appmarket.blog.data.repository

import com.appmarket.blog.data.model.Role
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.functions.functions
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 管理后台 Repository，负责查询所有用户列表与修改用户角色。
 *
 * 安全说明：
 * - 仅持有 Publishable key，敏感操作由 Edge Function 使用 service_role key 执行。
 * - RLS 限制普通用户只能读自己的 profile，故 getProfiles 必须经 list-profiles
 *   Edge Function 由服务端绕过 RLS 获取所有用户列表。
 * - profiles.role 字段已撤销 anon/authenticated 的直接写权限，assignRole 必须经
 *   assign-role Edge Function 由服务端执行。
 * - device_token 由 AuthInterceptor 自动附加到请求 header，无需手动传递。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
@Singleton
class AdminRepository @Inject constructor(
    private val supabaseClient: SupabaseClient,
) {
    /**
     * JSON 解析器，忽略未知字段以兼容服务端字段扩展。
     */
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 查询所有 profiles（分页加载）。
     *
     * 调用 list-profiles Edge Function，由服务端使用 service_role key 绕过 RLS
     * 读取所有用户列表。仅返回非敏感字段（id / device_fingerprint / role /
     * created_at），不返回 device_token 等敏感字段。
     *
     * @param offset 分页偏移量，默认 0
     * @param limit 每页数量，默认 20，服务端上限 100
     * @return 成功返回 ProfilePage（含 profiles 列表与总数），失败返回异常
     */
    suspend fun getProfiles(
        offset: Int = 0,
        limit: Int = 20,
    ): Result<ProfilePage> {
        return try {
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "list-profiles",
                body = ListProfilesRequest(offset = offset, limit = limit),
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            // 非 2xx 视为错误，解析服务端返回的 error 字段
            if (response.status.value !in 200..299) {
                return Result.failure(AdminException(parseError(bodyText)))
            }

            val result = json.decodeFromString<ListProfilesResponse>(bodyText)
            val profiles = result.profiles.map { it.toModel() }
            Result.success(
                ProfilePage(
                    profiles = profiles,
                    total = result.total,
                    offset = result.offset,
                    limit = result.limit,
                ),
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 修改目标用户的角色。调用 assign-role Edge Function。
     *
     * 服务端校验：
     * - 仅站长（owner）可调用
     * - new_role 只能为 'user' 或 'admin'（不能直接设为 owner）
     * - 不允许修改自己的角色
     * - 不允许修改 owner 的角色
     *
     * @param targetProfileId 目标 profile 的 UUID
     * @param newRole 新角色（仅 USER / ADMIN）
     * @return 成功返回 AssignRoleResult，失败返回异常
     */
    suspend fun assignRole(
        targetProfileId: String,
        newRole: Role,
    ): Result<AssignRoleResult> {
        return try {
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "assign-role",
                body = AssignRoleRequest(
                    targetProfileId = targetProfileId,
                    newRole = newRole.value,
                ),
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            // 非 2xx 视为错误，解析服务端返回的 error 字段
            if (response.status.value !in 200..299) {
                return Result.failure(AdminException(parseError(bodyText)))
            }

            val result = json.decodeFromString<AssignRoleResponse>(bodyText)
            Result.success(
                AssignRoleResult(
                    targetProfileId = result.targetProfileId,
                    newRole = Role.fromValue(result.newRole),
                ),
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 解析 Edge Function 错误响应 { error: "..." }，提取可读错误信息。
     */
    private fun parseError(body: String): String {
        return try {
            json.decodeFromString<AdminErrorResponse>(body).error
        } catch (e: Exception) {
            "请求失败"
        }
    }
}

/**
 * 用户列表分页数据。
 *
 * @property profiles 当前页的用户列表
 * @property total 总用户数（用于客户端判断是否还有更多数据）
 * @property offset 当前页偏移量
 * @property limit 当前页数量
 */
data class ProfilePage(
    val profiles: List<AdminProfile>,
    val total: Int,
    val offset: Int,
    val limit: Int,
) {
    /** 是否还有更多数据可加载 */
    val hasMore: Boolean get() = offset + profiles.size < total
}

/**
 * 管理后台展示用的用户 Profile 数据。
 *
 * 不包含 device_token 等敏感字段，仅用于管理界面展示。
 *
 * @property id profile 的 UUID
 * @property deviceFingerprint 设备指纹（SHA-256 哈希值），UI 层需脱敏显示
 * @property role 角色
 * @property createdAt 注册时间（ISO 8601 字符串）
 */
data class AdminProfile(
    val id: String,
    val deviceFingerprint: String,
    val role: Role,
    val createdAt: String,
)

/**
 * 角色变更结果。
 *
 * @property targetProfileId 目标 profile 的 UUID
 * @property newRole 新角色
 */
data class AssignRoleResult(
    val targetProfileId: String,
    val newRole: Role,
)

/**
 * 管理操作失败异常，携带服务端返回的错误信息。
 */
class AdminException(message: String) : Exception(message)

/**
 * list-profiles Edge Function 的请求体。
 */
@Serializable
private data class ListProfilesRequest(
    @SerialName("offset") val offset: Int,
    @SerialName("limit") val limit: Int,
)

/**
 * list-profiles Edge Function 的响应体。
 */
@Serializable
private data class ListProfilesResponse(
    @SerialName("profiles") val profiles: List<AdminProfileDto> = emptyList(),
    @SerialName("total") val total: Int = 0,
    @SerialName("offset") val offset: Int = 0,
    @SerialName("limit") val limit: Int = 0,
)

/**
 * list-profiles Edge Function 返回的单个 profile DTO。
 *
 * 不包含 device_token 等敏感字段。
 */
@Serializable
private data class AdminProfileDto(
    @SerialName("id") val id: String,
    @SerialName("device_fingerprint") val deviceFingerprint: String,
    @SerialName("role") val role: String,
    @SerialName("created_at") val createdAt: String,
) {
    /** 转换为领域模型 */
    fun toModel(): AdminProfile = AdminProfile(
        id = id,
        deviceFingerprint = deviceFingerprint,
        role = Role.fromValue(role),
        createdAt = createdAt,
    )
}

/**
 * assign-role Edge Function 的请求体。
 */
@Serializable
private data class AssignRoleRequest(
    @SerialName("target_profile_id") val targetProfileId: String,
    @SerialName("new_role") val newRole: String,
)

/**
 * assign-role Edge Function 的响应体。
 */
@Serializable
private data class AssignRoleResponse(
    @SerialName("success") val success: Boolean = false,
    @SerialName("target_profile_id") val targetProfileId: String,
    @SerialName("new_role") val newRole: String,
)

/**
 * Edge Function 错误响应体。
 */
@Serializable
private data class AdminErrorResponse(
    @SerialName("error") val error: String = "请求失败",
)
