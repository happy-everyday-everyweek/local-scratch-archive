package com.appmarket.blog.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * 用户角色枚举。
 *
 * 序列化时使用 @SerialName 对应数据库中的字符串值（user / admin / owner）。
 *
 * @property value 数据库中存储的角色字符串
 */
@Serializable
enum class Role(val value: String) {
    /** 普通用户 */
    @SerialName("user") USER("user"),

    /** 管理员 */
    @SerialName("admin") ADMIN("admin"),

    /** 站长（首个 profile 自动成为 owner，通过数据库触发器实现） */
    @SerialName("owner") OWNER("owner"),
    ;

    companion object {
        /**
         * 从数据库字符串解析角色，未知值默认为 USER。
         */
        fun fromValue(value: String?): Role = entries.find { it.value == value } ?: USER
    }
}

/**
 * 用户 Profile 数据模型，对应数据库 profiles 表。
 *
 * @property id profile 的 UUID
 * @property deviceFingerprint 设备指纹（SHA-256 哈希值）
 * @property role 角色
 * @property deviceToken 设备 token，用于 RLS 鉴权（请求 header 中携带）
 */
@Serializable
data class Profile(
    @SerialName("id") val id: String,
    @SerialName("device_fingerprint") val deviceFingerprint: String,
    @SerialName("role") val role: Role,
    @SerialName("device_token") val deviceToken: String,
)
