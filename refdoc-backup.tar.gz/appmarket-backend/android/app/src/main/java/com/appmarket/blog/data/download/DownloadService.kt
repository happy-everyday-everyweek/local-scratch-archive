package com.appmarket.blog.data.download

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.appmarket.blog.data.local.SecureStorage
import com.appmarket.blog.data.model.AppApk
import com.appmarket.blog.data.remote.MirrorSpeedTest
import com.appmarket.blog.data.remote.SpeedTestResult
import com.appmarket.blog.data.repository.SettingsRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.postgrest
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.http.HttpHeaders
import io.ktor.utils.io.readAvailable
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.time.Instant
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * 下载 Worker，使用 Foreground Service + WorkManager 执行 APK 下载任务。
 *
 * 下载流程：
 * 1. 接收 apk_id，查询 app_apks 获取 github_asset_url 和 size
 * 2. 查询所有 enabled 镜像站
 * 3. 调用 MirrorSpeedTest.testMirrors() 测速
 * 4. 选择最佳镜像站（优先用户首选站，其次按延迟排序）
 * 5. 下载到 app 缓存目录（FileProvider 配置的 downloads/ 路径）
 * 6. 支持断点续传（HTTP Range 请求）
 * 7. 下载中若连续 10 秒无进度，切换到下一个最佳镜像站
 * 8. 切换时尝试续传（若新站支持 Range），否则重新下载
 * 9. 下载进度通过 DownloadManager 的 StateFlow 暴露
 * 10. 下载完成后在 download_logs 表 insert 记录
 * 11. 下载失败时记录错误日志
 */
@HiltWorker
class DownloadWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val downloadManager: DownloadManager,
    private val settingsRepository: SettingsRepository,
    private val supabaseClient: SupabaseClient,
    private val secureStorage: SecureStorage,
) : CoroutineWorker(appContext, params) {

    /**
     * 下载停滞异常，连续 10 秒无进度时抛出，触发镜像站切换。
     */
    private class DownloadStalledException : Exception("下载停滞")

    /**
     * download_logs 表插入记录 DTO。
     */
    @Serializable
    private data class DownloadLogRecord(
        @SerialName("profile_id") val profileId: String,
        @SerialName("app_id") val appId: String,
        @SerialName("apk_id") val apkId: String,
        @SerialName("mirror_site_id") val mirrorSiteId: String,
        @SerialName("started_at") val startedAt: String,
        @SerialName("completed_at") val completedAt: String? = null,
        @SerialName("status") val status: String,
        @SerialName("bytes_downloaded") val bytesDownloaded: Long,
        @SerialName("total_bytes") val totalBytes: Long,
        @SerialName("error_message") val errorMessage: String? = null,
    )

    companion object {
        /** WorkManager 输入数据键：APK ID。 */
        const val KEY_APK_ID = "apk_id"

        private const val CHANNEL_ID = "download_channel"
        private const val NOTIFICATION_ID = 1001
        private const val STALL_TIMEOUT_MS = 10000L
        private const val BUFFER_SIZE = 8192
        private const val PROGRESS_UPDATE_INTERVAL_MS = 500L
    }

    /**
     * 下载专用 HttpClient，跟随重定向，仅设置连接超时。
     * 读取超时通过 withTimeoutOrNull 手动控制（10 秒无进度切换镜像站）。
     */
    private val downloadClient: HttpClient by lazy {
        HttpClient(Android) {
            install(HttpTimeout) {
                connectTimeoutMillis = 10000
            }
            followRedirects = true
        }
    }

    override suspend fun doWork(): Result {
        val apkId = inputData.getString(KEY_APK_ID) ?: return Result.failure()
        val startTime = Instant.now().toString()
        var apk: AppApk? = null
        var lastMirrorId: String? = null

        // 创建通知渠道并启动前台服务
        createNotificationChannel()
        setForegroundSafely(0, "准备下载...")

        downloadManager.updateState(apkId, DownloadState.Testing)
        downloadManager.addLog(apkId, log("开始下载任务", DownloadLogType.INFO))

        try {
            // 1. 查询 APK 信息
            apk = queryApk(apkId) ?: throw Exception("APK 不存在")
            val githubAssetUrl = apk.githubAssetUrl ?: throw Exception("无下载地址")
            val totalBytes = apk.size

            // 2. 查询镜像站
            val mirrors = settingsRepository.getMirrorSites()
            if (mirrors.isEmpty()) throw Exception("无可用镜像站")
            downloadManager.addLog(
                apkId,
                log("发现 ${mirrors.size} 个镜像站，开始测速", DownloadLogType.INFO),
            )

            // 3. 测速
            val speedResults = MirrorSpeedTest.testMirrors(githubAssetUrl, mirrors)
            val availableCount = speedResults.count { it.available }
            downloadManager.addLog(
                apkId,
                log("测速完成：$availableCount/${mirrors.size} 可用", DownloadLogType.INFO),
            )

            // 记录各镜像站延迟明细
            speedResults.forEach { result ->
                val latencyText = if (result.available) {
                    "${result.latencyMs}ms (HTTP ${result.statusCode})"
                } else {
                    "不可用"
                }
                downloadManager.addLog(
                    apkId,
                    log("镜像站 ${result.mirrorSite.name}：$latencyText", DownloadLogType.INFO),
                )
            }

            // 4. 选择最佳镜像站（按优先级排序）
            val preferredMirrorId = settingsRepository.getPreferredMirror()
            if (!preferredMirrorId.isNullOrEmpty()) {
                val preferredName = mirrors.firstOrNull { it.id == preferredMirrorId }?.name ?: preferredMirrorId
                val preferredResult = speedResults.firstOrNull { it.mirrorSite.id == preferredMirrorId }
                val preferredStatus = if (preferredResult?.available == true) {
                    "可用（${preferredResult.latencyMs}ms）"
                } else {
                    "不可用，将使用延迟最低的镜像站"
                }
                downloadManager.addLog(
                    apkId,
                    log("用户优先镜像站：$preferredName - $preferredStatus", DownloadLogType.INFO),
                )
            }
            val sortedMirrors = sortMirrorsByPreference(speedResults, preferredMirrorId)
            if (sortedMirrors.isEmpty()) throw Exception("无可用镜像站")

            val selectedMirror = sortedMirrors.first()
            downloadManager.addLog(
                apkId,
                log("选择下载源：${selectedMirror.mirrorSite.name}（延迟 ${selectedMirror.latencyMs}ms）", DownloadLogType.INFO),
            )

            // 5. 准备下载文件
            val outputFile = File(
                applicationContext.cacheDir,
                "downloads/${apk.filename ?: apkId}",
            )
            outputFile.parentFile?.mkdirs()

            // 若文件已完整存在，直接返回
            if (totalBytes > 0 && outputFile.exists() && outputFile.length() == totalBytes) {
                val fileUri = getFileUri(outputFile)
                downloadManager.updateState(apkId, DownloadState.Completed(fileUri))
                downloadManager.addLog(apkId, log("文件已存在，跳过下载", DownloadLogType.INFO))
                insertDownloadLog(
                    apk = apk,
                    mirrorSiteId = sortedMirrors.first().mirrorSite.id,
                    status = "completed",
                    bytesDownloaded = totalBytes,
                    totalBytes = totalBytes,
                    errorMessage = null,
                    startedAt = startTime,
                )
                return Result.success()
            }

            // 6. 执行下载（含镜像站切换）
            lastMirrorId = performDownload(
                apkId = apkId,
                githubAssetUrl = githubAssetUrl,
                sortedMirrors = sortedMirrors,
                outputFile = outputFile,
                totalBytes = totalBytes,
            )

            // 7. 下载完成
            val fileUri = getFileUri(outputFile)
            downloadManager.updateState(apkId, DownloadState.Completed(fileUri))
            downloadManager.addLog(apkId, log("下载完成", DownloadLogType.INFO))

            // 8. 记录下载日志
            insertDownloadLog(
                apk = apk,
                mirrorSiteId = lastMirrorId,
                status = "completed",
                bytesDownloaded = outputFile.length(),
                totalBytes = totalBytes,
                errorMessage = null,
                startedAt = startTime,
            )

            return Result.success()
        } catch (e: CancellationException) {
            downloadManager.updateState(apkId, DownloadState.Failed("已取消"))
            downloadManager.addLog(apkId, log("下载已取消", DownloadLogType.WARNING))
            insertDownloadLogSafely(apk, apkId, lastMirrorId, "cancelled", startTime, "已取消")
            throw e
        } catch (e: Exception) {
            downloadManager.updateState(apkId, DownloadState.Failed(e.message ?: "下载失败"))
            downloadManager.addLog(
                apkId,
                log("下载失败：${e.message}", DownloadLogType.ERROR),
            )
            insertDownloadLogSafely(apk, apkId, lastMirrorId, "failed", startTime, e.message)
            return Result.failure()
        }
    }

    /**
     * 执行下载，支持镜像站切换。
     *
     * 按排序顺序依次尝试每个镜像站：
     * - 下载停滞（10 秒无进度）或失败时切换到下一个镜像站
     * - 切换时尝试续传（若新站支持 Range），否则重新下载
     *
     * @return 最终成功下载的镜像站 ID
     */
    private suspend fun performDownload(
        apkId: String,
        githubAssetUrl: String,
        sortedMirrors: List<SpeedTestResult>,
        outputFile: File,
        totalBytes: Long,
    ): String {
        var bytesDownloaded = outputFile.length()

        for ((index, mirrorResult) in sortedMirrors.withIndex()) {
            val mirror = mirrorResult.mirrorSite
            val url = MirrorSpeedTest.buildMirrorUrl(githubAssetUrl, mirror)

            try {
                downloadManager.addLog(apkId, log("从 ${mirror.name} 下载", DownloadLogType.INFO))

                val completed = downloadFromMirror(
                    apkId = apkId,
                    url = url,
                    outputFile = outputFile,
                    resumeFrom = bytesDownloaded,
                    totalBytes = totalBytes,
                    mirrorName = mirror.name,
                )

                if (completed) {
                    return mirror.id
                }
            } catch (_: DownloadStalledException) {
                bytesDownloaded = outputFile.length()
                handleMirrorSwitch(
                    apkId, sortedMirrors, index, mirror.name,
                    "下载停滞",
                )
                continue
            } catch (e: Exception) {
                bytesDownloaded = outputFile.length()
                handleMirrorSwitch(
                    apkId, sortedMirrors, index, mirror.name,
                    e.message ?: "下载错误",
                )
                continue
            }
        }

        throw Exception("所有镜像站均不可用")
    }

    /**
     * 处理镜像站切换：更新状态与日志。
     */
    private fun handleMirrorSwitch(
        apkId: String,
        sortedMirrors: List<SpeedTestResult>,
        currentIndex: Int,
        fromMirrorName: String,
        reason: String,
    ) {
        val nextMirror = sortedMirrors.getOrNull(currentIndex + 1) ?: return
        downloadManager.updateState(
            apkId,
            DownloadState.SwitchingMirror(
                fromMirror = fromMirrorName,
                toMirror = nextMirror.mirrorSite.name,
                reason = reason,
            ),
        )
        downloadManager.addLog(
            apkId,
            log(
                "$fromMirrorName $reason，切换到 ${nextMirror.mirrorSite.name}",
                DownloadLogType.WARNING,
            ),
        )
    }

    /**
     * 从单个镜像站下载。
     *
     * - 若 resumeFrom > 0，发送 Range 请求尝试续传
     * - 响应 206 表示支持续传，追加到文件末尾
     * - 响应 200 表示不支持续传，删除已有内容重新下载
     * - 每次读取超时 10 秒（无进度），抛出 DownloadStalledException
     *
     * @return 是否下载完成
     */
    private suspend fun downloadFromMirror(
        apkId: String,
        url: String,
        outputFile: File,
        resumeFrom: Long,
        totalBytes: Long,
        mirrorName: String,
    ): Boolean {
        return downloadClient.prepareGet(url) {
            if (resumeFrom > 0) {
                headers.append(HttpHeaders.Range, "bytes=$resumeFrom-")
            }
        }.execute { response ->
            val statusCode = response.status.value
            if (statusCode != 200 && statusCode != 206) {
                throw IOException("HTTP $statusCode")
            }

            val isResume = statusCode == 206
            var bytesDownloaded = if (isResume) resumeFrom else 0L

            // 镜像站不支持续传时，清除已有内容重新下载
            if (!isResume && resumeFrom > 0) {
                outputFile.delete()
                outputFile.createNewFile()
                bytesDownloaded = 0L
                downloadManager.addLog(
                    apkId,
                    log("${mirrorName} 不支持续传，重新下载", DownloadLogType.INFO),
                )
            }

            val channel = response.bodyAsChannel()
            val buffer = ByteArray(BUFFER_SIZE)
            val fileOutput = FileOutputStream(outputFile, isResume)

            var lastUpdateTime = System.currentTimeMillis()
            var lastSampleTime = System.currentTimeMillis()
            var lastSampleBytes = bytesDownloaded
            var smoothedSpeed = 0.0

            fileOutput.use { out ->
                while (true) {
                    val bytesRead = withTimeoutOrNull(STALL_TIMEOUT_MS) {
                        channel.readAvailable(buffer)
                    }

                    if (bytesRead == null) {
                        throw DownloadStalledException()
                    }
                    if (bytesRead <= 0) break // EOF

                    out.write(buffer, 0, bytesRead)
                    bytesDownloaded += bytesRead

                    // 节流更新进度（每 500ms）
                    val now = System.currentTimeMillis()
                    if (now - lastUpdateTime >= PROGRESS_UPDATE_INTERVAL_MS) {
                        val interval = now - lastSampleTime
                        if (interval > 0) {
                            val instantSpeed =
                                (bytesDownloaded - lastSampleBytes) * 1000.0 / interval
                            smoothedSpeed = if (smoothedSpeed == 0.0) {
                                instantSpeed
                            } else {
                                smoothedSpeed * 0.7 + instantSpeed * 0.3
                            }
                            lastSampleTime = now
                            lastSampleBytes = bytesDownloaded
                        }

                        val progress = if (totalBytes > 0) {
                            (bytesDownloaded * 100 / totalBytes).toInt().coerceIn(0, 100)
                        } else 0

                        val speed = smoothedSpeed.toLong()
                        val eta = if (speed > 0 && totalBytes > 0) {
                            (totalBytes - bytesDownloaded) / speed
                        } else 0L

                        downloadManager.updateState(
                            apkId,
                            DownloadState.Downloading(
                                progress = progress,
                                speed = speed,
                                eta = eta,
                                currentMirror = mirrorName,
                            ),
                        )
                        setForegroundSafely(progress, "$progress% - $mirrorName")
                        lastUpdateTime = now
                    }
                }
            }

            totalBytes == 0L || bytesDownloaded >= totalBytes
        }
    }

    /**
     * 按用户优先级与延迟排序镜像站测速结果。
     *
     * - 用户优先镜像站排在首位（若可用）
     * - 其余按延迟升序排列
     */
    private fun sortMirrorsByPreference(
        results: List<SpeedTestResult>,
        preferredMirrorId: String?,
    ): List<SpeedTestResult> {
        val available = results.filter { it.available }
        val sorted = available.sortedBy { it.latencyMs }

        return if (!preferredMirrorId.isNullOrEmpty()) {
            val preferred = sorted.firstOrNull { it.mirrorSite.id == preferredMirrorId }
            if (preferred != null) {
                listOf(preferred) + sorted.filter { it.mirrorSite.id != preferredMirrorId }
            } else {
                sorted
            }
        } else {
            sorted
        }
    }

    /**
     * 查询 app_apks 表获取 APK 信息。
     */
    private suspend fun queryApk(apkId: String): AppApk? {
        return try {
            val result = supabaseClient.postgrest.from("app_apks").select {
                filter { eq("id", apkId) }
            }
            result.decodeList<AppApk>().firstOrNull()
        } catch (_: Exception) {
            null
        }
    }

    /**
     * 插入 download_logs 记录。
     */
    private suspend fun insertDownloadLog(
        apk: AppApk,
        mirrorSiteId: String,
        status: String,
        bytesDownloaded: Long,
        totalBytes: Long,
        errorMessage: String?,
        startedAt: String,
    ) {
        try {
            val profileId = secureStorage.getProfileId() ?: return
            val completedAt = if (status == "completed") Instant.now().toString() else null
            val record = DownloadLogRecord(
                profileId = profileId,
                appId = apk.appId,
                apkId = apk.id,
                mirrorSiteId = mirrorSiteId,
                startedAt = startedAt,
                completedAt = completedAt,
                status = status,
                bytesDownloaded = bytesDownloaded,
                totalBytes = totalBytes,
                errorMessage = errorMessage,
            )
            supabaseClient.postgrest.from("download_logs").insert(record)
        } catch (_: Exception) {
            // 忽略日志写入错误，不影响下载流程
        }
    }

    /**
     * 安全插入 download_logs 记录（APK 信息可能为空）。
     */
    private suspend fun insertDownloadLogSafely(
        apk: AppApk?,
        apkId: String,
        mirrorSiteId: String?,
        status: String,
        startedAt: String,
        errorMessage: String?,
    ) {
        if (apk == null) return
        insertDownloadLog(
            apk = apk,
            mirrorSiteId = mirrorSiteId ?: "",
            status = status,
            bytesDownloaded = 0L,
            totalBytes = apk.size,
            errorMessage = errorMessage,
            startedAt = startedAt,
        )
    }

    /**
     * 通过 FileProvider 获取文件 URI。
     */
    private fun getFileUri(file: File): Uri {
        return FileProvider.getUriForFile(
            applicationContext,
            "${applicationContext.packageName}.fileprovider",
            file,
        )
    }

    /**
     * 构造下载日志条目，自动填充当前时间。
     */
    private fun log(message: String, type: DownloadLogType): DownloadLog {
        val timestamp = LocalDateTime.now()
            .format(DateTimeFormatter.ofPattern("HH:mm:ss"))
        return DownloadLog(timestamp = timestamp, message = message, type = type)
    }

    /**
     * 创建通知渠道（Android 8.0+）。
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "下载服务",
                NotificationManager.IMPORTANCE_LOW,
            )
            val manager = applicationContext
                .getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    /**
     * 构造前台服务通知信息。
     */
    @Suppress("DEPRECATION")
    private fun createForegroundInfo(progress: Int, contentText: String): ForegroundInfo {
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle("正在下载")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    /**
     * 安全设置前台服务，失败时忽略（继续后台下载）。
     */
    private suspend fun setForegroundSafely(progress: Int, contentText: String) {
        try {
            setForeground(createForegroundInfo(progress, contentText))
        } catch (_: Exception) {
            // 前台服务启动失败时忽略，继续下载
        }
    }
}
