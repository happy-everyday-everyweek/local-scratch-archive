package com.appmarket.blog.ui.components.download

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.GetApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.appmarket.blog.data.download.DownloadState
import com.appmarket.blog.util.ApkInstaller

/**
 * 下载下弹窗。
 *
 * 展示下载进度信息：
 * - 进度条（LinearProgressIndicator）
 * - 百分比文字
 * - 下载速度（如 1.2 MB/s）
 * - 剩余时间（如 剩余 30 秒）
 * - 当前下载源（镜像站名称）
 * - 状态文字（测速中/下载中/切换下载源中/下载完成/下载失败）
 * - 「展开日志」按钮
 * - 「取消」按钮（下载中显示）
 * - 「安装」按钮（下载完成显示，触发 APK 安装 Intent）
 *
 * 黑白主题，Material 3 风格。
 *
 * @param apkId APK ID
 * @param downloadState 当前下载状态
 * @param onExpandLogs 展开日志回调
 * @param onCancel 取消下载回调
 * @param modifier 修饰符
 */
@Composable
fun DownloadBottomSheet(
    apkId: String,
    downloadState: DownloadState,
    onExpandLogs: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // 状态文字 + 当前下载源
            StatusHeader(downloadState = downloadState)

            // 进度条
            ProgressSection(downloadState = downloadState)

            // 速度与剩余时间
            SpeedAndEtaSection(downloadState = downloadState)

            // 操作按钮
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // 「展开日志」按钮
                OutlinedButton(
                    onClick = onExpandLogs,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.GetApp,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(text = "展开日志")
                }

                // 「取消」按钮（下载中显示）
                if (downloadState is DownloadState.Testing ||
                    downloadState is DownloadState.Downloading ||
                    downloadState is DownloadState.SwitchingMirror
                ) {
                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                    ) {
                        Text(text = "取消")
                    }
                }

                // 「安装」按钮（下载完成显示）
                if (downloadState is DownloadState.Completed) {
                    Button(
                        onClick = {
                            ApkInstaller.installApk(context, downloadState.fileUri)
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.onSurface,
                            contentColor = MaterialTheme.colorScheme.surface,
                        ),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Download,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = "安装",
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
        }
    }
}

/**
 * 状态文字与当前下载源。
 */
@Composable
private fun StatusHeader(downloadState: DownloadState) {
    val statusText = when (downloadState) {
        is DownloadState.Idle -> "准备中"
        is DownloadState.Testing -> "测速中..."
        is DownloadState.Downloading -> "下载中"
        is DownloadState.SwitchingMirror -> "切换下载源中..."
        is DownloadState.Completed -> "下载完成"
        is DownloadState.Failed -> "下载失败：${downloadState.error}"
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = statusText,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
        )

        // 当前下载源（镜像站名称）
        when (downloadState) {
            is DownloadState.Downloading -> {
                Text(
                    text = downloadState.currentMirror,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            is DownloadState.SwitchingMirror -> {
                Text(
                    text = "${downloadState.fromMirror} -> ${downloadState.toMirror}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            else -> {}
        }
    }
}

/**
 * 进度条与百分比。
 */
@Composable
private fun ProgressSection(downloadState: DownloadState) {
    val progress = when (downloadState) {
        is DownloadState.Downloading -> downloadState.progress / 100f
        is DownloadState.Completed -> 1f
        else -> 0f
    }

    val isIndeterminate = downloadState is DownloadState.Testing ||
        downloadState is DownloadState.SwitchingMirror

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        if (isIndeterminate) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp),
                color = MaterialTheme.colorScheme.onSurface,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )
        } else {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp),
                color = MaterialTheme.colorScheme.onSurface,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )
        }

        // 百分比文字
        val percentText = when (downloadState) {
            is DownloadState.Downloading -> "${downloadState.progress}%"
            is DownloadState.Completed -> "100%"
            is DownloadState.Failed -> "失败"
            else -> ""
        }
        if (percentText.isNotEmpty()) {
            Text(
                text = percentText,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * 下载速度与剩余时间。
 */
@Composable
private fun SpeedAndEtaSection(downloadState: DownloadState) {
    if (downloadState !is DownloadState.Downloading) return

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // 下载速度
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Icon(
                imageVector = Icons.Outlined.Download,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
            Text(
                text = formatSpeed(downloadState.speed),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // 剩余时间
        Text(
            text = formatEta(downloadState.eta),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/**
 * 格式化下载速度（字节/秒 -> 可读字符串）。
 */
private fun formatSpeed(speed: Long): String {
    return when {
        speed >= 1024 * 1024 -> "%.1f MB/s".format(speed / (1024.0 * 1024.0))
        speed >= 1024 -> "%.1f KB/s".format(speed / 1024.0)
        else -> "$speed B/s"
    }
}

/**
 * 格式化剩余时间（秒 -> 可读字符串）。
 */
private fun formatEta(etaSeconds: Long): String {
    if (etaSeconds <= 0L) return "计算中..."
    return when {
        etaSeconds >= 3600 -> "剩余 ${etaSeconds / 3600} 时 ${etaSeconds % 3600 / 60} 分"
        etaSeconds >= 60 -> "剩余 ${etaSeconds / 60} 分 ${etaSeconds % 60} 秒"
        else -> "剩余 $etaSeconds 秒"
    }
}
