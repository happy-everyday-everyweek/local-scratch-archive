package com.appmarket.blog.ui.components.cards

import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.Article

/**
 * 信息流卡片数据模型。
 *
 * 密封类层次结构，对应信息流首页的五种卡片类型。
 * 参考 Apple Today 的卡片化布局风格。
 */
sealed class FeedItem {

    /**
     * 单应用卡片。
     *
     * 大图卡片，展示单个应用的图标、名称、简介。
     * 在信息流中较少出现，用于突出展示单个应用。
     *
     * @property app 展示的应用
     */
    data class SingleAppCard(val app: App) : FeedItem()

    /**
     * 多应用卡片。
     *
     * 标题 + 2~4 个应用列表，标题包括：
     * - 「你可能需要」
     * - 「重磅更新」
     * - 「全新上线」
     *
     * @property title 卡片标题
     * @property subtitle 副标题（可选）
     * @property apps 应用列表（2~4 个）
     */
    data class MultiAppCard(
        val title: String,
        val subtitle: String?,
        val apps: List<App>,
    ) : FeedItem()

    /**
     * 主题卡片。
     *
     * 主题封面 + 主题内应用预览，展示多个应用的主题合集。
     *
     * @property article 主题文章（type 为 theme）
     * @property apps 主题内关联的应用列表
     */
    data class ThemeCard(
        val article: Article,
        val apps: List<App>,
    ) : FeedItem()

    /**
     * 文章卡片。
     *
     * 文章封面 + 标题 + 摘要，不关联应用。
     *
     * @property article 文章（type 为 article）
     */
    data class ArticleCard(val article: Article) : FeedItem()

    /**
     * 推荐卡片。
     *
     * 文章内容 + 底部快速跳转/安装组件，关联应用的文章。
     *
     * @property article 推荐文章（type 为 recommend）
     * @property apps 关联的应用列表
     */
    data class RecommendCard(
        val article: Article,
        val apps: List<App>,
    ) : FeedItem()
}
