package com.appmarket.blog.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.appmarket.blog.R
import com.appmarket.blog.ui.screens.admin.AdminScreen
import com.appmarket.blog.ui.screens.admin.ReviewScreen
import com.appmarket.blog.ui.screens.appdetail.AppDetailScreen
import com.appmarket.blog.ui.screens.download.DownloadScreen
import com.appmarket.blog.ui.screens.home.HomeScreen
import com.appmarket.blog.ui.screens.publish.PublishScreen
import com.appmarket.blog.ui.screens.settings.SettingsScreen
import com.appmarket.blog.ui.screens.theme.ThemeDetailScreen
import com.appmarket.blog.ui.screens.upload.UploadScreen

/**
 * 顶层导航宿主，包含底部导航栏。
 */
@Composable
fun AppMarketNavHost() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    val bottomNavItems = listOf(
        BottomNavItem(Routes.HOME, R.string.nav_home),
        BottomNavItem(Routes.UPLOAD, R.string.nav_upload),
        BottomNavItem(Routes.SETTINGS, R.string.nav_settings)
    )

    Scaffold(
        bottomBar = {
            val showBottomBar = bottomNavItems.any { item ->
                currentDestination?.hierarchy?.any { it.route == item.route } == true
            }
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { item ->
                        val selected = currentDestination?.hierarchy?.any { it.route == item.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            label = { Text(stringResource(item.labelRes)) },
                            icon = { Text(item.route.first().uppercaseChar().toString()) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    onAppClick = { appId -> navController.navigate(Routes.appDetail(appId)) },
                    onThemeClick = { articleId -> navController.navigate(Routes.themeDetail(articleId)) },
                )
            }
            composable(
                route = Routes.APP_DETAIL,
                arguments = listOf(navArgument("appId") { type = NavType.StringType })
            ) { backStackEntry ->
                val appId = backStackEntry.arguments?.getString("appId").orEmpty()
                AppDetailScreen(
                    appId = appId,
                    onDownloadClick = { apkId -> navController.navigate(Routes.download(apkId)) },
                    onBack = { navController.popBackStack() },
                )
            }
            composable(Routes.UPLOAD) {
                UploadScreen()
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    onNavigateToAdmin = { navController.navigate(Routes.ADMIN) },
                    onNavigateToReview = { navController.navigate(Routes.REVIEW) },
                    onNavigateToPublish = { navController.navigate(Routes.PUBLISH) },
                )
            }
            composable(
                route = Routes.DOWNLOAD,
                arguments = listOf(navArgument("apkId") { type = NavType.StringType })
            ) { backStackEntry ->
                val apkId = backStackEntry.arguments?.getString("apkId").orEmpty()
                DownloadScreen(
                    apkId = apkId,
                    onBack = { navController.popBackStack() },
                )
            }
            // 管理后台路由：仅 OWNER 可见
            // 入口在 SettingsScreen 中根据 currentRole 条件渲染（仅 OWNER 显示「管理后台」按钮），
            // 形成导航层权限控制；服务端 Edge Function 也会再次校验调用者角色，
            // 即使非 OWNER 直接构造路由进入，所有数据请求都会被服务端拒绝。
            composable(Routes.ADMIN) {
                AdminScreen()
            }
            // 应用审核路由：仅 ADMIN/OWNER 可见
            // 入口在 SettingsScreen 中根据 currentRole 条件渲染（ADMIN/OWNER 显示「应用审核」按钮），
            // 形成导航层权限控制；服务端 Edge Function（manual-review / list-pending-reviews）
            // 也会再次校验调用者角色，即使非 ADMIN/OWNER 直接构造路由进入，
            // 所有数据请求都会被服务端拒绝。
            composable(Routes.REVIEW) {
                ReviewScreen()
            }
            // 发布内容路由：仅 ADMIN/OWNER 可见
            // 入口在 SettingsScreen 中根据 currentRole 条件渲染（ADMIN/OWNER 显示「发布内容」按钮），
            // 形成导航层权限控制；服务端 publish-content Edge Function 也会再次校验调用者角色，
            // 即使非 ADMIN/OWNER 直接构造路由进入，发布请求都会被服务端拒绝。
            composable(Routes.PUBLISH) {
                PublishScreen(
                    onBack = { navController.popBackStack() },
                )
            }
            // 主题详情路由：展示主题文章与其包含的应用列表
            composable(
                route = Routes.THEME_DETAIL,
                arguments = listOf(navArgument("articleId") { type = NavType.StringType })
            ) { backStackEntry ->
                val articleId = backStackEntry.arguments?.getString("articleId").orEmpty()
                ThemeDetailScreen(
                    articleId = articleId,
                    onBack = { navController.popBackStack() },
                    onAppClick = { appId -> navController.navigate(Routes.appDetail(appId)) },
                    onDownloadClick = { appId -> navController.navigate(Routes.appDetail(appId)) },
                )
            }
        }
    }
}

private data class BottomNavItem(
    val route: String,
    val labelRes: Int
)
