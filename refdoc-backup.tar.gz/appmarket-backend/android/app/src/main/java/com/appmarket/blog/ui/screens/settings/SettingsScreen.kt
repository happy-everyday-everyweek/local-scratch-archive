package com.appmarket.blog.ui.screens.settings

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.blog.data.repository.AuthRepository
import com.appmarket.blog.data.repository.GithubSettings
import com.appmarket.blog.data.repository.InheritCode
import com.appmarket.blog.data.repository.InheritRepository
import com.appmarket.blog.data.repository.UploadDirectRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.Instant
import javax.inject.Inject

/**
 * 设置页面 UI 状态。
 *
 * @property isLoading 是否正在请求（生成继承码 / 执行继承 / 保存 GitHub 配置）
 * @property generatedCode 已生成的继承码（非 null 时展示结果弹窗）
 * @property errorMessage 错误提示（非 null 时展示错误弹窗）
 * @property inheritSuccessMessage 继承成功提示（非 null 时展示成功弹窗）
 * @property githubPatInput GitHub PAT 输入框内容（密码框，不显示明文）
 * @property githubUsername GitHub 用户名输入
 * @property githubRepoForUpload GitHub 仓库名输入
 * @property hasGithubPat 是否已配置 GitHub PAT（从服务端读取，PAT 明文不在客户端存储）
 * @property githubSettingsLoaded GitHub 设置是否已从服务端加载
 * @property githubSaveSuccess GitHub 配置保存成功提示（非 null 时展示）
 * @property currentRole 当前登录用户角色（user / admin / owner），未登录为 null
 */
data class SettingsUiState(
    val isLoading: Boolean = false,
    val generatedCode: InheritCode? = null,
    val errorMessage: String? = null,
    val inheritSuccessMessage: String? = null,
    val githubPatInput: String = "",
    val githubUsername: String = "",
    val githubRepoForUpload: String = "",
    val hasGithubPat: Boolean = false,
    val githubSettingsLoaded: Boolean = false,
    val githubSaveSuccess: String? = null,
    val currentRole: String? = null,
)

/**
 * 设置页面 ViewModel，处理账号继承与 GitHub 密钥配置相关逻辑。
 *
 * 注入 InheritRepository（生成码 / 执行继承）、AuthRepository（继承成功后
 * 清除本地登录态并重新走 create-or-get-profile 流程）与 UploadDirectRepository
 * （保存 GitHub PAT 到 Vault、更新 user_settings）。
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val inheritRepository: InheritRepository,
    private val authRepository: AuthRepository,
    private val uploadDirectRepository: UploadDirectRepository,
    @ApplicationContext private val context: Context,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        // 进入设置页面时加载已有的 GitHub 配置（用户名、仓库名、PAT 配置状态）
        // 同时读取当前用户角色，用于控制管理后台入口的可见性（仅 OWNER 可见）
        _uiState.value = _uiState.value.copy(currentRole = authRepository.getRole())
        loadGithubSettings()
    }

    /**
     * 从服务端加载 GitHub 设置（用户名、仓库名、是否已配置 PAT）。
     * PAT 明文不从服务端读取，仅读取配置状态。
     */
    private fun loadGithubSettings() {
        viewModelScope.launch {
            val settings: GithubSettings = uploadDirectRepository.getGithubSettings()
            _uiState.value = _uiState.value.copy(
                githubUsername = settings.githubUsername ?: "",
                githubRepoForUpload = settings.githubRepoForUpload ?: "",
                hasGithubPat = settings.hasGithubPat,
                githubSettingsLoaded = true,
            )
        }
    }

    /**
     * 更新 GitHub PAT 输入框内容。
     */
    fun updateGithubPatInput(value: String) {
        _uiState.value = _uiState.value.copy(
            githubPatInput = value,
            githubSaveSuccess = null,
        )
    }

    /**
     * 更新 GitHub 用户名输入。
     */
    fun updateGithubUsername(value: String) {
        _uiState.value = _uiState.value.copy(
            githubUsername = value,
            githubSaveSuccess = null,
        )
    }

    /**
     * 更新 GitHub 仓库名输入。
     */
    fun updateGithubRepoForUpload(value: String) {
        _uiState.value = _uiState.value.copy(
            githubRepoForUpload = value,
            githubSaveSuccess = null,
        )
    }

    /**
     * 保存 GitHub 配置。
     *
     * 1. 若 PAT 输入框非空，调用 save-github-pat Edge Function 将 PAT 存入 Vault
     * 2. 更新 user_settings 表的 github_username 和 github_repo_for_upload
     *
     * PAT 不在客户端持久化明文，仅经 Edge Function 存入 Vault。
     */
    fun saveGithubConfig() {
        val state = _uiState.value
        if (state.githubUsername.isBlank() || state.githubRepoForUpload.isBlank()) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "请填写 GitHub 用户名和仓库名",
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            // 若 PAT 输入框非空，先保存 PAT 到 Vault
            var patSaved = true
            if (state.githubPatInput.isNotBlank()) {
                uploadDirectRepository.saveGithubPat(state.githubPatInput)
                    .onSuccess {
                        patSaved = true
                    }
                    .onFailure { e ->
                        patSaved = false
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = e.message ?: "保存 GitHub 密钥失败",
                        )
                        return@launch
                    }
            }

            // 更新 user_settings
            val settingsSaved = uploadDirectRepository.saveGithubSettings(
                username = state.githubUsername,
                repo = state.githubRepoForUpload,
            )

            if (settingsSaved) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    githubPatInput = "",
                    hasGithubPat = state.hasGithubPat || patSaved,
                    githubSaveSuccess = "GitHub 配置保存成功",
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "保存 GitHub 用户名或仓库名失败",
                )
            }
        }
    }

    /**
     * 生成继承码。调用 generate-inherit-code Edge Function。
     */
    fun generateCode() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            inheritRepository.generateCode()
                .onSuccess { code ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        generatedCode = code,
                    )
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "生成继承码失败",
                    )
                }
        }
    }

    /**
     * 执行账号继承。成功后清除本地 SecureStorage，重新走 create-or-get-profile 流程，
     * 此时获得的是新设备账号（已继承原账号所有数据）。
     */
    fun executeInherit(code: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            inheritRepository.executeInherit(code)
                .onSuccess {
                    // 清除本地登录态，重新走 create-or-get-profile 流程
                    // target profile 仍存在，会返回其 device_token，本地状态刷新后即可访问继承的数据
                    authRepository.logout()
                    val ensured = authRepository.ensureProfile(context)
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        inheritSuccessMessage = if (ensured) {
                            "继承成功，已获得原账号所有数据"
                        } else {
                            "继承成功，但本地账号刷新失败，请重启应用"
                        },
                    )
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "继承失败",
                    )
                }
        }
    }

    /** 关闭继承码结果弹窗。 */
    fun clearGeneratedCode() {
        _uiState.value = _uiState.value.copy(generatedCode = null)
    }

    /** 关闭错误弹窗。 */
    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    /** 关闭成功弹窗。 */
    fun clearSuccess() {
        _uiState.value = _uiState.value.copy(inheritSuccessMessage = null)
    }

    /** 清除 GitHub 配置保存成功提示。 */
    fun clearGithubSaveSuccess() {
        _uiState.value = _uiState.value.copy(githubSaveSuccess = null)
    }
}

/**
 * 设置页面。
 *
 * 提供账号继承入口：
 * 1. 生成继承码：弹窗显示继承码与 10 分钟倒计时，提示在新设备输入此码完成继承。
 * 2. 继承账号：弹窗输入继承码，成功后清除本地登录态并重新创建账号。
 * 3. 管理后台入口：仅 role=OWNER 可见，点击后导航至管理后台。
 * 4. 应用审核入口：仅 role in (ADMIN, OWNER) 可见，点击后导航至应用审核页面。
 * 5. 发布内容入口：仅 role in (ADMIN, OWNER) 可见，点击后导航至发布内容页面。
 *
 * @param onNavigateToAdmin 点击管理后台入口的回调，仅 OWNER 可见
 * @param onNavigateToReview 点击应用审核入口的回调，仅 ADMIN/OWNER 可见
 * @param onNavigateToPublish 点击发布内容入口的回调，仅 ADMIN/OWNER 可见
 */
@Composable
fun SettingsScreen(
    onNavigateToAdmin: () -> Unit = {},
    onNavigateToReview: () -> Unit = {},
    onNavigateToPublish: () -> Unit = {},
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    var showInheritInputDialog by remember { mutableStateOf(false) }
    var inputCode by remember { mutableStateOf("") }
    var patVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = "设置",
            style = MaterialTheme.typography.headlineMedium,
        )

        Spacer(modifier = Modifier.height(8.dp))

        // ============================================================
        // 管理后台入口（仅 OWNER 可见，导航层权限控制）
        // ============================================================
        if (uiState.currentRole == "owner") {
            Text(
                text = "管理",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            OutlinedButton(
                onClick = onNavigateToAdmin,
                modifier = Modifier.fillMaxWidth(),
                enabled = !uiState.isLoading,
            ) {
                Text("管理后台")
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // ============================================================
        // 应用审核入口（仅 ADMIN/OWNER 可见，导航层权限控制）
        // 服务端 Edge Function（manual-review / list-pending-reviews）会再次
        // 校验调用者角色，即使非 ADMIN/OWNER 直接构造路由进入也会被拒绝。
        // ============================================================
        if (uiState.currentRole == "admin" || uiState.currentRole == "owner") {
            if (uiState.currentRole != "owner") {
                // 非站长（即管理员）时显示「管理」分组标题，避免与上方重复
                Text(
                    text = "管理",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            OutlinedButton(
                onClick = onNavigateToReview,
                modifier = Modifier.fillMaxWidth(),
                enabled = !uiState.isLoading,
            ) {
                Text("应用审核")
            }
            OutlinedButton(
                onClick = onNavigateToPublish,
                modifier = Modifier.fillMaxWidth(),
                enabled = !uiState.isLoading,
            ) {
                Text("发布内容")
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // ============================================================
        // GitHub 密钥配置区域
        // ============================================================
        Text(
            text = "GitHub 密钥配置",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )

        Text(
            text = "用于正版/自然分类应用的本地 APK 直传。PAT 经服务端加密存入 Vault，客户端不持久化明文。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // PAT 配置状态提示
        if (uiState.githubSettingsLoaded) {
            Text(
                text = if (uiState.hasGithubPat) "已配置 GitHub 密钥" else "未配置 GitHub 密钥",
                style = MaterialTheme.typography.bodySmall,
                color = if (uiState.hasGithubPat) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.error
                },
            )
        }

        // GitHub PAT 输入框（密码框，不显示明文）
        OutlinedTextField(
            value = uiState.githubPatInput,
            onValueChange = viewModel::updateGithubPatInput,
            label = { Text("GitHub Personal Access Token") },
            placeholder = { Text("留空则不更新已保存的密钥") },
            singleLine = true,
            enabled = !uiState.isLoading,
            visualTransformation = if (patVisible) {
                VisualTransformation.None
            } else {
                PasswordVisualTransformation()
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Next,
            ),
            trailingIcon = {
                TextButton(onClick = { patVisible = !patVisible }) {
                    Text(if (patVisible) "隐藏" else "显示")
                }
            },
            modifier = Modifier.fillMaxWidth(),
        )

        // GitHub 用户名输入框
        OutlinedTextField(
            value = uiState.githubUsername,
            onValueChange = viewModel::updateGithubUsername,
            label = { Text("GitHub 用户名") },
            placeholder = { Text("your-username") },
            singleLine = true,
            enabled = !uiState.isLoading,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Ascii,
                imeAction = ImeAction.Next,
            ),
            modifier = Modifier.fillMaxWidth(),
        )

        // GitHub 仓库名输入框
        OutlinedTextField(
            value = uiState.githubRepoForUpload,
            onValueChange = viewModel::updateGithubRepoForUpload,
            label = { Text("GitHub 仓库名") },
            placeholder = { Text("your-repo") },
            singleLine = true,
            enabled = !uiState.isLoading,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Ascii,
                imeAction = ImeAction.Done,
            ),
            modifier = Modifier.fillMaxWidth(),
        )

        // 保存按钮
        Button(
            onClick = viewModel::saveGithubConfig,
            enabled = !uiState.isLoading &&
                uiState.githubUsername.isNotBlank() &&
                uiState.githubRepoForUpload.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("保存 GitHub 配置")
        }

        // GitHub 配置保存成功提示
        uiState.githubSaveSuccess?.let { msg ->
            Text(
                text = msg,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ============================================================
        // 账号继承区域
        // ============================================================
        Text(
            text = "账号继承",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )

        // 生成继承码
        OutlinedButton(
            onClick = { viewModel.generateCode() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !uiState.isLoading,
        ) {
            Text("生成继承码")
        }

        // 继承账号
        OutlinedButton(
            onClick = {
                inputCode = ""
                showInheritInputDialog = true
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !uiState.isLoading,
        ) {
            Text("继承账号")
        }

        if (uiState.isLoading) {
            CircularProgressIndicator(modifier = Modifier.padding(top = 8.dp))
        }
    }

    // 生成继承码结果弹窗（含 10 分钟倒计时）
    uiState.generatedCode?.let { code ->
        GenerateCodeDialog(
            inheritCode = code,
            onDismiss = { viewModel.clearGeneratedCode() },
        )
    }

    // 继承账号输入弹窗
    if (showInheritInputDialog) {
        AlertDialog(
            onDismissRequest = { showInheritInputDialog = false },
            title = { Text("继承账号") },
            text = {
                OutlinedTextField(
                    value = inputCode,
                    onValueChange = { inputCode = it.uppercase().trim() },
                    label = { Text("请输入继承码") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showInheritInputDialog = false
                        viewModel.executeInherit(inputCode)
                    },
                    enabled = inputCode.isNotBlank() && !uiState.isLoading,
                ) {
                    Text("确认继承")
                }
            },
            dismissButton = {
                TextButton(onClick = { showInheritInputDialog = false }) {
                    Text("取消")
                }
            },
        )
    }

    // 错误提示弹窗
    uiState.errorMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { viewModel.clearError() },
            title = { Text("提示") },
            text = { Text(msg) },
            confirmButton = {
                TextButton(onClick = { viewModel.clearError() }) {
                    Text("确定")
                }
            },
        )
    }

    // 继承成功提示弹窗
    uiState.inheritSuccessMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { viewModel.clearSuccess() },
            title = { Text("提示") },
            text = { Text(msg) },
            confirmButton = {
                TextButton(onClick = { viewModel.clearSuccess() }) {
                    Text("确定")
                }
            },
        )
    }
}

/**
 * 生成继承码结果弹窗，显示继承码与 10 分钟倒计时。
 *
 * 倒计时根据 expires_at 实时计算，到达 0 后显示「已过期」。
 */
@Composable
private fun GenerateCodeDialog(
    inheritCode: InheritCode,
    onDismiss: () -> Unit,
) {
    // 剩余秒数，根据 expires_at 实时计算
    var remainingSeconds by remember(inheritCode.expiresAt) {
        mutableLongStateOf(computeRemainingSeconds(inheritCode.expiresAt))
    }

    // 每秒刷新倒计时，过期后停止
    LaunchedEffect(inheritCode.expiresAt) {
        while (true) {
            remainingSeconds = computeRemainingSeconds(inheritCode.expiresAt)
            if (remainingSeconds <= 0) break
            delay(1000L)
        }
    }

    val timeText = if (remainingSeconds > 0) {
        val minutes = remainingSeconds / 60
        val seconds = remainingSeconds % 60
        "%02d:%02d".format(minutes, seconds)
    } else {
        "已过期"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("继承码") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = inheritCode.code,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(vertical = 8.dp),
                )
                Text(
                    text = "有效期剩余：$timeText",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "在新设备上输入此继承码完成账号继承，继承后当前设备账号将销毁。",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("关闭")
            }
        },
    )
}

/**
 * 根据过期时间字符串（ISO 8601）计算剩余秒数，已过期返回 0。
 */
private fun computeRemainingSeconds(expiresAt: String): Long {
    return try {
        val expiry = Instant.parse(expiresAt)
        val now = Instant.now()
        (expiry.epochSecond - now.epochSecond).coerceAtLeast(0L)
    } catch (e: Exception) {
        0L
    }
}
