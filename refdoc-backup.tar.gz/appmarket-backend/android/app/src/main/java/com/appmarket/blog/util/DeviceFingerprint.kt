package com.appmarket.blog.util

import android.content.Context
import android.os.Build
import android.provider.Settings
import java.security.MessageDigest

/**
 * 设备指纹采集工具。
 *
 * 采集 Android ID、厂商、型号，拼接后做 SHA-256 哈希生成设备指纹。
 * 设备指纹用于唯一标识设备，配合 device_token 实现设备指纹账号体系。
 *
 * 安全说明：
 * - 不采集可追溯个人身份的 IMEI/MAC 等信息，仅使用 Android ID（应用级标识）。
 * - 采集后立即做 SHA-256 哈希，原始信息不上传服务端。
 */
object DeviceFingerprint {

    /**
     * 采集设备指纹。
     * 将 Android ID、厂商、型号拼接后做 SHA-256 哈希，返回 64 字符小写十六进制字符串。
     *
     * @param context 上下文，用于读取 Android ID
     * @return 64 字符的 SHA-256 十六进制设备指纹
     */
    suspend fun getDeviceFingerprint(context: Context): String {
        val androidId = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        ) ?: ""
        val manufacturer = Build.MANUFACTURER ?: ""
        val model = Build.MODEL ?: ""

        // 使用分隔符拼接，避免字段边界歧义
        val raw = "$androidId|$manufacturer|$model"
        return sha256(raw)
    }

    /**
     * 计算 SHA-256 哈希，返回小写十六进制字符串。
     */
    private fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }
}
