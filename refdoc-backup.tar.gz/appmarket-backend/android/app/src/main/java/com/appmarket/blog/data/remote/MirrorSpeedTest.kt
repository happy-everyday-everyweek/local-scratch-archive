package com.appmarket.blog.data.remote

import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.head
import io.ktor.client.statement.HttpResponse
import io.ktor.http.HttpHeaders
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.net.URI

/**
 * 镜像站数据模型，对应数据库 mirror_sites 表的客户端子集。
 *
 * @property id 镜像站 UUID
 * @property name 镜像站名称
 * @property urlTemplate URL 模板，含 {github_url} 或 {path} 占位符
 * @property siteType 站点类型：prefix（前缀代理型）或 replace（域名替换型）
 * @property priority 优先级（数值越小优先级越高）
 * @property isOfficial 是否为官方镜像站
 */
@Serializable
data class MirrorSite(
    @SerialName("id") val id: String,
    @SerialName("name") val name: String,
    @SerialName("url_template") val urlTemplate: String,
    @SerialName("site_type") val siteType: String,
    @SerialName("priority") val priority: Int = 0,
    @SerialName("is_official") val isOfficial: Boolean = false,
)

/**
 * 单个镜像站测速结果。
 *
 * @property mirrorSite 被测镜像站
 * @property latencyMs 响应延迟（毫秒），不可用时为 -1
 * @property available 是否可用（HTTP 200 或 302）
 * @property statusCode HTTP 状态码，请求失败时为 -1
 */
data class SpeedTestResult(
    val mirrorSite: MirrorSite,
    val latencyMs: Long,
    val available: Boolean,
    val statusCode: Int,
)

/**
 * 镜像站测速工具。
 *
 * 并发对所有镜像站发起 HEAD 请求，3 秒超时，根据响应延迟选择最佳镜像站。
 * 使用独立的 Ktor HttpClient，不依赖 Supabase 客户端。
 */
object MirrorSpeedTest {

    /** 测速超时时间（毫秒）。 */
    private const val TIMEOUT_MILLIS: Long = 3000L

    /**
     * 测速专用 HttpClient，3 秒超时，不跟随重定向（以便识别 302）。
     */
    private val httpClient: HttpClient by lazy {
        HttpClient(Android) {
            install(HttpTimeout) {
                requestTimeoutMillis = TIMEOUT_MILLIS
                connectTimeoutMillis = TIMEOUT_MILLIS
                socketTimeoutMillis = TIMEOUT_MILLIS
            }
            followRedirects = false
        }
    }

    /**
     * 并发对每个镜像站发起 HEAD 请求测速。
     *
     * - 前缀代理型（prefix）：url = urlTemplate.replace("{github_url}", githubAssetUrl)
     * - 域名替换型（replace）：从 githubAssetUrl 提取 path，
     *   url = urlTemplate.replace("{path}", path)
     * - 记录从发起请求到收到响应头的延迟
     * - HTTP 200 或 302 视为可用
     *
     * @param githubAssetUrl GitHub Release 资产原始下载地址
     * @param mirrorSites 待测镜像站列表
     * @return 每个镜像站的测速结果列表
     */
    suspend fun testMirrors(
        githubAssetUrl: String,
        mirrorSites: List<MirrorSite>,
    ): List<SpeedTestResult> = coroutineScope {
        mirrorSites.map { mirror ->
            async { testSingleMirror(githubAssetUrl, mirror) }
        }.awaitAll()
    }

    /**
     * 选择最佳镜像站。
     *
     * - 若用户优先镜像站可用，直接返回优先站
     * - 否则返回延迟最低的可用站
     * - 无可用站返回 null
     *
     * @param results 测速结果列表
     * @param preferredMirrorId 用户优先镜像站 ID（可为空）
     */
    suspend fun pickBestMirror(
        results: List<SpeedTestResult>,
        preferredMirrorId: String?,
    ): SpeedTestResult? {
        val available = results.filter { it.available }
        if (available.isEmpty()) return null

        // 用户优先镜像站可用时直接返回
        if (!preferredMirrorId.isNullOrEmpty()) {
            available.firstOrNull { it.mirrorSite.id == preferredMirrorId }
                ?.let { return it }
        }

        // 否则返回延迟最低的可用站
        return available.minByOrNull { it.latencyMs }
    }

    /**
     * 根据镜像站类型构造实际下载 URL。
     *
     * @param githubAssetUrl GitHub Release 资产原始下载地址
     * @param mirror 镜像站
     * @return 实际下载 URL
     */
    fun buildMirrorUrl(githubAssetUrl: String, mirror: MirrorSite): String {
        return when (mirror.siteType.lowercase()) {
            "replace" -> {
                val path = extractPath(githubAssetUrl)
                mirror.urlTemplate.replace("{path}", path)
            }
            else -> {
                // prefix 类型及其他未知类型均按前缀代理处理
                mirror.urlTemplate.replace("{github_url}", githubAssetUrl)
            }
        }
    }

    /**
     * 对单个镜像站发起 HEAD 请求测速。
     */
    private suspend fun testSingleMirror(
        githubAssetUrl: String,
        mirror: MirrorSite,
    ): SpeedTestResult {
        val url = buildMirrorUrl(githubAssetUrl, mirror)
        val startTime = System.currentTimeMillis()
        return try {
            val response: HttpResponse = httpClient.head(url)
            val latency = System.currentTimeMillis() - startTime
            val statusCode = response.status.value
            val available = statusCode == 200 || statusCode == 302
            SpeedTestResult(mirror, latency, available, statusCode)
        } catch (_: Exception) {
            SpeedTestResult(mirror, -1L, false, -1)
        }
    }

    /**
     * 从完整 URL 中提取 path（含 query），用于域名替换型镜像站。
     * 例如 https://github.com/user/repo/releases/download/v1.0/app.apk
     * 提取出 /user/repo/releases/download/v1.0/app.apk
     */
    private fun extractPath(url: String): String {
        return try {
            val uri = URI(url)
            val path = uri.rawPath ?: ""
            val query = uri.rawQuery
            if (query.isNullOrEmpty()) path else "$path?$query"
        } catch (_: Exception) {
            url
        }
    }
}
