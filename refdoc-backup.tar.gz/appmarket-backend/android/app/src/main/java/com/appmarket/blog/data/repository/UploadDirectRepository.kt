package com.appmarket.blog.data.repository

import com.appmarket.blog.data.local.SecureStorage
import com.appmarket.blog.data.model.AppCategory
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.functions.functions
import io.github.jan.supabase.postgrest.postgrest
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 直接上传结果。
 *
 * @property appId 应用 ID
 * @property releaseId GitHub Release ID
 * @property status 应用状态（pending_review）
 */
data class UploadDirectResult(
    val appId: String,
    val releaseId: Long,
    val status: String,
)

/**
 * GitHub 设置信息。
 *
 * @property githubUsername GitHub 用户名
 * @property githubRepoForUpload GitHub 仓库名
 * @property hasGithubPat 是否已配置 GitHub PAT
 */
data class GithubSettings(
    val githubUsername: String? = null,
    val githubRepoForUpload: String? = null,
    val hasGithubPat: Boolean = false,
)

/**
 * 直接上传 Repository，负责通过用户 GitHub PAT 直接上传 APK。
 *
 * 调用 save-github-pat 与 upload-apk-direct Edge Function，由服务端使用
 * service_role key 操作 Vault 与 GitHub API。客户端仅持有 Publishable key，
 * PAT 不在客户端持久化明文。
 *
 * device_token 由 AuthInterceptor 自动附加到请求 header，无需手动传递。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
@Singleton
class UploadDirectRepository @Inject constructor(
    private val supabaseClient: SupabaseClient,
    private val secureStorage: SecureStorage,
) {

    /**
     * JSON 解析器，忽略未知字段以兼容服务端字段扩展。
     */
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 保存 GitHub PAT 到 Supabase Vault。
     *
     * 调用 save-github-pat Edge Function，由服务端使用 service_role key
     * 将 PAT 加密存入 Vault。客户端不持久化 PAT 明文。
     *
     * @param pat GitHub Personal Access Token
     * @return 成功返回 Unit，失败返回异常
     */
    suspend fun saveGithubPat(pat: String): Result<Unit> {
        return try {
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "save-github-pat",
                body = buildJsonObject {
                    put("pat", pat.trim())
                },
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            if (response.status.value !in 200..299) {
                val errorResponse = try {
                    json.decodeFromString<UploadErrorResponse>(bodyText)
                } catch (_: Exception) {
                    null
                }
                return Result.failure(
                    Exception(errorResponse?.message ?: "保存 GitHub 密钥失败")
                )
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 保存 GitHub 用户名和仓库名到 user_settings 表。
     *
     * 使用 upsert，若记录不存在则创建，存在则更新。
     * 通过 RLS 确保只能修改自己的设置。
     *
     * @param username GitHub 用户名
     * @param repo GitHub 仓库名
     * @return 是否保存成功
     */
    suspend fun saveGithubSettings(username: String, repo: String): Boolean {
        val profileId = secureStorage.getProfileId() ?: return false
        return try {
            val updateBody = buildJsonObject {
                put("id", profileId)
                put("github_username", username.trim())
                put("github_repo_for_upload", repo.trim())
            }
            supabaseClient.postgrest.from("user_settings").upsert(updateBody)
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * 获取当前用户的 GitHub 设置（用户名、仓库名、是否已配置 PAT）。
     *
     * 从 user_settings 表读取 github_username 和 github_repo_for_upload，
     * 从 profiles 表读取 github_pat_secret_id 判断是否已配置 PAT。
     *
     * @return GitHub 设置，查询失败返回默认值
     */
    suspend fun getGithubSettings(): GithubSettings {
        return try {
            // 查询 user_settings 获取用户名和仓库名（RLS 仅返回当前用户的记录）
            val settingsResult = supabaseClient.postgrest
                .from("user_settings")
                .select()
                .decodeList<UploadUserSettingsDto>().firstOrNull()

            // 查询 profiles 获取 github_pat_secret_id 判断是否已配置 PAT（RLS 仅返回当前用户的记录）
            val profileResult = supabaseClient.postgrest
                .from("profiles")
                .select()
                .decodeList<UploadProfileDto>().firstOrNull()

            GithubSettings(
                githubUsername = settingsResult?.githubUsername,
                githubRepoForUpload = settingsResult?.githubRepoForUpload,
                hasGithubPat = profileResult?.githubPatSecretId != null,
            )
        } catch (_: Exception) {
            GithubSettings()
        }
    }

    /**
     * 直接上传 APK 到 GitHub Release。
     *
     * 调用 upload-apk-direct Edge Function，由服务端使用用户 PAT 创建
     * GitHub Release 并上传 APK 资产。仅支持 genuine 和 natural 分类。
     *
     * @param apkBase64 APK 文件的 base64 编码字符串
     * @param appName 应用名称
     * @param packageName 包名
     * @param version 版本号
     * @param description 应用描述
     * @param category 分类（仅 genuine / natural）
     * @param iconBase64 图标的 base64 编码字符串（可选）
     * @param filename APK 文件名
     * @return 成功返回 UploadDirectResult，失败返回异常
     */
    suspend fun uploadApkDirect(
        apkBase64: String,
        appName: String,
        packageName: String,
        version: String,
        description: String,
        category: AppCategory,
        iconBase64: String?,
        filename: String,
    ): Result<UploadDirectResult> {
        return try {
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "upload-apk-direct",
                body = UploadApkDirectRequest(
                    apkBase64 = apkBase64,
                    appName = appName,
                    packageName = packageName,
                    version = version,
                    description = description,
                    category = category.value,
                    iconBase64 = iconBase64,
                    filename = filename,
                ),
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            if (response.status.value !in 200..299) {
                val errorResponse = try {
                    json.decodeFromString<UploadErrorResponse>(bodyText)
                } catch (_: Exception) {
                    null
                }
                return Result.failure(
                    Exception(errorResponse?.message ?: "上传失败")
                )
            }

            val result = json.decodeFromString<UploadApkDirectResponse>(bodyText)
            Result.success(
                UploadDirectResult(
                    appId = result.appId,
                    releaseId = result.releaseId,
                    status = result.status,
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/**
 * upload-apk-direct Edge Function 的请求体。
 */
@Serializable
private data class UploadApkDirectRequest(
    @SerialName("apk_base64") val apkBase64: String,
    @SerialName("app_name") val appName: String,
    @SerialName("package_name") val packageName: String,
    @SerialName("version") val version: String,
    @SerialName("description") val description: String,
    @SerialName("category") val category: String,
    @SerialName("icon_base64") val iconBase64: String?,
    @SerialName("filename") val filename: String,
)

/**
 * upload-apk-direct Edge Function 的成功响应体。
 */
@Serializable
private data class UploadApkDirectResponse(
    @SerialName("app_id") val appId: String,
    @SerialName("release_id") val releaseId: Long,
    @SerialName("status") val status: String,
)

/**
 * Edge Function 错误响应体。
 */
@Serializable
private data class UploadErrorResponse(
    @SerialName("error") val error: String? = null,
    @SerialName("message") val message: String? = null,
)

/**
 * user_settings 表的客户端查询 DTO。
 */
@Serializable
private data class UploadUserSettingsDto(
    @SerialName("github_username") val githubUsername: String? = null,
    @SerialName("github_repo_for_upload") val githubRepoForUpload: String? = null,
)

/**
 * profiles 表的客户端查询 DTO（仅查询 PAT 配置状态）。
 */
@Serializable
private data class UploadProfileDto(
    @SerialName("github_pat_secret_id") val githubPatSecretId: String? = null,
)
