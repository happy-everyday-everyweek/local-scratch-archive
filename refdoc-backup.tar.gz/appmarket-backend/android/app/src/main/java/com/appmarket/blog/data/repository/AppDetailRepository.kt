package com.appmarket.blog.data.repository

import com.appmarket.blog.data.local.SecureStorage
import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.AppApk
import com.appmarket.blog.data.model.Article
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.time.Instant

/**
 * 应用详情页 Repository。
 *
 * 负责查询应用信息、APK 列表、关联文章，以及记录浏览历史。
 *
 * 安全说明：
 * - 仅持有 Publishable key，device_token 由 AuthInterceptor 自动附加到请求 header，
 *   服务端通过 RLS 鉴权。
 * - view_history 表的写入受 RLS 控制，仅允许已登录用户记录自己的浏览历史。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
class AppDetailRepository(
    private val supabaseClient: SupabaseClient,
    private val secureStorage: SecureStorage,
) {

    /**
     * 查询单个应用信息。
     *
     * @param appId 应用 UUID
     * @return 应用信息，查询失败或不存在时返回 null
     */
    suspend fun getApp(appId: String): App? {
        return try {
            val result = supabaseClient.postgrest.from("apps").select {
                filter { eq("id", appId) }
            }
            result.decodeList<App>().firstOrNull()
        } catch (_: Exception) {
            null
        }
    }

    /**
     * 查询应用的所有 APK。
     *
     * @param appId 应用 UUID
     * @return APK 列表，查询失败时返回空列表
     */
    suspend fun getApks(appId: String): List<AppApk> {
        return try {
            val result = supabaseClient.postgrest.from("app_apks").select {
                filter { eq("app_id", appId) }
            }
            result.decodeList<AppApk>()
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * 查询关联的博客文章（articles 表中 app_ids 包含 appId 的记录）。
     *
     * 使用 Postgrest 的 contains（cs）操作符查询数组包含关系，
     * 按创建时间降序排列。
     *
     * @param appId 应用 UUID
     * @return 文章列表，查询失败时返回空列表
     */
    suspend fun getRelatedArticles(appId: String): List<Article> {
        return try {
            val result = supabaseClient.postgrest.from("articles").select {
                filter { contains("app_ids", listOf(appId)) }
                order("created_at", Order.DESCENDING)
            }
            result.decodeList<Article>()
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * 记录浏览历史到 view_history 表。
     *
     * 静默失败：未登录或写入失败时不影响正常使用。
     *
     * @param appId 应用 UUID
     */
    suspend fun recordView(appId: String) {
        try {
            val profileId = secureStorage.getProfileId() ?: return
            supabaseClient.postgrest.from("view_history").insert(
                ViewHistoryInsert(
                    profileId = profileId,
                    appId = appId,
                    viewedAt = Instant.now().toString(),
                )
            )
        } catch (_: Exception) {
            // 记录浏览历史失败不影响正常使用
        }
    }
}

/**
 * view_history 表插入 DTO。
 *
 * @property profileId 浏览者 profile UUID
 * @property appId 应用 UUID
 * @property viewedAt 浏览时间（ISO 8601 字符串）
 */
@Serializable
private data class ViewHistoryInsert(
    @SerialName("profile_id") val profileId: String,
    @SerialName("app_id") val appId: String,
    @SerialName("viewed_at") val viewedAt: String,
)
