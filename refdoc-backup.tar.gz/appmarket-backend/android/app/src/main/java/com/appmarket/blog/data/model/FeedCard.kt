package com.appmarket.blog.data.model

/**
 * 顶层 Article 数据类的类型别名。
 *
 * 用于在 FeedCard 密封类内部消除子类 FeedCard.Article 与
 * 顶层 Article 数据类之间的命名歧义（Kotlin 在密封类内部会
 * 优先解析同名的嵌套子类）。
 */
typealias ArticleEntry = Article

/**
 * 信息流卡片密封类，对应信息流首页的五种卡片类型。
 *
 * 参考 Apple Today 的卡片化布局风格，由 FeedRepository 从
 * get-feed Edge Function 获取并混排后返回。
 */
sealed class FeedCard {

    /**
     * 单应用卡片。
     *
     * 大图卡片，展示单个应用的图标、名称、简介。
     * 在信息流中较少出现，用于突出展示单个应用。
     *
     * @property app 展示的应用
     */
    data class SingleApp(val app: App) : FeedCard()

    /**
     * 多应用卡片。
     *
     * 标题 + 2~4 个应用列表。标题包括：
     * - 你可能需要
     * - 重磅更新
     * - 全新上线
     *
     * @property title 卡片标题
     * @property apps 应用列表（2~4 个）
     */
    data class MultiApp(val title: String, val apps: List<App>) : FeedCard()

    /**
     * 主题卡片。
     *
     * 主题封面 + 标题，展示主题包含的应用数量。
     * 对应 articles 表中 type 为 theme 的记录。
     *
     * @property article 主题文章（type 为 theme）
     */
    data class Theme(val article: ArticleEntry) : FeedCard()

    /**
     * 文章卡片。
     *
     * 文章封面 + 标题 + 摘要 + 作者 + 时间，不关联应用。
     * 对应 articles 表中 type 为 article 的记录。
     *
     * @property article 文章（type 为 article）
     */
    data class Article(val article: ArticleEntry) : FeedCard()

    /**
     * 推荐卡片。
     *
     * 文章内容 + 底部快速跳转/安装组件，关联应用。
     * 对应 articles 表中 type 为 recommend 的记录。
     *
     * @property article 推荐文章（type 为 recommend）
     * @property apps 关联的应用列表
     */
    data class Recommend(val article: ArticleEntry, val apps: List<App>) : FeedCard()
}
