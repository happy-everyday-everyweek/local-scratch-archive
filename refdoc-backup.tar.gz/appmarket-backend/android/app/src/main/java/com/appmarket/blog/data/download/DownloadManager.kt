package com.appmarket.blog.data.download

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * 下载管理器，单例，管理下载队列。
 *
 * 职责：
 * - 维护每个 APK 的下载状态（StateFlow）与日志列表
 * - 通过 WorkManager 启动与取消下载
 * - 为 DownloadWorker 提供状态与日志的更新入口
 *
 * 使用 ConcurrentHashMap 保证多线程访问安全。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
class DownloadManager(
    private val context: Context,
) {

    /** 每个 APK 的下载状态流。 */
    private val downloadStates = ConcurrentHashMap<String, MutableStateFlow<DownloadState>>()

    /** 每个 APK 的下载日志列表。 */
    private val downloadLogs = ConcurrentHashMap<String, MutableList<DownloadLog>>()

    /**
     * 观察指定 APK 的下载状态。
     *
     * 若该 APK 尚未开始下载，返回 Idle 状态的流。
     *
     * @param apkId APK ID
     * @return 下载状态 StateFlow
     */
    fun observeDownload(apkId: String): StateFlow<DownloadState> {
        return getOrCreateStateFlow(apkId).asStateFlow()
    }

    /**
     * 启动指定 APK 的下载。
     *
     * 通过 WorkManager 以唯一工作名称排队下载任务，已存在同名工作时保留旧任务。
     *
     * @param apkId APK ID
     */
    fun startDownload(apkId: String) {
        // 重置状态与日志
        getOrCreateStateFlow(apkId).value = DownloadState.Idle
        downloadLogs[apkId]?.clear()

        val request = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(workDataOf(DownloadWorker.KEY_APK_ID to apkId))
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            uniqueWorkName(apkId),
            ExistingWorkPolicy.KEEP,
            request,
        )
    }

    /**
     * 取消指定 APK 的下载。
     *
     * 取消 WorkManager 中的对应任务，并将状态置为 Failed("已取消")。
     *
     * @param apkId APK ID
     */
    fun cancelDownload(apkId: String) {
        WorkManager.getInstance(context).cancelUniqueWork(uniqueWorkName(apkId))
        val flow = getOrCreateStateFlow(apkId)
        val current = flow.value
        if (current !is DownloadState.Completed && current !is DownloadState.Failed) {
            flow.value = DownloadState.Failed("已取消")
        }
    }

    /**
     * 获取指定 APK 的下载日志列表。
     *
     * @param apkId APK ID
     * @return 日志列表副本，无日志时返回空列表
     */
    fun getDownloadLogs(apkId: String): List<DownloadLog> {
        val list = downloadLogs[apkId] ?: return emptyList()
        synchronized(list) {
            return list.toList()
        }
    }

    /**
     * 更新指定 APK 的下载状态（供 DownloadWorker 调用）。
     */
    internal fun updateState(apkId: String, state: DownloadState) {
        getOrCreateStateFlow(apkId).value = state
    }

    /**
     * 追加一条下载日志（供 DownloadWorker 调用）。
     */
    internal fun addLog(apkId: String, log: DownloadLog) {
        val list = downloadLogs.getOrPut(apkId) {
            Collections.synchronizedList(mutableListOf())
        }
        list.add(log)
    }

    /**
     * 获取或创建指定 APK 的状态流。
     */
    private fun getOrCreateStateFlow(apkId: String): MutableStateFlow<DownloadState> {
        return downloadStates.getOrPut(apkId) { MutableStateFlow(DownloadState.Idle) }
    }

    /**
     * 生成下载任务的唯一工作名称。
     */
    private fun uniqueWorkName(apkId: String): String = "download_$apkId"
}
