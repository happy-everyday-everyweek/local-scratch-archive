package com.appmarket.blog.di

import android.content.Context
import com.appmarket.blog.data.download.DownloadManager
import com.appmarket.blog.data.local.SecureStorage
import com.appmarket.blog.data.remote.AuthInterceptor
import com.appmarket.blog.data.repository.AdminRepository
import com.appmarket.blog.data.repository.AppDetailRepository
import com.appmarket.blog.data.repository.AuthRepository
import com.appmarket.blog.data.repository.ContentRepository
import com.appmarket.blog.data.repository.FeedRepository
import com.appmarket.blog.data.repository.InheritRepository
import com.appmarket.blog.data.repository.ReviewRepository
import com.appmarket.blog.data.repository.SettingsRepository
import com.appmarket.blog.data.repository.ThemeRepository
import com.appmarket.blog.data.repository.UploadDirectRepository
import com.appmarket.blog.data.repository.UploadRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import javax.inject.Singleton

/**
 * 应用级依赖注入模块。
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    /**
     * 提供 SecureStorage 单例。
     * 使用 EncryptedSharedPreferences 加密存储 device_token 等敏感数据。
     */
    @Provides
    @Singleton
    fun provideSecureStorage(@ApplicationContext context: Context): SecureStorage {
        return SecureStorage(context)
    }

    /**
     * 提供 Supabase 客户端单例。
     *
     * 关键：在返回 client 前，先设置 AuthInterceptor.deviceTokenProvider，
     * 确保 SupabaseClient.client 懒加载初始化时（安装 Ktor 插件时）
     * deviceTokenProvider 已就绪。后续每次请求都会从 SecureStorage 动态
     * 读取最新 device_token 并附加到请求 header。
     *
     * 仅使用 Publishable key 初始化，见 SupabaseClient。
     */
    @Provides
    @Singleton
    fun provideSupabaseClient(secureStorage: SecureStorage): SupabaseClient {
        // 设置 device_token 提供者：从 SecureStorage 动态读取
        AuthInterceptor.deviceTokenProvider = { secureStorage.getDeviceToken() }
        // 使用全限定名访问自定义 SupabaseClient 对象，避免与 SDK 类同名冲突
        return com.appmarket.blog.data.remote.SupabaseClient.client
    }

    /**
     * 提供 AuthRepository 单例。
     */
    @Provides
    @Singleton
    fun provideAuthRepository(
        secureStorage: SecureStorage,
        supabaseClient: SupabaseClient,
    ): AuthRepository {
        return AuthRepository(secureStorage, supabaseClient)
    }

    /**
     * 提供 UploadRepository 单例。
     * 通过 GitHub 仓库地址提交应用，调用 submit-app-by-repo Edge Function。
     */
    @Provides
    @Singleton
    fun provideUploadRepository(
        supabaseClient: SupabaseClient,
    ): UploadRepository {
        return UploadRepository(supabaseClient)
    }

    /**
     * 提供 UploadDirectRepository 单例。
     * 通过用户 GitHub PAT 直接上传 APK，调用 save-github-pat 与
     * upload-apk-direct Edge Function（服务端使用 service_role key）。
     * 同时管理 user_settings 中的 GitHub 用户名/仓库名配置。
     */
    @Provides
    @Singleton
    fun provideUploadDirectRepository(
        supabaseClient: SupabaseClient,
        secureStorage: SecureStorage,
    ): UploadDirectRepository {
        return UploadDirectRepository(supabaseClient, secureStorage)
    }

    /**
     * 提供 InheritRepository 单例。
     * 账号继承：生成继承码与执行继承，分别调用 generate-inherit-code 与
     * execute-inherit Edge Function（服务端使用 service_role key）。
     */
    @Provides
    @Singleton
    fun provideInheritRepository(
        supabaseClient: SupabaseClient,
    ): InheritRepository {
        return InheritRepository(supabaseClient)
    }

    /**
     * 提供 SettingsRepository 单例。
     * 负责镜像站列表查询与用户优先镜像站设置（user_settings 表）。
     */
    @Provides
    @Singleton
    fun provideSettingsRepository(
        supabaseClient: SupabaseClient,
        secureStorage: SecureStorage,
    ): SettingsRepository {
        return SettingsRepository(supabaseClient, secureStorage)
    }

    /**
     * 提供 AdminRepository 单例。
     * 角色管理：查询所有用户列表（list-profiles Edge Function）与修改用户角色
     * （assign-role Edge Function）。两者均由服务端使用 service_role key 执行，
     * 绕过 RLS 限制。
     */
    @Provides
    @Singleton
    fun provideAdminRepository(
        supabaseClient: SupabaseClient,
    ): AdminRepository {
        return AdminRepository(supabaseClient)
    }

    /**
     * 提供 ReviewRepository 单例。
     * 应用审核：查询待审核应用列表（list-pending-reviews Edge Function）与执行
     * 审核操作（manual-review Edge Function：通过 / 报毒但安全 / 拒绝）。两者均由
     * 服务端使用 service_role key 执行，绕过 RLS 与字段级 revoke 限制。
     */
    @Provides
    @Singleton
    fun provideReviewRepository(
        supabaseClient: SupabaseClient,
    ): ReviewRepository {
        return ReviewRepository(supabaseClient)
    }

    /**
     * 提供 FeedRepository 单例。
     * 信息流首页数据源：调用 get-feed Edge Function 获取混排卡片列表。
     * Edge Function 不可用时回退到直接查询 apps 表。
     * 仅持有 Publishable key，device_token 由 AuthInterceptor 自动附加。
     */
    @Provides
    @Singleton
    fun provideFeedRepository(
        supabaseClient: SupabaseClient,
    ): FeedRepository {
        return FeedRepository(supabaseClient)
    }

    /**
     * 提供 ContentRepository 单例。
     * 内容发布：调用 publish-content Edge Function 发布文章/推荐/主题
     * （服务端使用 service_role key 执行，绕过 articles 表 RLS 写限制）。
     * 同时查询已审核应用列表（getApprovedApps）用于关联应用选择。
     * 仅持有 Publishable key，device_token 由 AuthInterceptor 自动附加。
     */
    @Provides
    @Singleton
    fun provideContentRepository(
        supabaseClient: SupabaseClient,
    ): ContentRepository {
        return ContentRepository(supabaseClient)
    }

    /**
     * 提供 ThemeRepository 单例。
     * 主题详情：查询主题文章（articles 表 type='theme'）与其包含的应用列表
     * （根据 article.app_ids 查询 apps 表）。仅持有 Publishable key，
     * device_token 由 AuthInterceptor 自动附加，通过 RLS 鉴权访问数据。
     */
    @Provides
    @Singleton
    fun provideThemeRepository(
        supabaseClient: SupabaseClient,
    ): ThemeRepository {
        return ThemeRepository(supabaseClient)
    }

    /**
     * 提供 AppDetailRepository 单例。
     * 应用详情页数据源：查询应用信息、APK 列表、关联文章，记录浏览历史。
     * 仅持有 Publishable key，device_token 由 AuthInterceptor 自动附加。
     */
    @Provides
    @Singleton
    fun provideAppDetailRepository(
        supabaseClient: SupabaseClient,
        secureStorage: SecureStorage,
    ): AppDetailRepository {
        return AppDetailRepository(supabaseClient, secureStorage)
    }

    /**
     * 提供 DownloadManager 单例。
     * 管理下载队列，通过 WorkManager 启动与取消下载，暴露下载状态 StateFlow。
     */
    @Provides
    @Singleton
    fun provideDownloadManager(
        @ApplicationContext context: Context,
    ): DownloadManager {
        return DownloadManager(context)
    }
}
