package com.appmarket.blog.data.repository

import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.AppStatus
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.functions.functions
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 内容发布 Repository，负责发布博客内容（文章 / 推荐 / 主题）与查询已审核应用列表。
 *
 * 安全说明：
 * - 仅持有 Publishable key，敏感写操作由 publish-content Edge Function 使用
 *   service_role key 执行。
 * - articles 表已撤销 anon/authenticated 的直接写权限（RLS 未创建
 *   insert/update/delete 策略），必须经 publish-content Edge Function
 *   由服务端 service_role key 执行。
 * - getApprovedApps 直接查询 apps 表（RLS 允许读取 status='approved' 的应用），
 *   用于发布编辑器的关联应用选择。
 * - device_token 由 AuthInterceptor 自动附加到请求 header，无需手动传递。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
@Singleton
class ContentRepository @Inject constructor(
    private val supabaseClient: SupabaseClient,
) {
    /**
     * JSON 解析器，忽略未知字段以兼容服务端字段扩展。
     */
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 发布博客内容。调用 publish-content Edge Function。
     *
     * 服务端校验：
     * - 仅站长/管理员可调用
     * - type in ('article', 'recommend', 'theme')
     * - title 非空
     * - recommend / theme 类型要求 appIds 非空
     * - article 类型 appIds 强制为空数组
     *
     * @param type 文章类型（article / recommend / theme）
     * @param title 标题
     * @param cover 封面图 URL，可为空
     * @param content 正文内容（Markdown）
     * @param appIds 关联应用 ID 列表（recommend / theme 类型必填）
     * @param tags 标签列表
     * @return 成功返回发布后的文章 ID，失败返回异常
     */
    suspend fun publishContent(
        type: String,
        title: String,
        cover: String?,
        content: String,
        appIds: List<String>,
        tags: List<String>,
    ): Result<String> {
        return try {
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "publish-content",
                body = buildJsonObject {
                    put("type", type)
                    put("title", title)
                    // cover 为 String?，put(key, String?) 重载会处理 null -> JsonNull
                    put("cover", cover)
                    put("content", content)
                    put("app_ids", appIds.toJsonArray())
                    put("tags", tags.toJsonArray())
                },
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            // 非 2xx 视为错误，解析服务端返回的 error 字段
            if (response.status.value !in 200..299) {
                return Result.failure(ContentException(parseError(bodyText)))
            }

            val result = json.decodeFromString<PublishContentResponse>(bodyText)
            if (!result.success || result.articleId.isBlank()) {
                return Result.failure(ContentException("发布失败"))
            }
            Result.success(result.articleId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 查询已审核通过（status='approved'）的应用列表，用于发布编辑器的关联应用选择。
     *
     * 通过 Postgrest 直接查询 apps 表，RLS 允许读取 status='approved' 的应用。
     * 按创建时间降序排列。
     *
     * @return 已审核应用列表，查询失败返回空列表
     */
    suspend fun getApprovedApps(): List<App> {
        return try {
            val result = supabaseClient.postgrest.from("apps").select {
                filter { eq("status", AppStatus.APPROVED.value) }
                order("created_at", Order.DESCENDING)
            }
            result.decodeList<App>()
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * 解析 Edge Function 错误响应 { error: "..." }，提取可读错误信息。
     */
    private fun parseError(body: String): String {
        return try {
            json.decodeFromString<ContentErrorResponse>(body).error
        } catch (e: Exception) {
            "请求失败"
        }
    }

    /**
     * 将字符串列表转为 JsonArray，用于构造请求体。
     */
    private fun List<String>.toJsonArray(): JsonArray =
        JsonArray(map { JsonPrimitive(it) })
}

/**
 * 内容发布失败异常，携带服务端返回的错误信息。
 *
 * 注意：使用唯一类名 ContentException，避免与其他 Repository 中的异常类冲突
 * 导致 Redeclaration 错误。
 */
class ContentException(message: String) : Exception(message)

/**
 * publish-content Edge Function 的成功响应体。
 *
 * 注意：使用唯一类名 PublishContentResponse，避免与其他 Repository 中的
 * 响应 DTO 冲突导致 Redeclaration 错误。
 */
@Serializable
private data class PublishContentResponse(
    @SerialName("success") val success: Boolean = false,
    @SerialName("article_id") val articleId: String = "",
)

/**
 * Edge Function 错误响应体。
 *
 * 注意：使用唯一类名 ContentErrorResponse，避免与其他 Repository 中的
 * ErrorResponse 等已有 DTO 类冲突导致 Redeclaration 错误。
 */
@Serializable
private data class ContentErrorResponse(
    @SerialName("error") val error: String = "请求失败",
)
