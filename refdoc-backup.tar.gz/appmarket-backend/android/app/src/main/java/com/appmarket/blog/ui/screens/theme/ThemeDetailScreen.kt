package com.appmarket.blog.ui.screens.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.Article
import com.appmarket.blog.data.repository.ThemeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 主题详情页面 ViewModel，负责加载主题文章与其包含的应用列表。
 *
 * 通过 Hilt 注入 ThemeRepository（查询 articles 与 apps 表）。
 * 仅持有 Publishable key，通过 RLS 鉴权访问数据。
 */
@HiltViewModel
class ThemeDetailViewModel @Inject constructor(
    private val themeRepository: ThemeRepository,
) : ViewModel() {

    /**
     * UI 状态。
     *
     * @property article 主题文章，加载中或失败时为 null
     * @property apps 主题包含的应用列表
     * @property isLoading 是否正在加载
     * @property error 错误信息（非 null 表示加载失败）
     */
    data class UiState(
        val article: Article? = null,
        val apps: List<App> = emptyList(),
        val isLoading: Boolean = true,
        val error: String? = null,
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    /** 当前加载的 articleId，避免重复加载。 */
    private var currentArticleId: String? = null

    /**
     * 加载主题文章与应用列表。
     *
     * @param articleId 主题文章 UUID
     */
    fun load(articleId: String) {
        if (articleId == currentArticleId) return
        currentArticleId = articleId

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            val article = themeRepository.getTheme(articleId)
            if (article == null) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = "主题不存在或加载失败",
                    )
                }
                return@launch
            }

            val apps = themeRepository.getThemeApps(articleId)
            _uiState.update {
                it.copy(
                    article = article,
                    apps = apps,
                    isLoading = false,
                    error = null,
                )
            }
        }
    }
}

/**
 * 主题详情页。
 *
 * 展示主题文章内容（封面、标题、正文）与主题包含的所有应用列表。
 * 每个应用展示图标、名称、简介与下载按钮，点击应用跳转应用详情。
 *
 * 黑白主题，Material 3 风格。
 *
 * @param articleId 主题文章 UUID
 * @param onBack 返回上一页回调
 * @param onAppClick 应用点击回调，参数为应用 ID（跳转应用详情）
 * @param onDownloadClick 下载按钮点击回调，参数为应用 ID（跳转应用详情触发下载流程）
 * @param viewModel 主题详情 ViewModel
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeDetailScreen(
    articleId: String,
    onBack: () -> Unit,
    onAppClick: (String) -> Unit,
    onDownloadClick: (String) -> Unit = {},
    viewModel: ThemeDetailViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()

    // 首次进入时加载主题数据
    LaunchedEffect(articleId) {
        viewModel.load(articleId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("主题详情") },
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Text("返回")
                    }
                },
            )
        },
    ) { innerPadding ->
        when {
            // 加载中
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
            }

            // 错误状态
            uiState.error != null -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        text = uiState.error!!,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { viewModel.load(articleId) }) {
                        Text("重试")
                    }
                }
            }

            // 正常内容
            else -> {
                val article = uiState.article
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        horizontal = 0.dp,
                        vertical = 0.dp,
                    ),
                ) {
                    // 主题封面 + 标题
                    if (article != null) {
                        item { ThemeHeader(article = article) }

                        // 正文内容
                        if (!article.content.isNullOrBlank()) {
                            item {
                                Text(
                                    text = article.content,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 16.dp),
                                )
                            }
                        }

                        // 应用列表标题
                        item {
                            Text(
                                text = "包含应用（${uiState.apps.size} 个）",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                            )
                        }
                    }

                    // 应用列表
                    items(uiState.apps) { app ->
                        ThemeAppRow(
                            app = app,
                            onAppClick = { onAppClick(app.id) },
                            onDownloadClick = { onDownloadClick(app.id) },
                            modifier = Modifier.padding(horizontal = 16.dp),
                        )
                    }

                    // 空应用列表提示
                    if (uiState.apps.isEmpty() && article != null) {
                        item {
                            Text(
                                text = "该主题暂未关联应用",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            )
                        }
                    }

                    item { Spacer(modifier = Modifier.height(16.dp)) }
                }
            }
        }
    }
}

/**
 * 主题头部：封面图 + 标题叠加。
 */
@Composable
private fun ThemeHeader(article: Article) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
    ) {
        if (!article.cover.isNullOrBlank()) {
            AsyncImage(
                model = article.cover,
                contentDescription = article.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        } else {
            // 无封面时使用纯色背景
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.onBackground),
            )
        }
        // 底部渐变遮罩，使标题在图片上可读
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.6f),
                        ),
                    ),
                ),
        )
        // 标题叠加在封面底部
        Text(
            text = article.title,
            style = MaterialTheme.typography.headlineLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(20.dp),
        )
    }
}

/**
 * 主题应用行：图标、名称、简介、下载按钮。
 *
 * 点击整行跳转应用详情，下载按钮触发下载流程。
 */
@Composable
private fun ThemeAppRow(
    app: App,
    onAppClick: () -> Unit,
    onDownloadClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onAppClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shadowElevation = 2.dp,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ThemeAppIcon(
                iconUrl = app.iconUrl,
                appName = app.name,
                size = 56.dp,
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = app.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = app.description ?: "暂无简介",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Button(onClick = onDownloadClick) {
                Text("下载")
            }
        }
    }
}

/**
 * 应用图标组件。有 URL 时加载网络图片，否则显示应用名首字母占位。
 */
@Composable
private fun ThemeAppIcon(
    iconUrl: String?,
    appName: String,
    size: Dp,
) {
    val cornerRadius = size / 4
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (!iconUrl.isNullOrBlank()) {
            AsyncImage(
                model = iconUrl,
                contentDescription = appName,
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(cornerRadius)),
                contentScale = ContentScale.Crop,
            )
        } else {
            Text(
                text = appName.firstOrNull()?.uppercase() ?: "?",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}
