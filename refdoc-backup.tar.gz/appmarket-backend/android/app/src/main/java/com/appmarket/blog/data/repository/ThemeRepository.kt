package com.appmarket.blog.data.repository

import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.Article
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 主题详情 Repository，负责查询主题文章与其包含的应用列表。
 *
 * 安全说明：
 * - 仅持有 Publishable key，device_token 由 AuthInterceptor 自动附加到请求 header。
 * - articles 表所有人可读（RLS select all），主题文章通过 type='theme' 过滤。
 * - apps 表 RLS 允许读取 status in ('approved','virus_safe') 或自己 owner_id 的应用，
 *   主题包含的应用应已审核通过，可直接查询。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
@Singleton
class ThemeRepository @Inject constructor(
    private val supabaseClient: SupabaseClient,
) {
    /**
     * 查询主题文章。
     *
     * 从 articles 表查询 id 等于 articleId 且 type='theme' 的记录。
     *
     * @param articleId 主题文章 UUID
     * @return 主题文章，不存在或查询失败返回 null
     */
    suspend fun getTheme(articleId: String): Article? {
        return try {
            val result = supabaseClient.postgrest.from("articles").select {
                filter {
                    eq("id", articleId)
                    eq("type", "theme")
                }
            }
            result.decodeList<Article>().firstOrNull()
        } catch (_: Exception) {
            null
        }
    }

    /**
     * 查询主题包含的应用列表。
     *
     * 先查询主题文章获取 app_ids，再根据 app_ids 查询 apps 表。
     * app_ids 为空时直接返回空列表，避免发出空 IN 查询。
     *
     * @param articleId 主题文章 UUID
     * @return 主题包含的应用列表，查询失败返回空列表
     */
    suspend fun getThemeApps(articleId: String): List<App> {
        return try {
            // 先查询主题文章获取 app_ids
            val articleResult = supabaseClient.postgrest.from("articles").select {
                filter { eq("id", articleId) }
            }
            val article = articleResult.decodeList<Article>().firstOrNull()
            val appIds = article?.appIds
            if (appIds.isNullOrEmpty()) return emptyList()

            // 根据 app_ids 查询 apps
            val appsResult = supabaseClient.postgrest.from("apps").select {
                filter { isIn("id", appIds) }
                order("created_at", Order.DESCENDING)
            }
            appsResult.decodeList<App>()
        } catch (_: Exception) {
            emptyList()
        }
    }
}
