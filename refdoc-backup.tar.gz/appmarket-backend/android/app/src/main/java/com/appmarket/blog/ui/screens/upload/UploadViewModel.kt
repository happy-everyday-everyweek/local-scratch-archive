package com.appmarket.blog.ui.screens.upload

import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.blog.data.model.AppCategory
import com.appmarket.blog.data.repository.NoApkFoundException
import com.appmarket.blog.data.repository.SubmitResult
import com.appmarket.blog.data.repository.UploadDirectRepository
import com.appmarket.blog.data.repository.UploadDirectResult
import com.appmarket.blog.data.repository.UploadRepository
import com.appmarket.blog.util.InstalledApp
import com.appmarket.blog.util.InstalledAppHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * 上传应用页面 ViewModel，管理 UI 状态与提交逻辑。
 *
 * 根据分类使用不同的上传方式：
 * - 开源分类：通过 GitHub 仓库地址提交，调用 submit-app-by-repo Edge Function
 * - 正版/自然分类：通过本地 APK 直传，调用 upload-apk-direct Edge Function
 *
 * 开源分类仍需选择本地已安装应用获取图标和包名信息。
 * 正版/自然分类需先在设置中配置 GitHub 密钥（PAT）。
 */
@HiltViewModel
class UploadViewModel @Inject constructor(
    private val uploadRepository: UploadRepository,
    private val uploadDirectRepository: UploadDirectRepository,
    @ApplicationContext private val context: Context,
) : ViewModel() {

    /**
     * UI 状态。
     *
     * @property githubRepo GitHub 仓库地址输入（开源分类必填）
     * @property selectedCategory 当前选中的分类
     * @property name 应用名称输入
     * @property description 应用描述输入
     * @property isLoading 是否正在提交
     * @property success 开源分类提交成功结果（非 null 表示成功）
     * @property directSuccess 正版/自然分类直传成功结果（非 null 表示成功）
     * @property errorMessage 错误信息（非 null 表示失败）
     * @property isNoApkError 是否为「未找到 APK」错误
     * @property selectedInstalledApp 已选择的本地应用（用于获取图标/包名/版本）
     * @property apkFileName 已选择的 APK 文件名
     * @property apkBase64 已选择的 APK 文件 base64 编码
     * @property hasGithubPat 是否已配置 GitHub PAT
     * @property patConfigLoaded PAT 配置状态是否已加载
     * @property installedApps 本地已安装应用列表
     * @property installedAppsLoaded 本地应用列表是否已加载
     * @property showAppPicker 是否显示本地应用选择器
     */
    data class UiState(
        val githubRepo: String = "",
        val selectedCategory: AppCategory = AppCategory.OPENSOURCE,
        val name: String = "",
        val description: String = "",
        val isLoading: Boolean = false,
        val success: SubmitResult? = null,
        val directSuccess: UploadDirectResult? = null,
        val errorMessage: String? = null,
        val isNoApkError: Boolean = false,
        val selectedInstalledApp: InstalledApp? = null,
        val apkFileName: String? = null,
        val apkBase64: String? = null,
        val hasGithubPat: Boolean = false,
        val patConfigLoaded: Boolean = false,
        val installedApps: List<InstalledApp> = emptyList(),
        val installedAppsLoaded: Boolean = false,
        val showAppPicker: Boolean = false,
    ) {
        /**
         * 提交按钮是否可点击。
         *
         * 开源分类：仓库地址和应用名称非空
         * 正版/自然分类：已选择本地应用、已选择 APK 文件、应用名称非空、已配置 PAT
         */
        val canSubmit: Boolean
            get() {
                if (isLoading) return false
                return when (selectedCategory) {
                    AppCategory.OPENSOURCE -> githubRepo.isNotBlank() && name.isNotBlank()
                    AppCategory.GENUINE, AppCategory.NATURAL ->
                        name.isNotBlank() &&
                            selectedInstalledApp != null &&
                            apkBase64 != null &&
                            hasGithubPat
                }
            }

        /** 是否为正版/自然分类且未配置 PAT */
        val needsPatConfig: Boolean
            get() = (selectedCategory == AppCategory.GENUINE ||
                selectedCategory == AppCategory.NATURAL) &&
                patConfigLoaded && !hasGithubPat
    }

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        // 加载 PAT 配置状态
        loadPatConfig()
    }

    /**
     * 加载 GitHub PAT 配置状态（仅判断是否已配置，不读取明文）。
     */
    private fun loadPatConfig() {
        viewModelScope.launch {
            val settings = uploadDirectRepository.getGithubSettings()
            _uiState.update {
                it.copy(
                    hasGithubPat = settings.hasGithubPat,
                    patConfigLoaded = true,
                )
            }
        }
    }

    /**
     * 更新 GitHub 仓库地址输入。
     */
    fun updateGithubRepo(value: String) {
        _uiState.update {
            it.copy(githubRepo = value, errorMessage = null, isNoApkError = false)
        }
    }

    /**
     * 选择分类。切换分类时清除之前的错误和结果。
     */
    fun selectCategory(category: AppCategory) {
        _uiState.update {
            it.copy(
                selectedCategory = category,
                errorMessage = null,
                isNoApkError = false,
                success = null,
                directSuccess = null,
            )
        }
    }

    /**
     * 更新应用名称输入。
     * 若未手动输入且已选择本地应用，自动填充应用名。
     */
    fun updateName(value: String) {
        _uiState.update {
            it.copy(name = value, errorMessage = null, isNoApkError = false)
        }
    }

    /**
     * 更新应用描述输入。
     */
    fun updateDescription(value: String) {
        _uiState.update { it.copy(description = value) }
    }

    /**
     * 加载本地已安装应用列表（在 IO 线程执行）。
     */
    fun loadInstalledApps() {
        if (_uiState.value.installedAppsLoaded) return
        viewModelScope.launch {
            val apps = withContext(Dispatchers.IO) {
                InstalledAppHelper.getInstalledApps(context)
            }
            _uiState.update { it.copy(installedApps = apps, installedAppsLoaded = true) }
        }
    }

    /**
     * 显示本地应用选择器。
     */
    fun showAppPicker() {
        loadInstalledApps()
        _uiState.update { it.copy(showAppPicker = true) }
    }

    /**
     * 隐藏本地应用选择器。
     */
    fun hideAppPicker() {
        _uiState.update { it.copy(showAppPicker = false) }
    }

    /**
     * 选择本地已安装应用。
     * 自动填充应用名称、包名、版本号。
     */
    fun selectInstalledApp(app: InstalledApp) {
        _uiState.update {
            it.copy(
                selectedInstalledApp = app,
                showAppPicker = false,
                name = if (it.name.isBlank()) app.label else it.name,
                errorMessage = null,
            )
        }
    }

    /**
     * 选择 APK 文件。
     * 从 content URI 读取文件内容并 base64 编码（在 IO 线程执行）。
     *
     * @param uri APK 文件的 content URI
     * @param filename 文件名
     */
    fun selectApkFile(uri: Uri, filename: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                val base64 = withContext(Dispatchers.IO) {
                    val inputStream = context.contentResolver.openInputStream(uri)
                        ?: throw Exception("无法读取文件")
                    val bytes = inputStream.readBytes()
                    inputStream.close()
                    Base64.encodeToString(bytes, Base64.NO_WRAP)
                }
                _uiState.update {
                    it.copy(
                        apkBase64 = base64,
                        apkFileName = filename,
                        isLoading = false,
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "读取 APK 文件失败：${e.message}",
                    )
                }
            }
        }
    }

    /**
     * 提交应用。
     *
     * 开源分类：调用 UploadRepository.submitByRepo()
     * 正版/自然分类：调用 UploadDirectRepository.uploadApkDirect()
     */
    fun submit() {
        val state = _uiState.value
        if (!state.canSubmit) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = true,
                    success = null,
                    directSuccess = null,
                    errorMessage = null,
                    isNoApkError = false,
                )
            }

            when (state.selectedCategory) {
                AppCategory.OPENSOURCE -> submitByRepo(state)
                AppCategory.GENUINE, AppCategory.NATURAL -> uploadDirect(state)
            }
        }
    }

    /**
     * 开源分类提交：通过 GitHub 仓库地址提交。
     */
    private suspend fun submitByRepo(state: UiState) {
        val packageName = state.selectedInstalledApp?.packageName
        val result = uploadRepository.submitByRepo(
            githubRepo = state.githubRepo.trim(),
            category = state.selectedCategory,
            name = state.name.trim(),
            description = state.description.trim(),
            packageName = packageName,
        )
        result.onSuccess { submitResult ->
            _uiState.update { it.copy(isLoading = false, success = submitResult) }
        }.onFailure { error ->
            val message = if (error is NoApkFoundException) {
                error.message ?: "无法发布，请先在 GitHub 创建包含 APK 的 Release"
            } else {
                error.message ?: "提交失败"
            }
            _uiState.update {
                it.copy(
                    isLoading = false,
                    errorMessage = message,
                    isNoApkError = error is NoApkFoundException,
                )
            }
        }
    }

    /**
     * 正版/自然分类直传：通过本地 APK 上传到 GitHub Release。
     */
    private suspend fun uploadDirect(state: UiState) {
        val installedApp = state.selectedInstalledApp ?: run {
            _uiState.update {
                it.copy(isLoading = false, errorMessage = "请先选择本地应用")
            }
            return
        }
        val apkBase64 = state.apkBase64 ?: run {
            _uiState.update {
                it.copy(isLoading = false, errorMessage = "请先选择 APK 文件")
            }
            return
        }

        val iconBase64 = InstalledAppHelper.drawableToBase64Png(installedApp.iconDrawable)
        val filename = state.apkFileName ?: "${installedApp.packageName}.apk"

        val result = uploadDirectRepository.uploadApkDirect(
            apkBase64 = apkBase64,
            appName = state.name.trim(),
            packageName = installedApp.packageName,
            version = installedApp.versionName.ifBlank { "1.0" },
            description = state.description.trim(),
            category = state.selectedCategory,
            iconBase64 = iconBase64,
            filename = filename,
        )

        result.onSuccess { directResult ->
            _uiState.update { it.copy(isLoading = false, directSuccess = directResult) }
        }.onFailure { error ->
            _uiState.update {
                it.copy(
                    isLoading = false,
                    errorMessage = error.message ?: "上传失败",
                )
            }
        }
    }

    /**
     * 清除结果状态，回到初始表单。
     */
    fun clearResult() {
        _uiState.update {
            it.copy(success = null, directSuccess = null, errorMessage = null, isNoApkError = false)
        }
    }
}
