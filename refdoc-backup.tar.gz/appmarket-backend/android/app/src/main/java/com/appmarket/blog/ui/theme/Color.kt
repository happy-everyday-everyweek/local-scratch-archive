package com.appmarket.blog.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * 黑白主题色板：仅黑、白、灰。
 * 参考 Apple Today 的简洁视觉风格。
 */

// 基础色
val Black = Color(0xFF000000)
val White = Color(0xFFFFFFFF)

// 灰阶
val GrayLight = Color(0xFFF5F5F5)
val GrayMedium = Color(0xFFBDBDBD)
val GrayDark = Color(0xFF424242)

// Material 3 语义色（浅色主题）
val LightPrimary = Black
val LightOnPrimary = White
val LightPrimaryContainer = GrayDark
val LightOnPrimaryContainer = White

val LightSecondary = GrayDark
val LightOnSecondary = White
val LightSecondaryContainer = GrayLight
val LightOnSecondaryContainer = Black

val LightBackground = White
val LightOnBackground = Black
val LightSurface = White
val LightOnSurface = Black
val LightSurfaceVariant = GrayLight
val LightOnSurfaceVariant = GrayDark

val LightOutline = GrayMedium

// Material 3 语义色（深色主题）
val DarkPrimary = White
val DarkOnPrimary = Black
val DarkPrimaryContainer = GrayLight
val DarkOnPrimaryContainer = Black

val DarkSecondary = GrayLight
val DarkOnSecondary = Black
val DarkSecondaryContainer = GrayDark
val DarkOnSecondaryContainer = White

val DarkBackground = Black
val DarkOnBackground = White
val DarkSurface = Black
val DarkOnSurface = White
val DarkSurfaceVariant = GrayDark
val DarkOnSurfaceVariant = GrayLight

val DarkOutline = GrayMedium
