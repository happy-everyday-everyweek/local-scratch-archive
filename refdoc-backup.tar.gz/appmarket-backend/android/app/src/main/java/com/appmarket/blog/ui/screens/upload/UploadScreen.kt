package com.appmarket.blog.ui.screens.upload

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.hilt.navigation.compose.hiltViewModel
import com.appmarket.blog.data.model.AppCategory
import com.appmarket.blog.util.InstalledApp

/**
 * 上传应用页面。
 *
 * 根据分类使用不同的上传方式：
 * - 开源分类：通过 GitHub 仓库地址上传，调用 submit-app-by-repo Edge Function。
 *   仍需选择本地已安装应用获取图标和包名信息。
 * - 正版/自然分类：通过本地 APK 直传，调用 upload-apk-direct Edge Function。
 *   需先在设置中配置 GitHub 密钥（PAT）。
 *
 * 黑白主题，Material 3 风格。
 */
@Composable
fun UploadScreen(
    viewModel: UploadViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()

    // APK 文件选择器 launcher
    val apkFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->
        if (uri != null) {
            // 查询文件名
            val filename = queryFilename(uri)
            viewModel.selectApkFile(uri, filename)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // 页面标题
        Text(
            text = "上传应用",
            style = MaterialTheme.typography.headlineMedium,
        )

        // 分类选择
        Text(
            text = "分类",
            style = MaterialTheme.typography.titleMedium,
        )
        CategorySelector(
            selectedCategory = uiState.selectedCategory,
            onSelect = viewModel::selectCategory,
            enabled = !uiState.isLoading,
        )

        // 根据分类显示不同的输入区域
        when (uiState.selectedCategory) {
            AppCategory.OPENSOURCE -> OpensourceUploadSection(
                uiState = uiState,
                viewModel = viewModel,
            )
            AppCategory.GENUINE, AppCategory.NATURAL -> DirectUploadSection(
                uiState = uiState,
                viewModel = viewModel,
                onPickApk = {
                    apkFileLauncher.launch(arrayOf(
                        "application/vnd.android.package-archive",
                        "application/octet-stream",
                    ))
                },
            )
        }

        // 错误信息显示
        uiState.errorMessage?.let { message ->
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
        }
    }

    // 本地应用选择器弹窗
    if (uiState.showAppPicker) {
        InstalledAppPickerDialog(
            apps = uiState.installedApps,
            onSelect = viewModel::selectInstalledApp,
            onDismiss = viewModel::hideAppPicker,
        )
    }
}

/**
 * 开源分类上传区域。
 *
 * 显示 GitHub 仓库地址输入框和本地应用选择器（获取图标/包名）。
 */
@Composable
private fun OpensourceUploadSection(
    uiState: UploadViewModel.UiState,
    viewModel: UploadViewModel,
) {
    // GitHub 仓库地址输入框
    OutlinedTextField(
        value = uiState.githubRepo,
        onValueChange = viewModel::updateGithubRepo,
        label = { Text("GitHub 仓库地址") },
        placeholder = { Text("https://github.com/user/repo") },
        singleLine = true,
        enabled = !uiState.isLoading,
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Uri,
            imeAction = ImeAction.Next,
        ),
        modifier = Modifier.fillMaxWidth(),
    )

    // 本地应用选择器（获取图标/包名）
    Text(
        text = "选择本地应用（获取图标和包名）",
        style = MaterialTheme.typography.titleMedium,
    )
    AppSelectionRow(
        selectedApp = uiState.selectedInstalledApp,
        enabled = !uiState.isLoading,
        onClick = viewModel::showAppPicker,
    )

    // 应用名称输入框
    OutlinedTextField(
        value = uiState.name,
        onValueChange = viewModel::updateName,
        label = { Text("应用名称") },
        singleLine = true,
        enabled = !uiState.isLoading,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        modifier = Modifier.fillMaxWidth(),
    )

    // 应用描述输入框（多行）
    OutlinedTextField(
        value = uiState.description,
        onValueChange = viewModel::updateDescription,
        label = { Text("应用描述") },
        enabled = !uiState.isLoading,
        minLines = 3,
        maxLines = 5,
        modifier = Modifier.fillMaxWidth(),
    )

    // 提交按钮
    Button(
        onClick = viewModel::submit,
        enabled = uiState.canSubmit,
        modifier = Modifier.fillMaxWidth(),
    ) {
        if (uiState.isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = MaterialTheme.colorScheme.onPrimary,
                strokeWidth = 2.dp,
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("提交中")
        } else {
            Text("提交")
        }
    }

    // 提交成功结果显示
    uiState.success?.let { result ->
        Text(
            text = "提交成功，已抓取 ${result.apkCount} 个 APK，状态：${result.status}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

/**
 * 正版/自然分类直传区域。
 *
 * 显示本地应用选择器、APK 文件选择器、描述输入框。
 * 若未配置 PAT，显示提示信息。
 */
@Composable
private fun DirectUploadSection(
    uiState: UploadViewModel.UiState,
    viewModel: UploadViewModel,
    onPickApk: () -> Unit,
) {
    // 若未配置 PAT，显示提示
    if (uiState.needsPatConfig) {
        Text(
            text = "请先在设置中配置 GitHub 密钥",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.error,
        )
        Spacer(modifier = Modifier.height(8.dp))
    }

    // 本地应用选择器（获取图标/包名/版本）
    Text(
        text = "选择本地应用",
        style = MaterialTheme.typography.titleMedium,
    )
    AppSelectionRow(
        selectedApp = uiState.selectedInstalledApp,
        enabled = !uiState.isLoading,
        onClick = viewModel::showAppPicker,
    )

    // APK 文件选择器
    Text(
        text = "选择 APK 文件",
        style = MaterialTheme.typography.titleMedium,
    )
    OutlinedButton(
        onClick = onPickApk,
        enabled = !uiState.isLoading,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(uiState.apkFileName ?: "点击选择 APK 文件")
    }

    // 应用名称输入框
    OutlinedTextField(
        value = uiState.name,
        onValueChange = viewModel::updateName,
        label = { Text("应用名称") },
        singleLine = true,
        enabled = !uiState.isLoading,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        modifier = Modifier.fillMaxWidth(),
    )

    // 应用描述输入框（多行）
    OutlinedTextField(
        value = uiState.description,
        onValueChange = viewModel::updateDescription,
        label = { Text("应用描述") },
        enabled = !uiState.isLoading,
        minLines = 3,
        maxLines = 5,
        modifier = Modifier.fillMaxWidth(),
    )

    // 提交按钮
    Button(
        onClick = viewModel::submit,
        enabled = uiState.canSubmit,
        modifier = Modifier.fillMaxWidth(),
    ) {
        if (uiState.isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = MaterialTheme.colorScheme.onPrimary,
                strokeWidth = 2.dp,
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("上传中")
        } else {
            Text("上传")
        }
    }

    // 直传成功结果显示
    uiState.directSuccess?.let { result ->
        Text(
            text = "上传成功，Release ID：${result.releaseId}，状态：${result.status}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

/**
 * 本地应用选择行，显示已选应用或点击选择按钮。
 */
@Composable
private fun AppSelectionRow(
    selectedApp: InstalledApp?,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 8.dp),
    ) {
        if (selectedApp != null) {
            // 显示已选应用图标
            selectedApp.iconDrawable?.let { drawable ->
                androidx.compose.foundation.Image(
                    bitmap = drawable.toBitmap(48, 48).asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.size(48.dp),
                )
                Spacer(modifier = Modifier.width(12.dp))
            }
            Column {
                Text(
                    text = selectedApp.label,
                    style = MaterialTheme.typography.bodyLarge,
                )
                Text(
                    text = selectedApp.packageName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (selectedApp.versionName.isNotBlank()) {
                    Text(
                        text = "版本：${selectedApp.versionName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        } else {
            OutlinedButton(
                onClick = onClick,
                enabled = enabled,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("点击选择本地应用")
            }
        }
    }
}

/**
 * 本地应用选择器弹窗。
 */
@Composable
private fun InstalledAppPickerDialog(
    apps: List<InstalledApp>,
    onSelect: (InstalledApp) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("选择本地应用") },
        text = {
            if (apps.isEmpty()) {
                Text("正在加载应用列表...")
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp),
                ) {
                    items(apps) { app ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(app) }
                                .padding(vertical = 8.dp),
                        ) {
                            app.iconDrawable?.let { drawable ->
                                androidx.compose.foundation.Image(
                                    bitmap = drawable.toBitmap(40, 40).asImageBitmap(),
                                    contentDescription = null,
                                    modifier = Modifier.size(40.dp),
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                            }
                            Column {
                                Text(
                                    text = app.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                Text(
                                    text = app.packageName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        },
    )
}

/**
 * 分类选择器，使用 RadioGroup 实现。
 *
 * 自然分类附带说明文字「对正版的 APK 进行的自然化」。
 */
@Composable
private fun CategorySelector(
    selectedCategory: AppCategory,
    onSelect: (AppCategory) -> Unit,
    enabled: Boolean,
) {
    val categories = listOf(
        AppCategory.OPENSOURCE to "开源",
        AppCategory.GENUINE to "正版",
        AppCategory.NATURAL to "自然",
    )

    Column {
        categories.forEach { (category, label) ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
            ) {
                RadioButton(
                    selected = selectedCategory == category,
                    onClick = { onSelect(category) },
                    enabled = enabled,
                )
                Column {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    // 自然分类附带说明
                    if (category == AppCategory.NATURAL) {
                        Text(
                            text = "对正版的 APK 进行的自然化",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

/**
 * 从 content URI 查询文件名。
 */
private fun queryFilename(uri: Uri): String {
    return uri.lastPathSegment ?: "app.apk"
}
