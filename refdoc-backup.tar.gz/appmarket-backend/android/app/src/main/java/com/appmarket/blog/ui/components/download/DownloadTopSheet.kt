package com.appmarket.blog.ui.components.download

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.AppStatus

/**
 * 下载上弹窗。
 *
 * 根据应用状态展示不同内容：
 * - VIRUS_SAFE（报毒但安全）：展示报毒原因解释与关网提示，使用黑色边框突出警告，
 *   提供「我已了解」按钮触发 onAcknowledge。
 * - APPROVED（普通）：展示应用名称与简介，提供关闭按钮触发 onAcknowledge。
 * - 其他状态：不展示上弹窗。
 *
 * 黑白主题，Material 3 Card 风格。
 *
 * @param app 应用数据
 * @param onAcknowledge 用户确认/关闭回调
 * @param modifier 修饰符
 */
@Composable
fun DownloadTopSheet(
    app: App,
    onAcknowledge: () -> Unit,
    modifier: Modifier = Modifier,
) {
    when (app.status) {
        AppStatus.VIRUS_SAFE -> VirusSafeTopSheet(
            reason = app.virusSafeReason,
            onAcknowledge = onAcknowledge,
            modifier = modifier,
        )

        AppStatus.APPROVED -> ApprovedTopSheet(
            appName = app.name,
            description = app.description,
            onAcknowledge = onAcknowledge,
            modifier = modifier,
        )

        else -> {
            // 其他状态不展示上弹窗
        }
    }
}

/**
 * 报毒但安全的上弹窗。
 *
 * 使用黑色边框与黑色标题条突出警告，内容包含报毒原因解释与关网提示。
 */
@Composable
private fun VirusSafeTopSheet(
    reason: String?,
    onAcknowledge: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        // 黑色边框突出警告
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.onSurface),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // 标题行：警告图标 + 「安全提示」
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = "安全提示",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }

            // 报毒原因解释
            Text(
                text = reason?.takeIf { it.isNotBlank() }
                    ?: "该应用被部分安全软件报毒，但经核实可安全使用。",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )

            // 关网提示
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                ),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = "可在下载完成、开始安装前关闭设备的 WiFi 和移动数据",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // 「我已了解」按钮
            Button(
                onClick = onAcknowledge,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.onSurface,
                    contentColor = MaterialTheme.colorScheme.surface,
                ),
            ) {
                Text(
                    text = "我已了解",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

/**
 * 普通应用简介上弹窗。
 *
 * 展示应用名称与简介，提供关闭按钮。
 */
@Composable
private fun ApprovedTopSheet(
    appName: String,
    description: String?,
    onAcknowledge: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // 标题行：应用名称 + 关闭按钮
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = appName,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onAcknowledge) {
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "关闭",
                        tint = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }

            // 应用简介
            Text(
                text = description?.takeIf { it.isNotBlank() } ?: "暂无简介",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
