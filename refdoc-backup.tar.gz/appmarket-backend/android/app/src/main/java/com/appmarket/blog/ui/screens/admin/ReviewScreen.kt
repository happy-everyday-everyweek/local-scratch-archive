package com.appmarket.blog.ui.screens.admin

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.blog.data.model.AppCategory
import com.appmarket.blog.data.repository.PendingReviewApp
import com.appmarket.blog.data.repository.ReviewException
import com.appmarket.blog.data.repository.ReviewRepository
import com.appmarket.blog.data.repository.ReviewResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 审核页面 UI 状态。
 *
 * @property isLoading 是否正在加载待审核列表
 * @property isOperating 是否正在执行审核操作（通过/报毒但安全/拒绝）
 * @property apps 待审核应用列表
 * @property total 总数
 * @property errorMessage 错误提示（非 null 时展示错误弹窗）
 * @property operateResult 审核操作成功提示（非 null 时展示成功弹窗）
 * @property selectedApp 当前选中的应用（非 null 时展示审核详情）
 * @property showVirusSafeDialog 是否展示「报毒但安全」原因输入弹窗
 */
data class ReviewUiState(
    val isLoading: Boolean = false,
    val isOperating: Boolean = false,
    val apps: List<PendingReviewApp> = emptyList(),
    val total: Int = 0,
    val errorMessage: String? = null,
    val operateResult: ReviewResult? = null,
    val selectedApp: PendingReviewApp? = null,
    val showVirusSafeDialog: Boolean = false,
)

/**
 * 审核页面 ViewModel，处理待审核应用列表加载与审核操作逻辑。
 *
 * 注入 ReviewRepository（查询待审核列表 / 执行审核操作）。
 */
@HiltViewModel
class ReviewViewModel @Inject constructor(
    private val reviewRepository: ReviewRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReviewUiState())
    val uiState: StateFlow<ReviewUiState> = _uiState.asStateFlow()

    init {
        // 进入页面时加载待审核应用列表
        loadPendingReviews()
    }

    /**
     * 加载待审核应用列表。
     */
    fun loadPendingReviews() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            reviewRepository.getPendingReviews()
                .onSuccess { page ->
                    _uiState.update { state ->
                        state.copy(
                            isLoading = false,
                            apps = page.apps,
                            total = page.total,
                        )
                    }
                }
                .onFailure { e -> handleError(e) }
        }
    }

    /**
     * 选中应用，进入审核详情。
     */
    fun selectApp(app: PendingReviewApp) {
        _uiState.update { it.copy(selectedApp = app) }
    }

    /**
     * 返回列表（关闭审核详情）。
     */
    fun clearSelectedApp() {
        _uiState.update { it.copy(selectedApp = null) }
    }

    /**
     * 通过审核。
     *
     * @param appId 应用 UUID
     */
    fun approve(appId: String) {
        operate(appId) { reviewRepository.approve(appId) }
    }

    /**
     * 拒绝审核。
     *
     * @param appId 应用 UUID
     */
    fun reject(appId: String) {
        operate(appId) { reviewRepository.reject(appId) }
    }

    /**
     * 展示「报毒但安全」原因输入弹窗。
     */
    fun showVirusSafeDialog() {
        _uiState.update { it.copy(showVirusSafeDialog = true) }
    }

    /**
     * 关闭「报毒但安全」原因输入弹窗。
     */
    fun dismissVirusSafeDialog() {
        _uiState.update { it.copy(showVirusSafeDialog = false) }
    }

    /**
     * 标记为「报毒但安全」。
     *
     * @param appId 应用 UUID
     * @param reason 报毒但安全的原因说明
     */
    fun markVirusSafe(appId: String, reason: String) {
        _uiState.update { it.copy(showVirusSafeDialog = false) }
        operate(appId) { reviewRepository.markVirusSafe(appId, reason) }
    }

    /**
     * 统一执行审核操作。
     * 操作成功后从列表中移除该应用，并关闭审核详情。
     */
    private fun operate(
        appId: String,
        block: suspend () -> Result<ReviewResult>,
    ) {
        val state = _uiState.value
        if (state.isOperating) return
        viewModelScope.launch {
            _uiState.update { it.copy(isOperating = true, errorMessage = null) }
            block()
                .onSuccess { result ->
                    _uiState.update { s ->
                        s.copy(
                            isOperating = false,
                            operateResult = result,
                            // 从列表中移除已审核的应用
                            apps = s.apps.filter { it.id != appId },
                            total = (s.total - 1).coerceAtLeast(0),
                            // 关闭审核详情与弹窗
                            selectedApp = null,
                            showVirusSafeDialog = false,
                        )
                    }
                }
                .onFailure { e -> handleError(e) }
        }
    }

    /** 关闭错误弹窗。 */
    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    /** 关闭成功弹窗。 */
    fun clearOperateResult() {
        _uiState.update { it.copy(operateResult = null) }
    }

    /**
     * 统一处理错误：区分 ReviewException（携带服务端错误信息）与其他异常。
     */
    private fun handleError(e: Throwable) {
        val message = if (e is ReviewException) {
            e.message ?: "请求失败"
        } else {
            e.message ?: "网络错误"
        }
        _uiState.update {
            it.copy(
                isLoading = false,
                isOperating = false,
                showVirusSafeDialog = false,
                errorMessage = message,
            )
        }
    }
}

/**
 * 应用审核页面。
 *
 * 仅 role in (ADMIN, OWNER) 可见（在导航层做权限控制）。
 *
 * 功能：
 * 1. 待审核应用列表：查询 status='pending_review' 的 apps（经 Edge Function）
 * 2. 每个应用显示：名称、分类、版本、上传者、上传时间、GitHub 仓库链接
 * 3. 点击应用进入审核详情：显示应用信息 + 三个操作按钮
 *    - 「通过审核」：调用 manual-review action=approve
 *    - 「标记报毒但安全」：弹出输入框填写 virus_safe_reason，调用 manual-review action=virus_safe
 *    - 「拒绝」：调用 manual-review action=reject
 * 4. 操作后刷新列表
 *
 * 黑白主题，Material 3 风格。
 */
@Composable
fun ReviewScreen(
    viewModel: ReviewViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // 页面标题
        Text(
            text = "应用审核",
            style = MaterialTheme.typography.headlineMedium,
        )

        // 待审核总数统计
        Text(
            text = "共 ${uiState.total} 个待审核应用",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Divider()

        // 内容区：列表或审核详情
        val selected = uiState.selectedApp
        if (selected != null) {
            // 审核详情
            ReviewDetailContent(
                app = selected,
                isOperating = uiState.isOperating,
                onApprove = { viewModel.approve(selected.id) },
                onReject = { viewModel.reject(selected.id) },
                onMarkVirusSafe = { viewModel.showVirusSafeDialog() },
                onBack = { viewModel.clearSelectedApp() },
            )
        } else {
            // 待审核应用列表
            PendingReviewListContent(
                uiState = uiState,
                onAppClick = { viewModel.selectApp(it) },
                onRefresh = { viewModel.loadPendingReviews() },
            )
        }
    }

    // 「报毒但安全」原因输入弹窗
    if (uiState.showVirusSafeDialog && uiState.selectedApp != null) {
        VirusSafeReasonDialog(
            appName = uiState.selectedApp!!.name,
            isOperating = uiState.isOperating,
            onDismiss = { viewModel.dismissVirusSafeDialog() },
            onConfirm = { reason ->
                viewModel.markVirusSafe(uiState.selectedApp!!.id, reason)
            },
        )
    }

    // 错误提示弹窗
    uiState.errorMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { viewModel.clearError() },
            title = { Text("提示") },
            text = { Text(msg) },
            confirmButton = {
                TextButton(onClick = { viewModel.clearError() }) {
                    Text("确定")
                }
            },
        )
    }

    // 审核操作成功提示弹窗
    uiState.operateResult?.let { result ->
        val statusText = when (result.status) {
            "approved" -> "已通过"
            "virus_safe" -> "已标记为报毒但安全"
            "rejected" -> "已拒绝"
            else -> result.status
        }
        AlertDialog(
            onDismissRequest = { viewModel.clearOperateResult() },
            title = { Text("提示") },
            text = { Text("审核操作完成：$statusText") },
            confirmButton = {
                TextButton(onClick = { viewModel.clearOperateResult() }) {
                    Text("确定")
                }
            },
        )
    }
}

/**
 * 待审核应用列表内容。
 *
 * @param uiState UI 状态
 * @param onAppClick 点击应用回调
 * @param onRefresh 刷新回调
 */
@Composable
private fun PendingReviewListContent(
    uiState: ReviewUiState,
    onAppClick: (PendingReviewApp) -> Unit,
    onRefresh: () -> Unit,
) {
    if (uiState.apps.isEmpty() && uiState.isLoading) {
        // 首次加载占位
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator()
        }
        return
    }

    if (uiState.apps.isEmpty()) {
        // 空列表
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = "暂无待审核应用",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(onClick = onRefresh) {
                Text("刷新")
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(
            items = uiState.apps,
            key = { it.id },
        ) { app ->
            PendingReviewItem(
                app = app,
                onClick = { onAppClick(app) },
            )
        }
        // 加载中指示器
        if (uiState.isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                }
            }
        }
    }
}

/**
 * 单个待审核应用卡片。
 *
 * 显示名称、分类、版本、上传者（脱敏）、上传时间、GitHub 仓库链接。
 *
 * @param app 应用信息
 * @param onClick 点击回调
 */
@Composable
private fun PendingReviewItem(
    app: PendingReviewApp,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // 应用名称
            Text(
                text = app.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
            )

            // 分类标签
            val categoryText = when (app.category) {
                AppCategory.OPENSOURCE -> "开源"
                AppCategory.GENUINE -> "正版"
                AppCategory.NATURAL -> "自然"
            }
            Text(
                text = "分类：$categoryText",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // 版本号
            Text(
                text = "版本：${app.latestVersion ?: "未知"}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // 上传者（设备指纹脱敏）
            Text(
                text = "上传者：${maskFingerprint(app.ownerFingerprint)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // 上传时间
            Text(
                text = "上传时间：${formatCreatedAt(app.createdAt)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // GitHub 仓库链接
            if (!app.githubRepo.isNullOrBlank()) {
                Text(
                    text = "仓库：${app.githubRepo}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/**
 * 审核详情内容。
 *
 * 显示应用信息 + 三个操作按钮（通过审核 / 标记报毒但安全 / 拒绝）。
 *
 * @param app 应用信息
 * @param isOperating 是否正在执行审核操作
 * @param onApprove 通过审核回调
 * @param onReject 拒绝回调
 * @param onMarkVirusSafe 标记报毒但安全回调
 * @param onBack 返回列表回调
 */
@Composable
private fun ReviewDetailContent(
    app: PendingReviewApp,
    isOperating: Boolean,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onMarkVirusSafe: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // 返回按钮
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack, enabled = !isOperating) {
                Text("返回列表")
            }
        }

        // 应用信息卡片
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface,
            ),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = app.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )

                val categoryText = when (app.category) {
                    AppCategory.OPENSOURCE -> "开源"
                    AppCategory.GENUINE -> "正版"
                    AppCategory.NATURAL -> "自然"
                }
                Text(
                    text = "分类：$categoryText",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Text(
                    text = "版本：${app.latestVersion ?: "未知"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Text(
                    text = "上传者：${maskFingerprint(app.ownerFingerprint)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Text(
                    text = "上传时间：${formatCreatedAt(app.createdAt)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                // GitHub 仓库链接（可点击打开浏览器）
                if (!app.githubRepo.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "GitHub 仓库：",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = app.githubRepo,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable {
                            openUrl(context, app.githubRepo)
                        },
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 操作按钮区
        Text(
            text = "审核操作",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )

        // 通过审核
        Button(
            onClick = onApprove,
            enabled = !isOperating,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            ),
        ) {
            Text("通过审核")
        }

        // 标记报毒但安全
        OutlinedButton(
            onClick = onMarkVirusSafe,
            enabled = !isOperating,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("标记报毒但安全")
        }

        // 拒绝
        OutlinedButton(
            onClick = onReject,
            enabled = !isOperating,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.error,
            ),
        ) {
            Text("拒绝")
        }

        // 操作中指示器
        if (isOperating) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp))
            }
        }
    }
}

/**
 * 「报毒但安全」原因输入弹窗。
 *
 * @param appName 应用名称（用于弹窗标题展示）
 * @param isOperating 是否正在执行操作
 * @param onDismiss 关闭弹窗回调
 * @param onConfirm 确认回调，参数为原因文本
 */
@Composable
private fun VirusSafeReasonDialog(
    appName: String,
    isOperating: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var reason by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = { if (!isOperating) onDismiss() },
        title = { Text("标记报毒但安全") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "应用：$appName",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "请填写该应用触发报毒但安全的原因，将发送给上传者。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("报毒但安全的原因") },
                    placeholder = { Text("请输入原因说明") },
                    enabled = !isOperating,
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(reason) },
                enabled = !isOperating && reason.isNotBlank(),
            ) {
                Text("确认标记")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                enabled = !isOperating,
            ) {
                Text("取消")
            }
        },
    )
}

/**
 * 设备指纹脱敏：仅显示前 8 位，其余用 * 替换。
 */
private fun maskFingerprint(fingerprint: String?): String {
    if (fingerprint.isNullOrBlank()) return "未知"
    if (fingerprint.length <= 8) return fingerprint
    return fingerprint.take(8) + "*".repeat(8)
}

/**
 * 格式化时间字符串（ISO 8601）为可读形式。
 * 解析失败时返回原字符串。
 */
private fun formatCreatedAt(createdAt: String): String {
    return try {
        // 简单截取日期时间部分（YYYY-MM-DDTHH:MM:SS -> YYYY-MM-DD HH:MM:SS）
        val tIndex = createdAt.indexOf('T')
        if (tIndex > 0) {
            val date = createdAt.substring(0, tIndex)
            val timePart = createdAt.substring(tIndex + 1)
            // 截取到秒，去除时区后缀
            val time = timePart.take(8)
            "$date $time"
        } else {
            createdAt
        }
    } catch (e: Exception) {
        createdAt
    }
}

/**
 * 使用系统浏览器打开 URL。
 */
private fun openUrl(context: android.content.Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        // 无可用浏览器时忽略
    }
}
