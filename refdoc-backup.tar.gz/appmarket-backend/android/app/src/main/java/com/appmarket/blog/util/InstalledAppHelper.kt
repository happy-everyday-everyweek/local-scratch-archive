package com.appmarket.blog.util

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.Base64
import androidx.core.content.pm.PackageInfoCompat
import java.io.ByteArrayOutputStream

/**
 * 已安装应用信息。
 *
 * @property packageName 包名
 * @property label 应用显示名称
 * @property versionName 版本名
 * @property versionCode 版本号
 * @property iconDrawable 应用图标 Drawable（可能为 null）
 */
data class InstalledApp(
    val packageName: String,
    val label: String,
    val versionName: String,
    val versionCode: Long,
    val iconDrawable: Drawable?,
)

/**
 * 本地已安装应用辅助工具。
 *
 * 使用 PackageManager 获取设备上已安装的第三方应用列表，
 * 排除系统应用。用于上传页面选择本地应用以获取图标和包名信息。
 *
 * 注意：Android 11（API 30）及以上需要 QUERY_ALL_PACKAGES 权限才能查询所有应用。
 */
object InstalledAppHelper {

    /**
     * 获取设备上已安装的第三方应用列表（排除系统应用）。
     *
     * @param context 上下文
     * @return 第三方应用列表，按应用名排序
     */
    fun getInstalledApps(context: Context): List<InstalledApp> {
        val packageManager = context.packageManager
        val packages = packageManager.getInstalledPackages(0)
        return packages
            .filter { pkg ->
                // 排除系统应用，只取第三方应用
                val appInfo = pkg.applicationInfo ?: return@filter false
                (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0
            }
            .map { pkg ->
                val appInfo = pkg.applicationInfo
                InstalledApp(
                    packageName = pkg.packageName,
                    label = packageManager.getApplicationLabel(appInfo).toString(),
                    versionName = pkg.versionName ?: "",
                    versionCode = PackageInfoCompat.getLongVersionCode(pkg),
                    iconDrawable = packageManager.getApplicationIcon(appInfo),
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    /**
     * 获取指定包名应用的图标。
     *
     * @param context 上下文
     * @param packageName 包名
     * @return 图标 Drawable，应用不存在时返回 null
     */
    fun getInstalledAppIcon(context: Context, packageName: String): Drawable? {
        return try {
            context.packageManager.getApplicationIcon(packageName)
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    /**
     * 将 Drawable 转换为 base64 编码的 PNG 字符串。
     *
     * 用于上传应用图标到 GitHub Release 资产。
     *
     * @param drawable 图标 Drawable
     * @return base64 编码的 PNG 字符串，转换失败返回 null
     */
    fun drawableToBase64Png(drawable: Drawable?): String? {
        if (drawable == null) return null
        return try {
            val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 192
            val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 192
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            val bytes = outputStream.toByteArray()
            bitmap.recycle()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }
}
