package com.appmarket.blog.ui.screens.admin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appmarket.blog.data.local.SecureStorage
import com.appmarket.blog.data.model.Role
import com.appmarket.blog.data.repository.AdminException
import com.appmarket.blog.data.repository.AdminProfile
import com.appmarket.blog.data.repository.AdminRepository
import com.appmarket.blog.data.repository.AssignRoleResult
import com.appmarket.blog.data.repository.ProfilePage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 管理后台页面 UI 状态。
 *
 * @property isLoading 是否正在加载用户列表（首次或分页加载）
 * @property isAssigning 是否正在修改角色
 * @property profiles 已加载的用户列表
 * @property total 总用户数
 * @property hasMore 是否还有更多数据可加载
 * @property errorMessage 错误提示（非 null 时展示错误弹窗）
 * @property assignResult 角色变更成功提示（非 null 时展示成功弹窗）
 * @property currentProfileId 当前登录用户的 profile id（用于禁用对自己的操作）
 */
data class AdminUiState(
    val isLoading: Boolean = false,
    val isAssigning: Boolean = false,
    val profiles: List<AdminProfile> = emptyList(),
    val total: Int = 0,
    val hasMore: Boolean = false,
    val errorMessage: String? = null,
    val assignResult: AssignRoleResult? = null,
    val currentProfileId: String? = null,
)

/**
 * 管理后台页面 ViewModel，处理用户列表加载与角色变更逻辑。
 *
 * 注入 AdminRepository（查询用户列表 / 修改角色）与 SecureStorage（读取当前
 * profile id，用于禁用对自己的操作）。
 */
@HiltViewModel
class AdminViewModel @Inject constructor(
    private val adminRepository: AdminRepository,
    private val secureStorage: SecureStorage,
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    // 分页参数
    private var currentOffset = 0
    private val pageSize = 20

    init {
        // 初始化时记录当前 profile id 并加载首页
        _uiState.update { it.copy(currentProfileId = secureStorage.getProfileId()) }
        loadFirstPage()
    }

    /**
     * 加载第一页用户列表（重置分页）。
     */
    fun loadFirstPage() {
        currentOffset = 0
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            adminRepository.getProfiles(offset = 0, limit = pageSize)
                .onSuccess { page -> applyPage(page, replace = true) }
                .onFailure { e -> handleError(e) }
        }
    }

    /**
     * 加载下一页用户列表（追加）。
     * 仅当当前未在加载且还有更多数据时执行。
     */
    fun loadNextPage() {
        val state = _uiState.value
        if (state.isLoading || state.isAssigning || !state.hasMore) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            adminRepository.getProfiles(offset = currentOffset, limit = pageSize)
                .onSuccess { page -> applyPage(page, replace = false) }
                .onFailure { e -> handleError(e) }
        }
    }

    /**
     * 修改目标用户角色。
     *
     * @param targetProfileId 目标 profile id
     * @param newRole 新角色（仅 USER / ADMIN）
     */
    fun assignRole(targetProfileId: String, newRole: Role) {
        val state = _uiState.value
        if (state.isAssigning) return
        // 客户端兜底校验：不能修改 owner 和自己的角色
        val target = state.profiles.find { it.id == targetProfileId } ?: return
        if (target.role == Role.OWNER) return
        if (targetProfileId == state.currentProfileId) return
        // newRole 只能为 USER 或 ADMIN
        if (newRole != Role.USER && newRole != Role.ADMIN) return

        viewModelScope.launch {
            _uiState.update { it.copy(isAssigning = true, errorMessage = null) }
            adminRepository.assignRole(targetProfileId, newRole)
                .onSuccess { result ->
                    // 本地即时更新对应 profile 的角色，避免重新拉取
                    _uiState.update { state ->
                        state.copy(
                            isAssigning = false,
                            assignResult = result,
                            profiles = state.profiles.map { p ->
                                if (p.id == result.targetProfileId) {
                                    p.copy(role = result.newRole)
                                } else {
                                    p
                                }
                            },
                        )
                    }
                }
                .onFailure { e -> handleError(e) }
        }
    }

    /** 关闭错误弹窗。 */
    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    /** 关闭成功弹窗。 */
    fun clearAssignResult() {
        _uiState.update { it.copy(assignResult = null) }
    }

    /**
     * 应用分页结果到 UI 状态。
     *
     * @param page 服务端返回的分页数据
     * @param replace true 表示替换列表（首页加载），false 表示追加（分页加载）
     */
    private fun applyPage(page: ProfilePage, replace: Boolean) {
        currentOffset = page.offset + page.profiles.size
        _uiState.update { state ->
            state.copy(
                isLoading = false,
                profiles = if (replace) page.profiles else state.profiles + page.profiles,
                total = page.total,
                hasMore = page.hasMore,
            )
        }
    }

    /**
     * 统一处理错误：区分 AdminException（携带服务端错误信息）与其他异常。
     */
    private fun handleError(e: Throwable) {
        val message = if (e is AdminException) {
            e.message ?: "请求失败"
        } else {
            e.message ?: "网络错误"
        }
        _uiState.update { it.copy(isLoading = false, isAssigning = false, errorMessage = message) }
    }
}

/**
 * 管理后台页面。
 *
 * 仅 role=OWNER 可见（在导航层做权限控制）。
 *
 * 功能：
 * 1. 用户列表：查询所有 profiles（分页加载）
 * 2. 每个用户显示：设备指纹（脱敏显示前 8 位）、角色、注册时间
 * 3. 站长可将 user 提升为 admin，或将 admin 撤销为 user
 * 4. 不能修改 owner 角色和自己的角色
 *
 * 黑白主题，Material 3 风格。
 */
@Composable
fun AdminScreen(
    viewModel: AdminViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()

    // 滚动接近底部时自动加载下一页
    val shouldLoadMore by remember {
        derivedStateOf {
            val lastVisibleIndex = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
            val totalItems = listState.layoutInfo.totalItemsCount
            totalItems > 0 && lastVisibleIndex >= totalItems - 3
        }
    }
    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) viewModel.loadNextPage()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // 页面标题
        Text(
            text = "管理后台",
            style = MaterialTheme.typography.headlineMedium,
        )

        // 用户总数统计
        Text(
            text = "共 ${uiState.total} 位用户",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Divider()

        // 用户列表
        if (uiState.profiles.isEmpty() && uiState.isLoading) {
            // 首次加载占位
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator()
            }
        } else if (uiState.profiles.isEmpty()) {
            // 空列表
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "暂无用户",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(
                    items = uiState.profiles,
                    key = { it.id },
                ) { profile ->
                    ProfileItem(
                        profile = profile,
                        currentProfileId = uiState.currentProfileId,
                        isAssigning = uiState.isAssigning,
                        onAssignRole = { newRole ->
                            viewModel.assignRole(profile.id, newRole)
                        },
                    )
                }
                // 分页加载更多指示器
                if (uiState.isLoading && uiState.profiles.isNotEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        }
                    }
                }
                // 角色变更中指示器
                if (uiState.isAssigning) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = "正在修改角色...",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }

    // 错误提示弹窗
    uiState.errorMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { viewModel.clearError() },
            title = { Text("提示") },
            text = { Text(msg) },
            confirmButton = {
                TextButton(onClick = { viewModel.clearError() }) {
                    Text("确定")
                }
            },
        )
    }

    // 角色变更成功提示弹窗
    uiState.assignResult?.let { result ->
        val roleText = when (result.newRole) {
            Role.USER -> "普通用户"
            Role.ADMIN -> "管理员"
            Role.OWNER -> "站长"
        }
        AlertDialog(
            onDismissRequest = { viewModel.clearAssignResult() },
            title = { Text("提示") },
            text = { Text("角色已更新为：$roleText") },
            confirmButton = {
                TextButton(onClick = { viewModel.clearAssignResult() }) {
                    Text("确定")
                }
            },
        )
    }
}

/**
 * 单个用户卡片。
 *
 * 显示设备指纹（脱敏前 8 位）、角色、注册时间。
 * 站长可将 user 提升为 admin，或将 admin 撤销为 user。
 * 不能修改 owner 角色和自己的角色。
 *
 * @param profile 用户信息
 * @param currentProfileId 当前登录用户的 profile id
 * @param isAssigning 是否正在修改角色（用于禁用按钮）
 * @param onAssignRole 角色变更回调，参数为新角色
 */
@Composable
private fun ProfileItem(
    profile: AdminProfile,
    currentProfileId: String?,
    isAssigning: Boolean,
    onAssignRole: (Role) -> Unit,
) {
    val isSelf = profile.id == currentProfileId
    val isOwner = profile.role == Role.OWNER
    // owner 和自己都不允许修改角色
    val canModify = !isSelf && !isOwner && !isAssigning

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // 设备指纹（脱敏显示前 8 位）
            Text(
                text = "设备：${maskFingerprint(profile.deviceFingerprint)}",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
            )

            // 角色标签
            val roleText = when (profile.role) {
                Role.USER -> "普通用户"
                Role.ADMIN -> "管理员"
                Role.OWNER -> "站长"
            }
            Text(
                text = "角色：$roleText",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // 注册时间
            Text(
                text = "注册时间：${formatCreatedAt(profile.createdAt)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // 标识自己
            if (isSelf) {
                Text(
                    text = "（你自己）",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            // 操作按钮区
            if (!isOwner) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    when (profile.role) {
                        Role.USER -> {
                            // user 可提升为 admin
                            OutlinedButton(
                                onClick = { onAssignRole(Role.ADMIN) },
                                enabled = canModify,
                                modifier = Modifier.weight(1f),
                            ) {
                                Text("提升为管理员")
                            }
                        }
                        Role.ADMIN -> {
                            // admin 可撤销为 user
                            OutlinedButton(
                                onClick = { onAssignRole(Role.USER) },
                                enabled = canModify,
                                modifier = Modifier.weight(1f),
                            ) {
                                Text("撤销管理员")
                            }
                        }
                        Role.OWNER -> {
                            // owner 不显示操作按钮
                        }
                    }
                }
            }
        }
    }
}

/**
 * 设备指纹脱敏：仅显示前 8 位，其余用 * 替换。
 */
private fun maskFingerprint(fingerprint: String): String {
    if (fingerprint.length <= 8) return fingerprint
    return fingerprint.take(8) + "*".repeat(8)
}

/**
 * 格式化注册时间字符串（ISO 8601）为可读形式。
 * 解析失败时返回原字符串。
 */
private fun formatCreatedAt(createdAt: String): String {
    return try {
        // 简单截取日期时间部分（YYYY-MM-DDTHH:MM:SS -> YYYY-MM-DD HH:MM:SS）
        val tIndex = createdAt.indexOf('T')
        if (tIndex > 0) {
            val date = createdAt.substring(0, tIndex)
            val timePart = createdAt.substring(tIndex + 1)
            // 截取到秒，去除时区后缀
            val time = timePart.take(8)
            "$date $time"
        } else {
            createdAt
        }
    } catch (e: Exception) {
        createdAt
    }
}
