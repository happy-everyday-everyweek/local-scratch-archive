package com.appmarket.blog.data.repository

import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.Article
import com.appmarket.blog.data.model.FeedCard
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.functions.functions
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * 信息流分页结果。
 *
 * @property cards 当前页的卡片列表
 * @property hasMore 是否还有更多页可加载
 */
data class FeedPage(
    val cards: List<FeedCard>,
    val hasMore: Boolean,
)

/**
 * 信息流 Repository，负责从 get-feed Edge Function 获取混排卡片。
 *
 * 调用 get-feed Edge Function（由 Task 15 实现服务端逻辑），
 * 返回按推荐算法混排的 FeedCard 列表。
 *
 * 安全说明：仅持有 Publishable key，device_token 由 AuthInterceptor
 * 自动附加到请求 header，服务端通过 RLS 鉴权。
 *
 * 当 Edge Function 不可用时，回退到直接查询 apps 表（仅展示已通过的应用），
 * 保证首页在 Edge Function 部署前仍可正常显示内容。
 *
 * 通过 AppModule 的 @Provides @Singleton 提供单例绑定（Hilt 注入）。
 */
class FeedRepository(
    private val supabaseClient: SupabaseClient,
) {

    /**
     * JSON 解析器，忽略未知字段以兼容服务端字段扩展。
     */
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 获取信息流分页数据。
     *
     * 调用 get-feed Edge Function，返回混排的 FeedCard 列表。
     * Edge Function 不可用时回退到直接查询 apps 表。
     *
     * @param page 页码，从 0 开始
     * @param pageSize 每页卡片数量
     * @return 成功返回 FeedPage，失败返回异常
     */
    suspend fun getFeed(page: Int, pageSize: Int): Result<FeedPage> {
        return try {
            val response: HttpResponse = supabaseClient.functions.invoke(
                function = "get-feed",
                body = FeedRequest(page = page, pageSize = pageSize),
                headers = Headers.build {
                    append(HttpHeaders.ContentType, "application/json")
                },
            )

            val bodyText = response.bodyAsText()

            if (response.status.value !in 200..299) {
                // Edge Function 返回错误，回退到直接查询
                return fallbackFromApps(page, pageSize)
            }

            val result = json.decodeFromString<FeedResponseDto>(bodyText)
            val cards = result.cards.mapNotNull { it.toFeedCard() }
            Result.success(FeedPage(cards = cards, hasMore = result.hasMore))
        } catch (_: Exception) {
            // Edge Function 不可用或网络异常，回退到直接查询 apps 表
            fallbackFromApps(page, pageSize)
        }
    }

    /**
     * 回退方案：直接查询 apps 表获取已通过的应用列表。
     *
     * 当 get-feed Edge Function 不可用时使用，仅返回 FeedCard.SingleApp
     * 类型的卡片，按创建时间降序排列。
     *
     * @param page 页码，从 0 开始
     * @param pageSize 每页数量
     * @return 成功返回 FeedPage，失败返回异常
     */
    private suspend fun fallbackFromApps(page: Int, pageSize: Int): Result<FeedPage> {
        return try {
            val from = (page * pageSize).toLong()
            val to = from + pageSize - 1
            val result = supabaseClient.postgrest.from("apps").select {
                filter { eq("status", "approved") }
                order("created_at", Order.DESCENDING)
                range(from, to)
            }
            val apps = result.decodeList<App>()
            val cards = apps.map { FeedCard.SingleApp(it) }
            Result.success(FeedPage(cards = cards, hasMore = apps.size >= pageSize))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/**
 * get-feed Edge Function 的请求体。
 *
 * @property page 页码，从 0 开始
 * @property pageSize 每页卡片数量
 */
@Serializable
private data class FeedRequest(
    @SerialName("page") val page: Int,
    @SerialName("page_size") val pageSize: Int,
)

/**
 * get-feed Edge Function 的响应体。
 *
 * @property cards 卡片列表
 * @property hasMore 是否还有更多页
 */
@Serializable
private data class FeedResponseDto(
    @SerialName("cards") val cards: List<FeedCardDto> = emptyList(),
    @SerialName("has_more") val hasMore: Boolean = false,
)

/**
 * get-feed Edge Function 返回的单个卡片 DTO。
 *
 * 根据 type 字段映射到对应的 FeedCard 子类。
 *
 * @property type 卡片类型（single_app / multi_app / theme / article / recommend）
 * @property app 单应用卡片时的应用数据
 * @property apps 多应用/推荐卡片时的应用列表
 * @property title 多应用卡片的标题
 * @property article 主题/文章/推荐卡片时的文章数据
 */
@Serializable
private data class FeedCardDto(
    @SerialName("type") val type: String = "",
    @SerialName("app") val app: App? = null,
    @SerialName("apps") val apps: List<App> = emptyList(),
    @SerialName("title") val title: String? = null,
    @SerialName("article") val article: Article? = null,
) {
    /**
     * 将 DTO 映射为 FeedCard，无法识别的类型返回 null。
     */
    fun toFeedCard(): FeedCard? = when (type) {
        "single_app" -> app?.let { FeedCard.SingleApp(it) }
        "multi_app" -> FeedCard.MultiApp(title ?: "推荐", apps)
        "theme" -> article?.let { FeedCard.Theme(it) }
        "article" -> article?.let { FeedCard.Article(it) }
        "recommend" -> article?.let { FeedCard.Recommend(it, apps) }
        else -> null
    }
}
