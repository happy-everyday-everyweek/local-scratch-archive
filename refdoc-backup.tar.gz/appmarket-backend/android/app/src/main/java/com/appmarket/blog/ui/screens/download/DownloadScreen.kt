package com.appmarket.blog.ui.screens.download

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/**
 * 下载页面（双弹窗）。
 *
 * 通过 apkId 加载应用信息并启动下载，应用信息就绪后展示 DownloadDialog。
 * 加载中显示进度指示器，加载失败显示错误提示与返回按钮。
 *
 * @param apkId APK ID
 * @param onBack 返回回调（关闭弹窗时调用）
 * @param viewModel 下载 ViewModel（由 Hilt 提供）
 */
@Composable
fun DownloadScreen(
    apkId: String,
    onBack: () -> Unit,
    viewModel: DownloadViewModel = hiltViewModel(),
) {
    val app by viewModel.app.collectAsStateWithLifecycle()
    val isLoadingApp by viewModel.isLoadingApp.collectAsStateWithLifecycle()

    // 进入页面时加载应用信息并启动下载
    LaunchedEffect(apkId) {
        viewModel.load(apkId)
    }

    when {
        // 应用信息加载中
        isLoadingApp && app == null -> {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
        }

        // 应用信息加载失败
        app == null -> {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "无法加载应用信息",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = "请检查网络后重试",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
                Button(
                    onClick = onBack,
                    modifier = Modifier.padding(top = 24.dp),
                ) {
                    Text(text = "返回")
                }
            }
        }

        // 应用信息就绪，展示下载弹窗
        else -> {
            DownloadDialog(
                app = app!!,
                apkId = apkId,
                onDismiss = onBack,
                viewModel = viewModel,
            )
        }
    }
}
