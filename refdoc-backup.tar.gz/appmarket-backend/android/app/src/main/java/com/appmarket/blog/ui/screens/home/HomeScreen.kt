package com.appmarket.blog.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshContainer
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.appmarket.blog.data.model.FeedCard
import com.appmarket.blog.data.repository.FeedRepository
import com.appmarket.blog.ui.components.feed.ArticleCard
import com.appmarket.blog.ui.components.feed.MultiAppCard
import com.appmarket.blog.ui.components.feed.RecommendCard
import com.appmarket.blog.ui.components.feed.SingleAppCard
import com.appmarket.blog.ui.components.feed.ThemeCard
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 首页信息流 ViewModel。
 *
 * 职责：
 * - 通过 FeedRepository 分页加载信息流卡片
 * - 支持下拉刷新与滚动到底部自动加载下一页
 * - 管理 loading / empty / error 状态
 *
 * 通过 Hilt 注入 FeedRepository（单例）。
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val feedRepository: FeedRepository,
) : ViewModel() {

    companion object {
        /** 每页卡片数量 */
        private const val PAGE_SIZE = 10
    }

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState = _uiState.asStateFlow()

    init {
        loadInitial()
    }

    /**
     * 首次加载信息流。
     *
     * 仅在卡片列表为空且未在加载中时执行。
     */
    fun loadInitial() {
        val state = _uiState.value
        if (state.cards.isNotEmpty() || state.isLoading) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val result = feedRepository.getFeed(page = 0, pageSize = PAGE_SIZE)
            result.onSuccess { feedPage ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        cards = feedPage.cards,
                        page = 0,
                        hasMore = feedPage.hasMore,
                        error = null,
                    )
                }
            }.onFailure { e ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message ?: "加载失败",
                    )
                }
            }
        }
    }

    /**
     * 下拉刷新。
     *
     * 重新加载第一页数据，替换当前卡片列表。
     */
    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshing = true, error = null) }
            val result = feedRepository.getFeed(page = 0, pageSize = PAGE_SIZE)
            result.onSuccess { feedPage ->
                _uiState.update {
                    it.copy(
                        isRefreshing = false,
                        cards = feedPage.cards,
                        page = 0,
                        hasMore = feedPage.hasMore,
                        error = null,
                    )
                }
            }.onFailure { e ->
                _uiState.update {
                    it.copy(
                        isRefreshing = false,
                        error = e.message ?: "刷新失败",
                    )
                }
            }
        }
    }

    /**
     * 加载下一页。
     *
     * 在以下情况跳过：正在加载更多、没有更多页、正在首次加载或刷新。
     */
    fun loadMore() {
        val state = _uiState.value
        if (state.isLoadingMore || !state.hasMore || state.isLoading || state.isRefreshing) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingMore = true) }
            val nextPage = state.page + 1
            val result = feedRepository.getFeed(page = nextPage, pageSize = PAGE_SIZE)
            result.onSuccess { feedPage ->
                _uiState.update {
                    it.copy(
                        isLoadingMore = false,
                        cards = it.cards + feedPage.cards,
                        page = nextPage,
                        hasMore = feedPage.hasMore,
                        error = null,
                    )
                }
            }.onFailure { e ->
                _uiState.update {
                    it.copy(
                        isLoadingMore = false,
                        error = e.message ?: "加载更多失败",
                    )
                }
            }
        }
    }
}

/**
 * 信息流首页。
 *
 * Apple Today 风格黑白主题卡片布局，使用 LazyColumn 展示混排卡片。
 * 支持下拉刷新、滚动到底部自动加载下一页、加载中/空状态/错误状态处理。
 *
 * @param onAppClick 应用点击回调，参数为应用 ID（跳转应用详情）
 * @param onArticleClick 文章点击回调，参数为文章 ID（跳转文章详情）
 * @param onThemeClick 主题点击回调，参数为主题文章 ID（跳转主题详情）
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onAppClick: (String) -> Unit,
    onArticleClick: (String) -> Unit = {},
    onThemeClick: (String) -> Unit = {},
) {
    val viewModel: HomeViewModel = hiltViewModel()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    val listState = rememberLazyListState()
    val pullToRefreshState = rememberPullToRefreshState()

    // 用户下拉触发刷新
    LaunchedEffect(pullToRefreshState.isRefreshing) {
        if (pullToRefreshState.isRefreshing) {
            viewModel.refresh()
        }
    }

    // 刷新完成后结束下拉刷新动画
    LaunchedEffect(uiState.isRefreshing) {
        if (!uiState.isRefreshing && pullToRefreshState.isRefreshing) {
            pullToRefreshState.endRefresh()
        }
    }

    // 滚动到底部自动加载下一页
    LaunchedEffect(listState, uiState.hasMore) {
        snapshotFlow {
            val lastVisibleIndex = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val totalItems = listState.layoutInfo.totalItemsCount
            totalItems > 0 && lastVisibleIndex >= totalItems - 2
        }
            .distinctUntilChanged()
            .filter { it }
            .collect {
                viewModel.loadMore()
            }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
    ) {
        // 顶部标题
        Text(
            text = "应用市场",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        )

        // 下拉刷新 + 内容区域
        Box(
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(pullToRefreshState.nestedScrollConnection),
        ) {
            when {
                // 首次加载中
                uiState.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator()
                    }
                }

                // 错误状态（无卡片时）
                uiState.error != null && uiState.cards.isEmpty() -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Text(
                            text = uiState.error!!,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { viewModel.loadInitial() }) {
                            Text(text = "重试")
                        }
                    }
                }

                // 空状态
                uiState.cards.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "暂无内容",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                    }
                }

                // 正常内容
                else -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        items(uiState.cards) { card ->
                            when (card) {
                                is FeedCard.SingleApp -> SingleAppCard(
                                    card = card,
                                    onAppClick = onAppClick,
                                )

                                is FeedCard.MultiApp -> MultiAppCard(
                                    card = card,
                                    onAppClick = onAppClick,
                                )

                                is FeedCard.Theme -> ThemeCard(
                                    card = card,
                                    onClick = { onThemeClick(card.article.id) },
                                )

                                is FeedCard.Article -> ArticleCard(
                                    card = card,
                                    onClick = { onArticleClick(card.article.id) },
                                )

                                is FeedCard.Recommend -> RecommendCard(
                                    card = card,
                                    onAppClick = onAppClick,
                                    onInstallClick = onAppClick,
                                )
                            }
                        }

                        // 加载更多指示器
                        if (uiState.isLoadingMore) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    CircularProgressIndicator()
                                }
                            }
                        }

                        // 加载更多失败时的重试
                        if (uiState.error != null && uiState.cards.isNotEmpty() && !uiState.isLoadingMore) {
                            item {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Text(
                                        text = uiState.error!!,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(onClick = { viewModel.loadMore() }) {
                                        Text(text = "重试")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 下拉刷新指示器
            PullToRefreshContainer(
                state = pullToRefreshState,
                modifier = Modifier.align(Alignment.TopCenter),
            )
        }
    }
}
