package com.appmarket.blog.data.download

import android.net.Uri

/**
 * 下载状态密封类。
 *
 * 通过 StateFlow 暴露给 UI 层，UI 根据当前状态渲染下载界面。
 */
sealed class DownloadState {

    /** 空闲状态，尚未开始下载。 */
    object Idle : DownloadState()

    /** 正在测速选择镜像站。 */
    object Testing : DownloadState()

    /**
     * 正在下载。
     *
     * @property progress 下载进度百分比（0-100）
     * @property speed 当前下载速度（字节/秒）
     * @property eta 预计剩余时间（秒）
     * @property currentMirror 当前下载源镜像站名称
     */
    data class Downloading(
        val progress: Int,
        val speed: Long,
        val eta: Long,
        val currentMirror: String,
    ) : DownloadState()

    /**
     * 正在切换镜像站。
     *
     * @property fromMirror 原镜像站名称
     * @property toMirror 目标镜像站名称
     * @property reason 切换原因
     */
    data class SwitchingMirror(
        val fromMirror: String,
        val toMirror: String,
        val reason: String,
    ) : DownloadState()

    /**
     * 下载完成。
     *
     * @property fileUri 下载完成的 APK 文件 URI（FileProvider 提供）
     */
    data class Completed(val fileUri: Uri) : DownloadState()

    /**
     * 下载失败。
     *
     * @property error 错误信息
     */
    data class Failed(val error: String) : DownloadState()
}

/**
 * 下载日志类型。
 *
 * @property value 日志类型字符串值
 */
enum class DownloadLogType(val value: String) {
    /** 信息 */
    INFO("info"),

    /** 警告 */
    WARNING("warning"),

    /** 错误 */
    ERROR("error"),
}

/**
 * 下载日志条目。
 *
 * @property timestamp 时间戳字符串（HH:mm:ss 格式）
 * @property message 日志内容
 * @property type 日志类型
 */
data class DownloadLog(
    val timestamp: String,
    val message: String,
    val type: DownloadLogType,
)
