package com.appmarket.blog.ui.screens.home

import com.appmarket.blog.data.model.FeedCard

/**
 * 首页信息流 UI 状态。
 *
 * @property isLoading 是否正在加载首页（首次加载）
 * @property isRefreshing 是否正在下拉刷新
 * @property isLoadingMore 是否正在加载下一页
 * @property cards 当前已加载的卡片列表
 * @property page 当前已加载的页码（从 0 开始）
 * @property hasMore 是否还有更多页可加载
 * @property error 错误信息，非 null 表示当前存在错误
 */
data class HomeUiState(
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val isLoadingMore: Boolean = false,
    val cards: List<FeedCard> = emptyList(),
    val page: Int = 0,
    val hasMore: Boolean = true,
    val error: String? = null,
) {
    /**
     * 是否为空状态（无卡片且不在加载中）。
     */
    val isEmpty: Boolean
        get() = cards.isEmpty() && !isLoading && !isRefreshing
}
