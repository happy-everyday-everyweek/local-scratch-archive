package com.appmarket.blog.ui.screens.publish

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.ArticleType
import com.appmarket.blog.data.model.Role
import com.appmarket.blog.data.repository.AuthRepository
import com.appmarket.blog.data.repository.ContentRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 发布内容页面 ViewModel，管理发布表单状态与提交逻辑。
 *
 * 仅 role in (ADMIN, OWNER) 可见发布功能。发布调用 publish-content Edge Function，
 * 服务端会再次校验调用者角色，即使非 ADMIN/OWNER 直接进入也会被拒绝。
 *
 * 通过 Hilt 注入 AuthRepository（读取当前角色）与 ContentRepository
 * （发布内容、查询已审核应用列表）。
 */
@HiltViewModel
class PublishViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val contentRepository: ContentRepository,
) : ViewModel() {

    /**
     * UI 状态。
     *
     * @property role 当前用户角色，未登录为 null
     * @property selectedType 当前选中的文章类型
     * @property title 标题输入
     * @property cover 封面图 URL 输入（可选）
     * @property content 正文输入（多行 Markdown）
     * @property tagsInput 标签输入（逗号分隔）
     * @property approvedApps 已审核应用列表（用于关联应用选择）
     * @property appsLoaded 已审核应用列表是否已加载
     * @property selectedAppIds 已选中的关联应用 ID 集合
     * @property publishing 是否正在发布
     * @property errorMessage 错误信息（非 null 表示失败）
     * @property publishSuccess 是否发布成功（触发返回上一页）
     */
    data class UiState(
        val role: Role? = null,
        val selectedType: ArticleType = ArticleType.ARTICLE,
        val title: String = "",
        val cover: String = "",
        val content: String = "",
        val tagsInput: String = "",
        val approvedApps: List<App> = emptyList(),
        val appsLoaded: Boolean = false,
        val selectedAppIds: Set<String> = emptySet(),
        val publishing: Boolean = false,
        val errorMessage: String? = null,
        val publishSuccess: Boolean = false,
    ) {
        /** 是否允许发布 */
        val canPublish: Boolean
            get() {
                if (publishing) return false
                if (title.isBlank()) return false
                return when (selectedType) {
                    ArticleType.ARTICLE -> true
                    ArticleType.RECOMMEND, ArticleType.THEME -> selectedAppIds.isNotEmpty()
                }
            }

        /** 当前用户是否有发布权限（仅 ADMIN/OWNER） */
        val canAccess: Boolean
            get() = role == Role.ADMIN || role == Role.OWNER
    }

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        // 读取当前用户角色
        _uiState.update { it.copy(role = Role.fromValue(authRepository.getRole())) }
        // 加载已审核应用列表（用于关联应用选择）
        loadApprovedApps()
    }

    /**
     * 加载已审核应用列表。
     */
    private fun loadApprovedApps() {
        viewModelScope.launch {
            val apps = contentRepository.getApprovedApps()
            _uiState.update { it.copy(approvedApps = apps, appsLoaded = true) }
        }
    }

    /** 选择文章类型。切换类型时清除关联应用选择与错误。 */
    fun selectType(type: ArticleType) {
        _uiState.update {
            it.copy(
                selectedType = type,
                // 切换到文章类型时清空关联应用（文章不关联应用）
                selectedAppIds = if (type == ArticleType.ARTICLE) emptySet() else it.selectedAppIds,
                errorMessage = null,
            )
        }
    }

    /** 更新标题输入。 */
    fun updateTitle(value: String) {
        _uiState.update { it.copy(title = value, errorMessage = null) }
    }

    /** 更新封面图 URL 输入。 */
    fun updateCover(value: String) {
        _uiState.update { it.copy(cover = value) }
    }

    /** 更新正文输入。 */
    fun updateContent(value: String) {
        _uiState.update { it.copy(content = value) }
    }

    /** 更新标签输入（逗号分隔）。 */
    fun updateTags(value: String) {
        _uiState.update { it.copy(tagsInput = value) }
    }

    /** 切换某个应用的选中状态。 */
    fun toggleApp(appId: String) {
        _uiState.update { state ->
            val newSet = if (appId in state.selectedAppIds) {
                state.selectedAppIds - appId
            } else {
                state.selectedAppIds + appId
            }
            state.copy(selectedAppIds = newSet, errorMessage = null)
        }
    }

    /**
     * 发布内容。调用 publish-content Edge Function。
     */
    fun publish() {
        val state = _uiState.value
        if (!state.canPublish) return

        // 解析标签（逗号分隔）
        val tags = state.tagsInput
            .split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        // 封面 URL 为空时传 null
        val cover = state.cover.trim().ifBlank { null }

        // 关联应用 ID 列表（文章类型为空数组）
        val appIds = when (state.selectedType) {
            ArticleType.ARTICLE -> emptyList()
            ArticleType.RECOMMEND, ArticleType.THEME -> state.selectedAppIds.toList()
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(publishing = true, errorMessage = null, publishSuccess = false)
            }

            val result = contentRepository.publishContent(
                type = state.selectedType.value,
                title = state.title.trim(),
                cover = cover,
                content = state.content,
                appIds = appIds,
                tags = tags,
            )

            result.onSuccess {
                _uiState.update {
                    it.copy(publishing = false, publishSuccess = true)
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        publishing = false,
                        errorMessage = error.message ?: "发布失败",
                    )
                }
            }
        }
    }
}

/**
 * 发布内容页面。
 *
 * 仅 ADMIN/OWNER 可见发布表单，其他角色显示无权限提示。
 * 表单字段：类型选择（文章 / 推荐 / 主题）、标题、封面 URL、正文、
 * 关联应用选择（推荐 / 主题类型显示）、标签（逗号分隔）。
 * 发布成功后通过 Snackbar 提示并返回上一页。
 *
 * 黑白主题，Material 3 风格。
 *
 * @param onBack 返回上一页回调
 * @param viewModel 发布页面 ViewModel
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublishScreen(
    onBack: () -> Unit,
    viewModel: PublishViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showAppPicker by remember { mutableStateOf(false) }

    // 发布成功：提示后返回上一页
    LaunchedEffect(uiState.publishSuccess) {
        if (uiState.publishSuccess) {
            snackbarHostState.showSnackbar("发布成功")
            onBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("发布内容") },
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Text("返回")
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    ) { innerPadding ->
        if (!uiState.canAccess) {
            // 非管理员/站长无发布权限
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(32.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "无发布权限，仅管理员或站长可发布内容",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // 类型选择
            Text(
                text = "类型",
                style = MaterialTheme.typography.titleMedium,
            )
            TypeSelector(
                selectedType = uiState.selectedType,
                onSelect = viewModel::selectType,
                enabled = !uiState.publishing,
            )

            // 标题输入框
            OutlinedTextField(
                value = uiState.title,
                onValueChange = viewModel::updateTitle,
                label = { Text("标题") },
                singleLine = true,
                enabled = !uiState.publishing,
                modifier = Modifier.fillMaxWidth(),
            )

            // 封面图 URL 输入框（可选）
            OutlinedTextField(
                value = uiState.cover,
                onValueChange = viewModel::updateCover,
                label = { Text("封面图 URL（可选）") },
                singleLine = true,
                enabled = !uiState.publishing,
                modifier = Modifier.fillMaxWidth(),
            )

            // 正文输入框（多行，支持 Markdown）
            OutlinedTextField(
                value = uiState.content,
                onValueChange = viewModel::updateContent,
                label = { Text("正文（支持 Markdown）") },
                enabled = !uiState.publishing,
                minLines = 5,
                maxLines = 12,
                modifier = Modifier.fillMaxWidth(),
            )

            // 关联应用选择（推荐 / 主题类型显示）
            if (uiState.selectedType == ArticleType.RECOMMEND ||
                uiState.selectedType == ArticleType.THEME
            ) {
                AppSelectionSection(
                    approvedApps = uiState.approvedApps,
                    selectedAppIds = uiState.selectedAppIds,
                    appsLoaded = uiState.appsLoaded,
                    enabled = !uiState.publishing,
                    onOpenPicker = { showAppPicker = true },
                    onToggle = viewModel::toggleApp,
                )
            }

            // 标签输入框（逗号分隔）
            OutlinedTextField(
                value = uiState.tagsInput,
                onValueChange = viewModel::updateTags,
                label = { Text("标签（逗号分隔）") },
                singleLine = true,
                enabled = !uiState.publishing,
                modifier = Modifier.fillMaxWidth(),
            )

            // 错误信息
            uiState.errorMessage?.let { message ->
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            // 发布按钮
            Button(
                onClick = viewModel::publish,
                enabled = uiState.canPublish,
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (uiState.publishing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("发布中")
                } else {
                    Text("发布")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }

    // 关联应用选择弹窗
    if (showAppPicker) {
        AppPickerDialog(
            apps = uiState.approvedApps,
            selectedAppIds = uiState.selectedAppIds,
            onToggle = viewModel::toggleApp,
            onDismiss = { showAppPicker = false },
        )
    }
}

/**
 * 类型选择器，使用 RadioGroup 实现。
 */
@Composable
private fun TypeSelector(
    selectedType: ArticleType,
    onSelect: (ArticleType) -> Unit,
    enabled: Boolean,
) {
    val types = listOf(
        ArticleType.ARTICLE to "文章",
        ArticleType.RECOMMEND to "推荐",
        ArticleType.THEME to "主题",
    )

    Column {
        types.forEach { (type, label) ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
            ) {
                RadioButton(
                    selected = selectedType == type,
                    onClick = { onSelect(type) },
                    enabled = enabled,
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}

/**
 * 关联应用选择区域。
 *
 * 显示已选中的应用数量，点击按钮打开选择弹窗，
 * 并以列表形式展示已选中的应用（图标 + 名称，可取消选择）。
 */
@Composable
private fun AppSelectionSection(
    approvedApps: List<App>,
    selectedAppIds: Set<String>,
    appsLoaded: Boolean,
    enabled: Boolean,
    onOpenPicker: () -> Unit,
    onToggle: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "关联应用",
            style = MaterialTheme.typography.titleMedium,
        )

        if (!appsLoaded) {
            Text(
                text = "正在加载应用列表...",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else if (approvedApps.isEmpty()) {
            Text(
                text = "暂无可关联的已审核应用",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        OutlinedButton(
            onClick = onOpenPicker,
            enabled = enabled && approvedApps.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("选择关联应用（已选 ${selectedAppIds.size} 个）")
        }

        // 已选中的应用列表
        val selectedApps = approvedApps.filter { it.id in selectedAppIds }
        selectedApps.forEach { app ->
            SelectedAppRow(
                app = app,
                enabled = enabled,
                onRemove = { onToggle(app.id) },
            )
        }
    }
}

/**
 * 已选中的应用行，显示图标与名称，点击可取消选择。
 */
@Composable
private fun SelectedAppRow(
    app: App,
    enabled: Boolean,
    onRemove: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onRemove),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AppIcon(iconUrl = app.iconUrl, appName = app.name, size = 40.dp)
            Text(
                text = app.name,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onRemove, enabled = enabled) {
                Text("移除")
            }
        }
    }
}

/**
 * 关联应用选择弹窗，支持多选。
 */
@Composable
private fun AppPickerDialog(
    apps: List<App>,
    selectedAppIds: Set<String>,
    onToggle: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("选择关联应用") },
        text = {
            if (apps.isEmpty()) {
                Text("暂无可关联的应用")
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp),
                ) {
                    items(apps) { app ->
                        val checked = app.id in selectedAppIds
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggle(app.id) }
                                .padding(vertical = 4.dp),
                        ) {
                            AppIcon(iconUrl = app.iconUrl, appName = app.name, size = 40.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = app.name,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            androidx.compose.material3.Checkbox(
                                checked = checked,
                                onCheckedChange = { onToggle(app.id) },
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("完成")
            }
        },
    )
}

/**
 * 应用图标组件。有 URL 时加载网络图片，否则显示应用名首字母占位。
 */
@Composable
private fun AppIcon(
    iconUrl: String?,
    appName: String,
    size: androidx.compose.ui.unit.Dp,
) {
    val cornerRadius = size / 4
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (!iconUrl.isNullOrBlank()) {
            AsyncImage(
                model = iconUrl,
                contentDescription = appName,
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(cornerRadius)),
                contentScale = ContentScale.Crop,
            )
        } else {
            Text(
                text = appName.firstOrNull()?.uppercase() ?: "?",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}
