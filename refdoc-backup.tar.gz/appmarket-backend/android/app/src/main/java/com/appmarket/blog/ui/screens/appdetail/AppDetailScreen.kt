package com.appmarket.blog.ui.screens.appdetail

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.appmarket.blog.data.model.App
import com.appmarket.blog.data.model.AppApk
import com.appmarket.blog.data.model.AppCategory
import com.appmarket.blog.data.model.Article
import com.appmarket.blog.data.model.toFormattedSize
import com.appmarket.blog.data.repository.AppDetailRepository
import com.appmarket.blog.ui.components.ApkVersionPickerDialog
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 应用详情页 ViewModel。
 *
 * 职责：
 * - 通过 AppDetailRepository 加载应用信息、APK 列表与关联文章
 * - 加载完成后记录浏览历史到 view_history 表
 * - 管理 loading / error 状态
 *
 * 通过 Hilt 注入 AppDetailRepository（单例）。
 */
@HiltViewModel
class AppDetailViewModel @Inject constructor(
    private val appDetailRepository: AppDetailRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(AppDetailUiState())
    val uiState = _uiState.asStateFlow()

    /** 当前已加载的应用 ID，避免重复加载。 */
    private var currentAppId: String? = null

    /**
     * 加载应用详情。
     *
     * 同一 appId 仅加载一次，避免重复请求。
     *
     * @param appId 应用 UUID
     */
    fun load(appId: String) {
        if (appId == currentAppId) return
        currentAppId = appId
        loadData(appId)
    }

    /**
     * 重试加载。
     *
     * 在加载失败后由用户触发，重新请求当前应用的数据。
     */
    fun retry() {
        val appId = currentAppId ?: return
        loadData(appId)
    }

    /**
     * 实际加载应用详情、APK 列表与关联文章，并记录浏览历史。
     */
    private fun loadData(appId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val app = appDetailRepository.getApp(appId)
                if (app == null) {
                    _uiState.update {
                        it.copy(isLoading = false, error = "应用不存在或加载失败")
                    }
                    return@launch
                }
                val apks = appDetailRepository.getApks(appId)
                val articles = appDetailRepository.getRelatedArticles(appId)
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        app = app,
                        apks = apks,
                        articles = articles,
                        error = null,
                    )
                }
                // 记录浏览历史（静默失败不影响正常使用）
                appDetailRepository.recordView(appId)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isLoading = false, error = e.message ?: "加载失败")
                }
            }
        }
    }
}

/**
 * 应用详情页。
 *
 * 黑白主题，Material 3 风格。包含两个 Tab：
 * - 简介：应用图标、名称、版本、分类、大小、截图轮播、描述、下载按钮
 * - 教程与活动：展示关联的博客文章列表
 *
 * 浏览时自动记录到 view_history 表。
 *
 * @param appId 应用 UUID
 * @param onDownloadClick 下载点击回调，参数为 APK ID（跳转下载页）
 * @param onBack 返回回调
 * @param onArticleClick 文章点击回调，参数为文章 ID（跳转文章详情）
 * @param viewModel 详情页 ViewModel（由 Hilt 提供）
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDetailScreen(
    appId: String,
    onDownloadClick: (String) -> Unit,
    onBack: () -> Unit = {},
    onArticleClick: (String) -> Unit = {},
    viewModel: AppDetailViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableIntStateOf(0) }
    var showApkPicker by remember { mutableStateOf(false) }

    // 进入页面时加载数据
    LaunchedEffect(appId) {
        viewModel.load(appId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = uiState.app?.name ?: "应用详情",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "返回",
                        )
                    }
                },
            )
        },
    ) { padding ->
        when {
            // 加载中
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
            }

            // 错误状态
            uiState.error != null -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = uiState.error!!,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { viewModel.retry() }) {
                        Text(text = "重试")
                    }
                }
            }

            // 正常内容
            uiState.app != null -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                ) {
                    TabRow(selectedTabIndex = selectedTab) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text(text = "简介") },
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text(text = "教程与活动") },
                        )
                    }
                    when (selectedTab) {
                        0 -> IntroTab(
                            app = uiState.app!!,
                            apks = uiState.apks,
                            onDownloadClick = {
                                val apkList = uiState.apks
                                if (apkList.size <= 1) {
                                    apkList.firstOrNull()?.let { onDownloadClick(it.id) }
                                } else {
                                    showApkPicker = true
                                }
                            },
                        )
                        1 -> ArticlesTab(
                            articles = uiState.articles,
                            onArticleClick = onArticleClick,
                        )
                    }
                }
            }
        }
    }

    // 多 APK 选择弹窗
    if (showApkPicker && uiState.apks.size > 1) {
        ApkVersionPickerDialog(
            apks = uiState.apks,
            onSelect = { apk ->
                showApkPicker = false
                onDownloadClick(apk.id)
            },
            onDismiss = { showApkPicker = false },
        )
    }
}

// =========================================================================
// 简介 Tab
// =========================================================================

/**
 * 简介 Tab 内容。
 *
 * 展示应用图标、名称、版本、分类、大小、截图轮播、描述与下载按钮。
 */
@Composable
private fun IntroTab(
    app: App,
    apks: List<AppApk>,
    onDownloadClick: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // 应用图标与基本信息
        item { AppHeader(app = app, apks = apks) }

        // 下载按钮
        item { DownloadButton(apks = apks, onClick = onDownloadClick) }

        // 截图轮播
        if (!app.screenshots.isNullOrEmpty()) {
            item { ScreenshotsSection(screenshots = app.screenshots!!) }
        }

        // 应用描述
        item { DescriptionSection(description = app.description) }
    }
}

/**
 * 应用头部：图标、名称、版本、分类标签、APK 大小。
 */
@Composable
private fun AppHeader(
    app: App,
    apks: List<AppApk>,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // 应用图标（大图，使用 Coil 加载）
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center,
        ) {
            if (!app.iconUrl.isNullOrBlank()) {
                AsyncImage(
                    model = app.iconUrl,
                    contentDescription = app.name,
                    modifier = Modifier
                        .size(96.dp)
                        .clip(RoundedCornerShape(24.dp)),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Text(
                    text = app.name.firstOrNull()?.uppercase() ?: "?",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // 名称、版本、分类、大小
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text = app.name,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )

            // 版本号
            app.latestVersion?.takeIf { it.isNotBlank() }?.let { version ->
                Text(
                    text = "版本 $version",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            // 分类标签
            CategoryTag(category = app.category)

            // APK 大小（取最新一条）
            apks.firstOrNull()?.let { apk ->
                Text(
                    text = "大小 ${apk.size.toFormattedSize()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/**
 * 分类标签（开源/正版/自然），黑白配色。
 */
@Composable
private fun CategoryTag(category: AppCategory) {
    val label = when (category) {
        AppCategory.OPENSOURCE -> "开源"
        AppCategory.GENUINE -> "正版"
        AppCategory.NATURAL -> "自然"
    }
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.onBackground,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
        )
    }
}

/**
 * 下载按钮。
 *
 * 无 APK 时禁用并提示；单个 APK 时直接下载；多个 APK 时提示选择版本。
 */
@Composable
private fun DownloadButton(
    apks: List<AppApk>,
    onClick: () -> Unit,
) {
    val enabled = apks.isNotEmpty()
    val text = when {
        apks.isEmpty() -> "暂无可下载的 APK"
        apks.size == 1 -> "下载"
        else -> "下载（选择版本）"
    }
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(text = text)
    }
}

/**
 * 截图轮播，横向滚动。
 */
@Composable
private fun ScreenshotsSection(screenshots: List<String>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "截图",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(screenshots) { screenshot ->
                AsyncImage(
                    model = screenshot,
                    contentDescription = "截图",
                    modifier = Modifier
                        .width(200.dp)
                        .height(360.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop,
                )
            }
        }
    }
}

/**
 * 应用描述区域。
 */
@Composable
private fun DescriptionSection(description: String?) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "应用介绍",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            text = if (description.isNullOrBlank()) "暂无描述" else description,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

// =========================================================================
// 教程与活动 Tab
// =========================================================================

/**
 * 教程与活动 Tab 内容。
 *
 * 展示与当前应用关联的博客文章列表，无文章时显示空状态。
 */
@Composable
private fun ArticlesTab(
    articles: List<Article>,
    onArticleClick: (String) -> Unit,
) {
    if (articles.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = "暂无相关文章",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(articles) { article ->
                ArticleListItem(
                    article = article,
                    onClick = { onArticleClick(article.id) },
                )
            }
        }
    }
}

/**
 * 文章列表项：封面图、标题、摘要、时间。
 */
@Composable
private fun ArticleListItem(
    article: Article,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // 封面图
            if (!article.cover.isNullOrBlank()) {
                AsyncImage(
                    model = article.cover,
                    contentDescription = article.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop,
                )
            }

            // 标题
            Text(
                text = article.title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )

            // 摘要
            val summary = article.content?.take(120)
            if (!summary.isNullOrBlank()) {
                Text(
                    text = summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // 时间
            val date = formatDate(article.createdAt)
            if (date.isNotBlank()) {
                Text(
                    text = date,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/**
 * 将 ISO 时间字符串格式化为日期部分（yyyy-MM-dd）。
 */
private fun formatDate(isoString: String?): String {
    if (isoString.isNullOrBlank()) return ""
    return try {
        isoString.substringBefore("T")
    } catch (_: Exception) {
        ""
    }
}
