package com.appmarket.blog.ui.navigation

/**
 * 应用路由定义。
 */
object Routes {
    const val HOME = "home"
    const val APP_DETAIL = "app_detail/{appId}"
    const val UPLOAD = "upload"
    const val SETTINGS = "settings"
    const val DOWNLOAD = "download/{apkId}"
    const val ADMIN = "admin"
    const val REVIEW = "review"
    const val PUBLISH = "publish"
    const val THEME_DETAIL = "theme/{articleId}"

    fun appDetail(appId: String): String = "app_detail/$appId"
    fun download(apkId: String): String = "download/$apkId"
    fun themeDetail(articleId: String): String = "theme/$articleId"
}
